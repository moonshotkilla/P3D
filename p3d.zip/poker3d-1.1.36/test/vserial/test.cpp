/* (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <vserial/vserial.h>
#include <vserial/scene.h>
#include <vserial/sceneserializer.h>
#include <vserial/mesh.h>
#include <vserial/meshlayer.h>
#include <vserial/meshserializer.h>
#include <vserial/vec3f.h>
#include <iostream>
#include <sstream>

#include <UnitTest++.h>

static std::string srcdir;
static std::string g_umeshFile;

void fetchsrcdir()
{
	char* srcdirPtr = getenv("srcdir");
	if (srcdirPtr)
	{
		//beware "." is always first in PathList
		srcdir = std::string(srcdirPtr) + "/";
		if (srcdir == "./")
			srcdir = "";
	}
}

int main(int argc, char *argv[])
{
  fetchsrcdir();
	return UnitTest::RunAllTests();
}

TEST(VSerialLoadSaveCompare)
{
	underware::Mesh *umesh = NULL;

	CHECK(underware::MeshSerializer::load((srcdir + "test.umesh").c_str(), ".", &umesh));
	CHECK(underware::MeshSerializer::save(*umesh, "tmp.umesh"));

	char cmd[4096];
#ifdef WIN32
	sprintf(cmd, "fc /A /B %s %s", (srcdir + "test.umesh").c_str(), "tmp.umesh");
#else
	sprintf(cmd, "diff %s %s", (srcdir + "test.umesh").c_str(), "tmp.umesh");
#endif
	int sameFile = system(cmd);
	CHECK(!sameFile);
}

TEST(VSerialCreatePointsFromScratchSaveLoadAndTest)
{
	underware::Mesh *mesh = new underware::Mesh();
	CHECK(mesh);

	underware::MeshLayer *ml = mesh->addLayer();
	CHECK(ml);

	underware::Vec3f pnts[4];
	pnts[0].x = -10;	pnts[0].y = -10;	pnts[0].z = 0;
	pnts[1].x =  10;	pnts[1].y = -10;	pnts[1].z = 0;
	pnts[2].x =  10;	pnts[2].y =  10;	pnts[2].z = 0;
	pnts[3].x = -10;	pnts[3].y =  10;	pnts[3].z = 0;
	ml->setPoints(pnts, 4);

	CHECK(underware::MeshSerializer::save(*mesh, "tmp.umesh"));
	delete mesh;

	CHECK(underware::MeshSerializer::load("tmp.umesh", ".", &mesh));
	int nbML = mesh->getNbLayers();
	CHECK_EQUAL(1, nbML);

	ml = mesh->getLayerByIndex(0);
	CHECK(ml);

	int nbPoints = ml->getNbPoints();
	CHECK_EQUAL(4, nbPoints);

	underware::Vec3f *pts = ml->getPoints();
	CHECK(pts);

	CHECK_CLOSE(-10, pts[0].x, 10e-6);	CHECK_CLOSE(-10, pts[0].y, 10e-6);	CHECK_CLOSE(0, pts[0].z, 10e-6);
	CHECK_CLOSE( 10, pts[1].x, 10e-6);	CHECK_CLOSE(-10, pts[1].y, 10e-6);	CHECK_CLOSE(0, pts[1].z, 10e-6);
	CHECK_CLOSE( 10, pts[2].x, 10e-6);	CHECK_CLOSE( 10, pts[2].y, 10e-6);	CHECK_CLOSE(0, pts[2].z, 10e-4);
	CHECK_CLOSE(-10, pts[3].x, 10e-6);	CHECK_CLOSE( 10, pts[3].y, 10e-6);	CHECK_CLOSE(0, pts[3].z, 10e-6);

	delete mesh;
}

TEST(VSerialCreateTriangesListFromScratchSaveLoadAndTest)
{
	underware::Mesh *mesh = new underware::Mesh();
	CHECK(mesh);

	underware::MeshLayer *ml = mesh->addLayer();
	CHECK(ml);

	underware::MeshPrimitivesPacket *pp = ml->addPrimitivesPacket(underware::MESHPRIM_TRIANGLES);
	CHECK(pp);
	unsigned short indices[6] = { 0, 1, 2, 3, 4, 5 };
	pp->setIndexBuffer(indices, 6);

	CHECK(underware::MeshSerializer::save(*mesh, "tmp.umesh"));
	delete mesh;

	CHECK(underware::MeshSerializer::load("tmp.umesh", ".", &mesh));
	int nbML = mesh->getNbLayers();
	CHECK_EQUAL(1, nbML);

	ml = mesh->getLayerByIndex(0);
	CHECK(ml);

	int nbPP = ml->getNbPrimitivesPackets();
	CHECK_EQUAL(nbPP, 1);

	pp = ml->getPrimitivesPacket(0);
	CHECK(pp);

	int nbIndices = pp->getNbIndices();
	CHECK_EQUAL(6, nbIndices);

	unsigned short *indexBuffer = pp->getIndexBuffer();
	CHECK_EQUAL(0, indexBuffer[0]);
	CHECK_EQUAL(1, indexBuffer[1]);
	CHECK_EQUAL(2, indexBuffer[2]);
	CHECK_EQUAL(3, indexBuffer[3]);
	CHECK_EQUAL(4, indexBuffer[4]);
	CHECK_EQUAL(5, indexBuffer[5]);

	delete mesh;
}
