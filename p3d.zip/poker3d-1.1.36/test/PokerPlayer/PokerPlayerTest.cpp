/* (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#undef readObjectFile

#include <UnitTest++.h>
#include <ReportAssert.h>
#include <Python.h>
#include <maf/application.h>
#include <maf/pbuffer.h>
#include <osgCal/Model>
#include <cal3d/model.h>
#include <cal3d/scheduler.h>
#include <CustomAssert/CustomAssert.h>
#include "PokerPlayer.h"
#include "PokerSceneView.h"
#include "PokerNoise.h"
#include <cal3d/corekeyframe.h>
struct PokerApplication : MAFApplication
{
  PokerApplication();
  virtual ~PokerApplication();
};

PokerApplication::PokerApplication()
{
}

PokerApplication::~PokerApplication()
{
}

struct PokerModel
{
  PokerModel();
  virtual ~PokerModel();
};

PokerModel::PokerModel()
{
}

PokerModel::~PokerModel()
{
}

void MAFController::Init()
{
  GetModel()->Init();
}

struct PokerCursor
{
  void ShowCursor(bool state);
  void WarpMouse(int x,int y);
};

void PokerCursor::ShowCursor(bool state)
{
}

void PokerCursor::WarpMouse(int x,int y)
{
}

struct PokerCameraController
{
  PokerCameraController();
  virtual ~PokerCameraController();
};

PokerCameraController::PokerCameraController()
{
}

PokerCameraController::~PokerCameraController()
{
}

struct PokerCameraModel
{
  PokerCameraModel();
  virtual ~PokerCameraModel();
};

PokerCameraModel::PokerCameraModel()
{
}

PokerCameraModel::~PokerCameraModel()
{
}

struct PokerPlayerTimeout
{
  PokerPlayerTimeout(PokerApplication* game, MAFOSGData* seatData, UGAMETimeOut *timeOut);
  void Disable();
  void Start();
  void SetFirstPerson(bool state);
};

PokerPlayerTimeout::PokerPlayerTimeout(PokerApplication* game, MAFOSGData* seatData, UGAMETimeOut *timeOut)
{
}

void PokerPlayerTimeout::Disable()
{
}

void PokerPlayerTimeout::Start()
{
}

void PokerPlayerTimeout::SetFirstPerson(bool state)
{
}

namespace betslider {

	class BetSlider : public osg::Referenced {
	public:
		unsigned int getCurrentValue();
		unsigned int moveCursor(float delta);
	};

	unsigned int BetSlider::getCurrentValue()
	{
		return 0;
	}

	unsigned int BetSlider::moveCursor(float delta)
	{
		return 0;
	}

};

namespace osgchips {
	class ManagedStacks : public osg::Referenced {
	};
};

void PokerChipsStackController::SetChips(const std::vector<int>& chips)
{
}

void PokerChipsStackController::MoveSlider(PokerApplication *, float x, float y)
{
}

void PokerChipsStackController::UninstallSlider(PokerApplication *)
{
}

void PokerChipsStackController::InstallSlider(PokerApplication *)
{
}

PokerChipsStackModel::PokerChipsStackModel(class PokerApplication* game)
{
  SetNode(new osg::Node());
}
PokerChipsStackModel::~PokerChipsStackModel()
{
}

MAFController::~MAFController()
{
}

void MAFCameraController::Init(void)
{
}

bool MAFOSGData::Load(const std::string& path, osgDB::ReaderWriter::Options* options)
{
  return false;
}

osg::Group* MAFOSGData::GetAnchor(const std::string&)
{
  osg::MatrixTransform* parent = new osg::MatrixTransform();
  osg::MatrixTransform* transform = new osg::MatrixTransform();
  parent->addChild(transform);
  osg::MultipleAnimationPathCallback* callback = new osg::MultipleAnimationPathCallback();
  callback->addAnimationPath("dummy", new osg::AnimationPath());
  transform->setUpdateCallback(callback);
  return transform;
}

MAFCameraController* MAFVisionData::GetCamera(const std::string& name)
{
  return NULL;
}

std::string MAFRepositoryData::mLevel;

MAFCameraModel::MAFCameraModel()
{
}

MAFCameraModel::~MAFCameraModel()
{
}

osg::Geode* OSGHelper_getGeodeByName(const osg::Group &_root, const std::string &_name)
{
  osg::Geode* geode = new osg::Geode();
  geode->addDrawable(new osg::Geometry());
  return geode;   
}

osg::Node* OSGHelper_getNodeByName(const osg::Group &_root, const std::string &_name)
{
  return new osg::Node();
}

enum UpdateResult {
  NONE = 0
};

enum CameraState {
  NONE_STATE = 0,
};

struct PokerCameraController;

struct PokerPlayerCamera
{
  PokerPlayerCamera(PokerCameraController* camera, std::map<std::string,std::string>& params);
  ~PokerPlayerCamera();
  UpdateResult Update(SDL_Event* event, float delta, bool focused, bool ignoreEvent, bool wantToForceFreeMode = false);
  CameraState GetCameraState() const;
};

PokerPlayerCamera::PokerPlayerCamera(PokerCameraController* camera, std::map<std::string,std::string>& params)
{
}

PokerPlayerCamera::~PokerPlayerCamera()
{
}

UpdateResult PokerPlayerCamera::Update(SDL_Event* event, float delta, bool focused, bool ignoreEvent, bool wantToForceFreeMode)
{
  return NONE;
}

CameraState PokerPlayerCamera::GetCameraState() const
{
  return NONE_STATE;
}

void PokerChipsStackController::SetBetLimits(int min, int max, int step, int call, int allin, int pot)
{
}

unsigned int PokerChipsStackController::GetBetValue(bool& isCall)
{
  return 0;
}

// struct PokerSceneView
// {
//   PokerSceneView* getInstance();
//   void removeDrawableThatStayInColor(osg::Drawable *_drawable);
//   void addDrawableThatStayInColor(osg::Drawable *_drawable, int _orgRenderBin, int _renderBinToUse, const std::string &_renderName, int _flags);
// };


PokerSceneView* PokerSceneView::getInstance()
{
  return new PokerSceneView(NULL, 0);
}

PokerSceneView::PokerSceneView(PokerApplication*, int)
{
}

PokerSceneView::~PokerSceneView()
{
}

void PokerSceneView::removeDrawableThatStayInColor(osg::Drawable *_drawable)
{
}

void PokerSceneView::addDrawableThatStayInColor(osg::Drawable *_drawable, int _orgRenderBin, int _renderBinToUse, const std::string &_renderName, int _flags)
{
}

void PokerSceneView::Init()
{
}

void PokerSceneView::Update(MAFWindow*)
{
}

void PokerSceneView::setup()
{
}

void PokerSceneView::uninit()
{
}

osg::Texture2D* PokerDeck::GetImage(int index)
{
  return new osg::Texture2D();
}

osg::Matrix MAFComputeLocalToWorld(osg::Node *_src, int _parentValidMask, int _nodeMaskExclude, int _nodeMaskStop)
{
  return osg::Matrix();
}

PokerMoveChipsBase::PokerMoveChipsBase(PokerApplication* game,unsigned int controllerID)
{
}

PokerMoveChipsBase::~PokerMoveChipsBase()
{
}

void PokerMoveChipsBase::Display(bool state)
{
}

bool PokerMoveChipsBase::IsFinished()
{
  return false;
}

PokerMoveChipsBet2PotController::PokerMoveChipsBet2PotController(PokerApplication* game,osg::Node* source,unsigned int controllerID):PokerMoveChipsBase(game, controllerID)
{
}

PokerMoveChipsBet2PotController::~PokerMoveChipsBet2PotController()
{
}

void PokerMoveChipsBet2PotController::ExecuteAtEnd(PokerPlayer* player)
{
}

bool PokerMoveChipsBet2PotController::Update(MAFApplication* application)
{
  return false;
}

PokerMoveChipsPot2PlayerController::~PokerMoveChipsPot2PlayerController()
{
}

void PokerMoveChipsPot2PlayerController::ExecuteAtEnd(PokerPlayer* player)
{
}

bool PokerMoveChipsPot2PlayerController::Update(MAFApplication*)
{
  return false;
}

struct PokerFoldAnimation 
{
  PokerFoldAnimation(PokerApplication* game,MAFOSGData* seat);
  void StartSequence();
  void ShowCard(int i);
  void Update(const double dt);
};

PokerFoldAnimation::PokerFoldAnimation(PokerApplication* game,MAFOSGData* seat) 
{
}

void PokerFoldAnimation::StartSequence()
{
}

void PokerFoldAnimation::ShowCard(int i)
{
}

void PokerFoldAnimation::Update(const double dt)
{
}

void MAFAudioSourceController::Init()
{
}

void MAFAudioSourceController::AttachTo( osg::Group* group )
{
}

void MAFAudioSourceController::Enable()
{
}

void MAFAudioSourceController::Disable()
{
}

MAFAudioSourceModel::MAFAudioSourceModel()
{
}

void MAFAudioSourceModel::Play(const std::string& name)
{
}

void MAFAudioSourceModel::Stop()
{
}

osgText::Font* MAFLoadFont(const std::string &_filename)
{
  return NULL;
}


UGAMEShadowedText::UGAMEShadowedText(const std::string& str, osgText::Font* font):mShadowOffset(osg::Vec2(8,8))
{
}

void UGAMEShadowedText::setAlignment(osgText::Text::AlignmentType type)
{
}

void UGAMEShadowedText::setCharacterSizeMode(osgText::Text::CharacterSizeMode type)
{
}

void UGAMEShadowedText::setCharacterSize(float size)
{
}

void UGAMEShadowedText::setPosition(const osg::Vec3& pos)
{
}

void UGAMEShadowedText::setText(const std::string& str)
{
}

void UGAMEShadowedText::setText(const osgText::String& str)
{
}

void UGAMEShadowedText::setColor(const osg::Vec4& color)
{
}

const osg::Vec4& UGAMEShadowedText::getColor() const
{
  static osg::Vec4 vec;
  return vec;
}

void PokerCardController::Receive()
{
}

void PokerCardController::Fold()
{
}

void PokerCardController::SetValue(int value) 
{
}

void PokerCardController::Visible(bool visible)
{
}

PokerShowdownController::~PokerShowdownController()
{
}

void PokerShowdownController::TurnProjectorOff()
{
}

bool PokerShowdownController::Update(MAFApplication*)
{
  return false;
}

PokerChipsStackController::PokerChipsStackController(PokerApplication* game,unsigned int controllerID)
{
  SetModel(new PokerChipsStackModel(game));
}

PokerChipsStackController::~PokerChipsStackController()
{
}

bool PokerChipsStackController::Update(MAFApplication*)
{
  return false;
}

void PokerChipsStackController::CreateShadowStacks(PokerApplication* game)
{
}

void PokerChipsStackController::CreateSlider(PokerApplication* game)
{
}

MAFAudioData* MAFRepositoryData::GetAudio(const std::string& name, MAFMonitor *_mon) 
{
  return NULL;
}

MAFXmlData* MAFRepositoryData::GetXml(const std::string &name) 
{
  return NULL;
}

std::list<std::string> MAFXmlData::GetList(const std::string& path)
{
  return std::list<std::string>();
}

void MAFCreateNodePath(osg::Node *_src, osg::NodePath &_path, int _parentValidMask)
{
}

osg::Matrixf MAFBuildShadowMatrix(const osg::Plane &_groundPlane, const osg::Vec4f &_lightPos)
{
  return osg::Matrixf();
}

void RecursiveClearUserData(osg::Node* node)
{
}

osg::NodeVisitor* RecursiveLeakCollect(osg::Node* node)
{
  return NULL;
}

void RecursiveLeakCheck(osg::NodeVisitor* visitor)
{
}

void MAFSceneModel::RemoveControllerFromCache(MAFVisionController* item)
{
}

struct MAFPacket
{
  void SetMember(const std::string& name, const std::string& value);
  void SetMember(const std::string& name, long value);
};

void MAFPacket::SetMember(const std::string& name, const std::string& value)
{
}

void MAFPacket::SetMember(const std::string& name, long value)
{
}

struct MAF_EXPORT MAFPacketsModule {
  MAFPacket* Create(const std::string& pyclass);
};

MAFPacket* MAFPacketsModule::Create(const std::string& pyclass)
{
  return NULL;
}

bool LoadSoundSettings(std::vector<SoundInit>& settings, MAFXmlData *data)
{
  return false;
}

PokerInteractorBase::PokerInteractorBase(unsigned int)
{
}

PokerInteractorBase::~PokerInteractorBase()
{
}

void PokerInteractorBase::Init(PokerApplication* game, MAFOSGData* seatData, const std::string &urlPrefix)
{
}

bool PokerInteractorBase::Update(MAFApplication*)
{
  return false;
}

bool PokerInteractorBase::GetNodeDisplayed(const std::string &state)
{
  return false;
}

void PokerInteractorBase::Finit(PokerApplication *game)
{
}

PokerCardController::PokerCardController(PokerApplication* game, const std::string& url,unsigned int controllerID) : UGAMEArtefactController(controllerID), mGame(game)
{
}

PokerShowdownController::PokerShowdownController(PokerApplication *_game, MAFOSGData *_seatData,unsigned int controllerID) : UGAMEArtefactController(controllerID)
{
}


class MAFShader {
  enum TECHNIC_AUTHORISATION {
    TECHNIC_AUTHORISATION_NONE = 0,
  };
  MAFShader::TECHNIC_AUTHORISATION getTechnicAuthorisation();
};
 
MAFShader::TECHNIC_AUTHORISATION MAFShader::getTechnicAuthorisation()
{
  return TECHNIC_AUTHORISATION_NONE;
}

// struct TextureManager
// {
//   osg::Texture2D* GetTexture2D(const std::string& _name, osgDB::ReaderWriter::Options* _options);
// };

osg::Texture2D* TextureManager::GetTexture2D(const std::string& _name, osgDB::ReaderWriter::Options* _options)
{
  return NULL;
}

void MAFVisionController::BindToNode(osg::Node*)
{
}

struct UGAMEError
{
  UGAMEError(gint code, const gchar* format, ...);
  virtual ~UGAMEError();
};

UGAMEError::UGAMEError(gint code, const gchar* format, ...)
{
}

UGAMEError::~UGAMEError()
{
}

// class MAFApplication
// {
// public:
//   MAFApplication();
//   virtual ~MAFApplication();
//   void AddController(MAFController* controller);
//   void RemoveController(MAFController* controller);
//   std::string HeaderGet(const std::string& name, const std::string& path);
//   std::list<std::string> HeaderGetList(const std::string& name, const std::string& path);
//   std::map<std::string,std::string> HeaderGetProperties(const std::string& name, const std::string& path);
//   MAFController* GetFocus(void);
//   bool HasEvent() const;
//   SDL_Event* GetLastEvent(MAFController* controller) const;
//   MAFPacketsModule* GetPacketsModule(void);
//   TextureManager* GetTextureManager();
//   void PythonCall(PyObject* instance, const std::string& method, MAFPacket* packet);
// };

MAFApplication::~MAFApplication()
{
}

void MAFApplication::AddController(MAFController* controller)
{
}

void MAFApplication::RemoveController(MAFController* controller)
{
}

std::string MAFApplication::HeaderGet(const std::string& name, const std::string& path)
{
  return "dummy";
}

std::list<std::string> MAFApplication::HeaderGetList(const std::string& name, const std::string& path)
{
  std::list<std::string> list;
  list.push_back("dummy");
  return list;
}

std::map<std::string,std::string> MAFApplication::HeaderGetProperties(const std::string& name, const std::string& path)
{
  std::map<std::string,std::string> properties;
  properties["min_random"] = "0.0f";
  properties["max_random"] = "0.0f";
  return properties;
}

MAFController* MAFApplication::GetFocus(void)
{
  return NULL;
}

bool MAFApplication::HasEvent() const
{
  return false;
}

SDL_Event* MAFApplication::GetLastEvent(MAFController* controller) const
{
  return NULL;
}

void MAFApplication::PythonCall(PyObject* instance, const std::string& method, MAFPacket* packet)
{
}

MAFPacketsModule* MAFApplication::GetPacketsModule(void)
{
  return NULL;
}

TextureManager* MAFApplication::GetTextureManager()
{
  return NULL;
}

void MAFApplication::Exit(int)
{
}

struct MAFGlowFX
{
  float getGlowTextureOpacity();
};

float MAFGlowFX::getGlowTextureOpacity()
{
  return 0.0f;
}

void UGAMETimeOut::Update(float dt)
{
}

struct MAFRenderBin
{
  bool GetRenderBinIndexOfEntity(const std::string &_entityName, int &_rbinIndex) const;
  MAFRenderBin& Instance();
  bool SetupRenderBin(const std::string &_entityName, osg::StateSet *_ss) const;
};

bool MAFRenderBin::GetRenderBinIndexOfEntity(const std::string &_entityName, int &_rbinIndex) const
{
  return true;
}

MAFRenderBin& MAFRenderBin::Instance()
{
  return *(new MAFRenderBin());
}

bool MAFRenderBin::SetupRenderBin(const std::string &_entityName, osg::StateSet *_ss) const
{
  return true;
}

struct MAFRepositoryDataMockup : MAFRepositoryData
{
  MAFRepositoryDataMockup() : MAFRepositoryData()
  {
  }
};

struct PokerApplicationMockup : PokerApplication
{
  PokerApplicationMockup() : PokerApplication()
  {
  }
  void Init()
  {
  }
  const std::string& SetLogPolicy()
  {
    static std::string dummy;
    return dummy;
  }
  void Crash()
  {
  }
  bool SetSoundEnabled(bool)
  {
    return false;
  }
  bool IsSoundEnabled()
  {
    return false;
  }
  void OnExit(int)
  {
  }
};



struct PokerPlayerMockup : PokerPlayer
{
  PokerPlayerMockup() : PokerPlayer(new PokerApplicationMockup(), 0, false, "", "")
  {
  }
};

struct MAFOSGDataMockup : MAFOSGData
{
  MAFOSGDataMockup() : MAFOSGData()
  {
    mGroup = new osg::Group();
  }
};

MAFData* MAFOSGData::Clone(unsigned int cloneFlag)
{
  return new MAFOSGDataMockup();
}

MAFVisionData* MAFRepositoryData::GetVision(const std::string& name, MAFMonitor *_mon)
{
  return new MAFOSGDataMockup();
}

MAFSceneModel::~MAFSceneModel()
{
}

void MAFSceneModel::Init(void)
{
}

void MAFSceneView::Init(void)
{
}

void MAFSceneView::Update(MAFWindow*)
{
}

void MAFSceneController::Init(void)
{
}

bool MAFSceneController::Update(MAFApplication*)
{
  return false;
}

struct MAFSceneModelMockup : MAFSceneModel
{
  MAFSceneModelMockup()
  {
    mScene = new osgUtil::SceneView();
    mScene->setSceneData(new osg::Group());
  }
};

struct MAFSceneControllerMockup : MAFSceneController
{
  MAFSceneControllerMockup()
  {
    SetModel(new MAFSceneModelMockup());
  }
};

MAFApplication::MAFApplication()
{
  SetScene(new MAFSceneControllerMockup());
}

bool osgCal::Model::setCoreModel(osgCal::CoreModel*)
{
  CalCoreModel* model = new CalCoreModel("");
  model->setCoreSkeleton(new CalCoreSkeleton());
  _calModel = new CalModel(model);
  return true;
}

bool osgCal::Model::setUseVertexProgram(bool, unsigned int)
{
  return true;
}

bool osgCal::Model::initOutfitFromXMLString(const std::string& xmlString, std::vector<std::string>* excludeMesh)
{
  return true;
}

bool osgCal::Model::create()
{
  return true;
}

void CalModel::setAbstractMixer(CalAbstractMixer* mixer)
{
  m_pMixer = mixer;
}

namespace osgDB
{
  osgCal::CoreModel* readObjectFileMockup(const std::string&, osgDB::ReaderWriter::Options const*)
  {
    return new osgCal::CoreModel();
  }
}

int CalCoreModel::loadCoreAnimation(const std::string&)
{
  return 1;
}

CalCoreAnimation *CalCoreModel::getCoreAnimation(int coreAnimationId)
{
  CalCoreAnimation* animation = new CalCoreAnimation();
  return animation;
}



std::list<CalCoreTrack *>& CalCoreAnimation::getListCoreTrack()
{
  CalCoreTrack* track = new CalCoreTrack();
  CalCoreKeyframe* key = new CalCoreKeyframe();
  track->addCoreKeyframe(key);
  static int i = 0;
  addCoreTrack(track);
  if (i == 2)
    {
      addCoreTrack(track);
    }
  ++i;
  return m_listCoreTrack;
}

int CalCoreSkeleton::getCoreBoneId(const std::string&)
{
  return 1;
}
#if CAL3D_VERSION < 11
int CalCoreTrack::getCoreBoneId()
{
  return 1;
}
#endif
NoiseEyes::NoiseEyes(CalModel* model, const std::string& data) : NoiseElement(model, data)
{
}

NoiseSkull::NoiseSkull(CalModel* model, const std::string& data) : NoiseElement(model, data)
{
}

void NoiseEyes::process(CalModel* model, CalAnimationAlt* animation)
{
}
void NoiseSkull::process(CalModel* model, CalAnimationAlt* animation)
{
}

NoiseElement::NoiseElement(CalModel* model, const std::string& data)
{
}

double NoiseElement::NoiseFunction(double)
{
  return 0.0;
}


bool CalCoreModel::addAnimationName(const std::string& strAnimationName, int coreAnimationId)
{
  return true;
}

osgCal::Model::Drawables* osgCal::Model::getDrawables(const std::string& materialName)
{
  osgCal::Model::Drawables* drawables = new osgCal::Model::Drawables();
  return drawables;
}

struct CriticalHandlerFixture
{
  bool _g_criticalIsCalled;
  std::string _g_criticalMessage;
  CriticalHandlerFixture()
  {
    g_log_set_handler(NULL, (GLogLevelFlags)(G_LOG_LEVEL_CRITICAL), g_criticalHandler, this);
  }
  ~CriticalHandlerFixture()
  {
    g_log_set_handler(NULL, (GLogLevelFlags)(G_LOG_LEVEL_CRITICAL), g_log_default_handler, NULL);
  }
  static void g_criticalHandler(const gchar *log_domain,
				GLogLevelFlags log_level,
				const gchar *message,
				gpointer user_data)
  {
    CUSTOM_ASSERT(user_data);
    CriticalHandlerFixture* fixture = (CriticalHandlerFixture*)user_data;
    fixture->_g_criticalIsCalled = true;
    fixture->_g_criticalMessage = message;
  }
};

TEST_FIXTURE(CriticalHandlerFixture, ShowCardTest)
{
  PokerPlayerMockup* player = new PokerPlayerMockup();
  std::vector<int> cards;
  cards.push_back(1);
  cards.push_back(2);
  player->SetPocketCards(cards);
  CHECK(_g_criticalIsCalled);
  CHECK_EQUAL("Data of player missing not enough cards (wanted 2 currently 0)\n", _g_criticalMessage);
  CHECK_ASSERT(player->ShowCard(0));
}

void reportCustomAssert()
{
  std::string description = CustomAssert::Instance().GetDescription();
  std::string message = CustomAssert::Instance().GetMessage();
  std::string function = CustomAssert::Instance().GetFunction();
  std::string file = CustomAssert::Instance().GetFile();
  int line  = CustomAssert::Instance().GetLine();
  UnitTest::ReportAssert((description+" "+message).c_str(), (function+" "+file).c_str(), line);
}

int	main()
{
  CustomAssert::Instance().SetHandler(reportCustomAssert);
  return UnitTest::RunAllTests();
}
