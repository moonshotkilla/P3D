import os
import sys
import platform
if platform.system() == "Windows":
	path = "../../../underware/examples/poker"
	path = os.path.abspath(path)
	sys.path.insert(0, path)
	path = "../../../underware/python"
	path = os.path.abspath(path)
	sys.path.insert(0, path)
	path = "../../../underware/examples"
	path = os.path.abspath(path)
	sys.path.insert(0, path)

from poker3d import PokerClientFactory3D
from twisted.internet import reactor
from pokerchildren3d import PokerChildXwnc, PokerChildInterface
from pokerchildren3d import PROCESS_XWNC_STARTED, PROCESS_XWNC_STOPPED, PROCESS_INTERFACE_STARTED, PROCESS_INTERFACE_STOPPED, CHILD_INTERFACE_READY
from pokernetwork.pokerchildren import PokerChildren, PokerRsync

class PokerDisplayMockup:
	def __init__(self):
		pass
	def load(self):
		pass
	def render(self, packet):
		pass

class PokerSkinMockup:
	def __init__(self):
		pass
	def destroy(self):
		pass

class PokerClientFactory3DMockup(PokerClientFactory3D):
    def __init__(self):
		self.interface = None
		self.display = PokerDisplayMockup()
		self.skin = PokerSkinMockup()
	
class XwncConfigMockup:
    def __init__(self):
		self.path = "/foo/bar"
    def headerGetInt(self, path):
		return 5
    def headerGet(self, path):
		if "/settings/data/@path" == path:
			return "../../../data.proprio"
		if "/settings/metisse/@display" == path:
			return "1"
		if "/settings/metisse/xwnc" == path:
			return "../../bin-cygwin/poker3d_xwnc.exe -localhost -to 200000 -rfbwait 180000 -depth 24 -geometry %width%x%height% :%display%"
		if "/settings/metisse/xwnc/@chdir":
			return "../../bin-cygwin"
		return ""
    def headerGetList(self, path):
		return ("",)
    def headerGetProperties(self, path):
		return ({"width" : "800", "height" : "600"},)

class InterfaceConfigMockup:
	def __init__(self):
		self.path = "/foo/bar"
	def headerGetInt(self, path):
		if "/settings/metisse/lobby/@port" == path:
			return 19379
		return 5
	def headerGet(self, path):
		if "/settings/data/@path" == path:
			return "../../../data.proprio"
		if "/settings/metisse/@display" == path:
			return "1"
		if "/settings/metisse/lobby" == path:
			return "../../bin-cygwin/poker3d-interface.exe --glade ../../../data.proprio/interface/interface.glade --datadir ../../../data.proprio/interface -r ../../../data.proprio/interface/gtkrc --smiley ../../../data.proprio/interface/smileys --verbose %verbose% --display :%display% --port %port%"
		if "/settings/metisse/lobby/@chdir":
			return "../../bin-cygwin"
		return ""
	def headerGetList(self, path):
		return ("",)

import unittest
from twisted.internet import defer

class PokerChildTest(unittest.TestCase):
	def setUp(self):
		pass
	def tearDown(self):
		pass
	def test_XwncSpawnAndKill(self):
		self.xwnc = PokerChildXwnc(XwncConfigMockup(), XwncConfigMockup())
		self.interface = PokerChildInterface(InterfaceConfigMockup(), InterfaceConfigMockup())
		self.running = True
		def startInterface():
			self.interface.spawn()
		def interfaceStarted():
			pass
		def interfaceReady(interfaceChild, interface, interfaceFactory):
			interface.showMenu()
			reactor.callLater(2, killAll)
		def killAll():
			self.interface.kill()
			self.xwnc.kill()
			reactor.stop()
		self.xwnc.registerHandler(PROCESS_XWNC_STARTED, startInterface)
		self.interface.registerHandler(PROCESS_INTERFACE_STARTED, interfaceStarted)
		self.interface.registerHandler(CHILD_INTERFACE_READY, interfaceReady)
		self.xwnc.spawn()
		interfaceDeferred = defer.Deferred()
		def interfaceStopped(arg):
			print "interfaceStopped %s" % str(arg)
			return arg
		def xwncStopped(arg):
			print "xwncStopped %s" % str(arg)
			return arg
		#interfaceDeferred.addCallback(interfaceStopped)
		xwncDeferred = defer.Deferred()
		#xwncDeferred.addCallback(xwncStopped)
		def childrenStopped(arg):
			print "childrenStopped %s" % str(arg)
			return arg
		childrenDeferred = defer.DeferredList((interfaceDeferred,xwncDeferred))
		#childrenDeferred.addCallback(childrenStopped)
		self.interface.registerHandler(PROCESS_INTERFACE_STOPPED, lambda: interfaceDeferred.callback(True))
		self.xwnc.registerHandler(PROCESS_XWNC_STOPPED, lambda: xwncDeferred.callback(True))		
		def reactorIsStopping():
			print "reactorIsStopping"
			return childrenDeferred
		def reactorIsStopped():
			print "reactorIsStopped"
			running = False
			return True
		reactor.addSystemEventTrigger('before', 'shutdown', reactorIsStopping)
		reactor.addSystemEventTrigger('after', 'shutdown', reactorIsStopped)
		reactor.startRunning()
		while reactor.running:
			reactor.iterate()
		print "leaving"
	def test_CheckInterfaceUnavailable(self):
		client = PokerClientFactory3DMockup()
		exceptionCaught = False
		try:
			client.clientVersionOk()
		except:
			exceptionCaught = True
		self.assertEquals(True, exceptionCaught)
	def test_PokerRsync(self):
		class PokerRsyncConfigMockup:
			def __init__(self):
				pass
		class PokerRsyncSettingsMockup:
			def __init__(self):
				pass
			def headerGetInt(self, path):
				return 0
			def headerGet(self, path):
				return ""
		rsync = PokerRsync(PokerRsyncConfigMockup(), PokerRsyncSettingsMockup(), ("rsync", "c:\\toto", "d:\\titi"))
		self.assertEquals('"/cygdrive/c/toto"', rsync.rsync[2])
		self.assertEquals('"/cygdrive/d/titi"', rsync.rsync[3])
unittest.main()
