import unittest
from pokerchildren import PokerChildBrowser
import win32api, win32con

class PokerConfigMockup:
	def headerGetInt(self, path):
		return 5
	def headerGet(self, path):
		if path == "/settings/web":
			return "http://www.pok3d.com/"
		else:
			return None
class PythonTestCase(unittest.TestCase):
	def setUp(self):
		self.backup = win32api.RegQueryValue(win32con.HKEY_CLASSES_ROOT, "HTTP\shell\open\command")		
		win32api.RegSetValue(win32con.HKEY_CLASSES_ROOT, "HTTP\shell\open\command", win32con.REG_SZ, "dummy")
	def tearDown(self):
		win32api.RegSetValue(win32con.HKEY_CLASSES_ROOT, "HTTP\shell\open\command", win32con.REG_SZ, self.backup)
	def testDummy(self):
		exceptionCaught = False
		try:
			browser = PokerChildBrowser(None, PokerConfigMockup(), "forums.php")
		except:
			import sys
			self.assertEquals('*CRITICAL*: failed to start browser at: dummy', str(sys.exc_info()[1]))
			exceptionCaught = True
		self.assertEquals(True, exceptionCaught)
		

if __name__ == '__main__':
    unittest.main()
