def killProcessByName(arg):
    pass
