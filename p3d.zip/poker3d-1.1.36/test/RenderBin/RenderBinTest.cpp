/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#include <UnitTest++.h>
#include <ReportAssert.h>
#include <osg/Vec2>
#include <osg/MatrixTransform>
#include <osg/Geode>
#include <osg/Version>
#if OSG_VERSION_MAJOR == 1
#include <osg/io_utils>
#endif // OSG_VERSION_MAJOR == 1
#include <osg/Geometry>
#include <osg/Material>
#include <osg/Projection>
#include <osg/BlendFunc>

#include "CustomAssert/CustomAssert.h"
#include "osgViewer.h"

struct MyDrawable : osg::Geometry
{
  static int _sRenderPosition;
  static void resetRenderPosition()
  {
    _sRenderPosition = 0;
  }
  mutable int _renderPosition;
  MyDrawable() : _renderPosition(0)
  {
    osg::StateSet* state = getOrCreateStateSet();
    osg::Material* material = new osg::Material;
    state->setAttributeAndModes(material, osg::StateAttribute::ON);
    state->setMode(GL_LIGHTING, osg::StateAttribute::OFF);
    state->setMode(GL_CULL_FACE, osg::StateAttribute::OFF);
    osg::BlendFunc* bf = new osg::BlendFunc;
    bf->setFunction(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    state->setAttributeAndModes(bf, osg::StateAttribute::ON);
    state->setMode(GL_ALPHA_TEST, GL_FALSE);
    
    osg::Vec3Array* array = new osg::Vec3Array();
    array->resize(4);  
    setVertexArray(array);
    
    osg::Vec2Array* uv = new osg::Vec2Array();
    uv->push_back( osg::Vec2f(0, 1) );
    uv->push_back( osg::Vec2f(1, 1) );
    uv->push_back( osg::Vec2f(1, 0) );
    uv->push_back( osg::Vec2f(0, 0) );
    setTexCoordArray(0, uv);
    
    GLushort index[6];
    index[0] = 0;
    index[1] = 1;
    index[2] = 2;
    index[3] = 0;
    index[4] = 2;
    index[5] = 3;
    osg::PrimitiveSet* ps = new osg::DrawElementsUShort(osg::PrimitiveSet::TRIANGLES, 6, index);
    addPrimitiveSet(ps);
    setUseDisplayList(false);
    setUseVertexBufferObjects(false);


    float w = 10.0f;
    float h = 10.0f;
    array[0][0] = osg::Vec3f(0, 0, 0);
    array[0][1] = osg::Vec3f(w, 0, 0);
    array[0][2] = osg::Vec3f(w, h, 0);
    array[0][3] = osg::Vec3f(0, h, 0);
    dirtyBound();
  }
  virtual void drawImplementation(osg::State& state) const
  {
    ++_sRenderPosition;
    _renderPosition = _sRenderPosition;
    //std::cout << _renderPosition << std::endl;
    //osg::Geometry::drawImplementation(state);
  }
  virtual osg::Object* cloneType() const
  {
    return osg::Geometry::cloneType();
  }
  virtual  osg::Object* clone(const osg::CopyOp& op) const
  {
    return osg::Geometry::clone(op);
  }
};

int MyDrawable::_sRenderPosition = 0;

TEST(MyDrawable)
{
  MyDrawable::resetRenderPosition();
  CHECK_EQUAL(0, MyDrawable::_sRenderPosition);
  MyDrawable drawable;
  osg::State& s = *((osg::State*)0);
  drawable.drawImplementation(s);
  CHECK_EQUAL(1, MyDrawable::_sRenderPosition);
  CHECK_EQUAL(1, drawable._renderPosition);
  drawable.drawImplementation(s);
  CHECK_EQUAL(2, MyDrawable::_sRenderPosition);
  CHECK_EQUAL(2, drawable._renderPosition);
  drawable.drawImplementation(s);
  CHECK_EQUAL(3, MyDrawable::_sRenderPosition);
  CHECK_EQUAL(3, drawable._renderPosition);
  MyDrawable::resetRenderPosition();
  CHECK_EQUAL(0, MyDrawable::_sRenderPosition);
}

TEST(RenderBin1)
{
  osgViewer viewer;
  viewer.Create();

  osg::Group* group = new osg::Group();
  osg::Geode* geode = new osg::Geode();  
  MyDrawable* draw1 = new MyDrawable();
  MyDrawable* draw2 = new MyDrawable();
  MyDrawable* draw3 = new MyDrawable();
  geode->addDrawable(draw1);
  geode->addDrawable(draw2);
  geode->addDrawable(draw3);

  group->addChild(geode);
  viewer.GetRoot()->addChild(group);

  CHECK_EQUAL(0, draw1->_renderPosition);
  CHECK_EQUAL(0, draw2->_renderPosition);
  CHECK_EQUAL(0, draw3->_renderPosition);

  MyDrawable::resetRenderPosition();
  viewer.Render();

  CHECK_EQUAL(1, draw1->_renderPosition);
  CHECK_EQUAL(2, draw2->_renderPosition);
  CHECK_EQUAL(3, draw3->_renderPosition);  

  viewer.Destroy();
}

TEST(RenderBin2)
{
  osgViewer viewer;
  viewer.Create();

  osg::Group* group = new osg::Group();
  osg::Geode* geode = new osg::Geode();  
  MyDrawable* draw1 = new MyDrawable();
  MyDrawable* draw2 = new MyDrawable();
  MyDrawable* draw3 = new MyDrawable();
  geode->addDrawable(draw2);
  geode->addDrawable(draw3);
  geode->addDrawable(draw1);

  group->addChild(geode);
  viewer.GetRoot()->addChild(group);

  CHECK_EQUAL(0, draw1->_renderPosition);
  CHECK_EQUAL(0, draw2->_renderPosition);
  CHECK_EQUAL(0, draw3->_renderPosition);  

  MyDrawable::resetRenderPosition();
  viewer.Render();

  CHECK_EQUAL(1, draw2->_renderPosition);
  CHECK_EQUAL(2, draw3->_renderPosition);  
  CHECK_EQUAL(3, draw1->_renderPosition);

  viewer.Destroy();
}


TEST(RenderBin3)
{
  osgViewer viewer;
  viewer.Create();

  osg::Group* group = new osg::Group();
  osg::MatrixTransform* mt = new osg::MatrixTransform();
  mt->setMatrix(osg::Matrix::translate(0.0f, 0.0f, -1.0f));
  osg::Geode* geode = new osg::Geode();  
  MyDrawable* draw1 = new MyDrawable();
  geode->addDrawable(draw1);
  mt->addChild(geode);
  group->addChild(mt);
  mt = new osg::MatrixTransform();
  mt->setMatrix(osg::Matrix::translate(0.0f, 0.0f, -3.0f));
  geode = new osg::Geode();  
  MyDrawable* draw2 = new MyDrawable();
  geode->addDrawable(draw2);
  mt->addChild(geode);
  group->addChild(mt);
  mt = new osg::MatrixTransform();
  mt->setMatrix(osg::Matrix::translate(0.0f, 0.0f, -2.0f));
  geode = new osg::Geode();  
  MyDrawable* draw3 = new MyDrawable();
  geode->addDrawable(draw3);
  mt->addChild(geode);
  group->addChild(mt);

  group->getOrCreateStateSet()->setRenderBinDetails(0, "DepthSortedBin");
  viewer.GetRoot()->addChild(group);


  CHECK_EQUAL(0, draw1->_renderPosition);
  CHECK_EQUAL(0, draw2->_renderPosition);
  CHECK_EQUAL(0, draw3->_renderPosition);  

  MyDrawable::resetRenderPosition();
  viewer.Render();


   CHECK_EQUAL(1, draw2->_renderPosition);  
   CHECK_EQUAL(2, draw3->_renderPosition);
   CHECK_EQUAL(3, draw1->_renderPosition);

  viewer.Destroy();
}

TEST(RenderBin3bis)
{
  osgViewer viewer;
  viewer.Create();

  osg::Group* group = new osg::Group();
  osg::MatrixTransform* mt = new osg::MatrixTransform();
  mt->setMatrix(osg::Matrix::translate(0.0f, 0.0f, -1.0f));
  osg::Geode* geode = new osg::Geode();  
  MyDrawable* draw1 = new MyDrawable();
  geode->addDrawable(draw1);
  mt->addChild(geode);
  group->addChild(mt);
  mt = new osg::MatrixTransform();
  mt->setMatrix(osg::Matrix::translate(0.0f, 0.0f, -3.0f));
  geode = new osg::Geode();  
  MyDrawable* draw2 = new MyDrawable();
  geode->addDrawable(draw2);
  mt->addChild(geode);
  group->addChild(mt);
  mt = new osg::MatrixTransform();
  mt->setMatrix(osg::Matrix::translate(0.0f, 0.0f, -2.0f));
  geode = new osg::Geode();  
  MyDrawable* draw3 = new MyDrawable();
  geode->addDrawable(draw3);
  mt->addChild(geode);
  group->addChild(mt);

  //group->getOrCreateStateSet()->setRenderBinDetails(0, "DepthSortedBin");
  viewer.GetRoot()->addChild(group);


  CHECK_EQUAL(0, draw1->_renderPosition);
  CHECK_EQUAL(0, draw2->_renderPosition);
  CHECK_EQUAL(0, draw3->_renderPosition);  

  MyDrawable::resetRenderPosition();
  viewer.Render();


   CHECK_EQUAL(1, draw1->_renderPosition);  
   CHECK_EQUAL(2, draw2->_renderPosition);
   CHECK_EQUAL(3, draw3->_renderPosition);

  viewer.Destroy();
}

TEST(RenderBin3ter)
{
  osgViewer viewer;
  viewer.Create();

  osg::Group* group = new osg::Group();
  osg::MatrixTransform* mt = new osg::MatrixTransform();
  mt->setMatrix(osg::Matrix::translate(0.0f, 0.0f, -1.0f));
  osg::Geode* geode = new osg::Geode();  
  MyDrawable* draw1 = new MyDrawable();
  geode->addDrawable(draw1);
  mt->addChild(geode);
  group->addChild(mt);
  mt = new osg::MatrixTransform();
  mt->setMatrix(osg::Matrix::translate(0.0f, 0.0f, -3.0f));
  geode = new osg::Geode();  
  MyDrawable* draw2 = new MyDrawable();
  geode->addDrawable(draw2);
  mt->addChild(geode);
  group->addChild(mt);
  mt = new osg::MatrixTransform();
  mt->setMatrix(osg::Matrix::translate(0.0f, 0.0f, -2.0f));
  geode = new osg::Geode();  
  MyDrawable* draw3 = new MyDrawable();
  geode->addDrawable(draw3);
  mt->addChild(geode);
  group->addChild(mt);

  group->getOrCreateStateSet()->setRenderBinDetails(0, "DepthSortedBin");
  draw1->getOrCreateStateSet()->setRenderBinDetails(1, "RenderBin");
  draw2->getOrCreateStateSet()->setRenderBinDetails(2, "RenderBin");
  draw3->getOrCreateStateSet()->setRenderBinDetails(3, "RenderBin");
  viewer.GetRoot()->addChild(group);


  CHECK_EQUAL(0, draw1->_renderPosition);
  CHECK_EQUAL(0, draw2->_renderPosition);
  CHECK_EQUAL(0, draw3->_renderPosition);  

  MyDrawable::resetRenderPosition();
  viewer.Render();

  CHECK_EQUAL(1, draw1->_renderPosition);  
  CHECK_EQUAL(2, draw2->_renderPosition);
  CHECK_EQUAL(3, draw3->_renderPosition);

  viewer.Destroy();
}


TEST(RenderBin4)
{
  osgViewer viewer;
  viewer.Create();

  osg::Group* group = new osg::Group();
  osg::Geode* geode = new osg::Geode();  
  MyDrawable* draw1 = new MyDrawable();
  MyDrawable* draw2 = new MyDrawable();
  MyDrawable* draw3 = new MyDrawable();
  geode->addDrawable(draw1);
  geode->addDrawable(draw2);
  geode->addDrawable(draw3);

  group->addChild(geode);
  viewer.GetRoot()->addChild(group);


  draw1->getOrCreateStateSet()->setRenderBinDetails(3, "RenderBin");
  draw2->getOrCreateStateSet()->setRenderBinDetails(1, "RenderBin");
  draw3->getOrCreateStateSet()->setRenderBinDetails(2, "RenderBin");

  CHECK_EQUAL(0, draw1->_renderPosition);
  CHECK_EQUAL(0, draw2->_renderPosition);
  CHECK_EQUAL(0, draw3->_renderPosition);  

  MyDrawable::resetRenderPosition();
  viewer.Render();

  CHECK_EQUAL(1, draw2->_renderPosition);
  CHECK_EQUAL(2, draw3->_renderPosition);  
  CHECK_EQUAL(3, draw1->_renderPosition);

  viewer.Destroy();
}


TEST(RenderBin5)
{
  osgViewer viewer;
  viewer.Create();

  osg::Group* group = new osg::Group();
  osg::MatrixTransform* mt = new osg::MatrixTransform();
  mt->setMatrix(osg::Matrix::translate(0.0f, 0.0f, -1.0f));
  osg::Geode* geode = new osg::Geode();  
  MyDrawable* draw1 = new MyDrawable();
  geode->addDrawable(draw1);
  mt->addChild(geode);
  group->addChild(mt);
  mt = new osg::MatrixTransform();
  mt->setMatrix(osg::Matrix::translate(0.0f, 0.0f, -3.0f));
  geode = new osg::Geode();  
  MyDrawable* draw2 = new MyDrawable();
  geode->addDrawable(draw2);
  mt->addChild(geode);
  group->addChild(mt);
  mt = new osg::MatrixTransform();
  mt->setMatrix(osg::Matrix::translate(0.0f, 0.0f, -2.0f));
  geode = new osg::Geode();  
  MyDrawable* draw3 = new MyDrawable();
  geode->addDrawable(draw3);
  mt->addChild(geode);
  group->addChild(mt);

  //group->getOrCreateStateSet()->setRenderBinDetails(0, "DepthSortedBin");
  draw1->getOrCreateStateSet()->setRenderBinDetails(1, "DepthSortedBin");
  draw2->getOrCreateStateSet()->setRenderBinDetails(2, "DepthSortedBin");
  draw3->getOrCreateStateSet()->setRenderBinDetails(3, "DepthSortedBin");
  viewer.GetRoot()->addChild(group);


  CHECK_EQUAL(0, draw1->_renderPosition);
  CHECK_EQUAL(0, draw2->_renderPosition);
  CHECK_EQUAL(0, draw3->_renderPosition);  

  MyDrawable::resetRenderPosition();
  viewer.Render();


   CHECK_EQUAL(1, draw1->_renderPosition);  
   CHECK_EQUAL(2, draw2->_renderPosition);
   CHECK_EQUAL(3, draw3->_renderPosition);

  viewer.Destroy();
}


TEST(RenderBin6)
{
  osgViewer viewer;
  viewer.Create();

  osg::Group* group = new osg::Group();
  osg::Geode* geode1 = new osg::Geode();  
  osg::Geode* geode2 = new osg::Geode();  
  osg::Geode* geode3 = new osg::Geode();  
  MyDrawable* draw1 = new MyDrawable();
  MyDrawable* draw2 = new MyDrawable();
  MyDrawable* draw3 = new MyDrawable();
  geode1->addDrawable(draw1);
  geode2->addDrawable(draw2);
  geode2->addDrawable(draw3);

  group->addChild(geode1);
  group->addChild(geode2);
  group->addChild(geode3);
  viewer.GetRoot()->addChild(group);
  
  geode1->getOrCreateStateSet()->setRenderBinDetails(1, "RenderBin");
  draw1->getOrCreateStateSet()->setRenderBinDetails(3, "RenderBin");
  geode2->getOrCreateStateSet()->setRenderBinDetails(2, "RenderBin");
  draw2->getOrCreateStateSet()->setRenderBinDetails(1, "RenderBin");
  draw3->getOrCreateStateSet()->setRenderBinDetails(2, "RenderBin");

  CHECK_EQUAL(0, draw1->_renderPosition);
  CHECK_EQUAL(0, draw2->_renderPosition);
  CHECK_EQUAL(0, draw3->_renderPosition);  

  MyDrawable::resetRenderPosition();
  viewer.Render();

  CHECK_EQUAL(1, draw1->_renderPosition);
  CHECK_EQUAL(2, draw2->_renderPosition);  
  CHECK_EQUAL(3, draw3->_renderPosition);

  viewer.Destroy();
}


void reportCustomAssert()
{
  std::string description = CustomAssert::Instance().GetDescription();
  std::string function = CustomAssert::Instance().GetFunction();
  std::string file = CustomAssert::Instance().GetFile();
  int line  = CustomAssert::Instance().GetLine();
  UnitTest::ReportAssert(description.c_str(), (function+" "+file).c_str(), line);
}

int main()
{
  CustomAssert::Instance().SetHandler(reportCustomAssert);  
  return UnitTest::RunAllTests();
}
