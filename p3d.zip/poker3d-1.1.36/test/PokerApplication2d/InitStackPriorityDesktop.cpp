/* (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */
#include <UnitTest++.h>
#include <ReportAssert.h>
#include <osg/TexMat>
#include <maf/wnc_desktop.h>
#include <maf/wnc_window.h>
#include <PokerApplication2d.h>
#include <CustomAssert/CustomAssert.h>
#include <string>

MAFError::MAFError(int, char const*, ...) {}
MAFError::~MAFError(){}

struct MAFApplication2DAnimate {
  MAFApplication2DAnimate();
  virtual ~MAFApplication2DAnimate();
  virtual void Map(osg::Group* group);
};
MAFApplication2DAnimate::MAFApplication2DAnimate() {}
MAFApplication2DAnimate::~MAFApplication2DAnimate() {}
void MAFApplication2DAnimate::Map(osg::Group* group) {}

struct MAFApplication2DAlpha {
  MAFApplication2DAlpha();
  virtual ~MAFApplication2DAlpha();
};
MAFApplication2DAlpha::MAFApplication2DAlpha() {}
MAFApplication2DAlpha::~MAFApplication2DAlpha() {}

struct MAFApplication2DDecorate {
  MAFApplication2DDecorate();
  virtual ~MAFApplication2DDecorate();
};
MAFApplication2DDecorate::MAFApplication2DDecorate() {}
MAFApplication2DDecorate::~MAFApplication2DDecorate() {}

struct MAFApplication2DDecorateSquare {
  MAFApplication2DDecorateSquare();
  virtual ~MAFApplication2DDecorateSquare();
};
MAFApplication2DDecorateSquare::MAFApplication2DDecorateSquare() {}
MAFApplication2DDecorateSquare::~MAFApplication2DDecorateSquare() {}

struct MAFApplication2DModel
{
  MAFApplication2DModel();
  virtual ~MAFApplication2DModel();
};
MAFApplication2DModel::MAFApplication2DModel() {}
MAFApplication2DModel::~MAFApplication2DModel() {}

struct MAFApplication2DAlphaFade {
  MAFApplication2DAlphaFade();
};
MAFApplication2DAlphaFade::MAFApplication2DAlphaFade() {}

struct MAFApplication2DSlideInOut {
  MAFApplication2DSlideInOut(int);
};

MAFApplication2DSlideInOut::MAFApplication2DSlideInOut(int) {}

struct MAFApplication2DSlide {
  MAFApplication2DSlide(int);
  void SetMouseTrigger(bool);
  void SetVisible(bool);
};
MAFApplication2DSlide::MAFApplication2DSlide(int) {}
void MAFApplication2DSlide::SetMouseTrigger(bool) {}
void MAFApplication2DSlide::SetVisible(bool) {}


struct MAFApplication2DController : public osg::Referenced
{
  MAFApplication2DController(MAFApplication*);
  void SetDefaultFocusedWindow(const std::string&, int);
  std::map<std::string, MAFApplication2DAnimate*>& GetName2Animate();
};
std::map<std::string, MAFApplication2DAnimate*>& MAFApplication2DController::GetName2Animate() {}
void MAFApplication2DController::SetDefaultFocusedWindow(const std::string&, int) {}
MAFApplication2DController::MAFApplication2DController(MAFApplication*){}


typedef std::map<std::string,std::string> Properties;
Properties propertiesMockup;
typedef std::list<Properties> PropertiesList;
PropertiesList propertiesListMockup;

struct MAFApplication
{
  PropertiesList HeaderGetPropertiesList(const std::string&, const std::string&);
};

PropertiesList MAFApplication::HeaderGetPropertiesList(const std::string&, const std::string&) { 
  return propertiesListMockup;
}



struct PokerApplication2DFixture : public PokerApplication2D
{
  MAFApplication mApplication;
  PokerApplication2DFixture() {
    propertiesListMockup.clear();
    PropertiesList pl;
    Properties p1;
    p1[std::string("title")] = "window1";
    p1[std::string("priorityStack")] = "1";
    pl.push_back(p1);
    Properties p2;
    p2[std::string("title")] = "yak";
    p2[std::string("priorityStack")] = "10";
    pl.push_back(p2);
    propertiesListMockup = pl;
  }

};

TEST_FIXTURE(PokerApplication2DFixture, TestReadStackpriority)
{
  std::map<std::string,int> map;
  InitStackPriorityDesktop(&mApplication,map);

  CHECK_EQUAL(true , map.find("window1") != map.end());
  CHECK_EQUAL(true , map.find("yak") != map.end());
  CHECK_EQUAL(1 , map["window1"]);
  CHECK_EQUAL(10 , map["yak"]);
}

TEST_FIXTURE(PokerApplication2DFixture, TestReadStackpriorityBadCase)
{
  std::map<std::string,int> map;
  propertiesListMockup.back().erase("priorityStack");

  CHECK_ASSERT(InitStackPriorityDesktop(&mApplication,map));
}

void reportCustomAssert()
{
  std::string description = CustomAssert::Instance().GetDescription();
  std::string message = CustomAssert::Instance().GetMessage();
  std::string function = CustomAssert::Instance().GetFunction();
  std::string file = CustomAssert::Instance().GetFile();
  int line  = CustomAssert::Instance().GetLine();
  UnitTest::ReportAssert((description+" "+message).c_str(), (function+" "+file).c_str(), line);
}

int	main()
{
  CustomAssert::Instance().SetHandler(reportCustomAssert);
  return UnitTest::RunAllTests();
}
