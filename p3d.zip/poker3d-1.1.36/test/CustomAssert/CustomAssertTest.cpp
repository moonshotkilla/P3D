/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#include <UnitTest++.h>
#include <ReportAssert.h>
#include <string>
#include "CustomAssert/CustomAssert.h"


struct CustomAssertFixture
{
  CustomAssertFixture()
  {
    CustomAssert::CreateInstance();
  }
  ~CustomAssertFixture()
  {
    CustomAssert::DestroyInstance();
  }
};
bool defaultHandlerCalled = false;
void defaultHandler()
{
  defaultHandlerCalled = true;
}
TEST_FIXTURE(CustomAssertFixture, AssertSetHandler)
{
  CustomAssert::Instance().SetHandler(defaultHandler);
  CustomAssert::Instance().Check(false, "1", "2", "3", 4);
  CHECK(defaultHandlerCalled);
  CHECK_EQUAL(CustomAssert::Instance().GetDescription(), "1");
  CHECK_EQUAL(CustomAssert::Instance().GetFile(), "2");
  CHECK_EQUAL(CustomAssert::Instance().GetFunction(), "3");
  CHECK_EQUAL(CustomAssert::Instance().GetLine(), 4);
  CHECK_EQUAL(CustomAssert::Instance().GetMessage(), "");
}
TEST_FIXTURE(CustomAssertFixture, CustomAssertMacro)
{
  defaultHandlerCalled = false;
  CustomAssert::Instance().SetHandler(defaultHandler);
  CUSTOM_ASSERT(true);
  CHECK_EQUAL(false, defaultHandlerCalled);
  CUSTOM_ASSERT(false);
  CHECK_EQUAL(true, defaultHandlerCalled);
  defaultHandlerCalled = false;
  CHECK_EQUAL("", CustomAssert::Instance().GetMessage());
  CUSTOM_ASSERT_MSG(true, "CustomAssertMsg");
  CHECK_EQUAL(false, defaultHandlerCalled);
  CHECK_EQUAL("", CustomAssert::Instance().GetMessage());
  CUSTOM_ASSERT_MSG(false, "CustomAssertMsg");
  CHECK_EQUAL(true, defaultHandlerCalled);
  CHECK_EQUAL("CustomAssertMsg", CustomAssert::Instance().GetMessage());
}
void reportCustomAssert()
{
  std::string description = CustomAssert::Instance().GetDescription();
  std::string function = CustomAssert::Instance().GetFunction();
  std::string file = CustomAssert::Instance().GetFile();
  std::string message = CustomAssert::Instance().GetMessage();
  int line  = CustomAssert::Instance().GetLine();
  UnitTest::ReportAssert((description+" "+message).c_str(), (function+" "+file).c_str(), line);
}
void functionThatCustomAssert()
{
  CUSTOM_ASSERT(false);
}
TEST_FIXTURE(CustomAssertFixture, CustomAssertException)
{  
  CustomAssert::Instance().SetHandler(reportCustomAssert);
  CHECK_ASSERT(functionThatCustomAssert());
}

CustomAssert assertDefault;
bool assertDefaultHandlerCalled = false;
void assertDefaultHandler()
{
  assertDefaultHandlerCalled = true;
}
TEST_FIXTURE(CustomAssertFixture, CustomAssertDefault)
{
  CHECK_EQUAL("", assertDefault.GetDescription());
  CHECK_EQUAL("", assertDefault.GetFunction());
  CHECK_EQUAL("", assertDefault.GetFile());
  CHECK_EQUAL(-1, assertDefault.GetLine());
  CHECK_EQUAL("", assertDefault.GetMessage());
  CHECK_EQUAL((void*)CustomAssert::DefaultHandler, (void*)assertDefault.GetHandler());
  assertDefault.SetHandler(assertDefaultHandler);
  CHECK_EQUAL((void*)assertDefaultHandler, (void*)assertDefault.GetHandler());
  assertDefault.Check(false, "1", "2", "3", 4, "5");
  CHECK(assertDefaultHandlerCalled);
  CHECK_EQUAL("1", assertDefault.GetDescription());
  CHECK_EQUAL("2", assertDefault.GetFile());
  CHECK_EQUAL("3", assertDefault.GetFunction());
  CHECK_EQUAL(4, assertDefault.GetLine());
  CHECK_EQUAL("5", assertDefault.GetMessage());
}
void orSuccessfull1()
{
  CUSTOM_ASSERT(1 || 0);
}
void orSuccessfull2()
{
  CUSTOM_ASSERT(0 || 1);
}
void orSuccessfull3()
{
  CUSTOM_ASSERT(1 || 1);
}
void orFailed()
{
  CUSTOM_ASSERT(0 || 0);
}
void andSuccessFull()
{
  CUSTOM_ASSERT(1 && 1);
}
void andFailed1()
{
  CUSTOM_ASSERT(1 && 0);
}
void andFailed2()
{
  CUSTOM_ASSERT(0 && 1);
}
void andOrSuccess()
{
  CUSTOM_ASSERT(1 || (1 && 0));
}
void andOrFailed()
{
  CUSTOM_ASSERT(0 && (1 || 0));
}
TEST_FIXTURE(CustomAssertFixture, ComplexAssertion)
{
  CustomAssert::Instance().SetHandler(reportCustomAssert);
  orSuccessfull1();
  orSuccessfull2();
  orSuccessfull3();
  CHECK_ASSERT(orFailed());
  andSuccessFull();
  CHECK_ASSERT(andFailed1());
  CHECK_ASSERT(andFailed2());
  andOrSuccess();
  CHECK_ASSERT(andOrFailed());
}

void customAssertReturnHandler()
{
}
TEST_FIXTURE(CustomAssertFixture, CustomAssertReturn)
{
  CustomAssert::Instance().SetHandler(customAssertReturnHandler);
  bool customAssertReturn = CUSTOM_ASSERT(true);
  CHECK_EQUAL(true, customAssertReturn);
  customAssertReturn = CUSTOM_ASSERT(false);
  CHECK_EQUAL(false, customAssertReturn);
}

int main()
{
  return UnitTest::RunAllTests();
}
