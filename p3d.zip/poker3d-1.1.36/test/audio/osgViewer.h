#pragma once
#include <osg/ref_ptr>
#include <string>
#include <SDL.h>

struct SDL_Surface;
namespace osgUtil
{
  class SceneView;
};
namespace osg
{
  class Group;
};

#define ASSERT(_condition) Assert::AssertMsg(_condition, #_condition, __FUNCTION__, __FILE__, __LINE__)
struct Assert
{
  static void AssertMsg(bool condition, const std::string& msg, const std::string& function, const std::string& file, int line);
};

struct osgViewer
{
  static int const WIDTH = 1024;
  static int const HEIGHT = 768;
  static int const BPP = 24;
  bool mRunning;
  double mDeltaTime;
  double mCurrentTime;
  double mPreviousTime;
  SDL_Surface* mSurface;
  SDL_Event* mLastEvent;
  SDL_Event mEvent;
  osg::ref_ptr<osgUtil::SceneView> mSceneView;
  osg::ref_ptr<osg::Group> mSceneRoot;
  osgViewer();
  ~osgViewer();
  void Create(int width = WIDTH, int height = HEIGHT, int bpp = BPP, bool fullscreen = false);
  void Destroy();
  void Update();
	void Render();
  void Draw();
  void Cull();
	void SwapBuffer();

  bool GetRunning() const;
  osg::Group* GetRoot();
  const SDL_Event* GetLastEvent() const;
  float GetDeltaTime() const;
  float GetCurrentTime() const;
  float GetPreviousTime() const;
  void updateCurrentTime();
};
