#include "UnitTest++.h"
#include <iostream>
#include "Undwr_unittest.h"
#include <osgDB/Registry>

static std::string srcdir;
void setsrcdir()
{
  char* srcdirPtr = getenv("srcdir");
  if (srcdirPtr)
    {
      //beware "." is always first in PathList
      srcdir = std::string(srcdirPtr) + "/";
      osgDB::Registry::instance()->getDataFilePathList().push_front(srcdir.c_str());
      if (srcdir == "./")
	srcdir = "";
    }
};

const std::string& getsrcdir()
{
  return srcdir;
}

int verbose = VERBOSE_NONE;

static void usage()
{
  printf("Underware Unittest\n");
  printf("Usage: unittest [options...]\n");
  printf("Options:\n");
  printf("  -h    print option list\n");
  printf("  -vt   verbose test\n");
  printf("  -va   verbose source message\n");
}

int main(int argc, char* argv[])
{
  
  int i;
  char* option;
  verbose = 0;

  for(i=1;i<argc;i++) {
    option = argv[i];
    if(*option != '-') {
      break;
    } else {
      option++;
    }
    if (strcmp(option, "h") == 0) {
      usage();
      exit(0);
    } else if (strcmp(option, "vt") == 0) {
      verbose |= VERBOSE_TEST;
    } else if (strcmp(option, "va") == 0) {
      verbose |= VERBOSE_ALL;
    }
  }

  setsrcdir();
  return UnitTest::RunAllTests();

}
