#include "UnitTest++.h"
#include "Undwr_unittest.h"

#include <ugame/BetSlider>

#include <osgDB/Registry>
#include <osgDB/ReadFile>
#include <osg/Geometry>
#include <osgText/Font>
#include <osgText/Text>

#include <osg/Notify>

#include <libxml/xmlreader.h>

const std::string& getsrcdir();

namespace betslider {

class BetSliderXtend : public betslider::BetSlider {

  public :
    BetSliderXtend() {};
    ~BetSliderXtend() {};

    void checkBuildTest() {
      _geode = new osg::Geode;
     addChild( _geode.get() );
     build();
   }

   void checkRowSetSeparatorArgs() {
     osg::ref_ptr<BetSlider::Row> _row = new Row( NULL, true, false, 0 );
     _row->setSeparator( 0, 0 );
   }

   void checkUpdateCursor_MotorPositionTest() {
     
     _motor_position = -1.0f;

     setCursor( new osg::Geode );     
     osg::ref_ptr<Row> row = _rows[0].get();
     row->add( this );
     float mot_span = -5.f;
     row->setMotorRange( mot_span, 5.f );

     updateCursorPosition();
   }

};

TEST( RectangleBackground )
{
   TEST_INIT( RectangleBackground::RectangleBackground );
   osg::ref_ptr<BetSlider::RectangleBackground> background = new BetSlider::RectangleBackground();

   CHECK( NULL != background.get() );
   TEST_RES( RectangleBackground object is null );

   TEST_INIT( RectangleBackground::setMiddleColor );
   background->setMiddleColor( osg::Vec4f( 0.1f, 0.2f, 0.3f, 0.4f ) );
   osg::Vec4* vec_mc = &(background->_middle_color);
   CHECK_EQUAL( 0.1f, vec_mc->x() );
   CHECK_EQUAL( 0.2f, vec_mc->y() );
   CHECK_EQUAL( 0.3f, vec_mc->z() );
   CHECK_EQUAL( 0.4f, vec_mc->w() );
   TEST_RES( _middle_color does not contains expected value ); 

   TEST_INIT( RectangleBackground::setMiddleWidth );
   float new_MiddleWidth = background->_middle_width + 0.5f;
   background->setMiddleWidth( new_MiddleWidth );
   CHECK_EQUAL( new_MiddleWidth, background->_middle_width );
   TEST_RES( _middle_width does not contains expected value );

   TEST_INIT( RectangleBackground::setBackgroundColor );
   background->setBackgroundColor( BetSlider::SIDE_LEFT ,osg::Vec4f( 0.1f, 0.2f, 0.3f, 0.4f ) );
   osg::Vec4* vec_bgL = &( background->_background_color[BetSlider::SIDE_LEFT] );
   CHECK_EQUAL( 0.1f, vec_bgL->x() );
   CHECK_EQUAL( 0.2f, vec_bgL->y() );
   CHECK_EQUAL( 0.3f, vec_bgL->z() );
   CHECK_EQUAL( 0.4f, vec_bgL->w() );

   background->setBackgroundColor( BetSlider::SIDE_RIGHT ,osg::Vec4f( 0.1f, 0.2f, 0.3f, 0.4f ) );
   osg::Vec4* vec_bgR = &( background->_background_color[BetSlider::SIDE_RIGHT] );
   CHECK_EQUAL( 0.1f, vec_bgR->x() );
   CHECK_EQUAL( 0.2f, vec_bgR->y() );
   CHECK_EQUAL( 0.3f, vec_bgR->z() );
   CHECK_EQUAL( 0.4f, vec_bgR->w() );
   TEST_RES( _background_color does not contains expected value );

   TEST_INIT(RectangleBackground::stretch);
   background->stretch( 2.0f, 3.0f, 4.0f );

   // note : how to test stretch success ?
   TEST_RES( stetch error message );

}

TEST( ImageBackground )
{
   if ( !( verbose & VERBOSE_ALL ) )
      osg::setNotifyLevel( osg::ALWAYS );

   TEST_INIT( ImageBackground::ImageBackground );
   osg::ref_ptr<BetSlider::ImageBackground> background = new BetSlider::ImageBackground();
   CHECK( NULL != background.get() );
   TEST_RES( ImageBackground object is null );

   osgDB::Registry::instance()->getDataFilePathList().push_front( getsrcdir() + "data/" );
   osg::ref_ptr<osgDB::ReaderWriter::Options> opt = new osgDB::ReaderWriter::Options;

   TEST_INIT( ImageBackground::stretch );
   osgDB::Registry::instance()->getDataFilePathList().push_front( getsrcdir() + "../../examples/poker/data/" );

   osg::ref_ptr<BetSlider::BetSlider> sliderImg  = dynamic_cast<betslider::BetSlider*>( osgDB::readNodeFile( "default.betslider" ) );
   CHECK( NULL != sliderImg.get() );
   TEST_RES( sliderImage object is null : failed to load default.betslider );

   BetSlider::Background* bgImg = sliderImg->getBackground();
   bgImg->stretch( 2.0f, 3.0f, 4.0f );

   // note : how to test stretch success ?
   TEST_RES( _background_color does not contains expected value  );

}

TEST( RowBackground )
{
   TEST_INIT( RowBackground::RowBackground );
   osg::ref_ptr<BetSlider::RowBackground> background = new BetSlider::RowBackground();
   CHECK ( NULL != background.get() );
   TEST_RES( RowBackground object is null );

   TEST_INIT( RowBackground::update );
   background->update( osg::Vec2( 0.0f, 0.0f ) , osg::Vec2( 1.0f, 1.0f ) ); 
   TEST_RES( -update error- ); 

}

TEST( BetSlider_Creation )
{
   if ( !( verbose & VERBOSE_ALL ) )
      osg::setNotifyLevel( osg::ALWAYS );

   osgDB::Registry::instance()->getDataFilePathList().push_front( getsrcdir() + "../../examples/poker/data" );

   TEST_INIT( creating BetSlider from file with BG image );
   osg::ref_ptr<BetSlider> sliderImg  = dynamic_cast<BetSlider*>( osgDB::readNodeFile( "default.betslider" ) );
   CHECK( NULL != sliderImg.get() );
   TEST_RES(BetSlider creation failed (BGimg) );

   TEST_INIT( creating BetSlider from file with BG rectangle );
   osg::ref_ptr<BetSlider> sliderRec  = dynamic_cast<BetSlider*>( osgDB::readNodeFile( "data/rect.betslider" ) );
   CHECK( NULL != sliderRec.get() );
   TEST_RES( BetSlider creation failed (BGrect) );

}

TEST( BetSlider_Destruction )
{
   TEST_INIT( BetSlider destruction );
   osg::ref_ptr<BetSlider::BetSlider> slider = new BetSlider();
   slider = 0;
   CHECK( NULL == slider.get() );
   TEST_RES( BetSlider destruction failed );
}

TEST( BetSlider_setFont )
{
   TEST_INIT( BetSlider::setFont );

   osg::ref_ptr<BetSlider::BetSlider> slider = new BetSlider();

   float new_fontsize = slider->_font_size[0] + 0.5f;   
   osg::ref_ptr<osgText::Font> font = new osgText::Font;

   slider->setFont( -1, font.get() , new_fontsize);
   slider->setFont(  0, font.get() , new_fontsize);

   CHECK_EQUAL( new_fontsize, slider->_font_size[0] );
   TEST_RES( setFont seems not working );

}

TEST( BetSlider_setNormalColor )
{
   TEST_INIT( BetSlider::setNormalColor );

   osg::ref_ptr<BetSlider::BetSlider> slider = new BetSlider();

   slider->setNormalColor( -1,  0, osg::Vec4f( 0.1f, 0.2f, 0.3f, 0.4f ));   
   slider->setNormalColor(  0, -1, osg::Vec4f( 0.1f, 0.2f, 0.3f, 0.4f ));   
   slider->setNormalColor(  1,  1, osg::Vec4f( 0.1f, 0.2f, 0.3f, 0.4f ));

   // note : how to test setNormalColor success ?
   TEST_RES( setNormalColor error msg );
}

TEST( BetSlider_setSelectedColor )
{
   TEST_INIT( BetSlider::setSelectedColor );

   osg::ref_ptr<BetSlider::BetSlider> slider = new BetSlider();
   slider->setSelectedColor( -1,  0, osg::Vec4f( 0.1f, 0.2f, 0.3f, 0.4f ));
   slider->setSelectedColor(  0, -1, osg::Vec4f( 0.1f, 0.2f, 0.3f, 0.4f ));
   slider->setSelectedColor(  1,  1, osg::Vec4f( 0.1f, 0.2f, 0.3f, 0.4f ));

   // note : how to test setSelectedColor success ?
   TEST_RES( setSelectedColor error msg );
}

TEST( BetSlider_setRowBackground )
{
   TEST_INIT( BetSlider::setRowBackground );

   osg::ref_ptr<BetSlider::BetSlider> slider = new BetSlider();
   osg::ref_ptr<BetSlider::RowBackground> background = new BetSlider::RowBackground();      

   slider->setRowBackground( -1,  0, background.get() );
   slider->setRowBackground(  0, -1, background.get() );
   slider->setRowBackground(  1,  1, background.get() );

   // note : how to test setRowBackground success ?
   TEST_RES( setRowBackground error msg );
}

TEST( BetSlider_setSeparator )
{
   TEST_INIT( BetSlider::setSeparator );

   osg::ref_ptr<BetSlider::BetSlider> slider = new BetSlider();
   slider->setLimits(  0, 20, 1000,    20,  2000, 5);
  
   slider->setSeparator( new osg::Geode );

   osg::ref_ptr<osg::Geode> geode = new osg::Geode;
   osg::ref_ptr<osg::StateSet> state = new osg::StateSet;

   state->setMode( GL_LIGHTING, osg::StateAttribute::OFF );
   osg::ref_ptr<osg::Geometry> geometry = new osg::Geometry;
   geometry->setStateSet( state.get() );

   osg::ref_ptr<osg::Vec3Array> vertexes = new osg::Vec3Array( 4 );
   (*vertexes)[0].set(-1, -1, 0.f);
   (*vertexes)[1].set( 1, -1, 0.f);
   (*vertexes)[2].set( 1,  1, 0.f);
   (*vertexes)[3].set(-1,  1, 0.f);
   geometry->setVertexArray( vertexes.get() );

   geometry->addPrimitiveSet( new osg::DrawArrays( osg::PrimitiveSet::QUADS, 0, 4 ) );

   geode->addDrawable( geometry.get() );

   slider->setSeparator( geode.get() );

   // note : how to test setSeparator success ?
   TEST_RES( setSeparator error msg );
}

TEST( BetSlider_setCursor )
{
   TEST_INIT( BetSlider::setCursor );

   osg::ref_ptr<BetSlider::BetSlider> slider = new BetSlider();   
   slider->setCursor( new osg::Geode );

   // note : how to test setCursor success ?
   TEST_RES( setCursor error msg );
}

TEST( BetSlider_setMotorFixedLength )
{
   TEST_INIT( BetSlider::setMotorFixedLength );
   
   osg::ref_ptr<BetSlider::BetSlider> slider = new BetSlider();
   float new_mfl = slider->_motor_fixed_length + 0.5f;   
   slider->setMotorFixedLength( new_mfl );

   CHECK_EQUAL( new_mfl, slider->_motor_fixed_length );
   TEST_RES( _motor_fixed_length has not the expected value );
}

TEST( BetSlider_setMotorVariableLength )
{
   TEST_INIT( BetSlider::setMotorVariableLength );
   
   osg::ref_ptr<BetSlider::BetSlider> slider = new BetSlider();
   float new_mvl = slider->_motor_variable_length + 0.5f;   
   slider->setMotorVariableLength( new_mvl );

   CHECK_EQUAL( new_mvl, slider->_motor_variable_length );
   TEST_RES( _motor_variable_length has not the expected value );
}

TEST( BetSlider_setCenterPad )
{
   TEST_INIT( BetSlider::setCenterPad );

   osg::ref_ptr<BetSlider> slider = dynamic_cast<BetSlider*>( osgDB::readNodeFile( "data/rect.betslider" ) );
   
   float pad = slider->_center_pad + 0.5f;   
   slider->setCenterPad( pad );

   CHECK_EQUAL( pad, slider->_center_pad );
   TEST_RES( _center_pad has not the expected value );

}

TEST( BetSlider_setBorderPad )
{
   TEST_INIT( BetSlider::setBorderPad );

   osg::ref_ptr<BetSlider::BetSlider> slider = new BetSlider();
   float pad = slider->_border_pad + 0.5f;   
   slider->setBorderPad( pad );

   CHECK_EQUAL( pad, slider->_border_pad );
   TEST_RES( _border_pad has not the expected value );
}

TEST( BetSlider_setLimits )
{
   TEST_INIT( BetSlider::setLimits );
   
   osg::ref_ptr<BetSlider> slider = dynamic_cast<BetSlider*>( osgDB::readNodeFile( "data/rect.betslider" ) );
  
   slider->setLimits(  5, 20, 1000,  2000,  2000, 5);
   slider->setLimits(  5, 20, 1000,  2000,  1000, 5);
   slider->setLimits(  5, 20, 1000,  1000,  1000, 5); 
   slider->setLimits(  5, 20, 2000,   500,  1000, 5);
   slider->setLimits(  5, 20, 1000,    15,  1000, 5); 
   slider->setLimits(  0, 20, 1000,  2000,  2000, 5);
   slider->setLimits(  0, 20, 1000,    20,  2000, 5);

   // note : how to test setLimits success ?
   TEST_RES( setLimits error msg );
}

TEST( BetSlider_moveCursor )
{
   TEST_INIT( BetSlider::moveCursor );

   osg::ref_ptr<BetSlider> slider = dynamic_cast<BetSlider*>( osgDB::readNodeFile( "data/rect.betslider" ) );

   int v0 = slider->moveCursor( 1.f);

   slider-> setLimits(5, 20, 1000, 2000, 2000, 5);

   int v1 = slider->moveCursor( -1.f);
   int v2 = slider->moveCursor( 0.3f);
   int v3 = slider->moveCursor( 0.3f);
   int v4 = slider->moveCursor(  3.f);
   int v5 = slider->moveCursor(-0.1f);

   slider->setLimits(  5, 20, 1000,  1000,  1000, 5);
   
   int v6 = slider->moveCursor( 0.5f);

   CHECK_EQUAL(    0, v0 );
   CHECK_EQUAL(    0, v1 );
   CHECK_EQUAL(   20, v2 );
   CHECK_EQUAL(  525, v3 );
   CHECK_EQUAL( 1000, v4 );
   CHECK_EQUAL( 1000, v5 );
   CHECK_EQUAL(  345, v6 );

   TEST_RES( moveCursor return unexpected value );
}


TEST( BetSlider_getCurrentValue )
{
   TEST_INIT( BetSlider::getCurrentValue );

   osg::ref_ptr<BetSlider::BetSlider> slider = new BetSlider();
   int return_getCurrentValue = slider->getCurrentValue();
   CHECK_EQUAL( 0, return_getCurrentValue);

   slider-> setLimits(5, 20, 1000, 2000, 2000, 5);

   return_getCurrentValue = slider->getCurrentValue();
   CHECK_EQUAL( 0, return_getCurrentValue);

   slider->moveCursor( 0.09f );
   return_getCurrentValue = slider->getCurrentValue();
   CHECK_EQUAL( 20, return_getCurrentValue);

   TEST_RES( getCurrentValue return unexpected value );
}

TEST( BetSlider_getCurrentIndex )
{
   TEST_INIT( BetSlider::getCurrentIndex );
   osg::ref_ptr<BetSlider::BetSlider> slider = new BetSlider();

   int return_getCurrentIndex = slider->getCurrentIndex();
   CHECK_EQUAL( 7, return_getCurrentIndex );

   slider-> setLimits(5, 20, 1000, 2000, 2000, 5);
   
   return_getCurrentIndex = slider->getCurrentIndex();
   CHECK_EQUAL( 0, return_getCurrentIndex );

   slider->moveCursor( 0.09f );
   return_getCurrentIndex = slider->getCurrentIndex();
   CHECK_EQUAL( 2, return_getCurrentIndex );

   slider->moveCursor( 0.1f );
   return_getCurrentIndex = slider->getCurrentIndex();
   CHECK_EQUAL( 4, return_getCurrentIndex );

   TEST_RES( getCurrentIndex return unexpected value );
}

TEST( BetSlider_getBackground )
{
   TEST_INIT( BetSlider::getBackground );

   osg::ref_ptr<BetSlider::BetSlider> slider = new BetSlider();
   BetSlider::Background* bg = slider->getBackground();

   CHECK( NULL != bg );
   TEST_RES( null returned from getBackground  );
}

TEST( BetSlider_replaceBackground )
{
   TEST_INIT( BetSlider::replaceBackground );

   osg::ref_ptr<BetSlider::BetSlider>  slider = new BetSlider();
   osg::ref_ptr<BetSlider::Background> background = new BetSlider::ImageBackground();

   int type_slidBg = ( slider->getBackground() )->getType();
   int type_newBg  = background->getType();

   if( type_newBg == type_slidBg ) {
      background = new BetSlider::RectangleBackground();
      type_newBg = background->getType();
   }

   slider->replaceBackground( background.get() );
   type_slidBg = ( slider->getBackground() )->getType();

   CHECK_EQUAL( type_newBg, type_slidBg );
   TEST_RES( _background seems not changed );
}

TEST( BetSlider_unserialize )
{

   if ( !( verbose & VERBOSE_ALL ) )
      osg::setNotifyLevel( osg::ALWAYS );

   osg::ref_ptr<BetSlider::BetSlider> slider = new BetSlider();
   
   TEST_INIT( BetSlider::unserialize );

   bool unserialize_return = slider->unserialize( "", NULL );
   CHECK( !unserialize_return );   

   unserialize_return = slider->unserialize( getsrcdir() + "data/rect.betslider", NULL );
   CHECK( unserialize_return );

   LIBXML_TEST_VERSION
   xmlDocPtr doc;
   doc = xmlReadFile( (getsrcdir() + "data/rect.betslider").c_str(), NULL, XML_PARSE_NOERROR );
   unserialize_return = slider->unserialize( doc, NULL );
   xmlFreeDoc(doc);
   xmlCleanupParser();
   CHECK( unserialize_return );

   unserialize_return = slider->unserialize( NULL, NULL );
   CHECK( !unserialize_return );

   TEST_RES( unserialize failed );

}

TEST( BetSlider_serialize )
{
   osg::ref_ptr<BetSlider::BetSlider> slider = new BetSlider();

   TEST_INIT( BetSlider::serialize );
   bool serialize_return = slider->serialize( "serialize.BetSliderTest" );
   CHECK( serialize_return );
   TEST_RES( serialize failed );
}

TEST( BetSlider_wrongfile )
{

   if ( !( verbose & VERBOSE_ALL ) )
      osg::setNotifyLevel( osg::ALWAYS );

   TEST_INIT( BetSlider with wrongfile );

   osgDB::Registry::instance()->getDataFilePathList().push_front( getsrcdir() + "data" );
   osg::ref_ptr<BetSlider> slider  = dynamic_cast<BetSlider*>( osgDB::readNodeFile( "wrong.betslider" ) );

   CHECK( NULL != slider.get() );
   TEST_RES( error loading a wrong file );

}

TEST( BetSlider_clone )
{

   TEST_INIT( BetSlider clone );

   osg::ref_ptr<BetSlider> slider = new BetSlider();
   osg::ref_ptr<BetSlider> clone  = dynamic_cast<BetSlider*>(slider->clone(osg::CopyOp::SHALLOW_COPY));
   CHECK( NULL != clone.get() );
   TEST_RES( error : objetc not destroyed );

}

TEST( BetSlider_protected )
{
   osg::ref_ptr<BetSliderXtend> x = new BetSliderXtend();

   TEST_INIT( BetSlider::Build_ChildTest );
   x->checkBuildTest();
   TEST_RES( ... );

   TEST_INIT( Row::SetSeparator_ArgsTest );
   x->checkRowSetSeparatorArgs();
   TEST_RES( ... );

   TEST_INIT( UpdateCursor_MotorPositionTest );
   x->checkUpdateCursor_MotorPositionTest();
   TEST_RES( ... );

}

TEST( BetSlider_allin )
{
  TEST_INIT( BetSlider allin );
  osg::ref_ptr<BetSlider> slider = dynamic_cast<BetSlider*>( osgDB::readNodeFile( getsrcdir() + "data/rect.betslider" ) );
  unsigned int call = 0;
  unsigned int raise = 100;
  unsigned int raise_max = 46540;
  unsigned int all_in = 46540;
  unsigned int pot = 400;
  unsigned int step = 100;
  slider->setLimits(call, raise, raise_max, all_in, pot, step);  
  unsigned int value = slider->moveCursor(1.0f);
  CHECK_EQUAL(46540u, value);
  value = slider->getCurrentValue();
  CHECK_EQUAL(46540u, value);
  TEST_RES( error BetSlider allin value rounded );
}

}
