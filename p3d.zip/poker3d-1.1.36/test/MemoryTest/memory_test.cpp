
#include "memory_test.h"

#include <PokerApplication.h>

#include <cal3d/coreanimation.h>
#include <cal3d/corekeyframe.h>
#include <cal3d/coretrack.h>

unsigned get_memory_usage(std::ostream &_out, PokerApplication *_app, const std::string &_prefix)
{
	unsigned size = 0;

	{
		std::list<std::string>::iterator it = _app->mLevelList.begin();
		for ( ; it != _app->mLevelList.end(); ++it) {
			//std::string &str = it.
		}
		unsigned siz = _app->mLevelList.size();
		for (unsigned i = 0; i < size; i++) {
			//size += _app->mLevelList[i].size();
		}
	}

	return size;
}

unsigned get_memory_usage(std::ostream &_out, CalCoreAnimation *_anim, const std::string &_prefix)
{
	unsigned size = 0;

	size += sizeof(CalCoreAnimation);

	{
		std::list<CalCoreTrack*> &coreTracks =  _anim->getListCoreTrack();
		std::list<CalCoreTrack *>::iterator it = coreTracks.begin();
		for ( ; it != coreTracks.end(); ++it) {
			CalCoreTrack *track = (*it);
			size += get_memory_usage(_out, track, _prefix);
		}
	}

	return size;
}

unsigned get_memory_usage(std::ostream &_out, CalCoreTrack *_track, const std::string &_prefix)
{
	unsigned size = 0;

	size += sizeof(CalCoreTrack);
	int nbKF = _track->getCoreKeyframeCount();
	for (int i = 0; i < nbKF; i++) {
		CalCoreKeyframe *kf = _track->getCoreKeyframe(i);
		size += get_memory_usage(_out, kf, _prefix);
	}

	return size;
}

unsigned get_memory_usage(std::ostream &_out, CalCoreKeyframe *_kf, const std::string &_prefix)
{
	unsigned size = 0;
	size += sizeof(CalCoreKeyframe);
	return size;
}
