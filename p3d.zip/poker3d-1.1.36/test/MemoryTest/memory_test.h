
#ifndef MEMORY_TEST_H
#define MEMORY_TEST_H

#include <ostream>

class PokerApplication;
class CalCoreAnimation;
class CalCoreTrack;
class CalCoreKeyframe;

unsigned get_memory_usage(std::ostream &out, PokerApplication *, const std::string &prefix);
unsigned get_memory_usage(std::ostream &out, CalCoreAnimation *, const std::string &prefix);
unsigned get_memory_usage(std::ostream &out, CalCoreTrack *, const std::string &prefix);
unsigned get_memory_usage(std::ostream &out, CalCoreKeyframe *, const std::string &prefix);

/*
template<typename T>
unsigned get_memory_usage(const std::list<T> &_list)
{
}
*/

#endif
