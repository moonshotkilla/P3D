/* (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 */

#include <UnitTest++.h>

#include <PokerEvent.h>
#include <Poker.h>
#include <maf/window.h>
#include <maf/renderbin.h>
#include <map>

#ifdef WIN32
#undef main
#endif

void PokerMoveChips::Update(PokerApplication* game,PokerPotController* potcenter) {}
void PokerMoveChips::PlayerLeave(int) {}
void PokerMoveChips::PokerPotChips(int, const std::vector<int>&) {}
void PokerMoveChips::PokerChipsBet2Pot(int, int, const std::vector<int> &) {}
template<> void PokerMoveChips::GameAccept<PokerEventPlayerFold>(const PokerEventPlayerFold& event){}
template<> void PokerMoveChips::GameAccept<PokerEventPlayerLeave>(const PokerEventPlayerLeave& event){}
template<> void PokerMoveChips::GameAccept<PokerEventPotChips>(const PokerEventPotChips& event){}
template<> void PokerMoveChips::GameAccept<PokerEventChipsBet2Pot>(const PokerEventChipsBet2Pot& event){}
template<> void PokerMoveChips::GameAccept<PokerEventChipsPot2Player>(const PokerEventChipsPot2Player& event){}
template<> void PokerMoveChips::GameAccept<PokerEventSwitchToExistingTable>(const PokerEventSwitchToExistingTable& event){}
template<> void PokerMoveChips::GameAccept<PokerEventGameStart>(const PokerEventGameStart& event) {}
template<> void PokerMoveChips::GameAccept<PokerEventEndRound>(const PokerEventEndRound& event) {}

void PokerMoveChips::PokerTrackActiveMoveChips::ClearEntries(unsigned int) {}
PokerMoveChips::PokerMoveChips(std::map<guint,osg::ref_ptr<PokerPlayer> >& serial):mSerial2Player(serial) {}
void PokerMoveChips::PlayerFold(int serial) {}
void PokerMoveChips::PokerTrackActiveMoveChips::ClearAllEntries() {}
bool PokerMoveChips::IsAnyChipsToMoveToPotFromPlayer(int) { return false;}
void PokerMoveChips::SortStack(std::vector<PokerMoveChipsCommand>& stackToSort,bool toPlayer) {}
osg::Matrixf MAFBuildShadowMatrix(const osg::Plane &, const osg::Vec4f &)
{
	osg::Matrixf t;
	return t;
}

void MAFCreateNodePath(osg::Node*, osg::NodePath &, int)
{
}

void RecursiveClearUserData(osg::Node *)
{
}

osg::Matrixd MAFComputeLocalToWorld(osg::Node* src, int parentValidMask, int nodeMaskExclude, int nodeMaskStop)
{
	osg::Matrixd m;
	return m;
}

std::string MAFformat_amount(unsigned int amount, bool bAdvancedFormat)
{
	return 0;
}

osg::Geode* GetGeode(osg::Node *)
{
	return 0;
}

class MAFPacket {
public:
	void GetMember(const std::string& name, std::string& value) const;
  void GetMember(const std::string& name, std::vector<int>& values) const;
  void GetMember(const std::string& name, long& value) const;
  void GetMember(const std::string& name, double& value) const;

	void SetMember(const std::string& name, long value);

  bool IsType(const std::string& name) const;
};

void MAFPacket::GetMember(const std::string& name, std::string& value) const
{
}

void MAFPacket::GetMember(const std::string& name, std::vector<int>& values) const
{
}

void MAFPacket::GetMember(const std::string& name, long& value) const
{
}

void MAFPacket::GetMember(const std::string& name, double& value) const
{
}

void MAFPacket::SetMember(const std::string& name, long value)
{
}

MAFCameraModel::MAFCameraModel()
{
}

MAFCameraModel::~MAFCameraModel()
{
}

class PokerPlayer : public osg::Referenced {
public:
  void HasRunAnimationBet(bool);

	PokerPlayer(PokerApplication *game, unsigned int tableId, bool me, const std::string &skinUrl, const std::string &skinOutfit);
	void SetSeatId(int);
	void SetBet(const std::vector<int>& amount);
	PokerMoveChipsBet2PotController* GetFreeAnimationBet2Pot();
	PokerMoveChipsPot2PlayerController* GetFreeAnimationPot2Player();
	void EnableSound();
	void DisableSound();
	void DisplayBetStack(bool);
	void WriteFadeText(const std::string &);
  void DisplayChipsOfBetAnimation(bool state);
	void SetValueChipsOfBetAnimation(const std::vector<int>& chips);
	void HideCard(int);
	void DisplayShadowStacks(const std::string &style);
	void SetTextMessage(const std::string &msg);
	void SetName(const std::string &name);
	void InPosition();
	void LostPosition();
	void LookAt(PokerPlayer *);
	void BetLimits(int, int, int, int, int, int);
	bool HasEmptyHoleCards();
	void SetHoleCards(const std::vector<int> &cards);
	void ShowCard(int);
	void SetPocketCards(const std::vector<int> &cards);
	void SetMoney(const std::vector<int> &amount);
	void DisableWarningTimer();
	void SetPlayerCameraToFreeMode();
	void FoldHoleCards();
	void SetSit(bool);
	void SetInGame(bool);
	void NoCards();
	void SyncBetStackWithPacket(bool);
	void TimeoutAdvise(float);
	int GetNbCardsDisplayed();
	void HideAnimateCard(int);
	osg::MatrixTransform* GetAnimationCard(int);
	void AnimateCard(int);
	unsigned int GetBetValue(bool &);
	void ResetBetValue();
	MAFAudioSourceController* GetSoundSource();
};

void PokerPlayer::HasRunAnimationBet(bool) {}


PokerPlayer::PokerPlayer(PokerApplication *game, unsigned int tableId, bool me, const std::string &skinUrl, const std::string &skinOutfit)
{
}

void PokerPlayer::SetSeatId(int)
{
}

void PokerPlayer::SetBet(const std::vector<int>& amount)
{
}

PokerMoveChipsBet2PotController* PokerPlayer::GetFreeAnimationBet2Pot()
{
	return 0;
}

PokerMoveChipsPot2PlayerController* PokerPlayer::GetFreeAnimationPot2Player()
{
	return 0;
}

void PokerPlayer::EnableSound()
{
}

void PokerPlayer::DisableSound()
{
}

void PokerPlayer::DisplayBetStack(bool)
{
}

void PokerPlayer::WriteFadeText(const std::string &)
{
}

void PokerPlayer::DisplayChipsOfBetAnimation(bool state)
{
}

void PokerPlayer::SetValueChipsOfBetAnimation(const std::vector<int>& chips)
{
}

void PokerPlayer::HideCard(int)
{
}

void PokerPlayer::DisplayShadowStacks(const std::string &style)
{
}

void PokerPlayer::SetTextMessage(const std::string &msg)
{
}

void PokerPlayer::SetName(const std::string &name)
{
}

void PokerPlayer::InPosition()
{
}

void PokerPlayer::LostPosition()
{
}

void PokerPlayer::LookAt(PokerPlayer *)
{
}

void PokerPlayer::BetLimits(int, int, int, int, int, int)
{
}

bool PokerPlayer::HasEmptyHoleCards()
{
	return true;
}

void PokerPlayer::SetHoleCards(const std::vector<int> &cards)
{
}

void PokerPlayer::ShowCard(int)
{
}

void PokerPlayer::SetPocketCards(const std::vector<int> &cards)
{
}

void PokerPlayer::SetMoney(const std::vector<int> &amount)
{
}

void PokerPlayer::DisableWarningTimer()
{
}

void PokerPlayer::SetPlayerCameraToFreeMode()
{
}

void PokerPlayer::FoldHoleCards()
{
}

void PokerPlayer::SetSit(bool)
{
}

void PokerPlayer::SetInGame(bool)
{
}

void PokerPlayer::NoCards()
{
}

void PokerPlayer::SyncBetStackWithPacket(bool)
{
}

void PokerPlayer::TimeoutAdvise(float)
{
}

int PokerPlayer::GetNbCardsDisplayed()
{
	return 0;
}

void PokerPlayer::HideAnimateCard(int)
{
}

osg::MatrixTransform* PokerPlayer::GetAnimationCard(int)
{
	return 0;
}

void PokerPlayer::AnimateCard(int)
{
}

unsigned int PokerPlayer::GetBetValue(bool &)
{
	return 0;
}

void PokerPlayer::ResetBetValue()
{
}

class PokerHUD : public osg::Group {
public:
	PokerHUD();
	~PokerHUD();

	void Load(_xmlDoc* doc, const std::string& path, unsigned int width, unsigned int height, const std::string& dataDir);
	void Hide(unsigned int);
	void Show(unsigned int);
	void UpdatePosition(float, unsigned int);
};

PokerHUD::PokerHUD()
{
}

PokerHUD::~PokerHUD()
{
}

void PokerHUD::Load(_xmlDoc* doc, const std::string& path, unsigned int width, unsigned int height, const std::string& dataDir)
{
}

void PokerHUD::Hide(unsigned int)
{
}

void PokerHUD::Show(unsigned int)
{
}

void PokerHUD::UpdatePosition(float, unsigned int)
{
}

class PokerHUDController : osg::Referenced {
public:
	PokerHUDController(PokerHUD *);
	~PokerHUDController();

  void PythonAccept(const MAFPacket& packet, const std::map<int, unsigned int>& serial2seat);
};

PokerHUDController::PokerHUDController(PokerHUD *)
{
}

PokerHUDController::~PokerHUDController()
{
}

void PokerHUDController::PythonAccept(const MAFPacket& packet, const std::map<int, unsigned int>& serial2seat)
{
}


MAFController::~MAFController()
{
}

void MAFController::Init()
{
}

class MAFPacketsModule {
public:
	MAFPacket* Create(const std::string& pyclass);
};

MAFPacket* MAFPacketsModule::Create(const std::string& pyclass)
{
	return 0;
}

void MAFApplication::Quit(int)
{
}

TextureManager* MAFApplication::GetTextureManager()
{
	return 0;
}

bool MAFApplication::LockMouse(MAFController *)
{
	return true;
}

void MAFApplication::PythonCall(PyObject *instance, const std::string  &method, MAFPacket *packet)
{
}

void MAFApplication::ReportControllers()
{
}

void MAFApplication::UnlockMouse(MAFController *)
{
}

SDL_Event* MAFApplication::GetLastEvent(MAFController *) const
{
	return 0;
}

SDL_Event* MAFApplication::GetLastEventIgnoreLocking() const
{
	return 0;
}

MAFPacketsModule* MAFApplication::GetPacketsModule()
{
	return 0;
}

void MAFApplication::SendPythonEvent(const std::string &event, const std::map<std::string,std::string>& map)
{
}

void MAFApplication::SetActiveController(unsigned int)
{
}

void MAFApplication::RemoveController(MAFController *)
{
}

void MAFApplication::AddController(MAFController *)
{
}

MAFApplication::MAFApplication()
{
}

MAFApplication::~MAFApplication()
{
}

void MAFApplication::Exit(int)
{
}

void MAFCameraController::Init()
{
}
PokerCameraController::~PokerCameraController()
{
}

void PokerCameraController::Init()
{
}

void PokerCameraController::RotateFreeMode(float, float, float)
{
}

void PokerCameraController::SetRespondToEvents(bool)
{
}

bool PokerCameraController::Update(MAFApplication *)
{
	return true;
}

PokerCameraModel::PokerCameraModel()
{
}

PokerCameraModel::~PokerCameraModel()
{
}

void MAFAudioController::AttachTo(osg::Group *)
{
}

void MAFAudioController::Init()
{
}

void MAFAudioController::Play()
{
}

MAFAudioModel::MAFAudioModel()
{
}

MAFAudioModel::~MAFAudioModel()
{
}

void MAFAudioModel::Init()
{
}

void MAFAudioModel::SetReferenceDistance(float)
{
}

void MAFAudioModel::SetAmbient(bool)
{
}

void MAFAudioModel::SetRolloff(float)
{
}

void MAFAudioModel::SetGain(float)
{
}

void MAFAudioModel::SetData(MAFAudioData *)
{
}

void MAFAudioModel::SetName(const std::string&)
{
}

class MAFMonitor;

std::string MAFRepositoryData::mLevel = "";
//std::string MAFRepositoryData::mDirectoryBase="";

MAFAudioData* MAFRepositoryData::GetAudio(const std::string& name, MAFMonitor *)
{
	return 0;
}
bool MAFOSGData::Load(const std::string& path, osgDB::ReaderWriter::Options* options)
{
	return false;
}

struct PokerBubbleManager {
public:
	PokerBubbleManager();
	virtual ~PokerBubbleManager();
	void Init(PokerApplication *);
	virtual bool Update(MAFApplication *);
	void Finit();
	template <typename T> void GameAccept(const T&);
};

PokerBubbleManager::PokerBubbleManager()
{
}

PokerBubbleManager::~PokerBubbleManager()
{
}

void PokerBubbleManager::Init(PokerApplication *)
{
}

bool PokerBubbleManager::Update(MAFApplication *)
{
	return true;
}

void PokerBubbleManager::Finit()
{
}

template <> void PokerBubbleManager::GameAccept<PokerEventStartFirstPerson>(const PokerEventStartFirstPerson&){}
template <> void PokerBubbleManager::GameAccept<PokerEventEndLeaveFirstPerson>(const PokerEventEndLeaveFirstPerson&){}

PokerDoorController::PokerDoorController(unsigned int)
{
}

PokerDoorController::~PokerDoorController()
{
}

void PokerDoorController::Init(PokerApplication *game, const std::string &path)
{
}

bool PokerDoorController::Update(MAFApplication *)
{
	return true;
}

PokerPotController::PokerPotController(PokerApplication *, unsigned int)
{
}

PokerPotController::~PokerPotController()
{
}

void PokerPotController::FreezeCenter()
{
}

void PokerPotController::UnFreezeCenter()
{
}

void PokerPotController::ResetPots()
{
}

float PokerPotController::BuildAnimationPotToPlayer(PokerMoveChipsPot2PlayerController* animation,int pot)
{
	return 0.0f;
}

bool PokerPotController::Update(MAFApplication *)
{
	return true;
}

PokerSeatManager::PokerSeatManager(unsigned int)
{
}

PokerSeatManager::~PokerSeatManager()
{
}

void PokerSeatManager::Init(PokerApplication *)
{
}

bool PokerSeatManager::Update(MAFApplication *)
{
	return true;
}

void PokerSeatManager::MainPlayerArrive(const std::vector<guint> &seats)
{
}

void PokerSeatManager::MainPlayerLeave(const std::vector<guint> &seat2serial)
{
}

void PokerSeatManager::PlayerLeave(unsigned int)
{
}

void PokerSeatManager::PlayerSeated(unsigned int)
{
}

void PokerSeatManager::MainPlayerSitOut()
{
}

void PokerSeatManager::MainPlayerSit()
{
}

void PokerSeatManager::DisableAllSeats()
{
}

void PokerSeatManager::SetSeats(const std::vector<int> &seats)
{
}

class PokerBoardController : public osg::Referenced {
public:
	PokerBoardController(PokerApplication *, unsigned int);
	void EnableSound();
	void DisableSound();
	void SetCards(const std::vector<int> &_cards);
	bool StartToDisplayShowDown(PokerPlayer *);
	bool StopToDisplayShowDown();
	void FoldCards();
};

PokerBoardController::PokerBoardController(PokerApplication *, unsigned int)
{
}

void PokerBoardController::EnableSound()
{
}

void PokerBoardController::DisableSound()
{
}

void PokerBoardController::SetCards(const std::vector<int> &_cards)
{
}

bool PokerBoardController::StartToDisplayShowDown(PokerPlayer *)
{
	return true;
}

bool PokerBoardController::StopToDisplayShowDown()
{
	return true;
}

void PokerBoardController::FoldCards()
{
}

void PokerMoveChipsBet2PotController::StartAnimation()
{
}

void PokerChipsStackController::SetChips(const std::vector<int>& chips)
{
}

void PokerChipsStackController::MoveSlider(PokerApplication *, float x, float y)
{
}

void PokerChipsStackController::UninstallSlider(PokerApplication *)
{
}

void PokerChipsStackController::InstallSlider(PokerApplication *)
{
}

PokerChipsStackModel::PokerChipsStackModel(class PokerApplication* game)
{
}
PokerChipsStackModel::~PokerChipsStackModel()
{
}

float PokerPotController::BuildAnimationBetToPot(PokerMoveChipsBet2PotController* animation, int pot)
{
	return 0.0f;
}

void PokerPotController::SetPotValue(const std::vector<int>& value,int index)
{
}

class PokerSceneView {
public:
	static PokerSceneView *getInstance();
	void addDrawableThatStayInColor(osg::Drawable *, int orgRenderBin, int renderBinToUse, const std::string &renderName, int flags);
	void showActivateButton(bool);
};

PokerSceneView* PokerSceneView::getInstance()
{
	return 0;
}

void PokerSceneView::addDrawableThatStayInColor(osg::Drawable *, int orgRenderBin, int renderBinToUse, const std::string &renderName, int flags)
{
}

void PokerSceneView::showActivateButton(bool)
{
}

void MAFSceneController::HUDInsert(MAFVisionController *)
{
}

void MAFSceneController::HUDRemove(MAFVisionController *)
{
}

void MAFSceneController::Init()
{
}

bool MAFSceneController::Update(MAFApplication*)
{
  return false;
}

MAFSceneModel::~MAFSceneModel()
{
}
void MAFSceneModel::Init()
{
}

void MAFSceneView::Init( void )
{
}
void MAFSceneView::Update(MAFWindow *)
{
}

void MAFApplication2DController::ReleaseFocus()
{
}

void MAFApplication2DController::ShowWindow(const std::string &windowName, bool bshow)
{
}

std::map<std::string, MAFApplication2DAnimate*>& MAFApplication2DController::GetName2Animate()
{
	static std::map<std::string, MAFApplication2DAnimate*> toto;
	return toto;
}

void MAFApplication2DModel::Init()
{
}

PokerSplashScreenController::PokerSplashScreenController(PokerApplication *)
{
}

PokerSplashScreenController::~PokerSplashScreenController()
{
}

bool PokerSplashScreenController::Update(PokerApplication *)
{
	return true;
}

PokerSplashScreenModel::PokerSplashScreenModel(PokerApplication*)
{
}
PokerSplashScreenModel::~PokerSplashScreenModel()
{
}

void PokerSplashScreenModel::write(const char *)
{
}
void PokerSplashScreenModel::setProgressLength(int len)
{
}
void PokerSplashScreenModel::progress()
{
}

class MAFApplication2DSlide {
public:
	MAFApplication2DSlide();
	virtual ~MAFApplication2DSlide();
	void SetMouseTrigger(bool);
};

MAFApplication2DSlide::MAFApplication2DSlide()
{
}
MAFApplication2DSlide::~MAFApplication2DSlide()
{
}
void MAFApplication2DSlide::SetMouseTrigger(bool)
{
}

class PokerMultiTable : public osg::Referenced {
public:
	void ShowButton(bool);
};

void PokerMultiTable::ShowButton(bool)
{
}

namespace osgCal { class Model; }

class UGAMEAnimatedModel {
public:
	osgCal::Model* GetOsgCalModel();
};

osgCal::Model* UGAMEAnimatedModel::GetOsgCalModel()
{
	return 0;
}

class PokerBodyModel {
public:
	void PlayFold(const std::string &foldAnimation);
	void PlayFacialNoise();
	void StopFacialNoise();
};

void PokerBodyModel::PlayFold(const std::string &foldAnimation)
{
}

void PokerBodyModel::PlayFacialNoise()
{
}

void PokerBodyModel::StopFacialNoise()
{
}

class PokerInteractorBase {
public:
	void Accept(MAFPacket *);
	void SetText(const std::string &text);
};

void PokerInteractorBase::Accept(MAFPacket *)
{
}

void PokerInteractorBase::SetText(const std::string &text)
{
}

class PokerInteractorRaise {
public:
  bool CanInstallSlider() const;
};
bool PokerInteractorRaise::CanInstallSlider() const
{
  return false;
}

class PokerShowdownController {
public:
	void TurnProjectorOn();
	void SetWinner(const std::string &handval);
	void SetCards(const std::string &side, std::vector<int> values);
	void ResetWinner();
	void Reset();
	void EnableProjector();
	void DisableProjector();
};

void PokerShowdownController::TurnProjectorOn()
{
}

void PokerShowdownController::SetWinner(const std::string &handval)
{
}

void PokerShowdownController::SetCards(const std::string &side, std::vector<int> values)
{
}

void PokerShowdownController::ResetWinner()
{
}

void PokerShowdownController::Reset()
{
}

void PokerShowdownController::EnableProjector()
{
}

void PokerShowdownController::DisableProjector()
{
}

bool PokerDeck::HasKnownCards(const std::vector<int> &deck)
{
	return true;
}

osgText::Text* UGAMEBasicText::getText()
{
	return 0;
}

UGAMEArtefactController::~UGAMEArtefactController()
{
}

void UGAMEArtefactController::Displayed(bool)
{
}

void UGAMEArtefactController::Init()
{
}

bool UGAMEArtefactController::Update(MAFApplication *)
{
	return true;
}

void UGAMEArtefactController::Anchor(osg::Group *)
{
}

void UGAMEArtefactController::SetSelected(bool)
{
}

void UGAMEArtefactController::SetSelectable(bool b)
{
}

UGAMEArtefactModel::UGAMEArtefactModel()
{
}

void UGAMEArtefactModel::Init(void)
{
}

void MAFAudioSourceModel::Play(const std::string &name)
{
}

unsigned int PokerChipsStackModel::GetChipsAmount() const
{
	return 0;
}

void UGAMEShadowedText::setText(const osgText::String& str)
{
}

void UGAMEShadowedText::setText(const std::string& str)
{
}

class PokerCursor {
public:
	void WarpMouse(int x, int y);
};

void PokerCursor::WarpMouse(int x, int y)
{
}

namespace betslider {

	class BetSlider : public osg::Referenced {
	public:
		unsigned int getCurrentValue();
		unsigned int moveCursor(float delta);
	};

	unsigned int BetSlider::getCurrentValue()
	{
		return 0;
	}

	unsigned int BetSlider::moveCursor(float delta)
	{
		return 0;
	}

};

namespace osgchips {
	class ManagedStacks : public osg::Referenced {
	};
};

void TextureManager::Reload()
{
}

osg::Node* UGAMEArtefactModel::GetArtefact()
{
	return 0;
}

PokerSelectableController::PokerSelectableController(unsigned int)
{
}

PokerSelectableController::~PokerSelectableController()
{
}

void PokerSelectableController::Init(PokerApplication *)
{
}

bool PokerSelectableController::Update(MAFApplication *)
{
	return true;
}

namespace osg {

	class MultipleAnimationPathCallback {
	public:
		double getAnimationTime() const;
	};

	double MultipleAnimationPathCallback::getAnimationTime() const
	{
		return 0;
	}
};

osg::Geode* OSGHelper_getGeodeByName(osg::Group const&, std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&)
{
  return 0;
}

struct PokerApplication2D : public osg::Referenced
{};

PokerApplication::PokerApplication()
{
}
MAFApplication2DController* PokerApplication::GetInterface() { return 0;}

PokerApplication::~PokerApplication()
{
}
void PokerApplication::Init()
{
}
void PokerApplication::InterfaceReady()
{
}
void PokerApplication::ShowSplashScreen()
{
}
void PokerApplication::HideSplashScreen()
{
}
void PokerApplication::UpdateSplashScreen(float, char*)
{
}
const std::string& PokerApplication::SetLogPolicy()
{
	static std::string str;
	return str;
}
void PokerApplication::Crash()
{
}
bool PokerApplication::SetSoundEnabled(bool)
{
	return false;
}
bool PokerApplication::IsSoundEnabled()
{
	return false;
}
void PokerApplication::PythonAccept(_object*)
{
}
osg::Referenced* PokerApplication::SearchAnimated(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&)
{
	return 0;
}
osg::Referenced* PokerApplication::SearchPlayer(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&)
{
	return 0;
}
void PokerApplication::OnExit(int)
{
}
void PokerApplication::SendPacket(std::basic_string<char, std::char_traits<char>, std::allocator<char> > const&)
{
}

std::string MAFApplication::HeaderGet(const std::string& name, const std::string& path)
{
  if ("/sequence/seat/@count" == path) {
    return "10";
  }
  if ("/sequence/seat/@minTimeToDealCard" == path) {
    return "1.0";
  }
  return "dummy";
}

bool MAFPacket::IsType(const std::string& name) const
{
  return (name == "POKER_PLAYER_ARRIVE");
}


class MAFOSGDataMockup : public MAFOSGData {
public:
  MAFOSGDataMockup()
  {
    mGroup = new osg::Group();
  }
};

MAFVisionData* MAFRepositoryData::GetVision(const std::string& name, MAFMonitor *_mon)
{
  return new MAFOSGDataMockup();
}

MAFData* MAFOSGData::Clone(unsigned int cloneFlag)
{
  return new MAFOSGDataMockup();
}
osg::Node* GetNode(osg::Node* node, const std::string& name)
{
  return new osg::Node();
}

osg::Group* MAFOSGData::GetAnchor(const std::string&)
{
  return new osg::Group();
}

class MAFCameraModelMockup : public MAFCameraModel {
public:
  MAFCameraModelMockup() : MAFCameraModel()
  {
  }
};
class MAFCameraControllerMockup : public MAFCameraController {
public:
  MAFCameraControllerMockup() : MAFCameraController()
  {
    SetModel(new MAFCameraModelMockup());
  }
};

PokerCameraController::PokerCameraController(PokerApplication* game,unsigned int controllerID)
{
  SetModel(new PokerCameraModel());
}

MAFCameraController* MAFVisionData::GetCamera(const std::string& name)
{
  return new MAFCameraControllerMockup();
}

class MAFSceneModelMockup : public MAFSceneModel {
public:
  MAFSceneModelMockup() : MAFSceneModel()
  {
  }
};

class MAFSceneControllerMockup : public MAFSceneController {
public:
  MAFSceneControllerMockup() : MAFSceneController()
  {
    SetModel(new MAFSceneModelMockup());
  }
};

MAFWindow::MAFWindow()
{
}

MAFWindow::~MAFWindow()
{
}

MAFWindow* MAFApplication::GetWindow(bool)
{
  return new MAFWindow();
}

class PokerApplicationMockup : public PokerApplication {
public:
  std::map<std::string,xmlDocPtr> mHeadersMockup;
  PokerApplicationMockup() : PokerApplication()
  {    
    SetScene(new MAFSceneControllerMockup());
    mHeadersMockup["sequence"] = NULL;
    SetHeaders(mHeadersMockup);
  }
};

MAFAudioSourceModel::MAFAudioSourceModel()
{
}

void MAFAudioSourceController::Init()
{
}

class MAFAudioSourceControllerMockup : public MAFAudioSourceController {
public:
  MAFAudioSourceControllerMockup() : MAFAudioSourceController()
  {
  }
};

MAFAudioSourceController* PokerPlayer::GetSoundSource()
{
  return new MAFAudioSourceControllerMockup();
}

class PokerPlayerMockup : public PokerPlayer {
public:
  PokerPlayerMockup() : PokerPlayer(new PokerApplicationMockup(), 0, true, "", "")
  {
  }
};

class PokerModelMockup : public PokerModel {
public:
  PokerModelMockup() : PokerModel(new PokerApplicationMockup(), 0, "")
  {
    mSerial2Player[1] = new PokerPlayerMockup();
  }
};
class PokerControllerMockup : public PokerController {
public:
  PokerControllerMockup() : PokerController(new PokerApplicationMockup(), 0)
  {
    SetModel(new PokerModelMockup());
  }
};



class MAFRenderBinMockup : public MAFRenderBin
{
public:
  MAFRenderBinMockup() : MAFRenderBin()
  {
    std::pair<int, std::string> rbin;
    rbin.first = 0;
    rbin.second = "RenderBin";
    mName2rbin["HUDFirstPerson"] = rbin;
  }
};
extern MAFRenderBin *g_renderbin;

TEST(PythonAcceptPacketPlayerArrive)
{
  g_renderbin = new MAFRenderBinMockup();
  PokerControllerMockup poker;
  MAFPacket packet;
  poker.PythonAccept(&packet);
}

int main(int argc, char *argv[])
{
	return UnitTest::RunAllTests();
}
