#pragma once
#include <sstream>
#include <vector>
#include <iostream>
#include "CustomAssert/CustomAssert.h"
class MAFPacket
{
public:
  std::string mType;
  std::map<std::string, std::string> mMembers;
  std::vector<int> mInts;
  std::vector<unsigned int> mUInts;
  std::vector<std::string> mStrings;
  MAFPacket() : mType("")
  {
    
  }
  void SetType(const std::string& type)
  {
    mType = type;
  }
  const std::string& GetType() const
  {
    return mType;
  }
	void GetMember(const std::string& member, std::string& out) const 
	{
    std::map<std::string, std::string>::const_iterator i =  mMembers.find(member);
    CUSTOM_ASSERT(i != mMembers.end());
    const std::string& value = (*i).second;
    out = value;
	}
	void GetMember(const std::string& member, unsigned int& out) const 
	{
    std::map<std::string, std::string>::const_iterator i =  mMembers.find(member);
    CUSTOM_ASSERT(i != mMembers.end());
    const std::string& value = (*i).second;
		std::istringstream in(value);
		in >> out;
	}
	void GetMember(const std::string& member, int& out) const 
	{
    std::map<std::string, std::string>::const_iterator i =  mMembers.find(member);
    CUSTOM_ASSERT(i != mMembers.end());
    const std::string& value = (*i).second;
		std::istringstream in(value);
		in >> out;
	}
	void GetMember(const std::string& member, std::vector<int>& out) const
	{
		CUSTOM_ASSERT(mMembers.find(member) != mMembers.end());
		CUSTOM_ASSERT((*(mMembers.find(member))).second == "true");
		out = mInts;
	}
	void GetMember(const std::string& member, std::vector<unsigned int>& out) const
	{
		CUSTOM_ASSERT(mMembers.find(member) != mMembers.end());
		CUSTOM_ASSERT((*(mMembers.find(member))).second == "true");
		out = mUInts;
	}
	void GetMember(const std::string& member, std::vector<std::string>& out) const
	{
		CUSTOM_ASSERT(mMembers.find(member) != mMembers.end());
		CUSTOM_ASSERT((*(mMembers.find(member))).second == "true");
		out = mStrings;
	}
	template<typename T>
  void SetMember(const std::string& member, const T& in)
  {
    std::ostringstream oss;
    oss << in;
    mMembers[member] = oss.str();
  }
  //template<typename T>
  //void GetMember(const std::string& member, T& out) const
  //{
  //  std::map<std::string, std::string>::const_iterator i =  mMembers.find(member);
  //  CUSTOM_ASSERT(i != mMembers.end());
  //  const std::string& value = (*i).second;
  //  std::istringstream iss(value);
  //  iss >> out;
  //}
  bool IsType(const std::string& type) const
  {
    return type == mType;
  }
};


template<>
void MAFPacket::SetMember< std::vector<int> > (const std::string& member, const std::vector<int>& in);
template<>
void MAFPacket::SetMember< std::vector<unsigned int> > (const std::string& member, const std::vector<unsigned int>& in);
template<>
void MAFPacket::SetMember< std::vector<std::string> > (const std::string& member, const std::vector<std::string>& in);
template<>
void MAFPacket::SetMember<std::string> (const std::string& member, const std::string& in);
//template<>
//void MAFPacket::GetMember< std::vector<int> > (const std::string& member, std::vector<int>& out) const;
//template<>
//void MAFPacket::GetMember< std::vector<unsigned int> > (const std::string& member, std::vector<unsigned int>& out) const;
//template<>
//void MAFPacket::GetMember< std::vector<std::string> > (const std::string& member, std::vector<std::string>& out) const;
//template<>
//void MAFPacket::GetMember<std::string> (const std::string& member, std::string& out) const;
