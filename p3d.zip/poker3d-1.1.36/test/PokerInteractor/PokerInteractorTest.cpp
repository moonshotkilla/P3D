/* (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <UnitTest++.h>
#include "PokerInteractor.h"
#include <osgDB/ReaderWriter>
#include "PokerApplication.h"
#include "CustomAssert/CustomAssert.h"
#include <ReportAssert.h>

#include <maf/packets.h>

#define VISIBLE_MASK 1
#define COLLISION_MASK 4

osg::Texture2D* TextureManager::GetTexture2D(const std::string& _name, osgDB::ReaderWriter::Options* _options)
{
  return NULL;
}

bool MAFApplication::HasEvent() const
{
  return false;
}

MAFController* MAFApplication::GetFocus()
{
  return NULL;
}

SDL_Event* MAFApplication::GetLastEvent(MAFController* controller) const
{
  return NULL;
}

TextureManager* MAFApplication::GetTextureManager()
{
  return new TextureManager();
}

std::list<std::string> MAFApplication::HeaderGetList(const std::string& name, const std::string& path)
{
  return std::list<std::string>();
}

std::string MAFApplication::HeaderGet(const std::string& name, const std::string& path)
{
  return std::string();
}

void MAFVisionController::BindToNode(osg::Node*)
{
}

class PokerSceneView
{
public:
  static PokerSceneView *getInstance();
  void addDrawableThatStayInColor(osg::Drawable *, int orgRenderBin, int renderBinToUse, const std::string &renderName, int flags);
  void removeDrawableThatStayInColor(osg::Drawable *);
};

PokerSceneView* PokerSceneView::getInstance()
{
  return NULL;
}

void PokerSceneView::removeDrawableThatStayInColor(osg::Drawable*)
{
}

void PokerSceneView::addDrawableThatStayInColor(osg::Drawable *, int orgRenderBin, int renderBinToUse, const std::string &renderName, int flags)
{
}

MAFAnchor* MAFOSGData::GetAnchor(const std::string& name)
{
  return NULL;
}

void RecursiveClearUserData(osg::Node*)
{
}

class MAFMonitor;;

MAFVisionData* MAFRepositoryData::GetVision(const std::string& name, MAFMonitor *_mon)
{
  return NULL;
}

class PokerMultiTable : public osg::Referenced
{
};

struct PokerApplication2D : public osg::Referenced
{
};

PokerApplication::PokerApplication()
{
}

PokerApplication::~PokerApplication()
{
}

MAFApplication::MAFApplication()
{
}

MAFApplication::~MAFApplication()
{
}

void PokerApplication::Init(void)
{
}

const std::string& PokerApplication::SetLogPolicy()
{
  static std::string policy;
  return policy;
}

void PokerApplication::Crash()
{
}

bool PokerApplication::SetSoundEnabled(bool state)
{
  return false;
}

bool PokerApplication::IsSoundEnabled()
{
  return false;
}

void PokerApplication::OnExit(int Code)
{
}

void PokerApplication::InterfaceReady()
{
}

void PokerApplication::ShowSplashScreen()
{
}

void PokerApplication::HideSplashScreen()
{
}

void PokerApplication::UpdateSplashScreen(float, char*)
{
}

void MAFApplication::Exit(int)
{
}

void PokerApplication::PythonAccept(PyObject*)
{
}

osg::Referenced* PokerApplication::SearchAnimated(const std::string&)
{
  return NULL;
}

osg::Referenced* PokerApplication::SearchPlayer(const std::string&)
{
  return NULL;
}

void PokerApplication::SendPacket(const std::string&)
{
}

TextureManager::TextureManager()
{
}


struct MAFSceneModelMockup : MAFSceneModel
{
  MAFSceneModelMockup()
  {
    mScene = new osgUtil::SceneView();
  }
};

struct MAFSceneViewMockup : MAFSceneView
{
  MAFSceneViewMockup()
  {
    SetModel(new MAFSceneModelMockup());
  }
};

struct MAFSceneControllerMockup : MAFSceneController
{
  MAFSceneControllerMockup()
  {
  }
  virtual ~MAFSceneControllerMockup()
  {
  }
  void Init()
  {
  }
  bool Update(MAFApplication*)
  {
    return false;
  }
  MAFSceneModel* GetModel()
  {
    return NULL;
  }
  MAFSceneView* GetView()
  {
    return new MAFSceneViewMockup();
  }
};

void MAFSceneController::Init()
{
}

bool MAFSceneController::Update(MAFApplication* application)
{
  return false;
}

void MAFSceneController::DoIntersection(MAFApplication* application, int x, int y)
{
}

void MAFSceneController::Insert(MAFVisionController* controller)
{
}

void MAFSceneController::Remove(MAFVisionController* controller)
{
}

void MAFSceneController::HUDInsert(MAFVisionController* controller)
{
}

void MAFSceneController::HUDRemove(MAFVisionController* controller)
{
}

void MAFSceneController::RegisterPickCallback(const std::string& path, MAFVisionController* controller)
{
}

MAFSceneModel::~MAFSceneModel()
{
}

void MAFSceneView::Init()
{
}

void MAFSceneView::Update(MAFWindow*)
{
}

void MAFSceneModel::Init()
{
}

struct PokerInteractorBaseMockup : PokerInteractorBase
{
  PokerInteractorBaseMockup() : PokerInteractorBase(0)
  {
    osg::Node *node;
    
    mMT_1 = new osg::MatrixTransform();
    mMT_3 = new osg::MatrixTransform();
    mRoot_1 = new osg::MatrixTransform();
    mDirtyDisplay = true;
    
    node = new osg::Node();
    mNodes["fold.escn"] = node;
    node->setNodeMask(0);
    
    node = new osg::Node();
    mNodes["fold_sel.escn"] = node;
    node->setNodeMask(0);
    
    std::vector<MAFTextWriter::FontElement> t;
    mText = new MAFTextWriter("", t);
  }
  void Init()
  {
    UGAMEArtefactController::Init();
  }
};

struct PokerInteractorRaiseMockup : PokerInteractorRaise
{
  PokerInteractorRaiseMockup() : PokerInteractorRaise(0)
  {
    osg::Node *node;
    
    mMT_1 = new osg::MatrixTransform();
    mMT_3 = new osg::MatrixTransform();
    mRoot_1 = new osg::MatrixTransform();
    mDirtyDisplay = true;
    
    node = new osg::Node();
    mNodes["fold.escn"] = node;
    node->setNodeMask(0);
    
    node = new osg::Node();
    mNodes["fold_sel.escn"] = node;
    node->setNodeMask(0);
    
    std::vector<MAFTextWriter::FontElement> t;
    mText = new MAFTextWriter("", t);
  }
  void Init()
  {
    UGAMEArtefactController::Init();
  }
};

class PokerInteractorFixture {
public:

  PokerInteractorBaseMockup interactor;
  PokerApplication *game;
  
  PokerInteractorFixture()
  {
    game = new PokerApplication();
    MAFSceneControllerMockup* scene = new MAFSceneControllerMockup();
    game->SetScene(scene);
    interactor.Init();
  }
};

TEST(MAFformat_amount)
{
  CHECK_EQUAL("1", MAFformat_amount(100, true));
  CHECK_EQUAL("1.10", MAFformat_amount(110, true));
  CHECK_EQUAL("1.01", MAFformat_amount(101, true));
  CHECK_EQUAL("100k", MAFformat_amount(10000000, true));
  CHECK_EQUAL("100.1k", MAFformat_amount(10010000, true));
  CHECK_EQUAL("100.11k", MAFformat_amount(10011000, true));
  CHECK_EQUAL("100.11k", MAFformat_amount(10011900, true));
  CHECK_EQUAL("1000k", MAFformat_amount(100000000, true));
  CHECK_EQUAL("10m", MAFformat_amount(1000000000, true));
  CHECK_EQUAL("10.1m", MAFformat_amount(1010000000, true));
  CHECK_EQUAL("10.11m", MAFformat_amount(1011000000, true));
  CHECK_EQUAL("10.11m", MAFformat_amount(1011900000, true));
  CHECK_EQUAL("1", MAFformat_amount(100, false));
  CHECK_EQUAL("1.10", MAFformat_amount(110, false));
  CHECK_EQUAL("1.01", MAFformat_amount(101, false));
  CHECK_EQUAL("100000", MAFformat_amount(10000000, false));
  CHECK_EQUAL("10000000", MAFformat_amount(1000000000, false));
}

TEST_FIXTURE(PokerInteractorFixture, PokerInteractorDefaultFold2ClickedFold)
{
  osg::ref_ptr<MAFPacket> packet = new MAFPacket(NULL, NULL);

  packet->SetMember(std::string("state"), std::string("default"));
  packet->SetMember(std::string("style"), std::string("fold.escn"));
  interactor.Accept(packet.get());
  CHECK_EQUAL(true, interactor.GetSelectable());
  CHECK_EQUAL(0, interactor.mNodes2Clear.size() );
  interactor.Update(game);
  CHECK_EQUAL(VISIBLE_MASK | COLLISION_MASK, interactor.mNodes["fold.escn"]->getNodeMask() );
  CHECK_EQUAL(0, interactor.mNodes["fold_sel.escn"]->getNodeMask() );

  packet->SetMember(std::string("state"), std::string("clicked"));
  packet->SetMember(std::string("style"), std::string("fold.escn"));
  interactor.Accept(packet.get());
  CHECK_EQUAL(true, interactor.GetSelectable());
  CHECK_EQUAL(0, interactor.mNodes2Clear.size() );
  interactor.Update(game);
  CHECK_EQUAL(VISIBLE_MASK | COLLISION_MASK, interactor.mNodes["fold.escn"]->getNodeMask() );
  CHECK_EQUAL(0, interactor.mNodes["fold_sel.escn"]->getNodeMask() );
}

TEST_FIXTURE(PokerInteractorFixture, PokerInteractorDefaultFold2DefaultRemove)
{
  osg::ref_ptr<MAFPacket> packet = new MAFPacket(NULL, NULL);

  packet->SetMember(std::string("state"), std::string("default"));
  packet->SetMember(std::string("style"), std::string("fold.escn"));
  interactor.Accept(packet.get());
  CHECK_EQUAL(true, interactor.GetSelectable());
  CHECK_EQUAL(0, interactor.mNodes2Clear.size() );
  interactor.Update(game);
  CHECK_EQUAL(VISIBLE_MASK | COLLISION_MASK, interactor.mNodes["fold.escn"]->getNodeMask() );
  CHECK_EQUAL(0, interactor.mNodes["fold_sel.escn"]->getNodeMask() );

  packet->SetMember(std::string("state"), std::string("default"));
  packet->SetMember(std::string("style"), std::string(""));
  interactor.Accept(packet.get());
  CHECK_EQUAL(false, interactor.GetSelectable());
  CHECK_EQUAL(1, interactor.mNodes2Clear.size() );
  CHECK_EQUAL("fold.escn", interactor.mNodes2Clear[0] );
  interactor.Update(game);
  CHECK_EQUAL(0, interactor.mNodes["fold.escn"]->getNodeMask() );
  CHECK_EQUAL(0, interactor.mNodes["fold_sel.escn"]->getNodeMask() );
}

TEST_FIXTURE(PokerInteractorFixture, PokerInteractorDefaultFoldDefaut2ClickedFold)
{
  osg::ref_ptr<MAFPacket> packet = new MAFPacket(NULL, NULL);

  packet->SetMember(std::string("state"), std::string("default"));
  packet->SetMember(std::string("style"), std::string("fold.escn"));
  interactor.Accept(packet.get());
  CHECK_EQUAL(true, interactor.GetSelectable());
  CHECK_EQUAL(0, interactor.mNodes2Clear.size() );
  interactor.Update(game);
  CHECK_EQUAL(VISIBLE_MASK | COLLISION_MASK, interactor.mNodes["fold.escn"]->getNodeMask() );
  CHECK_EQUAL(0, interactor.mNodes["fold_sel.escn"]->getNodeMask() );

  packet->SetMember(std::string("state"), std::string("clicked"));
  packet->SetMember(std::string("style"), std::string("fold.escn"));
  interactor.Accept(packet.get());
  CHECK_EQUAL(true, interactor.GetSelectable());
  CHECK_EQUAL(0, interactor.mNodes2Clear.size() );
  interactor.Update(game);
  CHECK_EQUAL(VISIBLE_MASK | COLLISION_MASK, interactor.mNodes["fold.escn"]->getNodeMask() );
  CHECK_EQUAL(0, interactor.mNodes["fold_sel.escn"]->getNodeMask() );
}

TEST_FIXTURE(PokerInteractorFixture, PokerInteractorClickedFoldsel2DefaultFold)
{
  osg::ref_ptr<MAFPacket> packet = new MAFPacket(NULL, NULL);

  packet->SetMember(std::string("state"), std::string("clicked"));
  packet->SetMember(std::string("style"), std::string("fold_sel.escn"));
  interactor.Accept(packet.get());
  CHECK_EQUAL(true, interactor.GetSelectable());
  CHECK_EQUAL(0, interactor.mNodes2Clear.size() );
  interactor.Update(game);
  CHECK_EQUAL(0, interactor.mNodes["fold_sel.escn"]->getNodeMask() );
  CHECK_EQUAL(0, interactor.mNodes["fold.escn"]->getNodeMask() );

  packet->SetMember(std::string("state"), std::string("default"));
  packet->SetMember(std::string("style"), std::string("fold.escn"));
  interactor.Accept(packet.get());
  CHECK_EQUAL(true, interactor.GetSelectable());
  CHECK_EQUAL(0, interactor.mNodes2Clear.size() );
  interactor.Update(game);
  CHECK_EQUAL(VISIBLE_MASK | COLLISION_MASK, interactor.mNodes["fold.escn"]->getNodeMask() );
  CHECK_EQUAL(0, interactor.mNodes["fold_sel.escn"]->getNodeMask() );
}

TEST_FIXTURE(PokerInteractorFixture, PokerInteractorClickedFoldsel2ClickedNone)
{
  osg::ref_ptr<MAFPacket> packet = new MAFPacket(NULL, NULL);

  packet->SetMember(std::string("state"), std::string("clicked"));
  packet->SetMember(std::string("style"), std::string("fold_sel.escn"));
  interactor.Accept(packet.get());
  CHECK_EQUAL(true, interactor.GetSelectable());
  CHECK_EQUAL(0, interactor.mNodes2Clear.size() );
  interactor.Update(game);
  CHECK_EQUAL(0, interactor.mNodes["fold_sel.escn"]->getNodeMask() );
  CHECK_EQUAL(0, interactor.mNodes["fold.escn"]->getNodeMask() );

  packet->SetMember(std::string("state"), std::string("clicked"));
  packet->SetMember(std::string("style"), std::string(""));
  interactor.Accept(packet.get());
  CHECK_EQUAL(false, interactor.GetSelectable());
  CHECK_EQUAL(1, interactor.mNodes2Clear.size() );
  CHECK_EQUAL("fold_sel.escn", interactor.mNodes2Clear[0]);
  interactor.Update(game);
  CHECK_EQUAL(0, interactor.mNodes["fold.escn"]->getNodeMask() );
  CHECK_EQUAL(0, interactor.mNodes["fold_sel.escn"]->getNodeMask() );
}

TEST_FIXTURE(PokerInteractorFixture, PokerInteractorClickedNone2ClickedFold)
{
  osg::ref_ptr<MAFPacket> packet = new MAFPacket(NULL, NULL);

  packet->SetMember(std::string("state"), std::string("clicked"));
  packet->SetMember(std::string("style"), std::string(""));
  interactor.Accept(packet.get());
  CHECK_EQUAL(false, interactor.GetSelectable());
  CHECK_EQUAL(0, interactor.mNodes2Clear.size() );
  interactor.Update(game);
  CHECK_EQUAL(0, interactor.mNodes["fold.escn"]->getNodeMask() );
  CHECK_EQUAL(0, interactor.mNodes["fold_sel.escn"]->getNodeMask() );

  packet->SetMember(std::string("state"), std::string("clicked"));
  packet->SetMember(std::string("style"), std::string("fold.escn"));
  interactor.Accept(packet.get());
  CHECK_EQUAL(true, interactor.GetSelectable());
  CHECK_EQUAL(0, interactor.mNodes2Clear.size() );
  interactor.Update(game);
  CHECK_EQUAL(0, interactor.mNodes["fold.escn"]->getNodeMask() );
  CHECK_EQUAL(0, interactor.mNodes["fold_sel.escn"]->getNodeMask() );
}

TEST_FIXTURE(PokerInteractorFixture, PokerInteractorClickedFold2ClickedFoldSel)
{
  osg::ref_ptr<MAFPacket> packet = new MAFPacket(NULL, NULL);

  packet->SetMember(std::string("state"), std::string("clicked"));
  packet->SetMember(std::string("style"), std::string("fold.escn"));
  interactor.Accept(packet.get());
  CHECK_EQUAL(true, interactor.GetSelectable());
  CHECK_EQUAL(0, interactor.mNodes2Clear.size() );
  interactor.Update(game);
  CHECK_EQUAL(0, interactor.mNodes["fold.escn"]->getNodeMask() );
  CHECK_EQUAL(0, interactor.mNodes["fold_sel.escn"]->getNodeMask() );

  packet->SetMember(std::string("state"), std::string("clicked"));
  packet->SetMember(std::string("style"), std::string("fold_sel.escn"));
  interactor.Accept(packet.get());
  CHECK_EQUAL(true, interactor.GetSelectable());
  CHECK_EQUAL(1, interactor.mNodes2Clear.size() );
  CHECK_EQUAL("fold.escn",  interactor.mNodes2Clear[0] );
  interactor.Update(game);
  CHECK_EQUAL(0, interactor.mNodes["fold.escn"]->getNodeMask() );
  CHECK_EQUAL(0, interactor.mNodes["fold_sel.escn"]->getNodeMask() );
}

TEST_FIXTURE(PokerInteractorFixture, PokerInteractorClickedNone2DefaultNone)
{
  osg::ref_ptr<MAFPacket> packet = new MAFPacket(NULL, NULL);

  packet->SetMember(std::string("state"), std::string("clicked"));
  packet->SetMember(std::string("style"), std::string(""));
  interactor.Accept(packet.get());
  CHECK_EQUAL(false, interactor.GetSelectable());
  CHECK_EQUAL(0, interactor.mNodes2Clear.size() );
  interactor.Update(game);
  CHECK_EQUAL(0, interactor.mNodes["fold.escn"]->getNodeMask() );
  CHECK_EQUAL(0, interactor.mNodes["fold_sel.escn"]->getNodeMask() );

  packet->SetMember(std::string("state"), std::string("default"));
  packet->SetMember(std::string("style"), std::string(""));
  interactor.Accept(packet.get());
  CHECK_EQUAL(false, interactor.GetSelectable());
  CHECK_EQUAL(0, interactor.mNodes2Clear.size() );
  interactor.Update(game);
  CHECK_EQUAL(0, interactor.mNodes["fold.escn"]->getNodeMask() );
  CHECK_EQUAL(0, interactor.mNodes["fold_sel.escn"]->getNodeMask() );
}

TEST_FIXTURE(PokerInteractorFixture, PokerInteractorBug)
{
  osg::ref_ptr<MAFPacket> packet = new MAFPacket(NULL, NULL);

  if (interactor.mState2Name["clicked"] == "raise_sel.escn")
    ;
  packet->SetMember(std::string("state"), std::string("clicked"));
  packet->SetMember(std::string("style"), std::string("fold.escn"));
  CHECK_ASSERT(interactor.Accept(packet.get()));
}

TEST(PokerInteractorCanInstallSlider)
{
  PokerInteractorRaiseMockup raiseInteractor;
  raiseInteractor.Init();
  raiseInteractor.mState2Name["clicked"] = "raise_sel.escn";
  raiseInteractor.mState2Name["default"] = "raise_sel.escn";
  CHECK_EQUAL(false, raiseInteractor.CanInstallSlider());
  raiseInteractor.mState2Name["clicked"] = "raise.escn";
  raiseInteractor.mState2Name["default"] = "raise.escn";
  CHECK_EQUAL(true, raiseInteractor.CanInstallSlider());
}

#ifdef WIN32
#undef main
#endif

void reportCustomAssert()
{
  std::string description = CustomAssert::Instance().GetDescription();
  std::string message = CustomAssert::Instance().GetMessage();
  std::string function = CustomAssert::Instance().GetFunction();
  std::string file = CustomAssert::Instance().GetFile();
  int line  = CustomAssert::Instance().GetLine();
  UnitTest::ReportAssert((description+" "+message).c_str(), (function+" "+file).c_str(), line);
}

int	main()
{
  CustomAssert::Instance().SetHandler(reportCustomAssert);  
  return UnitTest::RunAllTests();
}
