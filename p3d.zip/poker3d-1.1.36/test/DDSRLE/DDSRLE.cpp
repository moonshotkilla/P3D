/* (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <osgDB/ReadFile>

#include <UnitTest++.h>

static std::string g_srcdir = "./";

#ifndef WIN32
void fetchsrcdir()
{
	char* srcdirPtr = getenv("srcdir");
	if (srcdirPtr)
	{
		//beware "." is always first in PathList
		osgDB::Registry::instance()->getDataFilePathList().push_front(srcdirPtr);
		g_srcdir = std::string(srcdirPtr) + "/";
		if (g_srcdir == "./")
			g_srcdir = "";
	}
};
#endif //WIN32

TEST(LoadImage)
{
	osg::Object *obj = osgDB::readImageFile(g_srcdir + "data/envmap2.ddsrle");
	osg::Image *img = dynamic_cast<osg::Image*>(obj);
	CHECK(img);

	int nbMipmaps = img->getNumMipmapLevels();
	CHECK_EQUAL(true, nbMipmaps > 1);
}

int main()
{
#ifndef WIN32
	fetchsrcdir();
#endif //WIN32

  return UnitTest::RunAllTests();
}
