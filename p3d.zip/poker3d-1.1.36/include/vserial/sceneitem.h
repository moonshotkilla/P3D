/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_SCENEITEM_H
#define UNDERWARE_VSERIAL_SCENEITEM_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <map>
#include <string>
#include <vector>

#include <vserial/vserial.h>
#include <vserial/quat.h>
#include <vserial/vec3f.h>
#endif

ENTER_NAMESPACE_UNDERWARE

class Motion;

class SceneItem {

protected:
	UW_VSERIAL_API SceneItem(const std::string &name = "none");

public:
	enum TYPE {
		MESH,
		NULLOBJECT,
		BONE,
		LIGHT,
		CAMERA
	};

	UW_VSERIAL_API virtual ~SceneItem();

	UW_VSERIAL_API inline TYPE getType() const { return type_; }

	UW_VSERIAL_API inline const std::string& getName() const { return name_; }
	UW_VSERIAL_API inline void setName(const std::string name) { name_ = name; }

	UW_VSERIAL_API inline SceneItem* getParent() const { return parent_; }

	UW_VSERIAL_API inline Motion* getMotion() const { return motion_; }
	UW_VSERIAL_API inline void setMotion(Motion *mot) { motion_ = mot; }

	UW_VSERIAL_API inline void setPosition(const Vec3f &position) { position_ = position; }
	UW_VSERIAL_API inline const Vec3f& getPosition() const { return position_; }

	UW_VSERIAL_API inline void setQuaternion(const Quaternion &quat) { quat_ = quat; }
	UW_VSERIAL_API inline const Quaternion& getQuaternion() const { return quat_; }

	UW_VSERIAL_API inline void setScale(const Vec3f &scale) { scale_ = scale; }
	UW_VSERIAL_API inline const Vec3f& getScale() const { return scale_; }

	UW_VSERIAL_API inline void setPivot(const Vec3f &pivot) { pivot_ = pivot; }
	UW_VSERIAL_API inline const Vec3f& getPivot() const { return pivot_; }

	UW_VSERIAL_API inline int getNbChildren() const { return children_.size(); }
	UW_VSERIAL_API inline SceneItem* getChildByIndex(int i) { return children_[i]; }
	UW_VSERIAL_API void addChild(SceneItem *item);
	UW_VSERIAL_API void removeChild(SceneItem *item);

	UW_VSERIAL_API inline void setProperty(const std::string &key, const std::string &value) { properties_[key] = value; }
	UW_VSERIAL_API inline int getNbProperties() const { return properties_.size(); }
	UW_VSERIAL_API const std::string& getPropertyValueByKey(const std::string &key) const;

protected:
	TYPE type_;
	std::string name_;
	SceneItem* parent_;
	std::vector<SceneItem*> children_;
	std::map<std::string, std::string> properties_;
	Vec3f position_;
	Quaternion quat_;
	Vec3f scale_;
	Vec3f pivot_;
	Motion *motion_;
};

LEAVE_NAMESPACE

#endif
