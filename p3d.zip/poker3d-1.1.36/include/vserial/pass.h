/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_PASS_H
#define UNDERWARE_VSERIAL_PASS_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>
#include <string>
#endif

#include <vserial/col4f.h>
#include <vserial/texturelayer.h>
#include <vserial/texturelayerbind.h>
#include <vserial/flagable.h>
#include <vserial/gpuprogram.h>

ENTER_NAMESPACE_UNDERWARE

#ifndef ENUM_PIXOP
#define ENUM_PIXOP
enum PIXOP {
	PIXOP_REPLACE = 0,
	PIXOP_SRCADD = 1,
	PIXOP_DSTADD = 2,
	PIXOP_BLEND = 3,
	PIXOP_MUL = 4,
};
#endif

class Pass : public Flagable {

	Pass();
	virtual ~Pass();

public:

	static const int FLAG_DOUBLESIDED = 0x1;
	static const int FLAG_IGNORELIGHTING = 0x2;

	UW_VSERIAL_API inline const Col4f& getDiffuse() const { return diffuse_; }
	UW_VSERIAL_API inline void setDiffuse(const Col4f &diffuse) { diffuse_ = diffuse; }

	UW_VSERIAL_API inline const Col4f& getEmissive() const { return emissive_; }
	UW_VSERIAL_API inline void setEmissive(const Col4f &emissive) { emissive_ = emissive; }

	UW_VSERIAL_API inline const Col4f& getSpecular() const { return specular_; }
	UW_VSERIAL_API inline void setSpecular(const Col4f &specular) { specular_ = specular; }

	UW_VSERIAL_API inline const Col4f& getAmbient() const { return ambient_; }
	UW_VSERIAL_API inline void setAmbient(const Col4f &ambient) { ambient_ = ambient; }

	UW_VSERIAL_API inline float getGlossiness() const { return glossiness_; }
	UW_VSERIAL_API inline void setGlossiness(float glossiness) { glossiness_ = glossiness; }

	UW_VSERIAL_API inline PIXOP getPixelOperation() const { return pixelOperation_; }
	UW_VSERIAL_API inline void setPixelOperation(PIXOP pixOp) { pixelOperation_ = pixOp; }

	UW_VSERIAL_API inline float getPixelOpacity() const { return pixelOpacity_; }
	UW_VSERIAL_API inline void setPixelOpacity(float pixOpa) { pixelOpacity_ = pixOpa; }

	UW_VSERIAL_API inline int getNbTextureLayers() const { return tlayers_.size(); }
	UW_VSERIAL_API void setNbTextureLayers(int _nb);

	UW_VSERIAL_API TextureLayer& getTextureLayer(int index) { return tlayers_[index]; }
	UW_VSERIAL_API TextureLayerBind& getTextureLayerBind(int index) { return tlayersbind_[index]; }

	UW_VSERIAL_API inline GPUProgram& getVertexProgram() { return vertexProgram_; }
	UW_VSERIAL_API inline GPUProgram& getFragmentProgram() { return fragmentProgram_; }

protected:
	PIXOP pixelOperation_;
	float pixelOpacity_;

	Col4f diffuse_;
	Col4f emissive_;
	Col4f specular_;
	Col4f ambient_;
	float glossiness_;

	std::vector<TextureLayer> tlayers_; 
	std::vector<TextureLayerBind> tlayersbind_; 

	GPUProgram vertexProgram_;
	GPUProgram fragmentProgram_;

	friend class Technique;
};

LEAVE_NAMESPACE

#endif // UNDERWARE_VSERIAL_PASS_H
