/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_MESH_H
#define UNDERWARE_VSERIAL_MESH_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vector>
#include <string>
#include <vserial/vserial.h>
#include <vserial/referenced.h>
#endif

ENTER_NAMESPACE_UNDERWARE

class MeshLayer;

class Mesh : public Referenced {
public:

	UW_VSERIAL_API static int getNb();
	UW_VSERIAL_API static Mesh* getByIndex(int i);
	UW_VSERIAL_API static Mesh* getByName(const std::string &name);

	UW_VSERIAL_API Mesh();
	UW_VSERIAL_API virtual ~Mesh();

	UW_VSERIAL_API const std::string& getFileName() const { return fname_; }
	UW_VSERIAL_API void setFileName(const std::string &fname) { fname_ = fname; }

	UW_VSERIAL_API int getNbLayers() const;
	UW_VSERIAL_API MeshLayer* getLayerByIndex(int i) const;
	UW_VSERIAL_API MeshLayer* getLayerByName(const std::string &name) const;

	UW_VSERIAL_API MeshLayer* addLayer();

protected:
	std::string fname_;
	std::vector<MeshLayer*> layers_;

	friend class MeshSerializer;
};

LEAVE_NAMESPACE

#endif // UNDERWARE_VSERIAL_MESH_H
