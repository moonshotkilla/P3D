/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *  (based on OSG's ref_ptr)
 *
 */

#ifndef UNDERWARE_VSERIAL_REF_PTR_H
#define UNDERWARE_VSERIAL_REF_PTR_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>
#endif

ENTER_NAMESPACE_UNDERWARE

template<class T>
class ref_ptr {
public:
	typedef T element_type;

	ref_ptr() : _ptr(0L) { }
	ref_ptr(T *t):_ptr(t) { if (_ptr) _ptr->ref(); }
	ref_ptr(const ref_ptr &rp) : _ptr(rp._ptr) { if (_ptr) _ptr->ref(); }
	~ref_ptr() { if (_ptr) _ptr->unref(); _ptr = 0; }

	inline ref_ptr& operator = (const ref_ptr& rp)
	{
		if (_ptr == rp._ptr) return *this;
		T *tmp_ptr = _ptr;
		_ptr = rp._ptr;
		if (_ptr) _ptr->ref();
		if (tmp_ptr) tmp_ptr->unref();
			return *this;
	}

	inline ref_ptr& operator = (T *ptr)
	{
		if (_ptr == ptr) return *this;
		T *tmp_ptr = _ptr;
		_ptr = ptr;
		if (_ptr) _ptr->ref();

		if (tmp_ptr) tmp_ptr->unref();
			return *this;
	}

	// comparison operators for ref_ptr.
	inline bool operator == (const ref_ptr &rp) const { return (_ptr == rp._ptr); }
	inline bool operator != (const ref_ptr &rp) const { return (_ptr != rp._ptr); }
	inline bool operator < (const ref_ptr &rp) const { return (_ptr < rp._ptr); }
	inline bool operator > (const ref_ptr &rp) const { return (_ptr > rp._ptr); }

	// comparison operator for const T*.
	inline bool operator == (const T *ptr) const { return (_ptr == ptr); }
	inline bool operator != (const T *ptr) const { return (_ptr != ptr); }
	inline bool operator < (const T *ptr) const { return (_ptr < ptr); }
	inline bool operator > (const T *ptr) const { return (_ptr > ptr); }

	inline T& operator*() { return *_ptr; }

	inline const T& operator*() const { return *_ptr; }

	inline T* operator->() { return _ptr; }

	inline const T* operator->() const   { return _ptr; }

	inline bool operator!() const	{ return _ptr==0L; }

	inline bool valid() const	{ return _ptr!=0L; }
        
	inline T* get() { return _ptr; }

	inline const T* get() const { return _ptr; }

private:
	T* _ptr;
};

LEAVE_NAMESPACE

#endif // UNDERWARE_VSERIAL_REF_PTR_H
