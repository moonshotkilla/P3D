/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_MOTION_H
#define UNDERWARE_VSERIAL_MOTION_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>
#include <string>
#include <vector>
#endif

ENTER_NAMESPACE_UNDERWARE

class EnvelopeBase;

class Motion {
public:

	UW_VSERIAL_API static int getNb();
	UW_VSERIAL_API static Motion* getByIndex(int);
	UW_VSERIAL_API static Motion* getByName(const std::string &);

	UW_VSERIAL_API Motion();
	UW_VSERIAL_API virtual ~Motion();

	UW_VSERIAL_API inline const std::string& getFileName() const { return fname_; }
	UW_VSERIAL_API inline void setFileName(const std::string &fname) { fname_ = fname; }

	UW_VSERIAL_API void addEnvelope(EnvelopeBase *);
	UW_VSERIAL_API inline int getNbEnvelopes() const { return envelopes_.size(); }
	UW_VSERIAL_API inline EnvelopeBase* getEnvelope(int i) { return envelopes_[i]; }

protected:
	std::string fname_;
	std::vector<EnvelopeBase*> envelopes_;
};

LEAVE_NAMESPACE

#endif
