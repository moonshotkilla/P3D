/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_SCENELIGHT_H
#define UNDERWARE_VSERIAL_SCENELIGHT_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <string>
#include <vserial/vserial.h>
#include <vserial/col4f.h>
#include <vserial/scenelight.h>
#endif

#include <vserial/sceneitem.h>

ENTER_NAMESPACE_UNDERWARE

class SceneLight : public SceneItem {
public:

	enum TYPE {
		TYPE_DISTANT = 0,
		TYPE_POINT = 1,
		TYPE_SPOT = 2,
		TYPE_FORCEDWORD = 0x7fffffff
	};

	enum FALLOFF {
		FALLOFF_NONE = 0,
		FALLOFF_LINEAR = 1,
		FALLOFF_INVDIST = 2,
		FALLOFF_FORCEDWORD = 0x7fffffff
	};

	class Data {
	public:

		Data() : type(TYPE_DISTANT), fallOff(FALLOFF_NONE), color(1,1,1,1), direction(0,0,1), range(0), att0(0), att1(0), att2(0), theta(0), phi(0) { };

		TYPE type;
		FALLOFF fallOff;
		Col4f color;
		// direction is expressed in view coordinates (camera system)
		Vec3f direction;
		float range;
		float att0, att1, att2;
		float theta;
		float phi;
	};

	UW_VSERIAL_API SceneLight();
	UW_VSERIAL_API virtual ~SceneLight();

	UW_VSERIAL_API Data& data() { return data_; }
	UW_VSERIAL_API const Data& data () const { return data_; }

protected:
	Data data_;
};

LEAVE_NAMESPACE

#endif
