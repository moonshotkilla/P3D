/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_SCENEMESH_H
#define UNDERWARE_VSERIAL_SCENEMESH_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <string>
#include <vserial/vserial.h>
#include <vserial/scenemesh.h>
#endif

#include <vserial/sceneitem.h>

ENTER_NAMESPACE_UNDERWARE

class BonesSet;
class Mesh;
class Skinning;

class SceneMesh : public SceneItem {

public:
	UW_VSERIAL_API SceneMesh();
	UW_VSERIAL_API virtual ~SceneMesh();

	UW_VSERIAL_API inline Mesh* getMesh() const { return mesh_; }
	UW_VSERIAL_API inline void setMesh(Mesh *mesh) { mesh_ = mesh; }

	UW_VSERIAL_API inline Skinning* getSkinning() const { return skinning_; }
	UW_VSERIAL_API inline void setSkinning(Skinning *skin) { skinning_ = skin; }

protected:
	Mesh *mesh_;
	Skinning *skinning_;
};

LEAVE_NAMESPACE

#endif
