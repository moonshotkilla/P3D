/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_SCENE_H
#define UNDERWARE_VSERIAL_SCENE_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <map>
#include <vector>
#include <string>

#include <vserial/vserial.h>
#endif

ENTER_NAMESPACE_UNDERWARE

class SceneBone;
class SceneItem;
class SceneLight;
class SceneMesh;
class SceneNullObject;

class Scene {
public:

	Scene();
	virtual ~Scene();

	UW_VSERIAL_API inline SceneItem* getRoot() const { return root_; }
	UW_VSERIAL_API inline void setRoot(SceneItem *root) { root_ = root; }

	UW_VSERIAL_API inline const std::string& getName() const { return name_; }
	UW_VSERIAL_API inline void setName(const std::string name) { name_ = name; }

	UW_VSERIAL_API void getBonesList(std::vector<SceneBone*> &list) const;
	UW_VSERIAL_API void getBonesListFrom(SceneItem *from, std::vector<SceneBone*> &list) const;

	UW_VSERIAL_API void getMeshesList(std::vector<SceneMesh*> &list) const;
	UW_VSERIAL_API void getMeshesListFrom(SceneItem *from, std::vector<SceneMesh*> &list) const;

	UW_VSERIAL_API void getLightsList(std::vector<SceneLight*> &list) const;
	UW_VSERIAL_API void getLightsListFrom(SceneItem *from, std::vector<SceneLight*> &list) const;

	UW_VSERIAL_API void getNullObjectsList(std::vector<SceneNullObject*> &list) const;
	UW_VSERIAL_API void getNullObjectsListFrom(SceneItem *from, std::vector<SceneNullObject*> &list) const;

protected:
	std::string name_;
	SceneItem* root_;

	friend class SceneSerializer;
};

LEAVE_NAMESPACE

#endif // UNDERWARE_VSERIAL_SCENE_H
