/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_MESHLAYER_H
#define UNDERWARE_VSERIAL_MESHLAYER_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <string>
#include <vector>
#include <vserial/vserial.h>
#endif

#include <vserial/meshprimitivespacket.h>
#include <vserial/vertexmap.h>

ENTER_NAMESPACE_UNDERWARE

class Mesh;

class MeshLayer {

	UW_VSERIAL_API MeshLayer(Mesh &);
	UW_VSERIAL_API virtual ~MeshLayer();

public:

	UW_VSERIAL_API const std::string& getName() const { return name_; }
	UW_VSERIAL_API void setName(const std::string &name) { name_ = name; }

	UW_VSERIAL_API MeshPrimitivesPacket* addPrimitivesPacket(MESHPRIM_PACKET_TYPE type = MESHPRIM_TRIANGLES);
	UW_VSERIAL_API MeshPrimitivesPacket* getPrimitivesPacket(int i) const { return packets_[i]; }
	UW_VSERIAL_API int getNbPrimitivesPackets() const { return packets_.size(); }

	UW_VSERIAL_API int getNbPoints() const { return nbPoints_; }
	UW_VSERIAL_API Vec3f* getPoints() const { return points_; }
	UW_VSERIAL_API void setPoints(Vec3f *points, int nbPoints);

	UW_VSERIAL_API void getBoundingBox(Vec3f &min, Vec3f &max);

	UW_VSERIAL_API VertexMap* addVertexMap(const std::string &name, VMAP_TYPE);
	UW_VSERIAL_API VertexMap* getVertexMapByName(const std::string &name, VMAP_TYPE) const;
	UW_VSERIAL_API VertexMap* getVertexMapByIndex(int index) const;
	UW_VSERIAL_API inline int getNbVertexMaps() const { return vertexMaps_.size(); }

	UW_VSERIAL_API void optimize();

	UW_VSERIAL_API Mesh *getParent() { return owner_; }

protected:

	std::string name_;
	Mesh *owner_;
	std::vector<MeshPrimitivesPacket*> packets_;
	std::vector<VertexMap*> vertexMaps_;
	Vec3f *points_;
	int nbPoints_;

	friend class Mesh;
	friend class MeshSerializer;
};

LEAVE_NAMESPACE

#endif // UNDERWARE_VSERIAL_MESHLAYER_H
