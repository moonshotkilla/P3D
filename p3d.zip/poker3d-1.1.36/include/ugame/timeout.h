/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#ifndef _ugametimeout_h
#define _ugametimeout_h

#ifndef UGAME_USE_VS_PCH

#include <osg/Vec4>
#include <osg/Referenced>
#include <osg/Node>

#include <vector>
#include <string>

#include "ugame/ugameexport.h"
#endif

extern "C" {
  struct _xmlDoc;
}

class UGAMETimeOut : public osg::Referenced
{
 public:

	struct Range {
		osg::Vec4 mColor;
		float mScale;

		float mBegin;
		float mEnd;

		Range(): mColor(osg::Vec4(1,1,1,1)),mScale(1),mBegin(0),mEnd(0) {}
	};

	class Callback : public osg::Referenced
	{
	public:
		virtual void operator()(int second) {}
	};



 private:

	float mCounter;
	osg::Vec4 mColor;
	float mScale;
	float mCounterFadeOut;

	osg::ref_ptr<Callback> mCallback;

	std::vector<Range> mRanges;
	Range mDefault;

	bool mEnable;

protected:

	virtual ~UGAMETimeOut(){}

 public:

	UGAME_EXPORT UGAMETimeOut() {}

	UGAME_EXPORT void Init();
	UGAME_EXPORT bool Unserialize(struct _xmlDoc* doc,const std::string& xp="");

	UGAME_EXPORT bool IsEnable() const { return mEnable; }
	UGAME_EXPORT void SetEnable(bool bEnable) { mEnable = bEnable; }

	UGAME_EXPORT void Update(float dt);

	UGAME_EXPORT void SetCounter(float value) { mCounter = value;}

	UGAME_EXPORT float GetCounter() const { return mCounter;}
	UGAME_EXPORT void GetCounterAsIntString(std::string& string) const;

	UGAME_EXPORT const osg::Vec4& GetColor() const { return mColor;}
	UGAME_EXPORT float GetScale() const { return mScale;}
	UGAME_EXPORT float GetFadeOut() const { return mCounterFadeOut;}

 	UGAME_EXPORT void SetCallback(Callback* callback) { mCallback = callback;}
	UGAME_EXPORT Callback* GetCallback() { return mCallback.get();}

	
};


#endif
