/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */
#ifndef __MAFSINGLETON_H__
#define __MAFSINGLETON_H__

#include <assert.h>

template<typename T>
struct MAFSingleton
{
	static void CreateInstance()
	{
		assert(_instance == 0);
		_instance = new T();
	}
	static void DestroyInstance()
	{
		assert(_instance != 0);
		T* instance = _instance;
		_instance = 0;
		delete(instance);
	}
	static T& GetInstance()
	{
		assert(_instance != 0);
		return *_instance;
	}
protected:
	MAFSingleton()
	{
		_instance = 0;
	}
	virtual ~MAFSingleton()
	{
		assert(_instance == 0);
	}
private:
	static T* _instance;
};

template<typename T>
T* MAFSingleton<T>::_instance = 0;

#endif // __MAFSINGLETON_H__ 

