/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef _maf_utils_h
#define _maf_utils_h

#ifndef MAF_USE_VS_PCH
#include <maf/mafexport.h>

#include <osg/Array>
#include <osg/Geode>
#include <osg/Geometry>
#include <osg/Material>
#include <osg/Texture2D>

#include <libxml/xpath.h>

#endif

namespace osg { class Texture2D;}

#define MAF_OR_NODEMASK(node, msk) node->setNodeMask( node->getNodeMask() | msk )
#define MAF_REMOVE_NODEMASK(node, msk) node->setNodeMask( node->getNodeMask() & ~msk )

MAF_EXPORT std::string MAFformat_amount(unsigned int value, bool bAdvancedFormat = false);
MAF_EXPORT osg::Matrix MAFComputeLocalToWorld(osg::Node* src, int parentValidMask = 0, int nodeMaskExclude = 0, int nodeMaskStop = 0);
MAF_EXPORT void MAFCreateNodePath(osg::Node* src, osg::NodePath &path, int parentValidMask = 0);

MAF_EXPORT osg::Node* GetNode(osg::Node* node, const std::string& name);
MAF_EXPORT osg::Geode* GetGeode(osg::Node* node);

MAF_EXPORT float MAFapprox_acos(float x);
MAF_EXPORT float MAFapprox_asin(float x);

MAF_EXPORT void MAFInvertPremultipliedAlpha(osg::Image &img);

// r,g,b values are from 0 to 1
// h = [0,360], s = [0,1], l = [0,1]
MAF_EXPORT void MAFRGBtoHSL(float r, float g, float b, float *h, float *s, float *l);
MAF_EXPORT void MAFHSLtoRGB(float h, float s, float l, float *r, float *g, float *b);

MAF_EXPORT int MAFGetNearestHighPow2(int value);

MAF_EXPORT const char* MAFXPath2Value(xmlXPathContextPtr context, const char *xpath);

class MAF_OSGQuadParams {
public:

	MAF_EXPORT MAF_OSGQuadParams()
	{
		textureName = "";
		bInvertUV = true;
		geomToUse = NULL;
		minPt = osg::Vec2f(0, 0);
		maxPt = osg::Vec2f(1, 1);
		minUV = osg::Vec2f(0, 0);
		maxUV = osg::Vec2f(1, 1);
		z = 0.1f;
		srcBlendFactor = GL_SRC_ALPHA;
		dstBlendFactor = GL_ONE_MINUS_SRC_ALPHA;
		bDisableWriteMask = true;
	}

	std::string textureName;
	bool bInvertUV;
	osg::Geometry *geomToUse;
	osg::Vec2f minPt;
	osg::Vec2f maxPt;
	osg::Vec2f minUV;
	osg::Vec2f maxUV;
	float z;
	GLenum srcBlendFactor;
	GLenum dstBlendFactor;
	bool bDisableWriteMask;
};

class MAF_OSGQuad : public osg::Referenced {

	MAF_OSGQuad() { };

public:
	MAF_EXPORT explicit MAF_OSGQuad(	const std::string &textureName,
																		bool bInvertUV = true,
																		const osg::Vec2f &minPt = osg::Vec2f(0, 0),
																		const osg::Vec2f &maxPt = osg::Vec2f(1, 1),
																		const osg::Vec2f &minUV = osg::Vec2f(0, 0),
																		const osg::Vec2f &maxUV = osg::Vec2f(1, 1),
																		GLenum srcBlendFactor = GL_SRC_ALPHA,
																		GLenum dstBlendFactor = GL_ONE_MINUS_SRC_ALPHA,
																		bool bDisableWriteMask = true);

	MAF_EXPORT explicit MAF_OSGQuad(MAF_OSGQuadParams &);

	virtual ~MAF_OSGQuad();

	MAF_EXPORT void setVertexInWindowCoordinates(float x, float y, int iVertex);
	MAF_EXPORT void setVertexInNormalisedCoordinates(float x, float y, int iVertex);
	MAF_EXPORT void setVertexInUnitCoordinates(float x, float y, int iVertex);

	MAF_EXPORT static void setScreenResolution(int w, int h);

	MAF_EXPORT inline osg::Geode* getGeode() const { return (osg::Geode*) geode_.get(); }
	MAF_EXPORT inline osg::Geometry* getGeometry() const { return (osg::Geometry*) geom_.get(); }
	MAF_EXPORT inline osg::Vec3Array* getVerticesArray() const { return (osg::Vec3Array*) vertices_.get(); }
	MAF_EXPORT inline osg::Vec2Array* getUVArray() const { return (osg::Vec2Array*) uv_.get(); }
	MAF_EXPORT inline osg::Material* getMaterial() const { return (osg::Material*) material_.get(); }
	MAF_EXPORT inline osg::Texture2D* getTexture() const { return (osg::Texture2D*) texture_.get(); }
	MAF_EXPORT inline void setTexture(osg::Texture2D *_tex) { texture_ = _tex; }

protected:
	osg::ref_ptr<osg::Geode> geode_;
	osg::ref_ptr<osg::Geometry> geom_;
	osg::ref_ptr<osg::Vec3Array> vertices_;
	osg::ref_ptr<osg::Vec2Array> uv_;
	osg::ref_ptr<osg::Material> material_;
	osg::ref_ptr<osg::Texture2D> texture_;
};

#endif // _maf_utils_h
