/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#ifndef MAF_SHADER_H
#define MAF_SHADER_H

#ifndef MAF_USE_VS_PCH
#include <maf/mafexport.h>

#include <osg/VertexProgram>
#include <osg/FragmentProgram>

namespace osg {
  class Texture1D;
  class Texture2D;
  class StateSet;
  class TextureCubeMap;
}

#endif

#ifndef MAFSHADER_NORMALIZE
#define MAFSHADER_NORMALIZE(a) "DP3 " #a ".w, " #a ", " #a ";\nRSQ " #a ".w, " #a ".w;\nMUL " #a ".xyz, " #a ".w, " #a ";\n"
#endif

enum MAFShaderType {
	MAFSHADERTYPE_NONE = 0,
	MAFSHADERTYPE_BLINN,
	MAFSHADERTYPE_BRDF,
	MAFSHADERTYPE_EMBM,
	MAFSHADERTYPE_ORENNAYAR,
	MAFSHADERTYPE_MOSAIC,
};

#ifndef GL_LUMINANCE16F_ARB
#define GL_LUMINANCE16F_ARB						0x881E
#endif

const int MAFSHADER_USE_VERTEX_PROGRAM = 0x1;
const int MAFSHADER_USE_FRAGMENT_PROGRAM = 0x2;

class MAFShader {

protected:
	MAF_EXPORT MAFShader(int VPflags = MAFSHADER_USE_VERTEX_PROGRAM | MAFSHADER_USE_FRAGMENT_PROGRAM);

public:

	enum TECHNIC_AUTHORISATION {
		TECHNIC_AUTHORISATION_NONE = 0,
		TECHNIC_AUTHORISATION_VERTEX_PROGRAM = 1,
		TECHNIC_AUTHORISATION_FRAGMENT_PROGRAM = 2,
		TECHNIC_AUTHORISATION_VERTEXFRAGMENT_PROGRAM = TECHNIC_AUTHORISATION_VERTEX_PROGRAM | TECHNIC_AUTHORISATION_FRAGMENT_PROGRAM
	};

	virtual ~MAFShader();
	MAF_EXPORT static void init();

	MAF_EXPORT static TECHNIC_AUTHORISATION getTechnicAuthorisation();
	MAF_EXPORT static void setTechnicAuthorisation(TECHNIC_AUTHORISATION);

	// return 1D texture lookup for some math function..
	MAF_EXPORT static osg::Texture1D* getAcosTexture();
	MAF_EXPORT static osg::Texture1D* getAsinTexture();

	// return a cubemap for vector normalization
	MAF_EXPORT static osg::TextureCubeMap* getCubeMapNormalize();

	MAF_EXPORT static bool isVertexProgramSupported();
	MAF_EXPORT static bool isFragmentProgramSupported();

	// Return a new instance of shader
	// This is typically just a factory
	MAF_EXPORT static bool get(MAFShaderType, MAFShader **);

	MAF_EXPORT inline osg::VertexProgram* getVertexProgram() { return vp_.get(); }
	MAF_EXPORT inline osg::FragmentProgram* getFragmentProgram() { return fp_.get(); }

	// configure a StateSet so that it uses properly this shader
	MAF_EXPORT virtual void configureStateSet(osg::StateSet &);

protected:
	static float* generateAcosLookup();
	static unsigned char* generateAsinLookup();

	void writeProgramToDisk(const char *vertex_file, const char *fragment_file, const char *vp, const char *fp);

	osg::ref_ptr<osg::VertexProgram> vp_;
	osg::ref_ptr<osg::FragmentProgram> fp_;
};

class MAFVertexProgram : public osg::VertexProgram {
public:
	MAFVertexProgram(MAFShader *from) : from_(from) { };

	MAFShader* from() const { return from_; }

protected:
	MAFShader *from_;
};

class MAFFragmentProgram : public osg::FragmentProgram {
public:
	MAFFragmentProgram(MAFShader *from) : from_(from) { };

	MAFShader* from() const { return from_; }

protected:
	MAFShader *from_;
};

#endif
