/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *  Cedric Pinson <cpinson@freesheep.org>
 */

#ifndef maf_cursor_h
#define maf_cursor_h

#ifndef MAF_USE_VS_PCH
#include <osg/PositionAttitudeTransform>
#endif

#include <maf/controller.h>

class MAFCursorModel  : public MAFModel
{
public:
	MAFCursorModel() {}
  MAF_EXPORT virtual void Init(MAFApplication* application, const std::string& path) {}
  MAF_EXPORT virtual void SetCursor(int cursor) {}
  MAF_EXPORT virtual int GetNbCursor() { return 0;}
  MAF_EXPORT virtual void ShowCursor(bool state) {}
  MAF_EXPORT virtual void WarpMouse(int x,int y) {}
  MAF_EXPORT virtual void Update(MAFApplication* application) {}
  MAF_EXPORT virtual void InitCursor() {}
  MAF_EXPORT virtual void ReleaseCursor(){}
  MAF_EXPORT virtual void UpdatePosition(int x,int y) {}
};


class MAFCursorModelSDL : public MAFCursorModel
{
public:
  MAF_EXPORT MAFCursorModelSDL();
  MAF_EXPORT void Init(MAFApplication* application, const std::string& path);
  MAF_EXPORT void Update(MAFApplication* application) {}
  MAF_EXPORT void SetCursor(int cursor);
  MAF_EXPORT int GetNbCursor();
  MAF_EXPORT void ShowCursor(bool state);
  MAF_EXPORT void WarpMouse(int x,int y);

  std::vector<SDL_Cursor*> mCursors;
};


class MAFSceneModel;
class MAFCursorModelGL : public MAFCursorModel
{
  osg::ref_ptr<osg::PositionAttitudeTransform> mPAT;
  osg::ref_ptr<osg::Node> mNode;
  osg::ref_ptr<osg::Node> mCursor;
	MAFApplication* mApplication;

  bool mWarpMouseOccur;
  int mWarpX,mWarpY;

 public:
  MAF_EXPORT MAFCursorModelGL(MAFApplication* application);
  MAF_EXPORT void Init(MAFApplication* application, const std::string& path);
  MAF_EXPORT void SetCursor(int cursor);
  MAF_EXPORT int GetNbCursor();
  MAF_EXPORT void InitCursor();
  MAF_EXPORT void ReleaseCursor();
  MAF_EXPORT void ShowCursor(bool state);
  MAF_EXPORT void WarpMouse(int x,int y);
  MAF_EXPORT void Update(MAFApplication* application);
  MAF_EXPORT void UpdatePosition(int x,int y);

  std::vector<osg::ref_ptr<osg::Node> > mCursors;
};


struct MAFCursorModelAnimated : public MAFCursorModel
{
	MAF_EXPORT MAFCursorModelAnimated();
  MAF_EXPORT void Init(MAFApplication* application, const std::string& path);
	// remove me
  MAF_EXPORT void SetCursor(int cursor);
  MAF_EXPORT int GetNbCursor() {return 0;}
  MAF_EXPORT void ShowCursor(bool state);
	MAF_EXPORT void WarpMouse(int x,int y);
  MAF_EXPORT void Update(MAFApplication* application);
  MAF_EXPORT void InitCursor();
  MAF_EXPORT void ReleaseCursor();
  MAF_EXPORT void UpdatePosition(int x,int y);
	int mCurrentFrame;
	float mCurrentTime;
	float mFrameTime;
	std::vector<MAFCursorModel*> mFrames;
};



class MAFCursorController : public MAFController
{
  std::string mCurrentCursor;
  std::string mPreviousCursor;
  bool mShowCursor;
public:
  MAF_EXPORT MAFCursorController();
  MAF_EXPORT ~MAFCursorController();
  MAF_EXPORT MAFCursorModel *GetModel(){return 	mModels[mCurrentCursor];}
  MAF_EXPORT void Init(MAFApplication* application);
  MAF_EXPORT bool Update(MAFApplication* application);

  MAF_EXPORT void InitCursor();
  MAF_EXPORT void ReleaseCursor();

  MAF_EXPORT void RestoreCursor();
  MAF_EXPORT void ShowCursor(bool state);

  MAF_EXPORT void SetCursor(const std::string& cursor);
  MAF_EXPORT int GetNbCursors();
  MAF_EXPORT void WarpMouse(int x,int y);
	std::map<std::string, MAFCursorModel*> mModels;
};


#endif //maf_cursor_h

