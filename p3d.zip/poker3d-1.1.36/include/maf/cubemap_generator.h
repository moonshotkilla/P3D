
#ifndef MAF_CUBEMAP_GENERATOR_H
#define MAF_CUBEMAP_GENERATOR_H

#ifndef MAF_USE_VS_PCH
#include <osg/Referenced>
#include <osg/Image>
#include <osg/TextureCubeMap>
#include <osg/Notify>
#include <osg/Vec3>
#include <osg/Matrix>
#endif

class MAFCubeMapGenerator : public osg::Referenced {
public:
	explicit MAFCubeMapGenerator(int texture_size = 64);
	MAFCubeMapGenerator(const MAFCubeMapGenerator &copy, const osg::CopyOp &copyop = osg::CopyOp::SHALLOW_COPY);	
	inline osg::Image *getImage(osg::TextureCubeMap::Face face);
	inline const osg::Image *getImage(osg::TextureCubeMap::Face face) const;

	void generateMap();

protected:
	virtual ~MAFCubeMapGenerator() {}
	MAFCubeMapGenerator &operator=(const MAFCubeMapGenerator &) { return *this; }

	inline void set_pixel(int index, int c, int r, const osg::Vec3 &color);
	inline static osg::Vec3 vector_to_color(const osg::Vec3 &vec);

	virtual osg::Vec3 compute_color(const osg::Vec3 &R) const = 0;

private:
	int texture_size_;

	typedef std::vector<osg::ref_ptr<osg::Image> > Image_list;
	Image_list images_;
};

inline osg::Image *MAFCubeMapGenerator::getImage(osg::TextureCubeMap::Face face)
{
	switch (face) {
		case osg::TextureCubeMap::POSITIVE_X: return images_[0].get();
		case osg::TextureCubeMap::NEGATIVE_X: return images_[1].get();
		case osg::TextureCubeMap::POSITIVE_Y: return images_[2].get();
		case osg::TextureCubeMap::NEGATIVE_Y: return images_[3].get();
		case osg::TextureCubeMap::POSITIVE_Z: return images_[4].get();
		case osg::TextureCubeMap::NEGATIVE_Z: return images_[5].get();
		default: return 0;
	}
}

inline const osg::Image *MAFCubeMapGenerator::getImage(osg::TextureCubeMap::Face face) const
{
	switch (face) {
		case osg::TextureCubeMap::POSITIVE_X: return images_[0].get();
		case osg::TextureCubeMap::NEGATIVE_X: return images_[1].get();
		case osg::TextureCubeMap::POSITIVE_Y: return images_[2].get();
		case osg::TextureCubeMap::NEGATIVE_Y: return images_[3].get();
		case osg::TextureCubeMap::POSITIVE_Z: return images_[4].get();
		case osg::TextureCubeMap::NEGATIVE_Z: return images_[5].get();
		default: return 0;
	}
}

inline void MAFCubeMapGenerator::set_pixel(int index, int c, int r, const osg::Vec3 &color)
{
	osg::Image *i = images_[index].get();
	if (i) {
		*(i->data(c, r)+0) = static_cast<unsigned char>(osg::clampBetween(color.x(), 0.0f, 1.0f) * 255);
		*(i->data(c, r)+1) = static_cast<unsigned char>(osg::clampBetween(color.y(), 0.0f, 1.0f) * 255);
		*(i->data(c, r)+2) = static_cast<unsigned char>(osg::clampBetween(color.z(), 0.0f, 1.0f) * 255);
	}
	else {
		osg::notify(osg::WARN) << "Warning: CubeMapGenerator::set_pixel(): invalid image index\n";
	}
}

inline osg::Vec3 MAFCubeMapGenerator::vector_to_color(const osg::Vec3 &vec)
{
	return osg::Vec3(
		vec.x() / vec.length() / 2 + 0.5f,
		vec.y() / vec.length() / 2 + 0.5f,
		vec.z() / vec.length() / 2 + 0.5f);
}

#endif
