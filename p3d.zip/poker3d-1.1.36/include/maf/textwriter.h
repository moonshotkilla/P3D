/*
*
* Copyright (C) 2005, 2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#ifndef MAF_TEXTWRITER_H
#define MAF_TEXTWRITER_H

#ifndef MAF_USE_VS_PCH

#include <maf/mafexport.h>

#include <osg/AutoTransform>
#include <osg/Texture2D>
#endif

class MAFTextWriter : public osg::AutoTransform {
public:

	enum TEXT_HALIGN {
		TEXT_HALIGN_LEFT,
		TEXT_HALIGN_CENTER,
		TEXT_HALIGN_RIGHT,
	};

	enum TEXT_VALIGN {
		TEXT_VALIGN_TOP,
		TEXT_VALIGN_CENTER,
		TEXT_VALIGN_BOTTOM,
	};

	class FontElement {
	public:

		FontElement(char _code, char *_filename = NULL) : code(_code), filename(_filename) { };
		char code;
		char *filename;
	};

	class Glyph {
	public:

		Glyph() : texture(NULL) { }
		virtual ~Glyph() { }

		osg::ref_ptr<osg::Texture2D> texture;
		osg::Vec2f uvmin;
		osg::Vec2f uvmax;
		float width;
		float height;
	};

	MAF_EXPORT MAFTextWriter(const std::string &basePath, const std::vector<FontElement> &font);
	virtual ~MAFTextWriter();

	MAF_EXPORT void setText(const std::string &);
	MAF_EXPORT float getTextWidth(const std::string &) const;

	MAF_EXPORT void setTextHAlign(TEXT_HALIGN textHAlign) { textHAlign_ = textHAlign; }
	MAF_EXPORT TEXT_HALIGN getTextHAlign() const { return textHAlign_; }

	MAF_EXPORT void setTextVerticalAlign(TEXT_VALIGN textVAlign) { textVAlign_ = textVAlign; }
	MAF_EXPORT TEXT_VALIGN getTextVerticalAlign() const { return textVAlign_; }

	MAF_EXPORT int getNbCharacters() const;
	MAF_EXPORT std::vector<osg::Geode*> getCharacters() const;

	MAF_EXPORT const std::map<char, Glyph>& charToGlyph() const { return charToGlyph_; }

protected:
	std::map<char, Glyph> charToGlyph_;
	TEXT_HALIGN textHAlign_;
	TEXT_VALIGN textVAlign_;
};

#endif
