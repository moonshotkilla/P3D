/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Johan Euphrosine <johan@mekensleep.com>
*
*/

#ifndef MAF_ALPHA_FX
#define MAF_ALPHA_FX

#ifndef MAF_USE_VS_PCH
#include <osg/TexEnvCombine>
#endif

#include <maf/interpolator.h>

struct MAFAlphaFX : osg::TexEnvCombine
{
  MAFAlphaFX() : mColor(1.0f, 1.0f, 1.0f, 1.0f)
  {
    setCombine_RGB(osg::TexEnvCombine::REPLACE);
    setCombine_Alpha(osg::TexEnvCombine::MODULATE);
    setSource0_RGB(osg::TexEnvCombine::TEXTURE);
    setOperand0_RGB(osg::TexEnvCombine::SRC_COLOR);
    setSource0_Alpha(osg::TexEnvCombine::TEXTURE);
    setOperand0_Alpha(osg::TexEnvCombine::SRC_ALPHA);
    setSource1_Alpha(osg::TexEnvCombine::CONSTANT);
    setOperand1_Alpha(osg::TexEnvCombine::SRC_ALPHA);
    setConstantColor(mColor);
  }
  MAFAlphaFX(const MAFAlphaFX& af,
	  const osg::CopyOp& copyop = osg::CopyOp::SHALLOW_COPY) : osg::TexEnvCombine(af, copyop)
  {
    assert(false);
  }
  ~MAFAlphaFX()
  {
  }
  void SetAlpha(float alpha)
  {
    mColor.w() = alpha;
    setConstantColor(mColor);
  }
  void Init(float from, float to, float duration)
  {
    mInterpolator.Init(from, to);
    mTimer.Init(duration);
    mTimer.Get(mColor.w(), mInterpolator);
    setConstantColor(mColor);
  }
  void Update(float delta)
  {
    if (mTimer.Finished() == false)
      {
				mTimer.AddTime(delta);
				mTimer.Get(mColor.w(), mInterpolator);
				setConstantColor(mColor);
      }
  }
  MAFLinearInterpolator<float> mInterpolator;
  MAFInterpolatorTimer<> mTimer;
  osg::Vec4 mColor;
};

#endif
