/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#ifndef maf_customassert_h 
#define maf_customassert_h

#ifndef MAF_USE_VS_PCH
#include <maf/mafexport.h>
#endif

#ifdef UNITTEST
#undef MAF_EXPORT
#define MAF_EXPORT
#endif

#ifndef DISABLE_CUSTOM_ASSERT
#define CUSTOM_ASSERT(_condition) CustomAssert::Instance().Check(_condition, #_condition, __FILE__, __FUNCTION__, __LINE__)
#define CUSTOM_ASSERT_MSG(_condition, _message) CustomAssert::Instance().Check(_condition, #_condition, __FILE__, __FUNCTION__, __LINE__, _message)
#else
#define CUSTOM_ASSERT(_condition)
#define CUSTOM_ASSERT_MSG(_condition, _message)
#endif

class MAF_EXPORT CustomAssert
{
public:
  static void CreateInstance();
  static void DestroyInstance();
  static CustomAssert& Instance();
  static CustomAssert* sInstance;
  CustomAssert();
  void SetHandler(void (&handler)());
  bool Check(bool condition, const char* description, const char* file, const char* function, int line, const char* message = "");
  const char* GetDescription() const;
  const char* GetMember() const;
  const char* GetFile() const;
  const char* GetFunction() const;
  const int GetLine() const;
  const char* GetMessage() const;
  typedef void (&HANDLER)();
  HANDLER GetHandler() const;
  static void DefaultHandler();
  private:
  void(*mHandler)();
  const char* mDescription;
  const char* mFile;
  const char* mFunction;
  int mLine;
  const char* mMessage;
};

#endif
