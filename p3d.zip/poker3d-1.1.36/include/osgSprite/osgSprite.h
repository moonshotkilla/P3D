/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#ifndef ugame_osgsprite_h
#define ugame_osgsprite_h

#ifndef UGAME_USE_VS_PCH
#include "ugame/ugameexport.h"
#endif

#ifdef UNITTEST
#undef UGAME_EXPORT
#define UGAME_EXPORT
#endif

#include <vector>
#include <string>
#include <sstream>
#include <istream>
#include <osg/ref_ptr>
#include <osg/MatrixTransform>
#include <osg/Vec3f>
#include <osg/Vec4f>
#include <osgText/Text>
#include <osg/Version>

#if OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1
static inline std::istream& operator >> (std::istream& input, osg::Vec3f& vec)
{
    input >> vec.x();
		input >> vec.y();
		input >> vec.z();
    return input;
}

static inline std::istream& operator >> (std::istream& input, osg::Vec4f& vec)
{
    input >> vec.x();
		input >> vec.y();
		input >> vec.z();
		input >> vec.w();
		return input;
}
#else //OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1
#include <osg/io_utils>
#endif //OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1


namespace osg
{
  class Image;
};

struct UGAME_EXPORT osgQuad : osg::MatrixTransform
{
  osgQuad();
  osgQuad(float w, float h, const osg::Vec4& color = osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f));
  ~osgQuad();
  void create();
  void resize(float w, float h);
  void setColor(const osg::Vec4& color);
  void setImage(const std::string& imagePath);
  const osg::Image* getImage() const;
  unsigned int _w;
  unsigned int _h;
  unsigned int _iw;
  unsigned int _ih;
};

struct _xmlDoc;

struct UGAME_EXPORT osgSprite : osg::MatrixTransform
{
  std::vector<osg::ref_ptr<osgQuad> > _frames;
  std::map<std::string, int> _name2index;
  float _currentTime;
  float _totalTime;
  osgSprite();
  ~osgSprite();
  void setTotalTime(float totalTime);
  float getTotalTime() const;
  void setCurrentTime(float currenTime);
  float getCurrentTime() const;
  void addTime(float delta);
  void subTime(float delta);
  void updateFrame();
  void addFrames(const std::string& directory, unsigned int frameCount);
  void addFrame(const std::string& path, const std::string& name = "");
  void setCurrentFrame(unsigned int index);
  void setCurrentFrame(const std::string& name);
  unsigned int getFrameCount() const;
  const osg::Image* getCurrentFrameImage() const;
  const osgQuad* getCurrentFrame() const;
  osgQuad* getCurrentFrame();
  void removeCurrentFrame();
  void load(const std::string& file, const std::string& path = "/", const std::string& dataDir = "");
  void load(_xmlDoc* name, const std::string& path = "/", const std::string& dataDir = "");
  void save(const std::string& file, const std::string& path = "/");
  static bool isPowerOfTwo(unsigned int size);
  static unsigned int nextPowerOfTwo(unsigned int x);
  static osg::Image* copySubImagePowerOfTwo(osg::Image* image);
};

bool UGAME_EXPORT _headerGetList(std::vector<std::string>& result, _xmlDoc* name, const std::string& path);
bool UGAME_EXPORT _headerGet(std::string& result, _xmlDoc* name, const std::string& path);

template<typename T>
 bool _headerGetT(T& result, _xmlDoc* name, const std::string& path)
{

  std::string resultStr;
  bool headerGetResult = _headerGet(resultStr, name, path);
  if (!headerGetResult)
    return false;
  std::istringstream iss(resultStr);
  iss >> result;

  return true;
}
template<typename T>
 bool _headerGetListT(std::vector<T>& result, _xmlDoc* name, const std::string& path)
{

  std::vector<std::string> resultStr;
  bool headerGetListResult = _headerGetList(resultStr, name, path);
  if (!headerGetListResult)
    return false;

  result.resize(resultStr.size());
  for (unsigned int i = 0; i < resultStr.size(); ++i)
    {      
      std::istringstream iss(resultStr[i]);
      iss >> result[i];
    }
  return true;
}
#endif
