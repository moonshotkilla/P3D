/*
 *
 * Copyright (C) 2005, 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 */

#ifndef _EVALPATH_H_
#define _EVALPATH_H_

#include <glib.h>

#if defined(_MSC_VER) || defined(__CYGWIN__) || defined(__MINGW32__) || defined( __BCPLUSPLUS__) || defined( __MWERKS__)
	#  ifdef EVALPATH_LIBRARY
	#    define EVALPATH_EXPORT   __declspec(dllexport)
	#  else
	#    define EVALPATH_EXPORT   __declspec(dllimport)
	#  endif /* EVALPATH_LIBRARY */
#else
	#  define EVALPATH_EXPORT
#endif

#ifdef  __cplusplus
extern "C" {
#endif /*  __cplusplus */

#define EVALPATH_ERROR evalpath_error_quark()

  EVALPATH_EXPORT GQuark evalpath_error_quark(void);

#define EVALPATH_ERROR_REF_NOT_REGULAR		1
#define EVALPATH_ERROR_DOES_NOT_EXIST		2
#define EVALPATH_ERROR_INCONSISTENT_ROOT  	3
#define EVALPATH_ERROR_REF_EMPTY		4

  EVALPATH_EXPORT gchar* evalpath(const gchar* path, GError** error);


#ifdef  __cplusplus
}
#endif /*  __cplusplus */

#endif /* _EVALPATH_H_ */
