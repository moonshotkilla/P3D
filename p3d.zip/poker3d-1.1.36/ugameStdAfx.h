/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Igor kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef __UGAMESTDAFX_H
#define __UGAMESTDAFX_H

#ifdef UGAME_USE_VS_PCH

#define NOMINMAX

#include <algorithm>
#include <assert.h>
#include <cstdio>
#include <iomanip>
#include <iostream>
#include <istream>
#include <sstream>
#include <vector>

#include <nprofile/profile.h>

#include <osg/Array>
#include <osg/BlendFunc>
#include <osg/CullFace>
#include <osg/CullStack>
#include <osg/Depth>
#include <osg/Geode>
#include <osg/Geometry>
#include <osg/Group>
#include <osg/LineWidth>
#include <osg/Material>
#include <osg/Matrix>
#include <osg/MatrixTransform>
#include <osg/NodeCallback>
#include <osg/NodeVisitor>
#include <osg/Notify>
#include <osg/PolygonMode>
#include <osg/PolygonOffset>
#include <osg/PositionAttitudeTransform>
#include <osg/Projection>
#include <osg/Referenced>
#include <osg/ShapeDrawable>
#include <osg/StateAttribute>
#include <osg/Texture2D>
#include <osg/Transform>
#include <osg/Vec3>
#include <osg/Vec4>

#include <osgText/Font>
#include <osgText/Text>

#include <osgDB/FileNameUtils>
#include <osgDB/FileUtils>
#include <osgDB/Input>
#include <osgDB/Output>
#include <osgDB/ReadFile>
#include <osgDB/Registry>

#include <libxml/xmlreader.h>
#include <libxml/xpath.h>

#include <cal3d/scheduler.h>

#include <osgCal/Model>

#include "osgchips/Stacks"

#include <maf/application.h>
#include <maf/assert.h>
#include <maf/depthmask.h>
#include <maf/renderbin.h>

#include "ugame/animated.h"
#include "ugame/artefact.h"
#include "ugame/BetSlider"
#include "ugame/Bubble"
#include "ugame/debug.h"
#include "ugame/text.h"
#include "ugame/timeout.h"
#include "ugame/ugameexport.h"
#include "ugame/ugameerror.h"
#include "osgSprite/osgSprite.h"

#include <varseditor/varseditor.h>

#include "CustomAssert/CustomAssert.h"

#ifndef snprintf
#define snprintf _snprintf
#endif
#ifndef vsnprintf
#define vsnprintf _vsnprintf
#endif

#endif

#endif // __UGAMESTDAFX_H
