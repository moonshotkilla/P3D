/* -*- c++ -*-
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *
 */

#include "ugameStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifndef UGAME_USE_VS_PCH
#include <iostream>

#include <libxml/xmlreader.h>
#include <libxml/xpath.h>

#ifdef USE_NPROFILE
#include <nprofile/profile.h>
#else  //USE_NPROFILE
#define NPROFILE_SAMPLE(a)
#endif //USE_NPROFILE

#include <osgDB/ReadFile>
#include <osgDB/Registry>
#include <osg/Notify>
#include <osg/Material>
#include <osg/Texture2D>
#include <osg/BlendFunc>
#include <osg/Depth>
#include <osg/NodeVisitor>
#include <osg/CullStack>

#include <varseditor/varseditor.h>
#include <maf/assert.h>
#include <osgchips/Stacks>

#ifdef WIN32
#ifndef snprintf
#define snprintf _snprintf
#endif
#ifndef vsnprintf
#define vsnprintf _vsnprintf
#endif
#endif

#endif

using namespace osgchips;

#define MAX_HEIGHT 1000000


//
// OSG interface for inclusion within a .osg file
//
static bool readLocalData(osg::Object &obj, osgDB::Input &fr)
{
  return true;
}

static bool writeLocalData(const osg::Object &obj, osgDB::Output &fw)
{
  return true;
}

static osgDB::RegisterDotOsgWrapperProxy static_ManagedStacks(
																											 new ManagedStacks,
																											 "ManagedStacks",
																											 "Object Node Geode ManagedStacks",
																											 readLocalData,
																											 writeLocalData
																											 );
 
static osgDB::RegisterDotOsgWrapperProxy static_Stacks(
																											 new Stacks,
																											 "Stacks",
																											 "Object Node Geode Stacks",
																											 readLocalData,
																											 writeLocalData
																											 );
 
static osgDB::RegisterDotOsgWrapperProxy static_Stack(
																											new Stack,
																											"Stack",
																											"Object Drawable Geometry Stack",
																											readLocalData,
																											writeLocalData
																											);



//
// Serialization helpers
//

static bool readColorFromXml(xmlTextReaderPtr reader, osg::Vec4& color) {
  bool status = false;
  xmlChar* red = xmlTextReaderGetAttribute(reader, (const xmlChar*)"red");
  if(red) {
    color.x() = atoi((const char*)red) / 255.f;
    xmlFree(red);
    status = true;
  }
  xmlChar* green = xmlTextReaderGetAttribute(reader, (const xmlChar*)"green");
  if(green) {
    color.y() = atoi((const char*)green) / 255.f;
    xmlFree(green);
    status = true;
  }
  xmlChar* blue = xmlTextReaderGetAttribute(reader, (const xmlChar*)"blue");
  if(blue) {
    color.z() = atoi((const char*)blue) / 255.f;
    xmlFree(blue);
    status = true;
  }
  xmlChar* alpha = xmlTextReaderGetAttribute(reader, (const xmlChar*)"alpha");
  if(alpha) {
    color.w() = atof((const char*)alpha);
    xmlFree(alpha);
    status = true;
  } else {
    color.w() = 1.f;
  }
  return status;
}

static bool readVec3FromXml(xmlTextReaderPtr reader, osg::Vec3& vec) {
  xmlChar* x = xmlTextReaderGetAttribute(reader, (const xmlChar*)"x");
  if(x) { vec.x() = atof((const char*)x); xmlFree(x); }
  xmlChar* y = xmlTextReaderGetAttribute(reader, (const xmlChar*)"y");
  if(y) { vec.y() = atof((const char*)y); xmlFree(y); }
  xmlChar* z = xmlTextReaderGetAttribute(reader, (const xmlChar*)"z");
  if(z) { vec.z() = atof((const char*)z); xmlFree(z); }
  return true;
}

static bool readMaterialFromXml(xmlTextReaderPtr reader, std::map<std::string, osg::Vec4>& name2material) {
  const char* fileName = (const char*)xmlTextReaderCurrentDoc(reader)->URL;
  xmlChar* name = xmlTextReaderGetAttribute(reader, (const xmlChar*)"name");
  if(!name) {
    osg::notify(osg::WARN) << fileName << ": materials must have a name attribute" << std::endl;
    return false;
  }

  osg::Vec4 color;
  if(readColorFromXml(reader, color))
    name2material[(const char*)name] = color;

  xmlFree(name);
  return true;
}

static osg::Group* readosgchipsSubTreeFromXml(xmlTextReaderPtr reader, ChipBank* chipBank, osgDB::Registry* registry) {
  if(!chipBank) chipBank = ChipBank::instance();
  std::map<std::string, osg::Vec4> name2material;
  osg::Group* group = new osg::Group;
  std::map<std::string, Stacks*> name2stacks;

  int status;
  while((status = xmlTextReaderRead(reader)) == 1) {
    if(xmlTextReaderNodeType(reader) == XML_READER_TYPE_END_ELEMENT &&
       (!strcmp("osgchips", (const char*)xmlTextReaderConstName(reader))))
      return group;
    const char* name = (const char*)xmlTextReaderConstName(reader);
    const char* fileName = (const char*)xmlTextReaderCurrentDoc(reader)->URL;
    if(xmlTextReaderNodeType(reader) == XML_READER_TYPE_ELEMENT) {

      if(!strcmp("material", name)) {
        if(!readMaterialFromXml(reader, name2material))
          break;
      } else if(!strcmp("chip", name)) {
        xmlChar* value = xmlTextReaderGetAttribute(reader, (const xmlChar*)"value");
        if(!value) {
          osg::notify(osg::WARN) << fileName << ": missing value attribute" << std::endl;
          continue;
        }

        xmlChar* name = xmlTextReaderGetAttribute(reader, (const xmlChar*)"name");
        if(!name) {
          xmlFree(value);
          osg::notify(osg::WARN) << fileName << ": missing name attribute" << std::endl;
          continue;
        }

        ChipBank::Chip* chip = new ChipBank::Chip((const char*)name, atoi((const char*)value));
	
        xmlFree(name);
        xmlFree(value);

        //
        // Create the texture from the image, if any
        //
        name = xmlTextReaderGetAttribute(reader, (const xmlChar*)"texture");
        if(name) {
          osg::Image* image = osgDB::readImageFile((const char*)name, registry->getOptions());
          xmlFree(name);
          if(image) chip->setTexture(image);
        } 

        //
        // Retrieve the material from its name, if any
        //
        name = xmlTextReaderGetAttribute(reader, (const xmlChar*)"material");
        if(name) {
          if(name2material.find((const char*)name) != name2material.end()) {
            chip->setColor(name2material[(const char*)name]);
          }
          xmlFree(name);
        }

        chipBank->addChip(chip);

      } else if(!strcmp("handler", (const char*)xmlTextReaderConstName(reader))) {
        char* type = (char*)xmlTextReaderGetAttribute(reader, (const xmlChar*)"type");
        if(type) {
          if(!strcmp(type, "OnTop")) {
            char* stacks1_name = (char*)xmlTextReaderGetAttribute(reader, (const xmlChar*)"stacks1");
		  
            if(stacks1_name) {
              if(name2stacks.find(stacks1_name) != name2stacks.end()) {
                ManagedStacks* stacks1 = dynamic_cast<ManagedStacks*>(name2stacks[stacks1_name]);
                if(stacks1) {
                  char* stacks2_name = (char*)xmlTextReaderGetAttribute(reader, (const xmlChar*)"stacks2");
		  
                  if(stacks2_name) {
                    if(name2stacks.find(stacks2_name) != name2stacks.end()) {
                      ManagedStacks* stacks2 = dynamic_cast<ManagedStacks*>(name2stacks[stacks2_name]);
                      if(stacks2) {
                        ManagedStacks::EventHandler* handler;

                        if(!strcmp(type, "OnTop"))
                          handler = new ManagedStacks::OnTopEventHandler(stacks1, stacks2);
                      } else {
                        osg::notify(osg::WARN) << fileName << ": the stacks " << stacks2_name << " is not an instance of ManagedStacks" << std::endl;
                      }
                    } else {
                      osg::notify(osg::WARN) << fileName << ": the stacks " << stacks2_name << " is unknown" << std::endl;
                    }
                    xmlFree(stacks2_name);
                  } else {
                    osg::notify(osg::WARN) << fileName << ": missing stacks2_ attribute" << std::endl;
                  }
                } else {
                  osg::notify(osg::WARN) << fileName << ": the stacks " << stacks1_name << " is not an instance of ManagedStacks" << std::endl;
                }
              } else {
                osg::notify(osg::WARN) << fileName << ": the stacks " << stacks1_name << " is unknown" << std::endl;
              }
              xmlFree(stacks1_name);
            } else {
              osg::notify(osg::WARN) << fileName << ": missing stacks attribute  " << std::endl;
            }
          } else {
            osg::notify(osg::WARN) << fileName << ": handler type " << type << " unknown " << std::endl;
          }
        } else {
          osg::notify(osg::WARN) << fileName << ": missing type attribute in handler element " << std::endl;
        }
        xmlFree(type);

      } else if(!strcmp("stacks", name) ||
                !strcmp("managedstacks", name)) {
        Stacks* stacks = 0;
        ManagedStacks* managedStacks = 0;
        if(!strcmp("managedstacks", name)) {
          stacks = managedStacks = new ManagedStacks(chipBank);
        } else {
          stacks = new Stacks(chipBank);
        }
        char* stacks_name = (char*)xmlTextReaderGetAttribute(reader, (const xmlChar*)"name");
        if(stacks_name) {
          name2stacks[stacks_name] = stacks;
          stacks->setName(stacks_name);
          xmlFree(stacks_name);
        }
	
        group->addChild(stacks);
        while((status = xmlTextReaderRead(reader)) == 1) {
          if(xmlTextReaderNodeType(reader) == XML_READER_TYPE_END_ELEMENT &&
             !strcmp(name, (const char*)xmlTextReaderConstName(reader)))
            break;

          if(xmlTextReaderNodeType(reader) == XML_READER_TYPE_ELEMENT) {
            if(!strcmp("stack", (const char*)xmlTextReaderConstName(reader))) {
              xmlChar* name;
              name = xmlTextReaderGetAttribute(reader, (const xmlChar*)"chip");
              if(!name) {
                osg::notify(osg::WARN) << fileName << ": each stack element must have a chip attribute " << std::endl;
                continue;
              }

              ChipBank::Chip* chip = chipBank->getChip((const char*)name);
              xmlFree(name);
              if(!chip) {
                osg::notify(osg::WARN) << fileName << ": a stack wants to use the unknown chip " << chip->_name << std::endl;
                continue;
              }
	      
              Stack* stack = new Stack();
              stack->setChip(chip);

              xmlChar* count = xmlTextReaderGetAttribute(reader, (const xmlChar*)"count");
              if(count) {
                stack->setCount(atoi((const char*)count));
                xmlFree(count);
              }

              osg::Vec3 position;
              if(!readVec3FromXml(reader, position)) {
                osg::notify(osg::WARN) << fileName << ": a failed to read x/y/z for a stack " << std::endl;
                continue;
              }
              stack->setPosition(position);

              stacks->addStack(stack);
            } else if(!strcmp("controller", (const char*)xmlTextReaderConstName(reader))) {
              char* type = (char*)xmlTextReaderGetAttribute(reader, (const xmlChar*)"type");
              if(type) {
                if(!strcmp(type, "Arithmetic")) {
                  ManagedStacks::ArithmeticController* controller = new ManagedStacks::ArithmeticController(managedStacks);
                  char* pattern = (char*)xmlTextReaderGetAttribute(reader, (const xmlChar*)"pattern");
                  if(pattern) {
                    controller->setPattern(pattern);
                    xmlFree(pattern);
                  }
                  managedStacks->addController(controller);
                } else {
                  osg::notify(osg::WARN) << fileName << ": controller type " << type << " unknown " << std::endl;
                }
                xmlFree(type);
              } else {
                osg::notify(osg::WARN) << fileName << ": a failed to get type of stacks controller " << std::endl;
              }
            } else if(!strcmp("handler", (const char*)xmlTextReaderConstName(reader))) {
              char* type = (char*)xmlTextReaderGetAttribute(reader, (const xmlChar*)"type");
              if(type) {
                if(!strcmp(type, "ScaledPlacement")) {
                  ManagedStacks::ScaledPlacementEventHandler* handler = new ManagedStacks::ScaledPlacementEventHandler;
                  managedStacks->addEventHandler(handler);
                } else {
                  osg::notify(osg::WARN) << fileName << ": handler type " << type << " unknown " << std::endl;
                }
              } else {
                osg::notify(osg::WARN) << fileName << ": failed to get type of stacks handler " << std::endl;
              }
              xmlFree(type);
            } 
          }
        }
      }
    }
  }
  if(status == 0) {
    return group;
  } else {
    osg::ref_ptr<osg::Group> delete_group = group;
    return NULL;
  }
}

static osg::Node* readosgchipsFromXml(xmlTextReaderPtr reader, ChipBank* chipBank, osgDB::Registry* registry) {
  osg::Group* group = NULL;
  int status;
  while((status = xmlTextReaderRead(reader)) == 1) {
    const char* fileName = (const char*)xmlTextReaderCurrentDoc(reader)->URL;
    if(xmlTextReaderNodeType(reader) == XML_READER_TYPE_ELEMENT) {

      if(!strcmp("osgchips", (const char*)xmlTextReaderConstName(reader))) {
        xmlChar* mesh_file = xmlTextReaderGetAttribute(reader, (const xmlChar*)"mesh");
        if(mesh_file) {
          osg::ref_ptr<osg::Geode> geode = dynamic_cast<osg::Geode*>(osgDB::readNodeFile((const char*)mesh_file));
          if(geode.valid()) {
            osg::Geometry* mesh = dynamic_cast<osg::Geometry*>(geode->getDrawable(0));
            if(mesh) {
              chipBank->setVertexArray(dynamic_cast<osg::Vec3Array*>(mesh->getVertexArray()));
              chipBank->setNormalArray(dynamic_cast<osg::Vec3Array*>(mesh->getNormalArray()));
              chipBank->setTexCoordArray(dynamic_cast<osg::Vec2Array*>(mesh->getTexCoordArray(0)));
              chipBank->setPrimitiveSetList(mesh->getPrimitiveSetList());
              chipBank->setBoundingBox(mesh->getBound());
            } else {
              osg::notify(osg::WARN) << fileName << ": mesh " << mesh_file << " was expected to contain a single drawable" << std::endl;
            }
          } else {
            osg::notify(osg::WARN) << fileName << ": failed to load mesh " << (const char*)mesh_file << std::endl;
          }
          xmlFree(mesh_file);
        }
        group = readosgchipsSubTreeFromXml(reader, chipBank, registry);
      }
    }
  }
  if(status == 0 && group) {
    if(group->getNumChildren() == 0)
      return NULL;
    else if(group->getNumChildren() == 1)
      return group->getChild(0);
    else
      return group;
  } else {
    return NULL;
  }
}

//
// osgchips::ChipBank
//

ChipBank::Chip::Chip(const std::string& name, unsigned int value) :
  _name(name),
  _value(value),
  _hasColor(false)
{}

ChipBank::Chip::~Chip() {}


void ChipBank::Chip::setTexture(osg::Image* image) {
  if(image) {
    osg::Texture2D* texture = new osg::Texture2D;
    texture->setImage(image);
    texture->setWrap(osg::Texture2D::WRAP_T, osg::Texture2D::REPEAT);
    texture->setWrap(osg::Texture2D::WRAP_S, osg::Texture2D::REPEAT);
    texture->setFilter(osg::Texture2D::MIN_FILTER, osg::Texture2D::LINEAR_MIPMAP_LINEAR);
    texture->setFilter(osg::Texture2D::MAG_FILTER, osg::Texture2D::LINEAR);
    _texture = texture;
  } else {
    _texture = 0;
  }
}

ChipBank::ChipBank()
{
}

ChipBank::~ChipBank() {
  for(Value2Chip::iterator i = _value2chip.begin(); i != _value2chip.end(); i++)
    delete i->second;
}

static osg::ref_ptr<ChipBank> __chipBank = new ChipBank();

ChipBank* ChipBank::instance() {
  return __chipBank.get();
}

static void changeRootXml(xmlDocPtr doc, const std::string& xpath, const std::string& method)
{
  xmlXPathContextPtr context = xmlXPathNewContext(doc);
  xmlXPathObjectPtr object = xmlXPathEvalExpression((xmlChar*)xpath.c_str(), context);

  if(object == NULL) {
    osg::notify(osg::WARN) << method << " failed to eval " << xpath << " in file " << doc->URL << std::endl;
    return;
  }
  xmlNodeSetPtr nodes = object->nodesetval;
  if(nodes == NULL) {
    osg::notify(osg::WARN) << method << " no element found for " << xpath << " in file " << doc->URL << std::endl;
    return;
  }
  if(nodes->nodeNr > 1) {
    osg::notify(osg::WARN) << method << " " << nodes->nodeNr << " elements found, expected 1 " << xpath << " in file " << doc->URL << std::endl;
    return;
  }
  xmlNodePtr node = nodes->nodeTab[0];
  if(node->type != XML_ELEMENT_NODE) {
    osg::notify(osg::WARN) << method << " " << xpath << " is not an element in file " << doc->URL << std::endl;
    return;
  }
  
  xmlXPathFreeObject(object);
  xmlXPathFreeContext(context); 
  
  xmlDocSetRootElement(doc, node);
}

bool ChipBank::unserialize(struct _xmlDoc* doc, const std::string& xpath, osgDB::Registry* registry) {
  xmlNodePtr root = xmlDocGetRootElement(doc);
  if(xpath != "") changeRootXml(doc, xpath, "osgchips::ChipBank::unserialize");
  xmlTextReaderPtr reader = xmlReaderWalker(doc);
  if(reader == NULL) return false;
  osg::Node* node = readosgchipsFromXml(reader, this, registry);
  xmlFreeTextReader(reader);
  xmlDocSetRootElement(doc, root);
  return node == 0;
}

bool ChipBank::unserialize(const std::string& fileName, osgDB::Registry* registry) {
  xmlTextReaderPtr reader = xmlReaderForFile(fileName.c_str(), NULL, XML_PARSE_PEDANTIC|XML_PARSE_NONET);
  if(reader == NULL) return false;
  osg::Node* node = readosgchipsFromXml(reader, this, registry);
  xmlFreeTextReader(reader);
  return node == 0;
}

//
// osgchips::Stack
//

Stack::Stack() :
  _count(1),
  _chip(0),
  _chipBank(ChipBank::instance()),
  _max_height(MAX_HEIGHT)
{
  setUseDisplayList(false);
  setUseVertexBufferObjects(false);
	if(_chipBank)
		setMesh(_chipBank);
}

Stack::Stack(ChipBank* chipBank) :
  _count(0),
  _chip(0),
  _chipBank(chipBank),
  _max_height(MAX_HEIGHT)
{
	setUseDisplayList(false);
	setUseVertexBufferObjects(false);
  if(_chipBank)
    setMesh(_chipBank);
}

Stack::Stack(const Stack& stack, const osg::CopyOp& copyop) :
  Geometry(stack, copyop),
  _count(stack._count),
  _position(stack._position),
  _chip(stack._chip),
  _chipBank(stack._chipBank),
  _max_height(stack._max_height)
{
}

void Stack::setCount(unsigned int count) {
  if(_count != count) {
    _count = count;
    updateVertexArray();
    updateTexCoordArray();
    dirtyParentBound();
  }
}

void Stack::setPosition(const osg::Vec3& position) {
  if(position != _position) {
    _position = position;
    updateVertexArray();
    dirtyParentBound();
  }
}

void Stack::setChip(const ChipBank::Chip* chip) {
  _chip = chip;
  if(chip && (chip->_hasColor || chip->_texture.valid())) {
    osg::StateSet* state = getOrCreateStateSet();

    if(chip->_texture.valid()) {
      state->setTextureAttributeAndModes(0, (osg::StateAttribute*)chip->_texture.get(), osg::StateAttribute::ON);
    }

    if(chip->_hasColor) {
      osg::Material* material = new osg::Material;
      material->setColorMode(osg::Material::DIFFUSE);
      material->setDiffuse(osg::Material::FRONT_AND_BACK, chip->_color);
      state->setAttributeAndModes(material);
      if(!osg::equivalent(chip->_color[3], 1.f)) {
				osg::BlendFunc* blendFunc = new osg::BlendFunc();
				//	blendFunc->setFunction(GL_SRC_ALPHA, GL_ONE);
				blendFunc->setFunction(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
				state->setAttributeAndModes(blendFunc);
				//state->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);

				int rbvalue = 0;
				if (!VarsEditor::Instance().Get("RB_StackTransparency",rbvalue))
					MAF_ASSERT(0 && "RB_StackTransparency not found in client.xml");
				state->setRenderBinDetails(rbvalue, "DepthSortedBin");

				osg::Depth* depth = new osg::Depth();
				depth->setWriteMask(0);
				state->setAttributeAndModes(depth);
      }
    }
  }
  setCount(0);
}

#if OSG_VERSION_MAJOR != 2
void Stack::drawImplementation(osg::State& state) const {
  NPROFILE_SAMPLE("Stack::drawImplementation");
  if(_count > 0)
    Geometry::drawImplementation(state);
}
#else // OSG_VERSION_MAJOR != 2
void Stack::drawImplementation(osg::RenderInfo& renderInfo) const {
  NPROFILE_SAMPLE("Stack::drawImplementation");
  if(_count > 0)
    Geometry::drawImplementation(renderInfo);
}
#endif  // OSG_VERSION_MAJOR != 2

void Stack::setMesh(ChipBank* chipBank) {
  if(chipBank->getTexCoordArray() == 0 ||
     chipBank->getVertexArray() == 0 ||
     chipBank->getNormalArray() == 0 ||
     chipBank->getPrimitiveSetList().size() == 0) {
    osg::notify(osg::WARN) << "osgchips::Stack::setMesh: chipbank has no valid mesh" << std::endl;
  } else {
    setNormalArray(chipBank->getNormalArray());
    setPrimitiveSetList(chipBank->getPrimitiveSetList());
    setTexCoordArray(0, new osg::Vec2Array(*dynamic_cast<osg::Vec2Array*>(chipBank->getTexCoordArray()),
                                           osg::CopyOp(osg::CopyOp::DEEP_COPY_ARRAYS)));
    setVertexArray(new osg::Vec3Array(*dynamic_cast<osg::Vec3Array*>(chipBank->getVertexArray()),
                                      osg::CopyOp(osg::CopyOp::DEEP_COPY_ARRAYS)));
  }
}

void Stack::updateVertexArray() {
  if(_count == 0 || _chipBank == 0) return;

  if(_chipBank->getVertexArray() && getVertexArray()) {
    unsigned int count = _count > _max_height ? _max_height : _count;
    //
    // Stretch the mesh up
    //
    osg::Vec3Array* from = _chipBank->getVertexArray();
    osg::Vec3Array* to = dynamic_cast<osg::Vec3Array*>(getVertexArray());
    for(osg::Vec3Array::iterator i = from->begin(), j = to->begin();
        i != from->end() && j != to->end();
        i++, j++) {
      osg::Vec3& vertex_from = *i;
      osg::Vec3& vertex_to = *j;
      vertex_to = vertex_from + _position;
      if(!osg::equivalent(vertex_from.y(), _position.y(), 0.1f))
        vertex_to.y() = _position.y() + vertex_from.y() * count;
    }
  }
}

void Stack::updateTexCoordArray() {
  if(_count == 0) return;

  if(getTexCoordArray(0)) {
    //
    // Wrap the texture of the chip border
    //
    unsigned int count = _count > _max_height ? _max_height : _count;
    osg::Vec2Array* texCoord = dynamic_cast<osg::Vec2Array*>(getTexCoordArray(0));
    for(osg::Vec2Array::iterator i = texCoord->begin() ; i != texCoord->end() ; i++) {
      osg::Vec2& uv = *i;
      if(uv.x() > 0.500 && (uv.y() > 0.245))
        uv.y() = count * 0.249;
    }
  }
}

void Stack::dirtyParentBound() {
  for(ParentList::iterator i = _parents.begin(); i != _parents.end(); ++i) {
    (*i)->dirtyBound();
  }
}

//
// osgchips::Stacks
//

class Box : public osg::Drawable {
public:
  META_Object(osgchips, Box)

    Box() {
    _box = new osg::Vec3Array(24);
    setUseDisplayList(false);
    setUseVertexBufferObjects(false);
  }

  Box(const Box& box, const osg::CopyOp& copyop=osg::CopyOp::SHALLOW_COPY) :
    osg::Drawable(box),
    _box(box._box)
  {
    setUseDisplayList(false);
    setUseVertexBufferObjects(false);
  }
    
#if OSG_VERSION_MAJOR != 2
  virtual void drawImplementation(osg::State&) const {
#else // OSG_VERSION_MAJOR != 2
  virtual void drawImplementation(osg::RenderInfo&) const {
#endif  // OSG_VERSION_MAJOR != 2
#if 0 // draw bounding box for debugging purpose
    glColor4f(1.f, 1.f, 1.f, 1.f);
    glBegin(GL_QUADS);
    for(osg::Vec3Array::const_iterator i  = _box->begin(); i != _box->end(); i++) {
      glVertex3fv((float*)i->_v);
    }
    glEnd();
#endif
  }

  virtual bool supports(osg::Drawable::AttributeFunctor&) const { return false; }
  virtual bool supports(osg::Drawable::ConstAttributeFunctor&) const { return true; }
  virtual void accept(osg::Drawable::ConstAttributeFunctor& af) const {}

#if OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
  virtual bool supports(osg::Drawable::PrimitiveIndexFunctor&) const { return false; }
  virtual void accept(osg::Drawable::PrimitiveIndexFunctor&) const {}

  virtual bool supports(osg::Drawable::PrimitiveFunctor&) const { return true; }
  virtual void accept(osg::Drawable::PrimitiveFunctor& functor) const;
#else // OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
  virtual bool supports(osg::PrimitiveIndexFunctor&) const { return false; }
  virtual void accept(osg::PrimitiveIndexFunctor&) const {}

  virtual bool supports(osg::PrimitiveFunctor&) const { return true; }
  virtual void accept(osg::PrimitiveFunctor& functor) const;
#endif // OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
  osg::ref_ptr<osg::Vec3Array> _box;
};

#if OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
void Box::accept(osg::Drawable::PrimitiveFunctor& functor) const {
#else // OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
void Box::accept(osg::PrimitiveFunctor& functor) const {
#endif // OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
  for(osg::Drawable::ParentList::const_iterator i = _parents.begin(); i != _parents.end(); i++) {
    (*i)->getBound();
  }

  if(_box.valid()) {
    osg::Vec3Array* box = const_cast<osg::Vec3Array*>(_box.get());
    
    functor.setVertexArray(box->getNumElements(), (osg::Vec3*)(box->getDataPointer()));
    functor.drawArrays(GL_QUADS, 0, box->getNumElements());
  }
}

Stacks::Stacks() :
  _box(new Box),
  _chipBank(ChipBank::instance())
{
  addDrawable(_box.get());
}

Stacks::Stacks(ChipBank* chipBank) :
  _box(new Box),
  _chipBank(chipBank)
{
  if(chipBank == 0)
    _chipBank = ChipBank::instance();
  addDrawable(_box.get());
}

Stacks::Stacks(const Stacks& stacks, const osg::CopyOp& copyop) :
  osg::Geode(stacks, copyop)
{
  if(getNumDrawables() < 1 || dynamic_cast<Box*>(getDrawable(0)) == 0)
    osg::notify(osg::WARN) << "osgchips::Stack::Stacks: first drawable is not of type Box" << std::endl;
  _box = dynamic_cast<Box*>(getDrawable(0));
}

Stacks::~Stacks() {}

bool Stacks::addStack(Stack* stack) {
  return addDrawable(stack);
}

bool Stacks::replaceStack(Stack* origStack, Stack* newStack) {
  return replaceDrawable(origStack, newStack);
}

bool Stacks::setStack(unsigned int index, Stack* stack) {
  return setDrawable(index + 1, stack);
}

#if OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
bool
#else // OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
osg::BoundingSphere
#endif // OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
Stacks::computeBound() const {
#if OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
   _bsphere.init();
#else // OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
  _boundingSphere.init();
#endif //  OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
  _bbox.init();

  const ChipBank* chipBank = _chipBank;
  for(unsigned int i = 0; i < getNumStacks(); i++) {
    const Stack* stack = getStack(i);
    if(stack && stack->getHeight() > 0) {
      const osg::Vec3& position = stack->getPosition();
      const osg::BoundingBox& reference = chipBank->getBoundingBox();
      osg::BoundingBox bbox;
      float r = (reference.xMax() - reference.xMin()) / 2.f;
      float h = (reference.yMax() - reference.yMin()) * stack->getHeight();
      bbox.expandBy(position + osg::Vec3(-r, 0, -r));
      bbox.expandBy(position + osg::Vec3(-r, 0, r));
      bbox.expandBy(position + osg::Vec3(r, 0, r));
      bbox.expandBy(position + osg::Vec3(r, 0, -r));
      bbox.expandBy(position + osg::Vec3(-r, h, -r));
      bbox.expandBy(position + osg::Vec3(-r, h, r));
      bbox.expandBy(position + osg::Vec3(r, h, r));
      bbox.expandBy(position + osg::Vec3(r, h, -r));
      _bbox.expandBy(bbox);
    }
  }

  if(!_bbox.valid()) 
    _bbox = osg::BoundingBox(osg::Vec3(-1.f, -1.f, -1.f), osg::Vec3(1.f, 1.f, 1.f));

  float h = (_bbox.yMax() - _bbox.yMin());
  Box* box = const_cast<Box*>(dynamic_cast<const Box*>(_box.get()));
  box->dirtyBound();
  osg::Vec3Array* cube = box->_box.get();
  int index = 0;
  // bottom
  (*cube)[index++].set(_bbox.xMax(), 0, _bbox.zMin());
  (*cube)[index++].set(_bbox.xMax(), 0, _bbox.zMax());
  (*cube)[index++].set(_bbox.xMin(), 0, _bbox.zMax());
  (*cube)[index++].set(_bbox.xMin(), 0, _bbox.zMin());
  // top
  (*cube)[index++].set(_bbox.xMin(), h, _bbox.zMin());
  (*cube)[index++].set(_bbox.xMin(), h, _bbox.zMax());
  (*cube)[index++].set(_bbox.xMax(), h, _bbox.zMax());
  (*cube)[index++].set(_bbox.xMax(), h, _bbox.zMin());
  // front
  (*cube)[index++].set(_bbox.xMin(), 0, _bbox.zMax());
  (*cube)[index++].set(_bbox.xMax(), 0, _bbox.zMax());
  (*cube)[index++].set(_bbox.xMax(), h, _bbox.zMax());
  (*cube)[index++].set(_bbox.xMin(), h, _bbox.zMax());
  // back
  (*cube)[index++].set(_bbox.xMin(), h, _bbox.zMin());
  (*cube)[index++].set(_bbox.xMax(), h, _bbox.zMin());
  (*cube)[index++].set(_bbox.xMax(), 0, _bbox.zMin());
  (*cube)[index++].set(_bbox.xMin(), 0, _bbox.zMin());
  // left
  (*cube)[index++].set(_bbox.xMin(), 0, _bbox.zMax());
  (*cube)[index++].set(_bbox.xMin(), h, _bbox.zMax());
  (*cube)[index++].set(_bbox.xMin(), h, _bbox.zMin());
  (*cube)[index++].set(_bbox.xMin(), 0, _bbox.zMin());
  // right
  (*cube)[index++].set(_bbox.xMax(), 0, _bbox.zMin());
  (*cube)[index++].set(_bbox.xMax(), h, _bbox.zMin());
  (*cube)[index++].set(_bbox.xMax(), h, _bbox.zMax());
  (*cube)[index++].set(_bbox.xMax(), 0, _bbox.zMax());

#if OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
   _bsphere.expandBy(_bbox);
   _bsphere_computed = true;
   return true;
#else // OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
  _boundingSphere.expandBy(_bbox);
  _boundingSphereComputed = true;
  return _boundingSphere;
#endif // OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
}

//
// osgchips::ManagedStacks
//

void ManagedStacks::ArithmeticController::addChips(const ChipsMap& chips_map) {

  ChipsMap current_chips_map;
  getChipsMap(current_chips_map);

  for(std::map<unsigned int,unsigned int>::const_iterator i = chips_map.begin();
      i != chips_map.end();
      i++) {
    unsigned int value = i->first;
    unsigned int count = i->second;
    if(current_chips_map.find(value) != current_chips_map.end())
      current_chips_map[value] += count;
    else
      current_chips_map[value] = count;
  }

  syncChips(current_chips_map);
}

void ManagedStacks::ArithmeticController::setChips(const std::vector<int>& chips) {

  if(chips.size() % 2) {
    osg::notify(osg::WARN) << "ManagedStacks::ArithmeticController::setChips: odd list size" << std::endl;
    return;
  }
  ChipsMap chips_map;
  for(std::vector<int>::const_iterator i = chips.begin(); i != chips.end(); i++) {
    int value = *i;
    i++;
    int count = *i;
    chips_map[value] = count;
  }

  setChips(chips_map);
}

void ManagedStacks::ArithmeticController::subChips(const ChipsMap& chips_map) {

  ChipsMap current_chips_map;
  getChipsMap(current_chips_map);

  for(std::map<unsigned int,unsigned int>::const_iterator i = chips_map.begin();
      i != chips_map.end();
      i++) {
    unsigned int value = i->first;
    unsigned int count = i->second;
    if(current_chips_map.find(value) != current_chips_map.end()) {
      if(current_chips_map[value] >= count) {
        current_chips_map[value] -= count;
      } else {
        osg::notify(osg::WARN) << "ManagedStacks::ArithmeticController::subChips: cannot subtract " << count << " from " << count << " chips stack because it only contains " << current_chips_map[value] << " chips (ignored)" << std::endl;
      }
    } else {
      osg::notify(osg::WARN) << "ManagedStacks::ArithmeticController::subChips: cannot subtract " << count << " from non existent stack (ignored)" << std::endl;
    }
  }

  syncChips(current_chips_map);
}

void ManagedStacks::ArithmeticController::syncChips(const ChipsMap& chips_map) {
  unsigned int j = 0;
  for(std::map<unsigned int,unsigned int>::const_iterator i = chips_map.begin();
      i != chips_map.end();
      i++, j++) {
    unsigned int value = i->first;
    unsigned int count = i->second;
    if(j >= getStacks()->getNumStacks())
      getStacks()->addStack(new Stack());
    Stack* stack = getStacks()->getStack(j);
    if(value != stack->getValue()) {
      char tmp[32];
      snprintf(tmp, 32, getPattern().c_str(), value);
      ChipBank::Chip* chip = stack->getChipBank()->getChip(tmp);
      if(!chip) {
				osg::notify(osg::WARN) << "ManagedStacks::ArithmeticController::syncChips: chip value " << value << " not defined in chip bank" << std::endl;
				continue;
      }
      stack->setChip(chip);
      getStacks()->postEvent(stack, STACK_CHANGED_CHIP);
    }
    if(count != stack->getCount()) {
      stack->setCount(count);
      getStacks()->postEvent(stack, STACK_CHANGED_COUNT);
    }
  }

  for(; j < getStacks()->getNumStacks(); j++) {
    Stack* stack = getStacks()->getStack(j);
    unsigned int count = stack->getCount();
    if(stack->getChip() != 0) {
      stack->setChip(0);
      getStacks()->postEvent(stack, STACK_CHANGED_CHIP);
    }
    if(count != stack->getCount())
      getStacks()->postEvent(stack, STACK_CHANGED_COUNT);
  }

  getStacks()->postEvent(STACKS_CHANGED);
}

void ManagedStacks::ArithmeticController::getChipsMap(ChipsMap& chips_map) const {
  const Stacks* stacks = getStacks();
  for(unsigned int i = 0; i < stacks->getNumStacks(); i++) {
    const Stack* stack = stacks->getStack(i);
    if(stack) {
      const ChipBank::Chip* chip = stack->getChip();
      if(chip) {
        if(chips_map.find(chip->_value) != chips_map.end()) {
          osg::notify(osg::WARN) << "ManagedStacks::ArithmeticController::getChipsMap: chip value " << chip->_value << " defined twice" << std::endl;
        } else {
          chips_map[chip->_value] = stack->getCount();
        }
      }
    }
  }
}

//
// osgchips::Stack::ScaledPlacementEventHandler
//

void ManagedStacks::ScaledPlacementEventHandler::handle(ManagedStacks* stacks, Stack* stack, int event) {
  if(event == STACK_ADDED) {
    const osg::BoundingBox& box = stack->getChipBank()->getBoundingBox();
    float diameter = box.xMax() - box.xMin();
    osg::Vec3 position = stack->getPosition();
    position *= diameter;
    stack->setPosition(position);
  }
}

//
// osgchips::Stack::OnTopEventHandler
//

ManagedStacks::OnTopEventHandler::OnTopEventHandler(ManagedStacks* top, ManagedStacks* bottom) :
  _top(top),
  _bottom(bottom)
{
  _top->getEventHandlerList().push_back(this);
  _bottom->getEventHandlerList().push_back(this);

  handle(NULL, STACKS_CREATE);
}

void ManagedStacks::OnTopEventHandler::handle(ManagedStacks* stacks, int event) {
  if(_top == NULL || _bottom == NULL)
    return;
  switch(event) {
  case STACKS_CREATE:
    for(unsigned int i = 0; i < _bottom->getNumStacks(); i++) {
      Stack* bottom_stack = _bottom->getStack(i);
      Stack* stack = new Stack(_bottom->getChipBank());
      stack->setMaxHeight(bottom_stack->getMaxHeight());
      _top->addStack(stack);
    }
    break;
  case STACKS_DELETE:
    {
      ManagedStacks* tmp;
      tmp = _bottom;
      _bottom = 0;
      if(stacks != tmp) 
        tmp->getEventHandlerList().remove(this);
      tmp = _top;
      _top = 0;
      if(stacks != tmp) 
        tmp->getEventHandlerList().remove(this);
      // !!! DO NOT ADD CODE HERE, THE OBJECT MIGHT BE DELETED !!!
    }
    break;
  case STACKS_CHANGED:
    synchronize(_top, _bottom);
    break;
  }
}

void ManagedStacks::OnTopEventHandler::synchronize(ManagedStacks* top, ManagedStacks* bottom) {
  Value2StackList bottom_value2stacks;
  Value2StackList top_value2stacks;
  StackList top_unused_stacks;
  unsigned int bottom_first_free_index = 0;
  for(unsigned int i = 0; i < bottom->getNumStacks(); i++) {
    Stack* stack = bottom->getStack(i);
    const ChipBank::Chip* chip = stack->getChip();
    if(chip) {
      bottom_value2stacks[chip->_value].push_back(stack);
    } else {
      bottom_first_free_index = i;
      break;
    }
  }

  for(unsigned int i = 0; i < top->getNumStacks(); i++) {
    Stack* stack = top->getStack(i);
    const ChipBank::Chip* chip = stack->getChip();
    if(chip) 
      top_value2stacks[chip->_value].push_back(stack);
  }


  for(Value2StackList::iterator i = top_value2stacks.begin(); i != top_value2stacks.end(); i++) {
    unsigned int value = i->first;
    StackList& top_stack_list = i->second;
    if(bottom_value2stacks.find(value) != bottom_value2stacks.end()) {
      StackList& bottom_stack_list = bottom_value2stacks[value];
      while(!bottom_stack_list.empty() || !top_stack_list.empty()) {
        onTop(top, top_stack_list.front(), bottom, bottom_stack_list.front());
        bottom_stack_list.pop_front();
        top_stack_list.pop_front();
      }
    }
  }

  unsigned int stack_index = bottom_first_free_index;
  for(Value2StackList::iterator i = top_value2stacks.begin(); i != top_value2stacks.end(); i++) {
    StackList& top_stack_list = i->second;
    for(StackList::iterator j = top_stack_list.begin(); j != top_stack_list.end(); j++) {
      if(stack_index < top->getNumStacks() ||
         stack_index < bottom->getNumStacks()) {
        Stack* top_stack = *j;
        top->swapStack(top->getStackIndex(top_stack), stack_index);
        top_stack->setPosition(bottom->getStack(stack_index)->getPosition());
        stack_index++;
      } else {
        osg::notify(osg::WARN) << "ManagedStacks::OnTopEventHandler::handle: not enough stacks (top or bottom)" << std::endl;
      }
    }
  }  
}

void ManagedStacks::OnTopEventHandler::onTop(ManagedStacks* top, Stack* top_stack, ManagedStacks* bottom, Stack* bottom_stack) {
  unsigned int bottom_stack_index = bottom->getStackIndex(bottom_stack);
  unsigned int top_stack_index = top->getStackIndex(top_stack);
  if(bottom_stack_index < top->getNumStacks()) {
    top->swapStack(top_stack_index, bottom_stack_index);
    const ChipBank* chipBank = bottom_stack->getChipBank();
    const osg::BoundingBox& boundingBox = chipBank->getBoundingBox();
    float chip_height = boundingBox.yMax() - boundingBox.yMin();
    float height = chip_height * bottom_stack->getHeight();
    osg::Vec3 position = bottom_stack->getPosition();
    position.y() += height - chip_height * 0.1;
    top_stack->setPosition(position);
  } else {
    osg::notify(osg::WARN) << "ManagedStacks::OnTopEventHandler::OnTop: not enough stacks" << std::endl;
  }
}

//
// osgchips::ManagedStacks
//

ManagedStacks::ManagedStacks() {}
ManagedStacks::ManagedStacks(ChipBank* chipBank) : Stacks(chipBank) {}
ManagedStacks::ManagedStacks(const ManagedStacks& managedStacks, const osg::CopyOp& copyop) :
  Stacks(managedStacks, copyop),
  _event_handlers(managedStacks._event_handlers),
  _controllers(managedStacks._controllers)
{
}

ManagedStacks::~ManagedStacks() {
	postEvent(STACKS_DELETE);
}

bool ManagedStacks::addStack(Stack* stack) {
  bool status = Stacks::addStack(stack);
  if(status)
    postEvent(stack, STACK_ADDED);
  return status;
}

bool ManagedStacks::replaceStack(Stack* origStack, Stack* newStack) {
  postEvent(origStack, STACK_REMOVED);
  bool status = Stacks::replaceStack(origStack, newStack);
  if(status)
    postEvent(newStack, STACK_ADDED);
  return status;
}

bool ManagedStacks::setStack(unsigned int index, Stack* stack) {
  Stack* remove = getStack(index);
  if(remove)
    postEvent(remove, STACK_REMOVED);
  bool status = Stacks::setStack(index, stack);
  if(status)
    postEvent(stack, STACK_ADDED);
  return status;
}

void ManagedStacks::postEvent(Stack* stack, unsigned int event) {
  for(EventHandlerList::iterator i = _event_handlers.begin(); i != _event_handlers.end(); i++)
    (*i)->handle(this, stack, event);
}

void ManagedStacks::postEvent(unsigned int event) {
  for(EventHandlerList::iterator i = _event_handlers.begin(); i != _event_handlers.end(); i++)
    (*i)->handle(this, event);
}

//
// osgchips::unserialize
//

osg::Node* osgchips::unserialize(struct _xmlDoc* doc, const std::string& xpath, osgDB::Registry* registry) {
  xmlNodePtr root = xmlDocGetRootElement(doc);
  if(xpath != "") changeRootXml(doc, xpath, "osgchips::unserialize");
  xmlTextReaderPtr reader = xmlReaderWalker(doc);
  if(reader == NULL) return NULL;
  osg::Node* node = readosgchipsFromXml(reader, ChipBank::instance(), registry);
  xmlFreeTextReader(reader);
  xmlDocSetRootElement(doc, root);
  return node;
}

osg::Node* osgchips::unserialize(const std::string& fileName, osgDB::Registry* registry) {
  xmlTextReaderPtr reader = xmlReaderForFile(fileName.c_str(), NULL, XML_PARSE_PEDANTIC|XML_PARSE_NONET);
  if(reader == NULL) return NULL;
  xmlDocPtr doc = xmlTextReaderCurrentDoc(reader);
  osg::Node* node = readosgchipsFromXml(reader, ChipBank::instance(), registry);
  xmlFreeDoc(doc);
  xmlFreeTextReader(reader);
  return node;
}
