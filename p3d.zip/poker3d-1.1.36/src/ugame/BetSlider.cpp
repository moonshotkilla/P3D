/* -*- c++ -*-
 *
 * Copyright (C) 2004, 2005, 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 */

#include "ugameStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifndef UGAME_USE_VS_PCH

#include <iostream>

#include <libxml/xmlreader.h>

#include <ugame/BetSlider>

#include <osg/Notify>
#include <osg/Geode>
#include <osg/PositionAttitudeTransform>
#include <osg/Geometry>
#include <osg/LineWidth>
#include <osg/BlendFunc>
#include <osgText/Font>
#include <osgText/Text>

#include <osgDB/ReadFile>

#ifdef WIN32
#ifndef snprintf
#define snprintf _snprintf
#endif
#endif

#endif

using namespace betslider;

static inline const char* format_amount(unsigned int value) {
  static char tmp[256];
  if(value % 100 != 0) {
    snprintf(tmp, 256, "%d.%02d", value / 100, value % 100);
  } else {
    snprintf(tmp, 256, "%d", value / 100);
  }
  return tmp;
}

#define DEFAULT_CHARACTER_SIZE 12.f

#define ROW_BACKGROUND_Z 0.1
#define TEXT_Z 0.2
#define CURSOR_Z 0.2
#define SEPARATOR_Z 0.15
//
// Serialization helpers
//

static inline void readStringAttributeFromXml(xmlTextReaderPtr reader, const char* name, std::string& value) {
  xmlChar* field = xmlTextReaderGetAttribute(reader, (const xmlChar*)name);
  if(field) {
    value = (const char*)field;
    xmlFree(field);
  }
}

static inline void readFloatAttributeFromXml(xmlTextReaderPtr reader, const char* name, float& value) {
  xmlChar* field = xmlTextReaderGetAttribute(reader, (const xmlChar*)name);
  if(field) {
    value = atof((const char*)field);
    xmlFree(field);
  }
}

static inline void readIntAttributeFromXml(xmlTextReaderPtr reader, const char* name, int& value) {
  xmlChar* field = xmlTextReaderGetAttribute(reader, (const xmlChar*)name);
  if(field) {
    value = atoi((const char*)field);
    xmlFree(field);
  }
}

static bool readColorFromXml(xmlTextReaderPtr reader, osg::Vec4& color) {
  bool status = false;
  xmlChar* red = xmlTextReaderGetAttribute(reader, (const xmlChar*)"red");
  if(red) {
    color.x() = atoi((const char*)red) / 255.f;
    xmlFree(red);
    status = true;
  }
  xmlChar* green = xmlTextReaderGetAttribute(reader, (const xmlChar*)"green");
  if(green) {
    color.y() = atoi((const char*)green) / 255.f;
    xmlFree(green);
    status = true;
  }
  xmlChar* blue = xmlTextReaderGetAttribute(reader, (const xmlChar*)"blue");
  if(blue) {
    color.z() = atoi((const char*)blue) / 255.f;
    xmlFree(blue);
    status = true;
  }
  xmlChar* alpha = xmlTextReaderGetAttribute(reader, (const xmlChar*)"alpha");
  if(alpha) {
    color.w() = atof((const char*)alpha);
    xmlFree(alpha);
    status = true;
  } else {
    color.w() = 1.f;
  }
  return status;
}

static bool readImage(osg::Geode* geode, const char* path, float width, float height, const osgDB::ReaderWriter::Options* options) {

  osg::ref_ptr<osg::Image> image = osgDB::readImageFile(path, options);

  if(image.valid() && image->s() > 0 && image->t() > 0) {
    float x = width / 2.f;
    float y = height / 2.f;

    osg::ref_ptr<osg::Texture2D> texture = new osg::Texture2D;
    texture->setUnRefImageDataAfterApply(true);
    texture->setImage(image.get());


    osg::ref_ptr<osg::StateSet> state = new osg::StateSet;
    state->setMode(GL_LIGHTING, osg::StateAttribute::OFF);
    state->setTextureAttributeAndModes(0, texture.get());
    osg::ref_ptr<osg::BlendFunc> blendFunc = new osg::BlendFunc();
    blendFunc->setFunction(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    state->setAttributeAndModes(blendFunc.get());
    state->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);

    osg::ref_ptr<osg::Geometry> geometry = new osg::Geometry;
    geometry->setStateSet(state.get());

    osg::ref_ptr<osg::Vec3Array> vertexes = new osg::Vec3Array(4);
    (*vertexes)[0].set(-x, -y, 0.f);
    (*vertexes)[1].set( x, -y, 0.f);
    (*vertexes)[2].set( x,  y, 0.f);
    (*vertexes)[3].set(-x,  y, 0.f);
    geometry->setVertexArray(vertexes.get());

    osg::ref_ptr<osg::Vec2Array> texcoords = new osg::Vec2Array(4);
    (*texcoords)[0].set(0.f, 0.f);
    (*texcoords)[1].set(1.f, 0.f);
    (*texcoords)[2].set(1.f, 1.f);
    (*texcoords)[3].set(0.f, 1.f);
    geometry->setTexCoordArray(0, texcoords.get());

    osg::ref_ptr<osg::Vec4Array> colours = new osg::Vec4Array(1);
    (*colours)[0].set(1.0f,1.0f,1.0,1.0f);
    geometry->setColorArray(colours.get());
    geometry->setColorBinding(osg::Geometry::BIND_OVERALL);

    geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::QUADS, 0, 4));

    geode->addDrawable(geometry.get());

    return true;
  }

  return false;
}

static bool readTextColorFromXml(xmlTextReaderPtr reader, const char* end_tag, int index, int row, BetSlider* betslider) {

  bool endRead = false;

  while(xmlTextReaderRead(reader) && !endRead ) {
    if(xmlTextReaderNodeType(reader) == XML_READER_TYPE_END_ELEMENT &&
       (!strcmp(end_tag, (const char*)xmlTextReaderConstName(reader))))
      endRead = true;
 
    if (!endRead) {
      osg::Vec4 color;
      if(!strcmp("normal", (const char*)xmlTextReaderConstName(reader))) {
        readColorFromXml(reader, color);
        betslider->setNormalColor(row, index, color);
      } else if(!strcmp("selected", (const char*)xmlTextReaderConstName(reader))) {
        readColorFromXml(reader, color);
        betslider->setSelectedColor(row, index, color);
      } else if(!strcmp("background", (const char*)xmlTextReaderConstName(reader))) {
        BetSlider::RowBackground* background = new BetSlider::RowBackground;
        readColorFromXml(reader, color);
        background->setColor(color);
        readFloatAttributeFromXml(reader, "left_pad", background->_left_pad);
        readFloatAttributeFromXml(reader, "right_pad", background->_right_pad);
        readFloatAttributeFromXml(reader, "bottom_pad", background->_bottom_pad);
        readFloatAttributeFromXml(reader, "top_pad", background->_top_pad);
        readStringAttributeFromXml(reader, "when", background->_when);
        betslider->setRowBackground(row, index, background);
      }
    }
  }
  return endRead;
}

static bool readTextIndexFromXml(xmlTextReaderPtr reader, const char* end_tag, int index, BetSlider* betslider, const osgDB::ReaderWriter::Options* options) {
  float font_size = DEFAULT_CHARACTER_SIZE;
  xmlChar* font_size_string = xmlTextReaderGetAttribute(reader, (const xmlChar*)"font_size");
  if(font_size_string) {
    font_size = atof((const char*)font_size_string);
    xmlFree(font_size_string);
  }
  xmlChar* font_path = xmlTextReaderGetAttribute(reader, (const xmlChar*)"font");
  if(font_path) {

    osg::ref_ptr<osg::Object> object = osgDB::readObjectFile((const char*)font_path, options);
    osg::ref_ptr<osgText::Font> font = dynamic_cast<osgText::Font*>(object.get());

    if( font.valid() ) {
      betslider->setFont(index, font.get(), font_size);
    }
    xmlFree(font_path);
  }

  bool endRead = false;
  while(xmlTextReaderRead(reader) && !endRead) {
    if(xmlTextReaderNodeType(reader) == XML_READER_TYPE_END_ELEMENT &&
       (!strcmp(end_tag, (const char*)xmlTextReaderConstName(reader))))
      endRead = true;

    if(!endRead) {
      if(!strcmp("cancel", (const char*)xmlTextReaderConstName(reader)))
        readTextColorFromXml(reader, "cancel", index, BetSlider::ROW_CANCEL, betslider);
      else if(!strcmp("call", (const char*)xmlTextReaderConstName(reader)))
        readTextColorFromXml(reader, "call", index, BetSlider::ROW_CALL, betslider);
      else if(!strcmp("raise", (const char*)xmlTextReaderConstName(reader)))
        readTextColorFromXml(reader, "raise", index, BetSlider::ROW_RAISE, betslider);
      else if(!strcmp("pot", (const char*)xmlTextReaderConstName(reader)))
        readTextColorFromXml(reader, "pot", index, BetSlider::ROW_POT, betslider);
      else if(!strcmp("raise_max", (const char*)xmlTextReaderConstName(reader)))
        readTextColorFromXml(reader, "raise_max", index, BetSlider::ROW_RAISE_MAX, betslider);
      else if(!strcmp("current_pot_amount", (const char*)xmlTextReaderConstName(reader)))
        readTextColorFromXml(reader, "current_pot_amount", index, BetSlider::ROW_CURRENT_POT_AMOUNT, betslider);
      else if(!strcmp("current_raise_amount", (const char*)xmlTextReaderConstName(reader)))
        readTextColorFromXml(reader, "current_raise_amount", index, BetSlider::ROW_CURRENT_RAISE_AMOUNT, betslider);
    }
  }
  return endRead;
}

static bool readTextFromXml(xmlTextReaderPtr reader, BetSlider* betslider, const osgDB::ReaderWriter::Options* options) {

  bool endRead = false;

  while(xmlTextReaderRead(reader) && !endRead) {
    if(xmlTextReaderNodeType(reader) == XML_READER_TYPE_END_ELEMENT &&
       !strcmp("text", (const char*)xmlTextReaderConstName(reader)))
      endRead = true;
    
    if (!endRead) {
      if(!strcmp("left", (const char*)xmlTextReaderConstName(reader)))
        readTextIndexFromXml(reader, "left", BetSlider::SIDE_LEFT, betslider, options);
      else if(!strcmp("right", (const char*)xmlTextReaderConstName(reader)))
        readTextIndexFromXml(reader, "right", BetSlider::SIDE_RIGHT, betslider, options);
    }
  }
  return endRead;
}

static bool readRectangleBackgroundFromXml(xmlTextReaderPtr reader, BetSlider* betslider, const osgDB::ReaderWriter::Options* options) {
  BetSlider::RectangleBackground* background = dynamic_cast<BetSlider::RectangleBackground*>(betslider->getBackground());
  if(background == NULL) {
    background = new BetSlider::RectangleBackground;
    betslider->replaceBackground(background);
  }

  bool endRead = false;
  while(xmlTextReaderRead(reader) && !endRead) {

    if(xmlTextReaderNodeType(reader) == XML_READER_TYPE_END_ELEMENT &&
       !strcmp("background", (const char*)xmlTextReaderConstName(reader)))
      endRead = true;

    if(!endRead) {
    
      const char* element_name = (const char*)xmlTextReaderConstName(reader);

      if(!strcmp("left", element_name) || !strcmp("right", element_name)) {
        int side = !strcmp("left", element_name) ? BetSlider::SIDE_LEFT : BetSlider::SIDE_RIGHT;
        osg::Vec4 color;
        if(readColorFromXml(reader, color))
          background->setBackgroundColor(side, color);
      
      } else if(!strcmp("middle", element_name)) {
        osg::Vec4 color;
        if(readColorFromXml(reader, color))
          background->setMiddleColor(color);
        xmlChar* width = xmlTextReaderGetAttribute(reader, (const xmlChar*)"width");
        if(width) {
          background->setMiddleWidth(atoi((const char*)width));
          xmlFree(width);
        }
      }
    }
  }  
  return endRead;
}

static bool readImageBackgroundFromXml(xmlTextReaderPtr reader, BetSlider* betslider, const osgDB::ReaderWriter::Options* options) {
  osg::ref_ptr<BetSlider::ImageBackground> background = new BetSlider::ImageBackground;

  bool endRead = false;
  while(xmlTextReaderRead(reader) && !endRead) {
    if(xmlTextReaderNodeType(reader) == XML_READER_TYPE_END_ELEMENT &&
       !strcmp("background", (const char*)xmlTextReaderConstName(reader))) {
      if(background->_geometry.valid())
        betslider->replaceBackground(background.get());
      endRead = true;
    }
    
    if (!endRead) {
      const char* element_name = (const char*)xmlTextReaderConstName(reader);

      if(!strcmp("image", element_name)) {
        xmlChar* file = xmlTextReaderGetAttribute(reader, (const xmlChar*)"file");
        if(file) {

          osg::ref_ptr<osg::Geode> geode = dynamic_cast<osg::Geode*>(osgDB::readNodeFile((const char*)file, options));

          if(!geode.valid()) {
            osg::notify(osg::WARN) << "BetSlider::unserialize: background " << (const char*)file << " is not a Geode (ignored)" << std::endl;
          } else if(geode->getNumDrawables() > 1) {
            osg::notify(osg::WARN) << "BetSlider::unserialize: background " << (const char*)file << " has more than one drawable (ignored)" << std::endl;
          } else if(dynamic_cast<osg::Geometry*>(geode->getDrawable(0)) == NULL) {
            osg::notify(osg::WARN) << "BetSlider::unserialize: background " << (const char*)file << " child is not a Geometry (ignored)" << std::endl;
          } else {
            osg::notify(osg::WARN) << "BetSlider::unserialize: 1 background " << std::endl;
            background->_geometry = dynamic_cast<osg::Geometry*>(geode->getDrawable(0));
            osg::ref_ptr<osg::Array> vertx_array = dynamic_cast<osg::Array*>(background->_geometry->getVertexArray()->clone(osg::CopyOp::DEEP_COPY_ALL));
            background->_vertexes = dynamic_cast<osg::Vec3Array*>(vertx_array.get());
            if(!background->_vertexes.valid())
              osg::notify(osg::WARN) << "BetSlider::unserialize: background " << (const char*)file << " unable to clone vertexes (ignored)" << std::endl;
          }
          xmlFree(file);
        }
        readFloatAttributeFromXml(reader, "left", background->_left);
        readFloatAttributeFromXml(reader, "right", background->_right);
        readFloatAttributeFromXml(reader, "bottom", background->_bottom);
        readFloatAttributeFromXml(reader, "top", background->_top);
        readFloatAttributeFromXml(reader, "middle", background->_middle);
      }
    }
  }
  return endRead;
}

static bool readSliderFromXml(xmlTextReaderPtr reader, BetSlider* betslider, const osgDB::ReaderWriter::Options* options) {
  bool endRead = false;
  while(xmlTextReaderRead(reader) && !endRead) {
    if(xmlTextReaderNodeType(reader) == XML_READER_TYPE_END_ELEMENT &&
       (!strcmp("betslider", (const char*)xmlTextReaderConstName(reader))))
      endRead = true;

    if(!endRead) {

      const char* name = (const char*)xmlTextReaderConstName(reader);

      if(!strcmp("cursor", name)) {
        xmlChar* image_file = xmlTextReaderGetAttribute(reader, (const xmlChar*)"image");
        xmlChar* width = xmlTextReaderGetAttribute(reader, (const xmlChar*)"width");
        xmlChar* height = xmlTextReaderGetAttribute(reader, (const xmlChar*)"height");
        if(image_file && width && height) {
          osg::ref_ptr<osg::Geode> geode = new osg::Geode;
          if(readImage(geode.get(), (const char*)image_file, atof((const char*)width), atof((const char*)height), options)) {
            betslider->setCursor(geode.get());
          }
        }
        if(image_file) xmlFree(image_file);
        if(width) xmlFree(width);
        if(height) xmlFree(height);

      } else if(!strcmp("separator", name)) {
        xmlChar* image_file = xmlTextReaderGetAttribute(reader, (const xmlChar*)"image");
        xmlChar* width = xmlTextReaderGetAttribute(reader, (const xmlChar*)"width");
        xmlChar* height = xmlTextReaderGetAttribute(reader, (const xmlChar*)"height");
        if(image_file && width && height) {
          osg::Geode* geode = new osg::Geode;
          if(readImage(geode, (const char*)image_file, atof((const char*)width), atof((const char*)height), options)) {
            betslider->setSeparator(geode);
          }
        }
        if(image_file) xmlFree(image_file);
        if(width) xmlFree(width);
        if(height) xmlFree(height);
      } else if(!strcmp("background", name)) {
        xmlChar* style_string = xmlTextReaderGetAttribute(reader, (const xmlChar*)"style");
        if(!strcmp("rectangle", (const char*)style_string)) {
          readRectangleBackgroundFromXml(reader, betslider, options);
        } else if(!strcmp("image", (const char*)style_string)) {
          readImageBackgroundFromXml(reader, betslider, options);
        } else {
          osg::notify(osg::WARN) << "BetSlider::unserialize: unknown background style " << (const char*)style_string << std::endl;
        }
        xmlFree(style_string);
      } else if(!strcmp("text", name)) {
        readTextFromXml(reader, betslider, options);
      } else if(!strcmp("motor", name)) {
        xmlChar* fixed_length = xmlTextReaderGetAttribute(reader, (const xmlChar*)"fixed_length");
        if(fixed_length) {
          betslider->setMotorFixedLength(atoi((const char*)fixed_length));
          xmlFree(fixed_length);
        }

        xmlChar* variable_length = xmlTextReaderGetAttribute(reader, (const xmlChar*)"variable_length");
        if(variable_length) {
          betslider->setMotorVariableLength(atoi((const char*)variable_length));
          xmlFree(variable_length);
        }
      }
    }
  }
  return endRead;
}

static bool readbetsliderFromXml(xmlTextReaderPtr reader, BetSlider* betslider, const osgDB::ReaderWriter::Options* options) {

  int status;
  while((status = xmlTextReaderRead(reader)) == 1) {
    //    const char* fileName = xmlTextReaderCurrentDoc(reader)->name;
    if(xmlTextReaderNodeType(reader) == XML_READER_TYPE_ELEMENT) {

      const char* name = (const char*)xmlTextReaderConstName(reader);
      if(!strcmp("betslider", name)) {
        xmlChar* center_pad = xmlTextReaderGetAttribute(reader, (const xmlChar*)"center_pad");
        if(center_pad) {
          betslider->setCenterPad(atof((const char*)center_pad));
          xmlFree(center_pad);
        }
        xmlChar* border_pad = xmlTextReaderGetAttribute(reader, (const xmlChar*)"border_pad");
        if(border_pad) {
          betslider->setBorderPad(atof((const char*)border_pad));
          xmlFree(border_pad);
        }
        readSliderFromXml(reader, betslider, options);
      }
    }
  }
  return status == 0;
}

BetSlider::BetSlider() :
  _rows(ROW_COUNT),
  _height(0.f),
  _center_pad(1.f),
  _border_pad(1.f),
  _motor_span(0.f),
  _motor_position(0.f),
  _motor_fixed_length(10.f),
  _motor_variable_length(100.f),
  _cursor_position(0.f),
  _value_step(1)
{
  _font_size[SIDE_LEFT] = DEFAULT_CHARACTER_SIZE;
  _font_size[SIDE_RIGHT] = DEFAULT_CHARACTER_SIZE;
  build();
}

BetSlider::BetSlider(const BetSlider& slider, const osg::CopyOp& copyop) :
  osg::Group(slider, copyop)  
{
}

BetSlider::~BetSlider()
{
}

void BetSlider::setFont(int side_index, osgText::Font* font, float font_size)
{
  if(side_index < 0 || side_index >= SIDE_COUNT) {
    osg::notify(osg::WARN) << "BetSlider::setFont: side_index out of range " << side_index << std::endl;
    return;
  }
    
  _font[side_index] = font;
  _font_size[side_index] = font_size;
  for(unsigned int i = 0; i < _rows.size(); i++) {
    if(_rows[i].valid()) {
      if(_rows[i]->_text[side_index].valid()) {
        _rows[i]->_text[side_index]->setFont(font);
        _rows[i]->_text[side_index]->setCharacterSize(font_size);
      }	
    }
  }

  layout();
}

void BetSlider::setNormalColor(int row_index, int side_index, const osg::Vec4& color)
{
  if(row_index < 0 || row_index >= ROW_COUNT) {
    osg::notify(osg::WARN) << "BetSlider::setNormalColor: row_index out of range " << row_index << std::endl;
    return;
  }

  if(side_index < 0 || side_index >= SIDE_COUNT) {
    osg::notify(osg::WARN) << "BetSlider::setNormalColor: side_index out of range " << side_index << std::endl;
    return;
  }

  if(_rows[row_index].valid()) {
    if(_rows[row_index]->_text[side_index].valid())
      _rows[row_index]->_text[side_index]->setColor(color);

    _rows[row_index]->_normal[side_index] = color;
  }
}

void BetSlider::setSelectedColor(int row_index, int side_index, const osg::Vec4& color)
{
  if(row_index < 0 || row_index >= ROW_COUNT) {
    osg::notify(osg::WARN) << "BetSlider::setSelectedColor: row_index out of range " << row_index << std::endl;
    return;
  }

  if(side_index < 0 || side_index >= SIDE_COUNT) {
    osg::notify(osg::WARN) << "BetSlider::setSelectedColor: side_index out of range " << side_index << std::endl;
    return;
  }

  if(_rows[row_index].valid()) {
    _rows[row_index]->_selected[side_index] = color;
  }
}

void BetSlider::setRowBackground(int row_index, int side_index, RowBackground* background)
{
  if(row_index < 0 || row_index >= ROW_COUNT) {
    osg::notify(osg::WARN) << "BetSlider::setRowBackground: row_index out of range " << row_index << std::endl;
    return;
  }

  if(side_index < 0 || side_index >= SIDE_COUNT) {
    osg::notify(osg::WARN) << "BetSlider::setRowBackground: side_index out of range " << side_index << std::endl;
    return;
  }

  if(_rows[row_index].valid()) {
    _rows[row_index]->_background[side_index] = background;
  }
}

void BetSlider::setSeparator(osg::Geode* separator)
{
  _separator = new osg::PositionAttitudeTransform;
  _separator->addChild(separator);
  _rows[ROW_CALL]->setSeparator(this, _separator.get());
  _rows[ROW_RAISE]->setSeparator(this, _separator.get());
  _rows[ROW_POT]->setSeparator(this, _separator.get());
  _rows[ROW_RAISE_MAX]->setSeparator(this, _separator.get());
}

void BetSlider::setCursor(osg::Geode* cursor)
{
  _cursor = new osg::PositionAttitudeTransform;
  _cursor->addChild(cursor);
  addChild(_cursor.get());
  updateCursorPosition();
}

void BetSlider::setCenterPad(float pad)
{
  if(pad != _center_pad) {
    _center_pad = pad;
    layout();
  }
}

void BetSlider::setBorderPad(float pad)
{
  if(pad != _border_pad) {
    _border_pad = pad;
    layout();
  }
}

void BetSlider::setLimits(unsigned int call, unsigned int raise, unsigned int raise_max, unsigned int all_in, unsigned int pot, unsigned int step)
{
  _value_step = step;

  float cursor = 0.f;
  _height = 0.f;
  _motor_span = 0.f;
  for(Rows::iterator i = _rows.begin(); i != _rows.end(); i++)
    (*i)->remove(this);

  Row* row;
  // cancel
  row = _rows[ROW_CANCEL].get();
  row->add(this);
  row->setText("Cancel", "");
  row->setMotorRange(_motor_span, _motor_fixed_length);
	row->setCursorRange(_height, cursor, 5.f);
  row->setValueRange(0, 0);

  // call
	/*
  if(call > 0) {
    //
    // The call row can be displayed when
    //
    // - the call value is not zero
    //
    row = _rows[ROW_CALL].get();
    row->add(this);
    if(all_in <= call) {
      row->setText("Call All In", format_amount(all_in));
      row->setValueRange(all_in, all_in);
    } else {
      row->setText("Call", format_amount(call));
      row->setValueRange(call, call);
    }
    row->setMotorRange(_motor_span, _motor_fixed_length);
    row->setCursorRange(_height, cursor, 5.f);
  }
*/
  if(all_in > call && raise > call) {
    //
    // The raise row can be displayed when
    //
    // - the player can bet more than the call (all_in > call)
    // - the minimum raise is larger than the call (raise > call)
    //   because the raise can be 0 if a raise is not allowed because
    //   of the game conditions.
    //
    row = _rows[ROW_RAISE].get();
    row->add(this);
    if(all_in <= raise) {
      if(call > 0)
        row->setText("Raise All In", format_amount(all_in));
      else
        row->setText("Bet All In", format_amount(all_in));
      row->setValueRange(all_in, all_in);
    } else {
      if(call > 0)
        row->setText("Raise", format_amount(raise));
      else
        row->setText("Bet", format_amount(raise));
      row->setValueRange(raise, raise);
    }
    row->setMotorRange(_motor_span, _motor_fixed_length);
    row->setCursorRange(_height, cursor, 5.f);

    if(all_in > raise && raise_max > raise) {
      // 
      // The pot row and/or the raise max row are displayed when 
      //
      // - the player can bet more than the minimum raise (all_in > raise)
      // - the maximum raise is larger than the minimum raise (raise_max > raise)
      //
      bool pot_row_displayed = false;
      if(pot <= raise_max && pot > raise && all_in >= pot) {
        // 
        // The pot row is displayed when 
        //
        // - the pot is lower or equal to the maximum raise (pot <= raise_max).
        //   If this is not the case, the raise max row is in charge since there
        //   is no point in having two different rows.
        // - the pot is larger than the minimum raise (pot > raise)
        // - the player can at least bet the amount of the pot (all_in >= pot)
        //
        pot_row_displayed = true;
        row = _rows[ROW_POT].get();
        row->add(this);
        if(all_in == pot) {
          row->setValueRange(raise, all_in);
          row->setText("Pot All In", format_amount(all_in));
        } else {
          row->setText("Pot", format_amount(pot));
          row->setValueRange(raise, pot);
        }
        row->setMotorRange(_motor_span, _motor_variable_length);
        row->setCursorRange(_height, cursor, 100.f);

        Row* row_current = _rows[ROW_CURRENT_POT_AMOUNT].get();
        row_current->add(this);
        row_current->setText(format_amount(pot), "");
        row_current->_text[SIDE_LEFT]->setPosition(osg::Vec3(0.f, (row->_cursor_start + row->_cursor_end) / 2, TEXT_Z));
      }

      if((pot_row_displayed == true && all_in > pot && raise_max > pot) ||
         (pot_row_displayed == false)) {
        //
        // If the pot row was displayed, the raise max row can be displayed when
        //
        // - the player can bet more than the pot (all_in > pot)
        // - the maximum raise is larger than the pot (raise_max > pot)
        //
        // If the pot row was NOT displayed, the raise max row can be displayed.
        //
        row = _rows[ROW_RAISE_MAX].get();
        row->add(this);
        int bottom_value = pot_row_displayed ? pot : raise;
        if(all_in <= raise_max) {
          row->setValueRange(bottom_value, all_in);
          row->setText("All In", format_amount(all_in));
        } else {
          row->setText("Max", format_amount(raise_max));
          row->setValueRange(bottom_value, raise_max);
        }
        row->setMotorRange(_motor_span, _motor_variable_length);
        row->setCursorRange(_height, cursor, 100.f);
   
        Row* row_current = _rows[ROW_CURRENT_RAISE_AMOUNT].get();
        row_current->add(this);
        row_current->setText(format_amount(raise_max), "");
        row_current->_text[SIDE_LEFT]->setPosition(osg::Vec3(0.f, (row->_cursor_start + row->_cursor_end) / 2, TEXT_Z));
      }
    }
  }

  _cursor_position = 0.f;
  _motor_position = 0.f;
  _height += 20.f;
  layout();

  setMotorPosition(0);
}

unsigned int BetSlider::moveCursor(float delta)
{
  float motor_delta = delta * _motor_span;
  float motor_position = _motor_position + motor_delta;
  setMotorPosition(motor_position);
  return getCurrentValue();
}

unsigned int BetSlider::getCurrentValue()
{
  Row* row = getCurrentRow();
	if (!row)
		return 0;
  if(row->_variable) {
    float fraction = (_cursor_position - row->_cursor_start) / (row->_cursor_end - row->_cursor_start);
    unsigned int value = row->_value_start + (unsigned int)((row->_value_end - row->_value_start) * fraction);
    bool not_allin = _cursor_position < row->_cursor_end;
    if (not_allin)
      {
	value -= value % _value_step;
      }
    return value > row->_value_end ? row->_value_end : value;
  } else {
    return row->_value_start;
  }
}

BetSlider::RowIndex BetSlider::getCurrentIndex()
{
  for(unsigned int i = 0; i < ROW_COUNT; i++) {
    Row* row = _rows[i].get();
    if(row->_defines_range) {
      if(row->_motor_start <= _motor_position && _motor_position < row->_motor_end)
        return (RowIndex)i;
    }
  }
  osg::notify(osg::WARN) << "BetSlider::getCurrentIndex: motor position " << _motor_position << " not matching any row" << std::endl;
  return ROW_COUNT;
}

void BetSlider::replaceBackground(Background* background)
{
  _geode->replaceDrawable(_background->_geometry.get(), background->_geometry.get());
  _background = background;
}

bool BetSlider::unserialize(struct _xmlDoc* doc, const osgDB::ReaderWriter::Options* options)
{
  xmlTextReaderPtr reader = xmlReaderWalker(doc);
  if(reader == NULL) return false;
  bool status = readbetsliderFromXml(reader, this, options);
  xmlFreeTextReader(reader);

  return status;
}

bool BetSlider::unserialize(const std::string& fileName, const osgDB::ReaderWriter::Options* options)
{
  LIBXML_TEST_VERSION
  xmlTextReaderPtr reader = xmlReaderForFile(fileName.c_str(), NULL, XML_PARSE_PEDANTIC|XML_PARSE_NONET);

  if(reader == NULL) return false;
  xmlDocPtr doc = xmlTextReaderCurrentDoc(reader);
  bool status = readbetsliderFromXml(reader, this, options);
  xmlFreeDoc(doc);
  xmlFreeTextReader(reader);
  xmlCleanupParser();

  return status;
}

bool BetSlider::serialize(const std::string& fileName) const
{
  return true;
}

void BetSlider::layout()
{
  float width[SIDE_COUNT] = { 0.f, 0.f };

  for(unsigned int i = 0; i < _rows.size(); i++) {
    if(_rows[i]->_active) {
      Row* row = _rows[i].get();
      for(int side = 0; side < SIDE_COUNT; side++) {
        if(row->_text[SIDE_LEFT].valid()) {
          const osg::BoundingBox& box = row->_text[SIDE_LEFT]->getBound();
          if(box.xMax() - box.xMin() > width[side])
            width[side] = box.xMax() - box.xMin();
        }
      }
    }
  }

  float text_x[SIDE_COUNT];
  text_x[SIDE_LEFT] = - ( _center_pad + width[SIDE_LEFT] / 2.f );
  text_x[SIDE_RIGHT] = _center_pad;

  float start_x[SIDE_COUNT];
  float end_x[SIDE_COUNT];

  start_x[SIDE_LEFT] = - ( _center_pad + width[SIDE_LEFT] );
  end_x[SIDE_LEFT] = - _center_pad;
  
  start_x[SIDE_RIGHT] = _center_pad;
  end_x[SIDE_RIGHT] = _center_pad + width[SIDE_RIGHT];
  
  for(unsigned int i = 0; i < _rows.size(); i++) {
    if(_rows[i]->_active) {
      Row* row = _rows[i].get();
      //
      // Background must have the same size on both sides
      //
      float background_height = 0.f;
      osg::Vec3 background_position;
      if(row->_background[SIDE_LEFT].valid() || row->_background[SIDE_RIGHT].valid()) {
        
        for(int side = 0; side < SIDE_COUNT; side++) {
          if(row->_text[side].valid()) {
            background_position = row->_text[side]->getPosition();
            const osg::BoundingBox& box = row->_text[side]->getBound();
            if(background_height < ( box.yMax() - box.yMin()) )
              background_height = ( box.yMax() - box.yMin() );
          }
        }
      }

      for(int side = 0; side < SIDE_COUNT; side++) {
        if(row->_text[side].valid()) {
          osg::Vec3 position = row->_text[side]->getPosition();
          position.x() = text_x[side];
          row->_text[side]->setPosition(position);
          if(row->_background[side].valid()) {
            float half_height = background_height / 2.f;
            osg::Vec2 bottom_left(start_x[side], background_position.y() - half_height);
            osg::Vec2 top_right(end_x[side], background_position.y() + half_height);
            row->_background[side]->update(bottom_left, top_right);
          }
        }
      }
    }
  }

  width[SIDE_LEFT] += _border_pad;
  width[SIDE_RIGHT] += _border_pad;

  _background->stretch(width[SIDE_LEFT], width[SIDE_RIGHT], _height);
}

void BetSlider::build()
{
  if(getNumChildren() > 0)
    removeChild(0, getNumChildren());

  _geode = new osg::Geode;
  addChild(_geode.get());

  RectangleBackground* background = new RectangleBackground();
  _geode->addDrawable(background->_geometry.get());
  _background = background;

  _rows[ROW_CANCEL] = new Row(_geode.get(), true, false, 0);

  _rows[ROW_CALL] = new Row(_geode.get(), true, true, _separator.get());

  _rows[ROW_RAISE] = new Row(_geode.get(), true, true, _separator.get());

  _rows[ROW_POT] = new Row(_geode.get(), true, true, _separator.get());
  _rows[ROW_POT]->_variable = true;

  _rows[ROW_CURRENT_POT_AMOUNT] = new Row(_geode.get(), true, false, 0);

  _rows[ROW_RAISE_MAX] = new Row(_geode.get(), true, true, _separator.get());
  _rows[ROW_RAISE_MAX]->_variable = true;

  _rows[ROW_CURRENT_RAISE_AMOUNT] = new Row(_geode.get(), true, false, 0);
}

BetSlider::Row* BetSlider::getCurrentRow()
{
  for(unsigned int i = 0; i < ROW_COUNT; i++) {
    Row* row = _rows[i].get();
    if(row->_defines_range) {
      if(row->_motor_start <= _motor_position && _motor_position < row->_motor_end)
        return row;
    }
  }
  osg::notify(osg::WARN) << "BetSlider::getCurrentRow: motor position " << _motor_position << " not matching any row" << std::endl;
  return 0;
}

void BetSlider::setMotorPosition(float motor_position)
{
  Row* row = getCurrentRow();
  if(row) row->unselected();
  if(motor_position < 0.f)
    _motor_position = 0.f;
  else if(motor_position >= _motor_span)
    _motor_position = _motor_span - 1;
  else
    _motor_position = motor_position;
  updateCursorPosition();
  updateCurrentValue();
}

void BetSlider::updateCursorPosition()
{
  Row* row = getCurrentRow();
  if(row && _cursor.valid()) {
    float position;
    if(row->_variable) {
      if(_motor_position >= row->_motor_end - 1) {
        position = row->_cursor_end;
      } else {
        float relative_position = (_motor_position - row->_motor_start);
        float height = (row->_motor_end - row->_motor_start);
        float _80_percent_height = height * .8; // Sticky on the upper 20% of the motor space
        float fraction;
        if(relative_position < _80_percent_height)
          fraction = relative_position / _80_percent_height;
        else
          fraction = 1.f;
        position = row->_cursor_start + (row->_cursor_end - row->_cursor_start) * fraction;
      }
    } else {
      position = row->_cursor_end;
    }
    if(_motor_position < 0.f) position = 0.f;
    _cursor->setPosition(osg::Vec3(0.f, position, CURSOR_Z));
    _cursor_position = position;
  }
}

void BetSlider::updateCurrentValue()
{
  Row* row = getCurrentRow();
  if(row) {
    bool current_active = false;
    unsigned int value = 0;
    if(row->_variable) {
      value = getCurrentValue();
      if(value < row->_value_end)
        current_active = true;
    }
    if(current_active) {
      unsigned int active_index;
      unsigned int inactive_index;
      if(getCurrentIndex() == ROW_POT) {
        active_index = ROW_CURRENT_POT_AMOUNT;
        inactive_index = ROW_CURRENT_RAISE_AMOUNT;
      } else {
        active_index = ROW_CURRENT_RAISE_AMOUNT;
        inactive_index = ROW_CURRENT_POT_AMOUNT;
      }
      _rows[active_index]->add(this);
      _rows[active_index]->setText(format_amount(value), "");
      _rows[inactive_index]->remove(this);
    } else {
      _rows[ROW_CURRENT_POT_AMOUNT]->remove(this);
      _rows[ROW_CURRENT_RAISE_AMOUNT]->remove(this);
      row->selected();
    }
  }
}

BetSlider::Row::Row(osg::Geode* geode,
                    bool left, bool right,
                    const osg::PositionAttitudeTransform* separator) :
  _defines_range(false),
  _active(false),
  _variable(false),
  _value_start(0),
  _value_end(0),
  _cursor_start(0.f),
  _cursor_end(0.f),
  _motor_start(0.f),
  _motor_end(0.f),
  _geode(geode),
  _separator(separator ? dynamic_cast<osg::PositionAttitudeTransform*>(separator->clone(osg::CopyOp::SHALLOW_COPY)) : 0)
{
  for(int i = 0; i < SIDE_COUNT; i++) {
    _normal[i] = osg::Vec4(.7f, .7f, .7f, 1.f);
    _selected[i] = osg::Vec4(1.f, 1.f, 1.f, 1.f);
  }

  if(left) {
    osgText::Text* text = new osgText::Text;
    text->setColor(_normal[SIDE_LEFT]);
    text->setCharacterSize(DEFAULT_CHARACTER_SIZE);
    //
    // Warning: changing the alignment will have consequences
    // on parts of the code that rely on this alignment.
    //
    text->setAlignment(osgText::Text::CENTER_CENTER);
    _text[SIDE_LEFT] = text;
  }

  if(right) {
    osgText::Text* text = new osgText::Text;
    text->setColor(_normal[SIDE_RIGHT]);
    text->setCharacterSize(DEFAULT_CHARACTER_SIZE);
    //
    // Warning: changing the alignment will have consequences
    // on parts of the code that rely on this alignment.
    //
    text->setAlignment(osgText::Text::LEFT_CENTER);
    _text[SIDE_RIGHT] = text;
  }
}

BetSlider::Row::~Row() {}

void BetSlider::Row::setText(const std::string& left, const std::string& right)
{
  std::string strings[SIDE_COUNT];
  strings[SIDE_LEFT] = left;
  strings[SIDE_RIGHT] = right;

  for(int i = 0; i < SIDE_COUNT; i++) {
    if(_text[i].valid())
      _text[i]->setText(strings[i]);
  }
}

void BetSlider::Row::setMotorRange(float& origin, float length)
{
  _defines_range = true;
  _motor_start = origin;
  _motor_end = origin + length;
  origin += length;
}

void BetSlider::Row::setCursorRange(float& origin, float& cursor, float height)
{
  _defines_range = true;
  osg::BoundingBox box = getBound();
  float text_height = box.yMax() - box.yMin();
  float position = origin + height + text_height;
  if(_variable) {
    _cursor_start = cursor;
    _cursor_end = position;
  } else {
    _cursor_end = _cursor_start = position;
  }
  cursor = position;
  if(_separator.valid())
    _separator->setPosition(osg::Vec3(0.f, position, SEPARATOR_Z));
  for(int i = 0; i < SIDE_COUNT; i++)
    if(_text[i].valid())
      _text[i]->setPosition(osg::Vec3(0.f, position, TEXT_Z));
  origin = position;
}

void BetSlider::Row::setSeparator(osg::Group* group, osg::PositionAttitudeTransform* separator)
{
  osg::Vec3 position;
  if(_separator.valid())
    position = _separator->getPosition();

  if(_active && _separator.valid()) {
    group->removeChild(_separator.get());
  }

  if(separator) {
    _separator = dynamic_cast<osg::PositionAttitudeTransform*>(separator->clone(osg::CopyOp::SHALLOW_COPY));
    _separator->setPosition(position);
  } else {
    _separator = 0;
  }

  if(_active && _separator.valid())
    group->addChild(_separator.get());
}

osg::BoundingBox BetSlider::Row::getBound() const
{
  osg::BoundingBox box;
  for(int i = 0; i < SIDE_COUNT; i++)
    if(_text[i].valid())
      box.expandBy(_text[i]->getBound());
  return box;
}

void BetSlider::Row::add(osg::Group* group)
{
  if(!_active) {
    _active = true;
    for(int i = 0; i < SIDE_COUNT; i++)
      if(_text[i].valid()) {
        if(_background[i].valid() && _background[i]->when() == "always")
          _geode->addDrawable(_background[i]->_geometry.get());
        _geode->addDrawable(_text[i].get());
      }
    if(_separator.valid())
      group->addChild(_separator.get());
  }
}

void BetSlider::Row::remove(osg::Group* group)
{
  if(_active) {
    _defines_range = false;
    _active = false;
    for(int i = 0; i < SIDE_COUNT; i++) {
      if(_text[i].valid())
        _geode->removeDrawable(_text[i].get());
      if(_background[i].valid())
        _geode->removeDrawable(_background[i]->_geometry.get());
    }
    if(_separator.valid())
      group->removeChild(_separator.get());
  }
}

void BetSlider::Row::selected()
{
  for(int i = 0; i < SIDE_COUNT; i++) {
    if(_text[i].valid())
      _text[i]->setColor(_selected[i]);
    if(_background[i].valid() && _background[i]->when() == "selected")
      _geode->addDrawable(_background[i]->_geometry.get());
  }
}

void BetSlider::Row::unselected()
{
  for(int i = 0; i < SIDE_COUNT; i++) {
    if(_text[i].valid())
      _text[i]->setColor(_normal[i]);
    if(_background[i].valid() && _background[i]->when() == "selected")
      _geode->removeDrawable(_background[i]->_geometry.get());
  }
}

BetSlider::RowBackground::RowBackground() :
  _left_pad(1),
  _right_pad(1),
  _bottom_pad(1),
  _top_pad(1)
{
  _geometry = new osg::Geometry;
	_geometry->getOrCreateStateSet()->setMode(GL_BLEND,osg::StateAttribute::OFF);
	_geometry->getOrCreateStateSet()->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);

  const int num_primitives = 1;
  osg::Vec3Array* vertexes = new osg::Vec3Array(4 * num_primitives);
  _geometry->setVertexArray(vertexes);

  _geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::QUADS, 0, 4));

  osg::Vec4Array* colors = new osg::Vec4Array(num_primitives);
  _geometry->setColorArray(colors);
  _geometry->setColorBinding(osg::Geometry::BIND_OVERALL);
}

void BetSlider::RowBackground::update(const osg::Vec2& bottom_left, const osg::Vec2& top_right) {
  osg::Vec3Array* vertexes = dynamic_cast<osg::Vec3Array*>(_geometry->getVertexArray());

  float left = bottom_left.x() - _left_pad;
  float right = top_right.x() + _right_pad;
  float bottom = bottom_left.y() - _bottom_pad;
  float top = top_right.y() + _top_pad;

  int index = 0;
  (*vertexes)[index++] = osg::Vec3(left, bottom, ROW_BACKGROUND_Z);
  (*vertexes)[index++] = osg::Vec3(right, bottom, ROW_BACKGROUND_Z);
  (*vertexes)[index++] = osg::Vec3(right, top, ROW_BACKGROUND_Z);
  (*vertexes)[index++] = osg::Vec3(left, top, ROW_BACKGROUND_Z);

  _geometry->setVertexArray(vertexes);
}

void BetSlider::RowBackground::setColor(const osg::Vec4& color) {
  osg::Vec4Array* colors = dynamic_cast<osg::Vec4Array*>(_geometry->getColorArray());
  (*colors)[0] = color;
  _geometry->setColorArray(colors);
}

BetSlider::RowBackground::~RowBackground() {}

BetSlider::Background::~Background() {}

BetSlider::RectangleBackground::RectangleBackground() :
  _middle_color(255.f/255.f, 240.f/255.f, 185.f/255.f, 1.f),
  _middle_width(5.f)
{

  _background_color[SIDE_LEFT] = osg::Vec4(85.f/255.f, 85.f/255.f, 85.f/255.f, 1.f);
  _background_color[SIDE_RIGHT] = osg::Vec4(150.f/255.f, 150.f/255.f, 150.f/255.f, 1.f);

  _geometry = new osg::Geometry;

  const int num_primitives = 3;
  osg::Vec3Array* vertexes = new osg::Vec3Array(4 * num_primitives);
  _geometry->setVertexArray(vertexes);

  _geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::QUADS, 0, 4));
  _geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::QUADS, 4, 4));
  _geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::QUADS, 8, 4));

  osg::Vec4Array* colors = new osg::Vec4Array(num_primitives);

  (*colors)[0] = _background_color[SIDE_LEFT];
  (*colors)[1] = _middle_color;
  (*colors)[2] = _background_color[SIDE_RIGHT];
  _geometry->setColorArray(colors);
  _geometry->setColorBinding(osg::Geometry::BIND_PER_PRIMITIVE_SET);
  
}

BetSlider::RectangleBackground::~RectangleBackground() {}

void BetSlider::RectangleBackground::setBackgroundColor(int side_index, const osg::Vec4& background_color)
{
  _background_color[side_index] = background_color;
  osg::Vec4Array* colors = dynamic_cast<osg::Vec4Array*>(_geometry->getColorArray());
  (*colors)[0] = _background_color[SIDE_LEFT];
  (*colors)[2] = _background_color[SIDE_RIGHT];
  _geometry->setColorArray(colors);
}


void BetSlider::RectangleBackground::setMiddleColor(const osg::Vec4& middle_color)
{
  _middle_color = middle_color;
  osg::Vec4Array* colors = dynamic_cast<osg::Vec4Array*>(_geometry->getColorArray());
  (*colors)[1] = _middle_color;
  _geometry->setColorArray(colors);
}

void BetSlider::RectangleBackground::setMiddleWidth(float middle_width)
{
  _middle_width = middle_width;
  _geometry->getOrCreateStateSet()->setAttributeAndModes(new osg::LineWidth(_middle_width));
}

void BetSlider::RectangleBackground::stretch(float left_width, float right_width, float height)
{
  osg::Vec3Array* vertexes = dynamic_cast<osg::Vec3Array*>(_geometry->getVertexArray());
  int index = 0;

  // left square
  float left = - (_middle_width / 2.f + left_width );
  float right = - _middle_width / 2.f;
  (*vertexes)[index++] = osg::Vec3(left, 0.f, 0.f);
  (*vertexes)[index++] = osg::Vec3(right, 0.f, 0.f);
  (*vertexes)[index++] = osg::Vec3(right, height, 0.f);
  (*vertexes)[index++] = osg::Vec3(left, height, 0.f);

  // middle line
  left = - _middle_width / 2.f;
  right = _middle_width / 2.f;
  (*vertexes)[index++] = osg::Vec3(left, 0.f, 0.f);
  (*vertexes)[index++] = osg::Vec3(right, 0.f, 0.f);
  (*vertexes)[index++] = osg::Vec3(right, height, 0.f);
  (*vertexes)[index++] = osg::Vec3(left, height, 0.f);

  // right square
  left = _middle_width / 2.f;
  right = _middle_width / 2.f + right_width;
  (*vertexes)[index++] = osg::Vec3(left, 0.f, 0.f);
  (*vertexes)[index++] = osg::Vec3(right, 0.f, 0.f);
  (*vertexes)[index++] = osg::Vec3(right, height, 0.f);
  (*vertexes)[index++] = osg::Vec3(left, height, 0.f);

  _geometry->setVertexArray(vertexes);
}

BetSlider::ImageBackground::ImageBackground() :
  _left(1),
  _right(1),
  _top(1),
  _bottom(1),
  _middle(1)
{}

BetSlider::ImageBackground::~ImageBackground() {}

void BetSlider::ImageBackground::stretch(float left_width, float right_width, float height)
{
  osg::Vec3Array* vertexes = dynamic_cast<osg::Vec3Array*>(_geometry->getVertexArray());

  float middle_half_width = _middle / 2.f + .5f;

  for(osg::Vec3Array::iterator i = vertexes->begin(), j = _vertexes->begin(); i != vertexes->end(); i++, j++) {
    osg::Vec3& v_to = *i;
    osg::Vec3& v_from = *j;
    if(v_from.x() < -middle_half_width) v_to.x() = v_from.x() - left_width;
    if(v_from.x() > middle_half_width) v_to.x() = v_from.x() + right_width;
    if(v_from.y() > .5f) v_to.y() = v_from.y() + height;
  }
  _geometry->setVertexArray(vertexes);
}
