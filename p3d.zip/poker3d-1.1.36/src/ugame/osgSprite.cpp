/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#include "ugameStdAfx.h"

#ifndef UGAME_USE_VS_PCH

#include "osgSprite/osgSprite.h"
#include "CustomAssert/CustomAssert.h"

#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <iostream>
#include <algorithm>
#include <osg/MatrixTransform>
#include <osg/Geometry>
#include <osg/Material>
#include <osg/Array>
#include <osg/Image>
#include <osg/Texture2D>
#include <osg/BlendFunc>
#include <osg/Group>
#if OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1
#else // OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1
#include <osg/io_utils>
#endif // OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1
#include <osgDB/ReadFile>
#include <osgDB/FileUtils>
#include <libxml/tree.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <libxml/xpathInternals.h>
#include <libxml/xmlsave.h>

#endif

_xmlDoc* g_doc = NULL;
struct TextureCacheEntry
{
  osg::ref_ptr<osg::Texture2D> _texture;
  unsigned int _iw;
  unsigned int _ih;
  unsigned int _w;
  unsigned int _h;
  TextureCacheEntry() : _texture(0), _iw(0), _ih(0), _w(0), _h(0)
  {
  }
  TextureCacheEntry(osg::Texture2D* texture, unsigned int iw, unsigned ih, unsigned int w, unsigned int h) : _texture(texture), _iw(iw), _ih(ih), _w(w), _h(h)
  {
  }
};
static std::map<std::string, TextureCacheEntry > g_filename2texture;

osgQuad::osgQuad() : _w(0), _h(0), _iw(0), _ih(0)
{
  create();
}

osgQuad::osgQuad(float w, float h, const osg::Vec4& color) : _w(0), _h(0), _iw(0), _ih(0)
{
  create();
  setColor(color);
  resize(w, h);
}

osgQuad::~osgQuad()
{
}

void osgQuad::create()
{
  osg::StateSet* state = getOrCreateStateSet();
  osg::Material* material = new osg::Material;
  state->setAttributeAndModes(material, osg::StateAttribute::ON);
  state->setMode(GL_LIGHTING, osg::StateAttribute::OFF);
  state->setMode(GL_CULL_FACE, osg::StateAttribute::OFF);
  osg::BlendFunc* bf = new osg::BlendFunc;
  bf->setFunction(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  state->setAttributeAndModes(bf, osg::StateAttribute::ON);
  state->setMode(GL_ALPHA_TEST, GL_FALSE);

  osg::Geometry* geom = new osg::Geometry();
    
  osg::Vec3Array* array = new osg::Vec3Array();
  array->resize(4);  
  geom->setVertexArray(array);

  osg::Vec2Array* uv = new osg::Vec2Array();
  uv->push_back( osg::Vec2f(0, 1) );
  uv->push_back( osg::Vec2f(1, 1) );
  uv->push_back( osg::Vec2f(1, 0) );
  uv->push_back( osg::Vec2f(0, 0) );
  geom->setTexCoordArray(0, uv);

  GLushort index[6];
  index[0] = 0;
  index[1] = 1;
  index[2] = 2;
  index[3] = 0;
  index[4] = 2;
  index[5] = 3;
  osg::PrimitiveSet* ps = new osg::DrawElementsUShort(osg::PrimitiveSet::TRIANGLES, 6, index);
  geom->addPrimitiveSet(ps);
  geom->setUseDisplayList(false);
  geom->setUseVertexBufferObjects(false);

  osg::Geode* geode = new osg::Geode();
  geode->addDrawable(geom);
  addChild(geode);
}

void osgQuad::resize(float w, float h)
{
  _w = (unsigned int)w;
  _h = (unsigned int)h;
  osg::Geode* geode = dynamic_cast<osg::Geode*>(getChild(0));
  CUSTOM_ASSERT(geode);
  osg::Geometry* geom = dynamic_cast<osg::Geometry*>(geode->getDrawable(0));
  CUSTOM_ASSERT(geom);
  osg::Vec3Array* array = dynamic_cast<osg::Vec3Array*>(geom->getVertexArray());
  array[0][0] = osg::Vec3f(0, 0, 0);
  array[0][1] = osg::Vec3f(w, 0, 0);
  array[0][2] = osg::Vec3f(w, h, 0);
  array[0][3] = osg::Vec3f(0, h, 0);
  geom->dirtyBound();
}

void osgQuad::setColor(const osg::Vec4& color)
{
  osg::StateSet* state = getStateSet();
  CUSTOM_ASSERT(state);
  osg::Material* mat = dynamic_cast<osg::Material*>(state->getAttribute(osg::StateAttribute::MATERIAL));
  CUSTOM_ASSERT(mat);
  mat->setDiffuse(osg::Material::FRONT_AND_BACK, color);
}

void osgQuad::setImage(const std::string& imagePath)
{
  if (g_filename2texture.find(imagePath) == g_filename2texture.end())
    {
      osg::ref_ptr<osg::Image> imageSrc = osgDB::readImageFile(imagePath);
      CUSTOM_ASSERT(imageSrc.get() && "readImageFile");
      osg::Image* image = osgSprite::copySubImagePowerOfTwo(imageSrc.get());
      osg::Texture2D* texture = new osg::Texture2D();
      texture->setImage(image);
      texture->setUnRefImageDataAfterApply(true);
      texture->setFilter(osg::Texture::MIN_FILTER, osg::Texture::NEAREST);
      texture->setFilter(osg::Texture::MAG_FILTER, osg::Texture::NEAREST);
      unsigned int iw = imageSrc->s();
      unsigned int ih = imageSrc->t();
      unsigned int w = image->s();
      unsigned int h = image->t();
      g_filename2texture[imagePath] = TextureCacheEntry(texture, iw, ih, w, h);
    }
  TextureCacheEntry& entry = g_filename2texture[imagePath];
  osg::Texture2D* texture = entry._texture.get();
  osg::StateSet* state = getOrCreateStateSet();
  state->setTextureAttributeAndModes(0, texture, osg::StateAttribute::ON);
  _iw = entry._iw;
  _ih = entry._ih;
  _w = entry._w;
  _h = entry._h;
  resize(_w, _h);
}

const osg::Image* osgQuad::getImage() const
{
  const osg::StateSet* state = getStateSet();
  if (!CUSTOM_ASSERT(state)) return NULL;
  const osg::Texture* texture = dynamic_cast<const osg::Texture*>(state->getTextureAttribute(0, osg::StateAttribute::TEXTURE));
  if (!CUSTOM_ASSERT(texture)) return NULL;
  const osg::Image* image = texture->getImage(0);
  if (!CUSTOM_ASSERT(image)) return NULL;
  return image;
}

osgSprite::osgSprite() : _frames(0), _currentTime(0.0f), _totalTime(0.0f)
{
}
osgSprite::~osgSprite()
{
}
void osgSprite::setTotalTime(float totalTime)
{
  _totalTime = totalTime;
}
float osgSprite::getTotalTime() const
{
  return _totalTime;
}
void osgSprite::setCurrentTime(float currenTime)
{
  _currentTime = currenTime;
  updateFrame();
}
float osgSprite::getCurrentTime() const
{
  return _currentTime;
}
void osgSprite::addTime(float delta)
{
  _currentTime += delta;
  if (_currentTime > _totalTime)
    _currentTime = _totalTime;
  updateFrame();
}
void osgSprite::subTime(float delta)
{
  _currentTime -= delta;
  if (_currentTime < 0.0f)
    _currentTime = 0.0f;
  updateFrame();
}
void osgSprite::updateFrame()
{
  CUSTOM_ASSERT(_totalTime != 0.0f);
  CUSTOM_ASSERT(_frames.size() > 0);
  float currentFrameRatio = (_currentTime / _totalTime) * (_frames.size());  
  unsigned int currentFrame = std::min((unsigned int)currentFrameRatio, (unsigned int)_frames.size() - 1);
  setCurrentFrame(currentFrame);
}
void osgSprite::addFrames(const std::string& directory, unsigned int frameCount)
{
  for (unsigned int i = 0; i < frameCount; ++i)
    {
      std::ostringstream oss;
      oss << directory;
      oss << std::setw(2) << std::setfill('0') << i + 1;
      oss << ".tga";
      addFrame(oss.str());
    }
}
osg::Image* osgSprite::copySubImagePowerOfTwo(osg::Image* image)
{
  osg::Image* imagePowerOfTwo = new osg::Image();
  int s = nextPowerOfTwo(image->s());
  if (!CUSTOM_ASSERT(s >= image->s())) return NULL;
  int t = nextPowerOfTwo(image->t());
  if (!CUSTOM_ASSERT(t >= image->t())) return NULL;
  imagePowerOfTwo->allocateImage(s, t, 1, GL_RGBA, GL_UNSIGNED_BYTE);
  if (!CUSTOM_ASSERT(imagePowerOfTwo->getTotalSizeInBytes() > 0)) return NULL;
  memset(imagePowerOfTwo->data(), 0, imagePowerOfTwo->getTotalSizeInBytes());
  const unsigned char* src = image->data();
  const unsigned char* srcEnd = image->data() + image->getTotalSizeInBytes();
  if (!CUSTOM_ASSERT(src < srcEnd)) return NULL;
  unsigned char* dst = imagePowerOfTwo->data();
  const unsigned char* dstEnd = imagePowerOfTwo->data() + imagePowerOfTwo->getTotalSizeInBytes();
  if (!CUSTOM_ASSERT(dst < dstEnd)) return NULL;
  int dstPixelSizeInBytes = imagePowerOfTwo->getPixelSizeInBits() / 8;
  int srcPixelSizeInBytes = image->getPixelSizeInBits() / 8;;
  int dstLineSizeInBytes = (imagePowerOfTwo->s() * dstPixelSizeInBytes);
  int deltaWidth = imagePowerOfTwo->t() - image->t();
  if (!CUSTOM_ASSERT(deltaWidth >= 0)) return NULL;
  dst += (deltaWidth) * dstLineSizeInBytes;
  if (!CUSTOM_ASSERT(dst + dstPixelSizeInBytes <= dstEnd)) return NULL;
  if (!CUSTOM_ASSERT(src + srcPixelSizeInBytes <= srcEnd)) return NULL;
  
  unsigned int mask = (image->getPixelFormat() == GL_RGBA) ? 0 : 0xff;
  for (int y = 0; y < image->t(); ++y)
    {	   
      unsigned char* beginOfLine = dst;
      for (int x = 0; x < image->s(); ++x)
	{
	  for (int i = 0; i < srcPixelSizeInBytes; ++i)
	    {
	      if (!CUSTOM_ASSERT(src + srcPixelSizeInBytes <= srcEnd)) return  NULL;
	      if (!CUSTOM_ASSERT(dst + dstPixelSizeInBytes <= dstEnd)) return NULL;
	      dst[i] = src[i];
	    }
	  if (!CUSTOM_ASSERT(dst + 3 < dstEnd)) return NULL;
	  dst[3] |= mask;
	  dst += dstPixelSizeInBytes;
	  src += srcPixelSizeInBytes;
	}
      dst = beginOfLine + dstLineSizeInBytes;
    }

  //for 1.0.0 compat
  const std::string& filename = image->getFileName();
  if (!CUSTOM_ASSERT(filename.size())) return NULL;
  const std::string& datafile = osgDB::findDataFile(filename);
  if (!CUSTOM_ASSERT(datafile.size())) return NULL;
  imagePowerOfTwo->setFileName(datafile);
  return imagePowerOfTwo;
}
bool osgSprite::isPowerOfTwo(unsigned int x)
{  
  return ((x & (x - 1)) == 0);
}
unsigned int osgSprite::nextPowerOfTwo(unsigned int x)
{
  if (isPowerOfTwo(x))
    return x;
  x |= (x >> 1);
  x |= (x >> 2);
  x |= (x >> 4);
  x |= (x >> 8);
  x |= (x >> 16);
  return(x+1);
}
void osgSprite::addFrame(const std::string& path, const std::string& name)
{
  osgQuad* quad = new osgQuad();
  quad->setImage(path);
  _frames.push_back(quad);
  int index = _frames.size() - 1;
  std::string key = name == "" ?  path : name;
  _name2index[key] = index;
  CUSTOM_ASSERT(_frames.size() == _name2index.size());
}
void osgSprite::setCurrentFrame(unsigned int index)
{
  CUSTOM_ASSERT(index < _frames.size());
  CUSTOM_ASSERT(getNumChildren() <= 1);
  if (getNumChildren() == 0)
    addChild(_frames[index].get());
  else
    replaceChild(getChild(0), _frames[index].get());	
}
void osgSprite::setCurrentFrame(const std::string& name)
{
  CUSTOM_ASSERT(_frames.size() == _name2index.size());  
  CUSTOM_ASSERT(_name2index.find(name) != _name2index.end());
  setCurrentFrame(_name2index[name]);
}
unsigned int osgSprite::getFrameCount() const
{
  return _frames.size();
}

const osg::Image* osgSprite::getCurrentFrameImage() const
{
  const osgQuad* frame = getCurrentFrame();
  return frame->getImage();
}

const osgQuad* osgSprite::getCurrentFrame() const
{
  if (!CUSTOM_ASSERT(getNumChildren() > 0)) return NULL;
  const osgQuad* frame = dynamic_cast<const osgQuad*>(getChild(0));
  if (!CUSTOM_ASSERT(frame)) return  NULL;
  return frame;
}

osgQuad* osgSprite::getCurrentFrame()
{
  if (!CUSTOM_ASSERT(getNumChildren())) return NULL;
  osgQuad* frame = dynamic_cast<osgQuad*>(getChild(0));
  if (!CUSTOM_ASSERT(frame)) return NULL;
  return frame;
}

void osgSprite::removeCurrentFrame()
{
  CUSTOM_ASSERT(getNumChildren() > 0);
  removeChild(getChild(0));
}

bool _headerGetList(std::vector<std::string>& result , _xmlDoc* name, const std::string& path)
{
  xmlDocPtr header = name;
  /* Create xpath evaluation context */
  xmlXPathContextPtr xpathCtx = xmlXPathNewContext(header);
  if (!CUSTOM_ASSERT(xpathCtx&& "HeaderGetList: unable to create new XPath context")) return false;
  xmlXPathObjectPtr xpathObj = xmlXPathEvalExpression((xmlChar*)path.c_str(), xpathCtx);
  if (!CUSTOM_ASSERT(xpathObj && "Error: unable to evaluate xpath expression")) return false;
  
  xmlNodeSetPtr nodes = xpathObj->nodesetval;
  if(nodes && nodes->nodeNr >= 1) {
    for(int i = 0; i < nodes->nodeNr; i++) {
      xmlNodePtr node = nodes->nodeTab[i];
      switch(node->type) {
      case XML_ELEMENT_NODE:
      case XML_ATTRIBUTE_NODE:
	{
	  const char* content = (const char*)xmlNodeGetContent(node);
	  result.push_back(content);
	  xmlFree((void*)content);
	}
	break;
      default:
	break;
      }
    }
  }
  xmlXPathFreeObject(xpathObj);
  xmlXPathFreeContext(xpathCtx); 
  return !result.empty();
}



bool _headerGet(std::string& result, _xmlDoc* name, const std::string& path)
{
	std::vector<std::string> results;
  bool headerGetListResult = _headerGetList(results, name, path);
	if (headerGetListResult)
		result = results.front();
	return headerGetListResult;
}

void osgSprite::load(const std::string& file, const std::string& path, const std::string& dataDir)
{
  _xmlDoc* doc = xmlParseFile(file.c_str());  
  g_doc = doc;
  load(doc, path, dataDir);
  xmlFreeDoc(doc);
  xmlCleanupParser();
}

void osgSprite::load(_xmlDoc* file, const std::string& path, const std::string& dataDir)
{
  std::string framePath;
  std::string sameasPath;
  framePath = path;
  bool sameasHeaderGetResult =_headerGetT(sameasPath, file, path+"/frame/@sameas");  
  if (sameasHeaderGetResult)
    framePath = sameasPath;
  std::vector<std::string> frames;
  _headerGetList(frames, file, framePath+"/frame/@path");
  std::vector<std::string> names;
  _headerGetList(names, file, framePath+"/frame/@name");
  CUSTOM_ASSERT(frames.size());
  bool haveName = frames.size() == names.size();
  CUSTOM_ASSERT((names.size() == 0) || haveName);
  for (unsigned int i = 0; i < frames.size(); ++i)
    {
      addFrame(dataDir + frames[i], haveName ? names[i] : frames[i]);
    }
  float totalTime;
  bool totalTimeHeaderGetResult = _headerGetT(totalTime, file, path+"/@totalTime");
  float currentTime;
  bool currentTimeHeaderGetResult = _headerGetT(currentTime, file, path+"/@currentTime");
  unsigned int currentFrameIndex;
  bool currentFrameIndexHeaderGetResult = _headerGetT(currentFrameIndex, file, path+"/@currentFrameIndex");
  CUSTOM_ASSERT(!currentFrameIndexHeaderGetResult || currentFrameIndex < _frames.size());
  std::string currentFrame;
  bool currentFrameHeaderGetResult = _headerGetT(currentFrame, file, path+"/@currentFrame");
  CUSTOM_ASSERT(!currentFrameHeaderGetResult || _name2index.find(currentFrame) != _name2index.end());
  osg::Vec3 translate;
  bool translateHeaderGetResult = _headerGetT(translate, file, path+"/@translate");

  CUSTOM_ASSERT(!((currentTimeHeaderGetResult && totalTimeHeaderGetResult) && currentFrameIndexHeaderGetResult));
  CUSTOM_ASSERT(!((currentTimeHeaderGetResult && totalTimeHeaderGetResult) && currentFrameHeaderGetResult));
  CUSTOM_ASSERT(!(currentFrameIndexHeaderGetResult && currentFrameHeaderGetResult));
  CUSTOM_ASSERT(!(currentTimeHeaderGetResult && !totalTimeHeaderGetResult));
  CUSTOM_ASSERT(!(!currentTimeHeaderGetResult && totalTimeHeaderGetResult));

  if (totalTimeHeaderGetResult)
    setTotalTime(totalTime);
  if (currentTimeHeaderGetResult)
    setCurrentTime(currentTime);
  if (currentFrameIndexHeaderGetResult)
    setCurrentFrame(currentFrameIndex);
  if (currentFrameHeaderGetResult)
    setCurrentFrame(currentFrame);
  if (translateHeaderGetResult)
    setMatrix(osg::Matrix::translate(translate));
}

void osgSprite::save(const std::string& file, const std::string& path)
{
}
