/* -*- c++ -*-
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.org>
 */

#include "ugameStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifndef UGAME_USE_VS_PCH

#define NOMINMAX

#include <iostream>
#include <sstream>
#include <cassert>
#include <cmath>

#include <ugame/Bubble>
#include <libxml/xmlreader.h>

#include <osg/Geode>
#include <osg/Texture2D>
#include <osg/PolygonOffset>
#include <osg/BlendFunc>
#include <osg/NodeCallback>
#include <osg/CullStack>
#include <osg/Transform>
#include <osg/Depth>
#include <osg/StateAttribute>
#include <osg/PositionAttitudeTransform>
#include <osg/MatrixTransform>
#include <osg/Projection>
#include <osg/Material>
#include <osg/CullFace>
#include <osg/Texture2D>

#include <osgDB/ReadFile>

#include <osgText/Text>

#include <osg/Vec3>

#include <varseditor/varseditor.h>
#include <maf/assert.h>
#include <maf/renderbin.h>

#include <maf/depthmask.h>
#include <CustomAssert/CustomAssert.h>
#endif

PokerEditor* g_editor = 0;

void setPokerEditor(PokerEditor* editor)
{
	g_editor = editor;
}

using namespace osgbubble;

// TODO make this xml dependant
// texture info

// to be refactored globals
static float __tt_size = 0.1f;
const float hackZ = -1.0f;


// vertices data
static const osg::Vec3	g_vertices[] =
  {
    osg::Vec3(-0.5 * __tt_size, +0.5 * __tt_size, 0),
    osg::Vec3(+0.5 * __tt_size, +0.5 * __tt_size, 0),
    osg::Vec3(-0.5 * __tt_size, -0.5 * __tt_size, 0),
    osg::Vec3(+0.5 * __tt_size, -0.5 * __tt_size, 0),
 };

// texture coordonate data
static const osg::Vec2	g_tex_coords[] =
  {
    osg::Vec2(0.0, 1.0),
    osg::Vec2(1.0, 1.0),
    osg::Vec2(0.0, 0.0),
    osg::Vec2(1.0, 0.0),
  };

// triangle strip (i.e: face) data

static const unsigned short g_tri_strip_1[] =
  {
    1, 0, 3, 2,
  };

// scalable vertices data

//const osg::Vec2f g_scale[] = 
//  {
//    osg::Vec2f(-0.7f,+1.5f), osg::Vec2(+0.7f,+1.5f),
//    osg::Vec2f(-0.7f,-2.5f), osg::Vec2(+0.7f,-2.5f),
//  };

static bool readColorFromXml(xmlTextReaderPtr reader, osg::Vec4& color) {
  bool status = false;
  xmlChar* red = xmlTextReaderGetAttribute(reader, (const xmlChar*)"red");
  if(red) {
    color.x() = atoi((const char*)red) / 255.f;
    xmlFree(red);
    status = true;
  }
  xmlChar* green = xmlTextReaderGetAttribute(reader, (const xmlChar*)"green");
  if(green) {
    color.y() = atoi((const char*)green) / 255.f;
    xmlFree(green);
    status = true;
  }
  xmlChar* blue = xmlTextReaderGetAttribute(reader, (const xmlChar*)"blue");
  if(blue) {
    color.z() = atoi((const char*)blue) / 255.f;
    xmlFree(blue);
    status = true;
  }
  xmlChar* alpha = xmlTextReaderGetAttribute(reader, (const xmlChar*)"alpha");
  if(alpha) {
    color.w() = atof((const char*)alpha);
    xmlFree(alpha);
    status = true;
  } else {
    color.w() = 1.f;
  }
  return status;
}

PatchBase::PatchBase()
{
}

void PatchBase::init(const std::string &xml)
{
}

void PatchBase::initStateSet()
{
  setUseVertexBufferObjects(false);
  setUseDisplayList(false);
  osg::StateSet* stateset = getOrCreateStateSet();
  stateset->setMode(GL_LIGHTING, osg::StateAttribute::ON);
  stateset->setAttributeAndModes(new osg::BlendFunc(osg::BlendFunc::SRC_ALPHA, osg::BlendFunc::ONE_MINUS_SRC_ALPHA),
				 osg::StateAttribute::ON);

// 	osg::ref_ptr<osg::CullFace> cull_face = new osg::CullFace;
// 	cull_face->setMode(osg::CullFace::FRONT);
// 	stateset->setAttribute(cull_face.get(), osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
 	stateset->setMode(GL_CULL_FACE, osg::StateAttribute::OFF | osg::StateAttribute::OVERRIDE);

//		_local_stateset->setMode(GL_CULL_FACE, osg::StateAttribute::ON | osg::StateAttribute::OVERRIDE);
}

void	PatchBase::setVertices(const osg::Vec3* vertices, unsigned int size)
{
  mVertices = new osg::Vec3Array(vertices, vertices + size);
  setVertexArray(mVertices.get());
}

void	PatchBase::setTexCoords(const osg::Vec2* tex_coord, unsigned int size)
{
  mTexCoords = new osg::Vec2Array(tex_coord, tex_coord + size);
  setTexCoordArray(0, mTexCoords.get());
}

void	PatchBase::addTriStrip(const unsigned short* tri_strip, unsigned int size)
{
  //addPrimitiveSet(new osg::DrawElementsUInt(osg::PrimitiveSet::LINE_STRIP, size, const_cast<unsigned int* >(tri_strip)));
  addPrimitiveSet(new osg::DrawElementsUShort(osg::PrimitiveSet::TRIANGLE_STRIP, size, const_cast<unsigned short* >(tri_strip)));
}

osg::Texture2D*	PatchBase::setTexture(const std::string &filename)
{
  osg::StateSet* stateset = getOrCreateStateSet();  
  osg::Image* image = osgDB::readImageFile(filename.c_str());
  CUSTOM_ASSERT_MSG(NULL != image, filename.c_str());
  osg::Texture2D *tex = new osg::Texture2D(image);
  tex->setFilter(osg::Texture::MIN_FILTER, osg::Texture::LINEAR);
  tex->setFilter(osg::Texture::MAG_FILTER, osg::Texture::LINEAR);
  tex->setWrap(osg::Texture::WRAP_S, osg::Texture::REPEAT);
  tex->setWrap(osg::Texture::WRAP_T, osg::Texture::REPEAT);
  tex->setBorderColor( osg::Vec4f(1, 0, 0, 1) );  
  stateset->setTextureAttributeAndModes(0, tex, osg::StateAttribute::ON);
  setStateSet(stateset);
  return tex;
}

Body::Body()
{
  //init();
}

void Body::init()
{
  // geometry
  { 
    initStateSet();

    getOrCreateStateSet()->setAttributeAndModes(new osg::PolygonOffset(-1.0, 5.0));
    getOrCreateStateSet()->setAttributeAndModes(new DepthMask(false));
    setVertices(g_vertices);
    setTexCoords(g_tex_coords);
    mTextureRight = setTexture(mBodyRightTextureFileName); 
    mTextureLeft = setTexture(mBodyLeftTextureFileName);    
    mTextureCenter = setTexture(mBodyCenterTextureFileName);    
    addTriStrip(g_tri_strip_1);
  }
}

void Body::computeXYLen(float xLen, float yLen)
{
	float bubbleTopOffset = 0.025f;
	float bubbleBottomOffset = 0.05f;
	float bubbleLeftOffset = 0.01f;
	float bubbleRightOffset = 0.01f;

	VarsEditor::Instance().Get("BUBBLE_bubbleTopOffset",bubbleTopOffset);
	VarsEditor::Instance().Get("BUBBLE_bubbleBottomOffset",bubbleBottomOffset);
	VarsEditor::Instance().Get("BUBBLE_bubbleLeftOffset",bubbleLeftOffset);
	VarsEditor::Instance().Get("BUBBLE_bubbleRightOffset",bubbleRightOffset);

	(*mVertices)[0].x() = g_vertices[0].x() + (-0.5f * xLen) - bubbleRightOffset;
  (*mVertices)[0].y() = g_vertices[0].y() + ( 0.5f * yLen) + bubbleTopOffset;
	(*mVertices)[1].x() = g_vertices[1].x() + ( 0.5f * xLen) + bubbleLeftOffset;
  (*mVertices)[1].y() = g_vertices[1].y() + ( 0.5f * yLen) + bubbleTopOffset;
	(*mVertices)[2].x() = g_vertices[2].x() + (-0.5f * xLen) - bubbleRightOffset;
  (*mVertices)[2].y() = g_vertices[2].y() + (-0.5f * yLen) - bubbleBottomOffset;
	(*mVertices)[3].x() = g_vertices[3].x() + ( 0.5f * xLen) + bubbleLeftOffset;
  (*mVertices)[3].y() = g_vertices[3].y() + (-0.5f * yLen) - bubbleBottomOffset;
}

Tail::Tail()
{
  //init();
}

void Tail::init()
{
  initStateSet();  

  getOrCreateStateSet()->setAttributeAndModes(new osg::PolygonOffset(-1.0, 4.0));
  getOrCreateStateSet()->setAttributeAndModes(new DepthMask(false));
}

void Tail::snap(const osg::Vec3& pos)
{	
	float g_tail_width = 0.5f;
  float width = g_tail_width * __tt_size;
  osg::Vec3 halfWidthV = osg::Vec3(width*0.5f, 0.0f, 0.0f);
  (*mVertices)[4] = pos - halfWidthV;
  (*mVertices)[5] = pos + halfWidthV;
}

Bubble::Bubble()
{
  mBody = new Body();
  mTailCenter = new Tail();
  mTailLeft = new Tail();
  mTailRight = new Tail();
  mAngle = 0.0f;
  mFlag = false;
}

Bubble::~Bubble()
{
}

void Bubble::init()
{
  mBubblePosition = osg::Vec3(0.0f, 0.0f, 0.0f);
  mTailPosition = osg::Vec3(0.0f, 0.0f, 0.0f);
  
  osg::Group* parent = 0;

  // billboard or not
  osg::MatrixTransform* mt = new osg::MatrixTransform;
  mt->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
  mt->setMatrix(osg::Matrix::identity());
  osg::Projection* pj = new osg::Projection;
  pj->addChild(mt);
  addChild(pj);
  parent = mt;
  parent = this;

  //state set
  {
    osg::StateSet* stateset = getOrCreateStateSet();
    osg::Material* material = new osg::Material;
    material->setColorMode(osg::Material::EMISSION);
    material->setEmission(osg::Material::FRONT_AND_BACK, osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f));
    stateset->setAttributeAndModes(material, osg::StateAttribute::ON|osg::StateAttribute::PROTECTED);
    stateset->setMode(GL_LIGHTING, osg::StateAttribute::ON|osg::StateAttribute::PROTECTED);

    if (!MAFRenderBin::Instance().SetupRenderBin("Bubble", stateset))
      MAF_ASSERT(0 && "Bubble not found in client.xml");
  }
  
  // init text
  {
    // init textDrawable
    {
      osgText::Font* font = dynamic_cast<osgText::Font*> (osgDB::readObjectFile(mTextFontFileName));      
      osgText::Text* text = new osgText::Text;
      text->setFont(font);
      text->setCharacterSize(1);
      text->setPosition(osg::Vec3(0.0f, 0.0f, 0.0f));
      const std::string& str = "osgbubble::Bubble";
      text->setText(osgText::String(str, osgText::String::ENCODING_UTF8));
      text->setAlignment(osgText::Text::CENTER_CENTER);
      text->setColor(mTextColor);

      osg::StateSet* stateset = text->getOrCreateStateSet();
      osg::Material* material = new osg::Material;
      material->setColorMode(osg::Material::EMISSION);
      material->setEmission(osg::Material::FRONT_AND_BACK, osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f));
      stateset->setAttributeAndModes(material);
      stateset->setMode(GL_LIGHTING, osg::StateAttribute::ON);
      if (!MAFRenderBin::Instance().SetupRenderBin("BubbleText", stateset))
        MAF_ASSERT(0 && "BubbleText not found in client.xml");
      stateset->setAttributeAndModes(new DepthMask(false));
      mText = text;
    }
    
    // init textNode
    {
      mTextGeode = new osg::Geode;
      mTextGeode->addDrawable(mText.get());
      mTextPAT = new osg::PositionAttitudeTransform;
      mTextPAT->addChild(mTextGeode.get());
      mTextPAT->setScale(osg::Vec3(mTextFontCharacterSize, mTextFontCharacterSize, 1.0f));
    }
  }

  // init patch
  {
    // init patchDrawable&Node
    {
      mBody->init();
      mBodyGeode = new osg::Geode;
      mBodyGeode->addDrawable(mBody.get());
      mBodyPAT = new osg::PositionAttitudeTransform;
      mBodyPAT->addChild(mBodyGeode.get());
      parent->addChild(mBodyPAT.get());
    }
      
    // compute patchBounds
    {
			mText->dirtyBound();
      const osg::BoundingBox&	bbox = mText->getBound();
      float	x_len = (bbox.xMax() - bbox.xMin()) * mTextPAT->getScale().x();
      float	y_len = (bbox.yMax() - bbox.yMin()) * mTextPAT->getScale().y();
      mBody->computeXYLen(x_len, y_len);
    }
  } 

  // init tail
  {
    mTailPAT = new osg::PositionAttitudeTransform();
    mTailCenter->init();
    mTailCenterGeode = new osg::Geode();
    mTailCenterGeode->addDrawable(mTailCenter.get());
    mTailCenterGeode->setNodeMask(0);   
    mTailCenterGeode->setName("tailCenterGeode");

    mTailRight->init();
    mTailRightGeode = new osg::Geode();
    mTailRightGeode->addDrawable(mTailRight.get());
    mTailRightGeode->setNodeMask(0);   
    mTailRightGeode->setName("tailRightGeode");

    mTailLeft->init();
    mTailLeftGeode = new osg::Geode();
    mTailLeftGeode->addDrawable(mTailLeft.get());
    mTailLeftGeode->setNodeMask(0);   
    mTailLeftGeode->setName("tailLeftGeode");
  }

  
  {
    mDebugGeode = new osg::Geode();
    mDebugGeom = new osg::Geometry();
    mDebugVertices = new osg::Vec3Array(2);
    mDebugGeom->setUseVertexBufferObjects(false);
    mDebugGeom->setUseDisplayList(false);
    mDebugGeom->setVertexArray(mDebugVertices.get());
    mDebugGeode->addDrawable(mDebugGeom.get());
    parent->addChild(mDebugGeode.get());
    
    mDebugGeom->getOrCreateStateSet()->setMode(GL_CULL_FACE, osg::StateAttribute::OFF);
    mDebugGeom->getOrCreateStateSet()->setMode(GL_LIGHTING,  osg::StateAttribute::OFF);
    mDebugGeom->getOrCreateStateSet()->setAttributeAndModes(new DepthMask(false));
    mDebugGeom->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::LINES, 0, 2));
  }
  parent->addChild(mTextPAT.get());
}

void Bubble::clean()
{
}
//
//static bool xmlReaderSeekToElement(xmlTextReaderPtr reader, const std::string &element)
//{
//  while ((xmlTextReaderRead(reader) == 1))
//    {
//      const char* namePtr = ((const char*)xmlTextReaderConstName(reader));
//      std::string name = namePtr;
//      if ((xmlTextReaderNodeType(reader) == XML_READER_TYPE_ELEMENT) && (name == element))
//	return true;
//    }
//  return false;
//}
//
//template<typename T>
//static bool xmlReaderGetAttribute(xmlTextReaderPtr reader, const std::string &name, T& attribute)
//{
//  xmlChar* attributePtr = xmlTextReaderGetAttribute(reader, (const xmlChar*)name.c_str());
//  if (attributePtr == 0)
//    return false;
//  std::istringstream iss((const char *)attributePtr);
//  iss >> attribute;
//  xmlFree(attributePtr);
//  return true;
//}

static bool xmlReaderSeekToElement(xmlTextReaderPtr reader, const std::string &element)
{
  while ((xmlTextReaderRead(reader) == 1))
    {
      const char* namePtr = ((const char*)xmlTextReaderConstName(reader));
      std::string name = namePtr;
      if ((xmlTextReaderNodeType(reader) == XML_READER_TYPE_ELEMENT) && (name == element))
				return true;
    }
  return false;
}

template<typename T>
static bool xmlReaderGetAttribute(xmlTextReaderPtr reader, const std::string &name, T& attribute)
{
  xmlChar* attributePtr = xmlTextReaderGetAttribute(reader, (const xmlChar*)name.c_str());
  if (attributePtr == 0)
    return false;
  std::istringstream iss((const char *)attributePtr);
  iss >> attribute;
  xmlFree(attributePtr);
  return true;
}

bool Bubble::unserialize(_xmlDoc* doc)
{
  xmlTextReaderPtr reader = xmlReaderWalker(doc);
  if (reader == NULL) 
    return false;

  if (!xmlReaderSeekToElement(reader, "bubble"))
    return false;
  if (!xmlReaderSeekToElement(reader, "bodyCenter"))
    return false;
  if (!xmlReaderGetAttribute(reader, "texture", mBody->mBodyCenterTextureFileName))
    return false;
  if (!xmlReaderSeekToElement(reader, "bodyLeft"))
    return false;
  if (!xmlReaderGetAttribute(reader, "texture", mBody->mBodyLeftTextureFileName))
    return false;
  if (!xmlReaderSeekToElement(reader, "bodyRight"))
    return false;
  if (!xmlReaderGetAttribute(reader, "texture", mBody->mBodyRightTextureFileName))
    return false;
  if (!xmlReaderSeekToElement(reader, "text"))
    return false;
  if (!xmlReaderGetAttribute(reader, "font", mTextFontFileName))
    return false;
  if (!xmlReaderGetAttribute(reader, "size", mTextFontCharacterSize))
    return false;
  if (!xmlReaderSeekToElement(reader, "color"))
    return false;
  if (!readColorFromXml(reader, mTextColor))
    return false;

  xmlFreeTextReader(reader);
  return true;
}

void Bubble::setText(const std::string &str)
{
  mText->setText(osgText::String(str, osgText::String::ENCODING_UTF8));
	float characterSize = 0.75;
	float characterAspectRatio = 1.0;
	VarsEditor::Instance().Get("BUBBLE_characterSize",characterSize);
	VarsEditor::Instance().Get("BUBBLE_characterAspectRatio",characterAspectRatio);
// 	EDITABLE2(g_editor, float, characterSize, 0.75f);
// 	EDITABLE2(g_editor, float, characterAspectRatio, 1.0f);
	mText->setCharacterSize(characterSize, characterAspectRatio);

	float textColorR = 1.0;
	float textColorG = 1.0;
	float textColorB = 1.0;
	float textColorA = 1.0;
	VarsEditor::Instance().Get("BUBBLE_textColorR",textColorR);
	VarsEditor::Instance().Get("BUBBLE_textColorG",textColorG);
	VarsEditor::Instance().Get("BUBBLE_textColorB",textColorB);
	VarsEditor::Instance().Get("BUBBLE_textColorA",textColorA);
// 	EDITABLE2(g_editor, float, textColorR, 1.0f);
// 	EDITABLE2(g_editor, float, textColorG, 1.0f);
// 	EDITABLE2(g_editor, float, textColorB, 1.0f);
// 	EDITABLE2(g_editor, float, textColorA, 1.0f);
	mText->setColor(osg::Vec4(textColorR, textColorG, textColorB, textColorA));
	mText->dirtyBound();
  const osg::BoundingBox&	bbox = mText->getBound();

	float	x_len = (bbox.xMax() - bbox.xMin()) * mTextPAT->getScale().x();
  float	y_len = (bbox.yMax() - bbox.yMin()) * mTextPAT->getScale().y();
	//EDITABLE2(g_editor, float, bubbleTopOffset, 0.025f);
	//EDITABLE2(g_editor, float, bubbleBottomOffset, 0.05f);
	//EDITABLE2(g_editor, float, bubbleLeftOffset, 0.01f);
	//EDITABLE2(g_editor, float, bubbleRightOffset, 0.01f);
	mSize.x() = x_len + 0.02f;
	mSize.y() = y_len + 0.075f;
	mBody->computeXYLen(x_len, y_len);
	//osg::Material* material = new osg::Material();
	//EDITABLE2(g_editor, float, bubbleColorR, mColor.x());
	//EDITABLE2(g_editor, float, bubbleColorG, mColor.y());
	//EDITABLE2(g_editor, float, bubbleColorB, mColor.z());
	//material->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4(0.0f, 0.0f, 0.0f, 1.0f));
	//material->setAmbient(osg::Material::FRONT_AND_BACK, osg::Vec4(0.0f, 0.0f, 0.0f, 0.0f));
	//material->setSpecular(osg::Material::FRONT_AND_BACK, osg::Vec4(0.0f, 0.0f, 0.0f, 0.0f));
	//material->setEmission(osg::Material::FRONT_AND_BACK, osg::Vec4(mColor.x(), mColor.y(), mColor.z(), 0.0f));
	//material->setEmission(osg::Material::FRONT_AND_BACK, osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f));	
	//getOrCreateStateSet()->setAttributeAndModes(material, osg::StateAttribute::ON|osg::StateAttribute::PROTECTED);
}

void intersect(float& ua, float& ub, const osg::Vec3& a, const osg::Vec3& b, const osg::Vec3& c, const osg::Vec3& d)
{
	float factor = (a.y() - c.y()) - (d.y() - c.y()) * (a.x() - c.x())
								  / ((d.y() - c.y()) * (b.x() - a.x()) - (d.x() - c.x()) * (b.y() - a.y()));	
	ua = ((d.x() - c.x()) * factor);
	ub = ((b.x() - a.x()) * factor);
}

void intersect2(float& ua, float& ub, const osg::Vec3& a, const osg::Vec3& b, const osg::Vec3& c, const osg::Vec3& d)
{
	// ab ef
	float x1, x2, x3, x4, y1, y2, y3, y4;
	x1 = a.x();
	x2 = b.x();
	x3 = c.x();
	x4 = d.x();			
	y1 = a.y();
	y2 = b.y();
	y3 = c.y();
	y4 = d.y();
	
	ua = ( (x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3) ) / ( (y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1) );
	ub = ( (x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3) ) / ( (y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1) );			
}

bool Bubble::IntersectBodyTail(float& t, int a, int b)
{
#if 0
	osg::Vec3Array& bodyVertices = *(mBody->mVertices.get())
	const osg::Vec3& tailPos = GetTailPosition();
	std::cout << tailPos.x() << "," << tailPos.y()oo << "," << tailPos.z() << std::endl;
	const osg::Vec3& bubblePos = GetBubblePosition();// + osg::Vec3(0.0f, 0.2f, 0.0f); // HACK REMOVE
	std::cout << bubblePos.x() << "," << bubblePos.y() << "," << bubblePos.z() << std::endl;	
	float ua, ub;
	osg::Vec3 zero(0.0f, 0.0f, 0.0f);
	intersect2(ua, ub, zero, tailPos - bubblePos, bodyVertices[a], bodyVertices[b]);
	
	t = std::min(std::max(0.0f, ub), 1.0f);
	osg::Vec3Array& tailVertices = *(mTail->mVertices.get());
// 	if ((ua > 0.0f) && (ua < 1.0f)
// 			&& (ub > 0.0f) && (ub < 1.0f))
// 		{
// 			t = ub;
// 			return true;
// 		}
// 	return false;
#endif
	return true;
}

struct math
{
  template<typename T>
  static void lerp(T& out, const T& in1, const T& in2, float t)
  {
    out = in1 * (1 - t) + in2 * (t);
  }
  template<typename T>
  static T lerp(const T& in1, const T& in2, float t)
  {
    return (in1 * (1 - t) + in2 * (t));
  }
};

void Bubble::UpdateBubblePosition()
{
  const osg::Vec3& bubblePos = GetBubblePosition();// + osg::Vec3(0.0f, 0.2f, 0.0f); // HACK REMOVE
  //const osg::Vec3& tailPos = GetTailPosition();
  mBodyPAT->setPosition(bubblePos);
	float textXOffset = 0;
	float textYOffset = 0;
	VarsEditor::Instance().Get("BUBBLE_textXOffset", textXOffset);
	VarsEditor::Instance().Get("BUBBLE_textYOffset", textYOffset);
// 	EDITABLE2(g_editor, float, textXOffset, 0.0f);
// 	EDITABLE2(g_editor, float, textYOffset, 0.0f);
  const osg::BoundingBox&	bbox = mText->getBound();
	float	x_len = (bbox.xMax() - bbox.xMin()) * mTextPAT->getScale().x();
  float	y_len = (bbox.yMax() - bbox.yMin()) * mTextPAT->getScale().y();
	osg::Vec3 textAnchor((118.0f-128.0f)/256.0f, (128.0f-108.0f)/256.0f, 0.0f);
	textAnchor.x() *= x_len;
	textAnchor.y() *= y_len;

	mTextPAT->setPosition(bubblePos+textAnchor+osg::Vec3(textXOffset, textYOffset, 0.0f));
  mTailPAT->setPosition(bubblePos);
}

void FinishBubbleTailPosition(Bubble* bubble, float t)
{
  osg::Vec3Array& bodyVertices = *(bubble->mBody->mVertices.get());	
  float tailLength = 0.025f;
  float tailHeight = 0.1f;
  float tailT = tailLength / (bodyVertices[9] - bodyVertices[10]).length();
  Tail* tailShow = bubble->mTailCenter.get();
  osg::Vec3Array& tailVertices = *(tailShow->mVertices.get());
  math::lerp(tailVertices[0], bodyVertices[9], bodyVertices[10], t-tailT);
  math::lerp(tailVertices[1], bodyVertices[9], bodyVertices[10], t+tailT);
  tailVertices[0].y() = tailVertices[1].y() = bodyVertices[9].y() = bodyVertices[10].y();
  //math::lerp(debugVertices[0], bodyVertices[9], bodyVertices[10], t);
  //IntersectBodyTail(t, 13, 14);
  math::lerp(tailVertices[2], bodyVertices[13], bodyVertices[14], t-tailT);
  math::lerp(tailVertices[3], bodyVertices[13], bodyVertices[14], t+tailT);
  tailVertices[2].y() = tailVertices[3].y() = bodyVertices[13].y() = bodyVertices[14].y();
  //math::lerp(debugVertices[1], bodyVertices[13], bodyVertices[14], t);
  math::lerp(tailVertices[4], bodyVertices[13]+osg::Vec3(0.0f, -tailHeight, 0.0f), bodyVertices[14]+osg::Vec3(0.0f, -tailHeight, 0.0f), t-tailT); 
  math::lerp(tailVertices[5], bodyVertices[13]+osg::Vec3(0.0f, -tailHeight, 0.0f), bodyVertices[14]+osg::Vec3(0.0f, -tailHeight, 0.0f), t+tailT); 
  bubble->mTailCenter->setVertexArray(&tailVertices);
  bubble->mTailRight->setVertexArray(&tailVertices);
  bubble->mTailLeft->setVertexArray(&tailVertices);
}

void Bubble::UpdateTailPosition()
{
	const osg::Vec3& bubblePos = GetBubblePosition();// + osg::Vec3(0.0f, 0.2f, 0.0f); // HACK REMOVE
	const osg::Vec3& tailPos = GetTailPosition();
	mBodyPAT->setPosition(bubblePos);
	mTextPAT->setPosition(bubblePos);
	mTailPAT->setPosition(bubblePos);

	osg::Vec3Array& bodyVertices = *(mBody->mVertices.get());	
	//osg::Vec3Array& debugVertices = *(mDebugVertices.get());
// 	math::lerp(tailVertices[0], bodyVertices[9], bodyVertices[10], 0.4); 
// 	math::lerp(tailVertices[1], bodyVertices[9], bodyVertices[10], 0.6); 
// 	math::lerp(tailVertices[2], bodyVertices[13], bodyVertices[14], 0.4); 
// 	math::lerp(tailVertices[3], bodyVertices[13], bodyVertices[14], 0.6); 
// 	math::lerp(tailVertices[4], bodyVertices[13]+osg::Vec3(0.0f, -0.1f, 0.0f), bodyVertices[14]+osg::Vec3(0.0f, -0.1f, 0.0f), 0.4); 
// 	math::lerp(tailVertices[5], bodyVertices[13]+osg::Vec3(0.0f, -0.1f, 0.0f), bodyVertices[14]+osg::Vec3(0.0f, -0.1f, 0.0f), 0.6);      

	float tailXPos = (tailPos - bubblePos).x();
	float t = (tailXPos - bodyVertices[0].x()) / (bodyVertices[1] - bodyVertices[0]).x();
	if (t < 0.0f)
	  {
	    t = 0.3f;
	  }
	else if (t > 1.0f)
	  {
	    t = 0.7f;
	  }
	else
	  {
	    t = 0.5f;
	  }

	  {
	    float teta = 0.1f;
	    float diff = bubblePos.x() - tailPos.x();
	    if (diff > teta)
	      {
					//mTailLeftGeode->setNodeMask(0xffffffff);
					//mTailRightGeode->setNodeMask(0x0);
					//mTailCenterGeode->setNodeMask(0x0);
				  mBody->getOrCreateStateSet()->setTextureAttributeAndModes(0, mBody->mTextureLeft.get(), osg::StateAttribute::ON);
	      }
	    else if (diff < -teta)
	      {
					//mTailRightGeode->setNodeMask(0xffffffff);
					//mTailLeftGeode->setNodeMask(0x0);
					//mTailCenterGeode->setNodeMask(0x0);
				  mBody->getOrCreateStateSet()->setTextureAttributeAndModes(0, mBody->mTextureRight.get(), osg::StateAttribute::ON);
	      }
	    else 
	      {
					//mTailCenterGeode->setNodeMask(0xffffffff);
					//mTailLeftGeode->setNodeMask(0.0f);
					//mTailRightGeode->setNodeMask(0.0f);
				  mBody->getOrCreateStateSet()->setTextureAttributeAndModes(0, mBody->mTextureCenter.get(), osg::StateAttribute::ON);
	      }
	  }

	  //FinishBubbleTailPosition(this, t);

// 	tailHide->getParent(0)->setNodeMask(0);
// 	tailShow->getParent(0)->setNodeMask(0xffffffff);

// 	debugVertices[0] = GetBubblePosition();
// 	debugVertices[1] = GetTailPosition();
// 	mDebugGeom->setVertexArray(mDebugVertices.get());

	//std::cout << a << "," << b << std::endl;
	//intersect(a, b, osg::Vec3(0.0f, 0.0f, 0.0f), GetTailPosition(), bodyVertices[13], bodyVertices[14]);
	//std::cout << a << "," << b << std::endl;
	
	//intersect2(float& ua, float& ub, const osg::Vec3& a, const osg::Vec3& b, const osg::Vec3& c, const osg::Vec3& d)
	// 	tailVertices[0] = bodyVertices[9];
	// 	tailVertices[1] = bodyVertices[10];
	// 	tailVertices[2] = bodyVertices[13];
	// 	tailVertices[3] = bodyVertices[14];
	// 	tailVertices[4] = bodyVertices[13] + osg::Vec3(0.0f, -0.1f, 0.0f);
	// 	tailVertices[5] = bodyVertices[14] + osg::Vec3(0.0f, -0.1f, 0.0f);
	return;
}

void Bubble::UpdateTailPosition2()
{
	return;
	const osg::Vec3& bubblePos = GetBubblePosition();// + osg::Vec3(0.0f, 0.2f, 0.0f); // HACK REMOVE
	const osg::Vec3& tailPos = GetTailPosition();
	mBodyPAT->setPosition(bubblePos);
	mTextPAT->setPosition(bubblePos);
	mTailPAT->setPosition(bubblePos);
	osg::Vec3Array& bodyVertices = *(mBody->mVertices.get());	
	//osg::Vec3Array& debugVertices = *(mDebugVertices.get());
	return;
// 	math::lerp(tailVertices[0], bodyVertices[9], bodyVertices[10], 0.4); 
// 	math::lerp(tailVertices[1], bodyVertices[9], bodyVertices[10], 0.6); 
// 	math::lerp(tailVertices[2], bodyVertices[13], bodyVertices[14], 0.4); 
// 	math::lerp(tailVertices[3], bodyVertices[13], bodyVertices[14], 0.6); 
// 	math::lerp(tailVertices[4], bodyVertices[13]+osg::Vec3(0.0f, -0.1f, 0.0f), bodyVertices[14]+osg::Vec3(0.0f, -0.1f, 0.0f), 0.4); 
// 	math::lerp(tailVertices[5], bodyVertices[13]+osg::Vec3(0.0f, -0.1f, 0.0f), bodyVertices[14]+osg::Vec3(0.0f, -0.1f, 0.0f), 0.6);      

	float tailXPos = (tailPos - bubblePos).x();
	float t = (tailXPos - bodyVertices[13].x()) / (bodyVertices[14] - bodyVertices[13]).x();
	bool update = false;
	if (t < 0.3f)
	  {
	    t = 0.3f;
	  }
	else if (t > 0.7f)
	  {
	    t = 0.7f;
	  }
	else
	  {	    
	   // t = 0.5f;
	  }
//	if (t != mAngle)
//	  {
	    update = true;
//	  }
	mAngle = t;
	//t = std::min(std::max(t, 0.0f), 1.0f);	
		
// 	mTailLeftGeode->setNodeMask(0x0);
// 	mTailRightGeode->setNodeMask(0x0);

	if (update)
	  {
	    float teta = 0.1f;
	    float diff = bubblePos.x() - tailPos.x();
	    if (diff > teta)
	      {
		mTailLeftGeode->setNodeMask(0xffffffff);
		mTailRightGeode->setNodeMask(0x0);
		mTailCenterGeode->setNodeMask(0x0);
	      }
	    else if (diff < -teta)
	      {
		mTailRightGeode->setNodeMask(0xffffffff);
		mTailLeftGeode->setNodeMask(0x0);
		mTailCenterGeode->setNodeMask(0x0);
	      }
	    else 
	      {
		mTailCenterGeode->setNodeMask(0xffffffff);
		mTailLeftGeode->setNodeMask(0);
		mTailRightGeode->setNodeMask(0);
	      }
	  }

	FinishBubbleTailPosition(this, t);
#if 0
	float tailLength = 0.025f;
	float tailHeight = 0.1f;
	float tailT = tailLength / (bodyVertices[9] - bodyVertices[10]).length();
	Tail* tailShow = mTailCenter.get();
	osg::Vec3Array& tailVertices = *(tailShow->mVertices.get());
	math::lerp(tailVertices[0], bodyVertices[9], bodyVertices[10], t-tailT);
	math::lerp(tailVertices[1], bodyVertices[9], bodyVertices[10], t+tailT);
	//math::lerp(debugVertices[0], bodyVertices[9], bodyVertices[10], t);
	//IntersectBodyTail(t, 13, 14);
	math::lerp(tailVertices[2], bodyVertices[13], bodyVertices[14], t-tailT);
	math::lerp(tailVertices[3], bodyVertices[13], bodyVertices[14], t+tailT);
	//math::lerp(debugVertices[1], bodyVertices[13], bodyVertices[14], t);
	math::lerp(tailVertices[4], bodyVertices[13]+osg::Vec3(0.0f, -tailHeight, 0.0f), bodyVertices[14]+osg::Vec3(0.0f, -tailHeight, 0.0f), t-tailT); 
	math::lerp(tailVertices[5], bodyVertices[13]+osg::Vec3(0.0f, -tailHeight, 0.0f), bodyVertices[14]+osg::Vec3(0.0f, -tailHeight, 0.0f), t+tailT); 
	mTailCenter->setVertexArray(&tailVertices);
	mTailRight->setVertexArray(&tailVertices);
	mTailLeft->setVertexArray(&tailVertices);
#endif
}

#if 0
//  	{
// 		const osg::Vec3& tailPos = GetTailPosition();
// 		float angle = mAngle;;
// 		osg::Vec3 delta = tailPos - bubblePos;
// 		osg::Vec3 pos;
// 		pos.y() = delta.length() * cos(angle);
// 		pos.x() = delta.length() * sin(angle);
// 		pos.z() = tailPos.z();
// 		pos += bubblePos;		
// 	}

//0  1             2  3 
//4  5						 6  7
//								 
//
//8  9		0	1			 10 11
//12 13		2	3	     14 15
//				4 5

	{
		osg::Vec3Array& bodyVertices = *(mBody->mVertices.get());
		osg::Vec3Array& tailVertices = *(mTail->mVertices.get());
		const osg::Vec3& tailPos = GetTailPosition();
		const osg::Vec3& bubblePos = GetBubblePosition();
		osg::Vec3 bubbleIn = bodyVertices[0] + bubblePos;
		osg::Vec3 bubbleOut = bodyVertices[15] + bubblePos;

		if ((tailPos.x() > bubbleIn.x())
				&& (tailPos.x() < bubbleOut.x())
				&& (tailPos.y() < bubbleIn.y()) 
				&& (tailPos.y() > bubbleOut.y()))
			{
				tailVertices[0] = bodyVertices[0];
				tailVertices[1] = bodyVertices[0];
				tailVertices[2] = bodyVertices[0];
				tailVertices[3] = bodyVertices[0];
				tailVertices[4] = bodyVertices[0];
				tailVertices[5] = bodyVertices[0];
				mTail->setVertexArray(&tailVertices);
				return;
			} 
	}
		
	float bubbleTailWidth = 0.05f;
	const osg::Vec3& tailPos = GetTailPosition();
	osg::Vec3Array& tailVertices = *(mTail->mVertices.get());

	osg::Vec3 dx = osg::Vec3(bubbleTailWidth/2.0f, 0.0f, 0.0f); 
	osg::Vec3 dy = osg::Vec3(0.0f, bubbleTailWidth/2.0f, 0.0f); 

	// 			osg::Vec3 tailAttach = bodyVertices[c] * (1.0f - t) + bodyVertices[d] * t;
// 			tailAttach += bubblePos;
// 			osg::Vec3Array& tailVertices = *(mTail->mVertices.get());
// 			tailVertices[a] = tailAttach - dx;
// 			tailVertices[b] = tailAttach + dx;


	float t;
	if (IntersectBodyTail(t, 12, 15))
		{
			osg::Vec3Array& bodyVertices = *(mBody->mVertices.get());
			float xLen = std::abs(bodyVertices[15].x() - bodyVertices[12].x());
			float xCorner =  std::abs(bodyVertices[15].x() - bodyVertices[14].x());
			float tHalfWidth = (bubbleTailWidth*0.5f)/xLen;
			float tCorner = xCorner/xLen;
			float tClamp = tHalfWidth + tCorner;
			t = std::min(std::max(t, tClamp), 1.0f - tClamp);
			osg::Vec3 tailAttach = bodyVertices[12] * (1.0f - t) + bodyVertices[15] * t;
			tailAttach += bubblePos;
 			osg::Vec3Array& tailVertices = *(mTail->mVertices.get());
 			tailVertices[2] = tailAttach - dx;
 			tailVertices[3] = tailAttach + dx;

			{
				float ua, ub;			
				osg::Vec3 zero(0.0f, 0.0f, 0.0f);
				intersect2(ua, ub, zero, tailPos - tailAttach, bodyVertices[8], bodyVertices[11]);
				float t = ub;
				float tClamp = tHalfWidth + tCorner;
				t = std::min(std::max(t, tClamp), 1.0f - tClamp);
				osg::Vec3 tailAttach = bodyVertices[8] * (1.0f - t) + bodyVertices[11] * t;
				tailAttach += bubblePos;
				tailVertices[0] = tailAttach - dx;
				tailVertices[1] = tailAttach + dx;
			}
			
 			tailVertices[4] = tailPos - dx;
 			tailVertices[5] = tailPos + dx;
		}
	else if (IntersectBodyTail(t, 3, 15))
		{
			osg::Vec3Array& bodyVertices = *(mBody->mVertices.get());
			float yLen = std::abs(bodyVertices[3].y() - bodyVertices[15].y());
			float yCorner =  std::abs(bodyVertices[3].y() - bodyVertices[7].y());
			float tHalfWidth = (bubbleTailWidth*0.5f)/yLen;
			float tCorner = yCorner/yLen;
			float tClamp = tHalfWidth + tCorner;
			t = std::min(std::max(t, tClamp), 1.0f - tClamp);
			osg::Vec3 tailAttach = bodyVertices[3] * (1.0f - t) + bodyVertices[15] * t;
			tailAttach += bubblePos;
 			osg::Vec3Array& tailVertices = *(mTail->mVertices.get());
 			tailVertices[3] = tailAttach - dy;
 			tailVertices[2] = tailAttach + dy;

			{
				float ua, ub;			
				osg::Vec3 zero(0.0f, 0.0f, 0.0f);
				intersect2(ua, ub, zero, tailPos - tailAttach, bodyVertices[2], bodyVertices[14]);
				float t = ub;
				float tClamp = tHalfWidth + tCorner;
				t = std::min(std::max(t, tClamp), 1.0f - tClamp);
				osg::Vec3 tailAttach = bodyVertices[2] * (1.0f - t) + bodyVertices[14] * t;
				tailAttach += bubblePos;
				tailVertices[1] = tailAttach - dy;
				tailVertices[0] = tailAttach + dy;
			}
			
 			tailVertices[5] = tailPos - dy;
 			tailVertices[4] = tailPos + dy;
		}
	else if	(IntersectBodyTail(t, 0, 3))
		{
			osg::Vec3Array& bodyVertices = *(mBody->mVertices.get());
			float xLen = std::abs(bodyVertices[15].x() - bodyVertices[12].x());
			float xCorner =  std::abs(bodyVertices[15].x() - bodyVertices[14].x());
			float tHalfWidth = (bubbleTailWidth*0.5f)/xLen;
			float tCorner = xCorner/xLen;
			float tClamp = tHalfWidth + tCorner;
			t = std::min(std::max(t, tClamp), 1.0f - tClamp);
			osg::Vec3 tailAttach = bodyVertices[0] * (1.0f - t) + bodyVertices[3] * t;
			tailAttach += bubblePos;
 			osg::Vec3Array& tailVertices = *(mTail->mVertices.get());
 			tailVertices[2] = tailAttach - dx;
 			tailVertices[3] = tailAttach + dx;

			{
				float ua, ub;			
				osg::Vec3 zero(0.0f, 0.0f, 0.0f);
				intersect2(ua, ub, zero, tailPos - tailAttach, bodyVertices[4], bodyVertices[7]);
				float t = ub;
				float tClamp = tHalfWidth + tCorner;
				t = std::min(std::max(t, tClamp), 1.0f - tClamp);
				osg::Vec3 tailAttach = bodyVertices[4] * (1.0f - t) + bodyVertices[7] * t;
				tailAttach += bubblePos;
				tailVertices[0] = tailAttach - dx;
				tailVertices[1] = tailAttach + dx;
			}
			
 			tailVertices[4] = tailPos - dx;
 			tailVertices[5] = tailPos + dx;
		}
	else if (IntersectBodyTail(t, 0, 12))
		{
			osg::Vec3Array& bodyVertices = *(mBody->mVertices.get());
			float yLen = std::abs(bodyVertices[0].y() - bodyVertices[12].y());
			float yCorner =  std::abs(bodyVertices[8].y() - bodyVertices[12].y());
			float tHalfWidth = (bubbleTailWidth*0.5f)/yLen;
			float tCorner = yCorner/yLen;
			float tClamp = tHalfWidth + tCorner;
			t = std::min(std::max(t, tClamp), 1.0f - tClamp);
			osg::Vec3 tailAttach = bodyVertices[0] * (1.0f - t) + bodyVertices[12] * t;
			tailAttach += bubblePos;
 			osg::Vec3Array& tailVertices = *(mTail->mVertices.get());
 			tailVertices[3] = tailAttach - dy;
 			tailVertices[2] = tailAttach + dy;

			{
				float ua, ub;			
				osg::Vec3 zero(0.0f, 0.0f, 0.0f);
				intersect2(ua, ub, zero, tailPos - tailAttach, bodyVertices[1], bodyVertices[13]);
				float t = ub;
				float tClamp = tHalfWidth + tCorner;
				t = std::min(std::max(t, tClamp), 1.0f - tClamp);
				osg::Vec3 tailAttach = bodyVertices[1] * (1.0f - t) + bodyVertices[13] * t;
				tailAttach += bubblePos;
				tailVertices[1] = tailAttach - dy;
				tailVertices[0] = tailAttach + dy;
			}
			
 			tailVertices[5] = tailPos - dy;
 			tailVertices[4] = tailPos + dy;
		}

//   if ((IntersectBodyTail(0, 1, 9, 10, dx) && IntersectBodyTail(2, 3, 12, 15, dx))
// 			|| (IntersectBodyTail(0, 1, 6, 5, dx) && IntersectBodyTail(2, 3, 3, 0, dx)))
// 		{
// 			tailVertices[4] = tailPos - dx;
// 			tailVertices[5] = tailPos + dx;
// 		}
// 	else if((IntersectBodyTail(0, 1, 10, 6, dy) && IntersectBodyTail(2, 3, 15, 3, dy))
// 					|| (IntersectBodyTail(0, 1, 5, 9, dy) && IntersectBodyTail(2, 3, 0, 12, dy)))
// 		{
// 			tailVertices[4] = tailPos - dy;
// 			tailVertices[5] = tailPos + dy;
// 		}
// 	else
// 		{
// 			//assert(false);
// 		}

	mTail->setVertexArray(&tailVertices);
}
#endif

void Bubble::SetFontSize(float size)
{
	mTextFontCharacterSize = size;
	mTextPAT->setScale(osg::Vec3(mTextFontCharacterSize, mTextFontCharacterSize, 1.0f));
}

void Bubble::SetRenderBinOffset(int offset)
{
	//mTailCenter->getOrCreateStateSet()->setRenderBinDetails(offset + 15, "RenderBin");
	//mTailLeft->getOrCreateStateSet()->setRenderBinDetails(offset + 15, "RenderBin");
	//mTailRight->getOrCreateStateSet()->setRenderBinDetails(offset + 15, "RenderBin");
	//mBody->getOrCreateStateSet()->setRenderBinDetails(offset + 15, "RenderBin");
	//mText->getOrCreateStateSet()->setRenderBinDetails(offset + 16, "RenderBin");
}

void Bubble::SetColor(const osg::Vec4& color)
{
	mColor.x() = color.x()/255.0f;
	mColor.y() = color.y()/255.0f;
	mColor.z() = color.z()/255.0f;
}
