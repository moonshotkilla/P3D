/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <maf/autoscale.h>
#include <osg/CullStack>
#endif


MAFAutoScale::MAFAutoScale() :
_zThreeShold(-120)
{
}

MAFAutoScale::MAFAutoScale(const MAFAutoScale & instance, const osg::CopyOp &copyop) :
_zThreeShold(instance._zThreeShold)
{
}

bool MAFAutoScale::computeLocalToWorldMatrix(osg::Matrix & matrix, osg::NodeVisitor *nv) const
{
	Parent::computeLocalToWorldMatrix(matrix, nv);

	if (nv) {
		osg::NodeVisitor::VisitorType vt = nv->getVisitorType();
		if (vt == osg::NodeVisitor::CULL_VISITOR) {
			osg::Matrix mat = matrix; // * lastViewMatrix_;
			float z = mat.getTrans()._v[2];
			if (z > _zThreeShold) {
				float scal = z / _zThreeShold;
				osg::Matrix scaleMat = osg::Matrix::scale(scal, scal, 1);

				if (_referenceFrame == RELATIVE_RF) {
					matrix.preMult(scaleMat);
				}
				else {
					matrix = scaleMat;
				}
			}
		}
	}

	return true;
}

void MAFAutoScale::accept(osg::NodeVisitor &nv)
{
	Parent::accept(nv);
}
