/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH

#include <stdio.h>
#include <string>

#ifdef WIN32
 #ifndef snprintf
  #define snprintf _snprintf
 #endif //snprintf
#endif //WIN32

#endif

std::string MAFformat_amount(unsigned int value, bool bAdvancedFormat)
{
  char tmp[64];

	if (bAdvancedFormat == false) {
		if(value % 100 != 0) {
			snprintf(tmp, 64, "%d.%02d", value / 100, value % 100);
		}
		else {
			snprintf(tmp, 64, "%d", value / 100);
		}
	}
	else {
		if (value > 999999999) {
			int left = value/100000000;
			int right0 = (value%100000000) / 10000000;
			int right1 = (value%10000000) / 1000000;
			if (!right0 && !right1)
				snprintf(tmp, 64, "%dm", left);
			else if (!right1)
				snprintf(tmp, 64, "%d.%dm", left, right0);
			else
				snprintf(tmp, 64, "%d.%d%dm", left, right0, right1);
		}
		else if (value > 999999) {
			int left = value/100000;
			int right0 = (value%100000) / 10000;
			int right1 = (value%10000) / 1000;
			if (!right0 && !right1)
				snprintf(tmp, 64, "%dk", left);
			else if (!right1)
				snprintf(tmp, 64, "%d.%dk", left, right0);
			else
				snprintf(tmp, 64, "%d.%d%dk", left, right0, right1);
		}
		else {
			if (value % 100 != 0)
				snprintf(tmp, 64, "%d.%02d", value / 100, value % 100);
			else
				snprintf(tmp, 64, "%d", value / 100);
		}
	}

  return tmp;
}
