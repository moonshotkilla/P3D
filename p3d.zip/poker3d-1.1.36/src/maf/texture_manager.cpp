/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <maf/texture_manager.h>
#endif

TextureManager::TextureManager()
{
	mTextureSize=0;
	mOptions = new osgDB::ReaderWriter::Options;
	mOptions->setObjectCacheHint(osgDB::ReaderWriter::Options::CACHE_NONE);
	mUseTrilinear = false;
}

TextureManager::~TextureManager()
{
	Flush();
	if (mTextures.size()) {
		for (ContainerTexture::iterator i=mTextures.begin();i!=mTextures.end();i++)
			g_critical("Texture %s does not seem to be released (%d)",(*i).first.c_str(),(*i).second->referenceCount());
	}
}

bool TextureManager::GetNameFromTexture2D(osg::Texture2D* _texture,std::string& _name)
{
	ContainerTexture2Name::iterator it;    
	it = mTextures2Name.find(_texture);
	if (it == mTextures2Name.end())
		return false;

	_name=it->second;

	return true;
}

osg::Texture2D* TextureManager::GetTexture2D(const std::string& _name, osgDB::ReaderWriter::Options* _options)
{
	if (mTextures.find(_name) == mTextures.end()) {

		if (_options && _name.rfind(".dds") != std::string::npos)
			_options->setOptionString("dds_flip");

		osg::Image* image = osgDB::readImageFile(_name, _options);
		if (!image) {
			g_critical("Image %s not found",_name.c_str());
			return 0;
		}

		osg::Texture2D* texture = new osg::Texture2D;
		texture->setUseHardwareMipMapGeneration(false);
		mTextures[_name]=texture;
		mTextures2Name[texture]=_name;

		TextureInformation* info = new TextureInformation(_name,image->s(),image->t());
		info->resetLastModificationTime();
		texture->setUserData(info);
		texture->setImage(image);
		texture->setWrap( osg::Texture::WRAP_R, osg::Texture::REPEAT);
		texture->setWrap( osg::Texture::WRAP_S, osg::Texture::REPEAT);
		texture->setWrap( osg::Texture::WRAP_T, osg::Texture::REPEAT);
		mTextureSize += image->getImageSizeInBytes();

		bool bCompressed = texture->isCompressedInternalFormat();
		int nbMipmaps = image->getNumMipmapLevels();

		if (mUseTrilinear == true) {
			if (nbMipmaps > 1 || (nbMipmaps == 1 && bCompressed == false))
				texture->setFilter(osg::Texture2D::MIN_FILTER, osg::Texture2D::LINEAR_MIPMAP_LINEAR);
			else
				texture->setFilter(osg::Texture2D::MIN_FILTER, osg::Texture2D::LINEAR);
		}
		else {
			texture->setFilter(osg::Texture2D::MIN_FILTER, osg::Texture2D::LINEAR_MIPMAP_NEAREST);
		}

		texture->setFilter(osg::Texture2D::MAG_FILTER, osg::Texture2D::LINEAR);

		if (texture->getInternalFormat() == GL_COMPRESSED_RGB_S3TC_DXT1_EXT && _name.rfind("_a.dds") != std::string::npos) {
			texture->setInternalFormat(GL_COMPRESSED_RGBA_S3TC_DXT1_EXT);
		}

	}
	return mTextures[_name].get();
}

void TextureManager::Statistics()
{
	g_debug("Max texture loaded %d", mTextureSize);
	for (ContainerTexture::iterator i = mTextures.begin(); i != mTextures.end(); i++) {
		g_debug("Texture name %s referenced %d times - compressed %d",i->first.c_str(), i->second.get()->referenceCount()-1, i->second.get()->isCompressedInternalFormat());
	}
}

void TextureManager::Flush() 
{
	std::vector<ContainerTexture::iterator> toRemove;
	for (ContainerTexture::iterator i = mTextures.begin(); i != mTextures.end(); i++)
		if ((*i).second->referenceCount() == 2) // means that only rdr reference it
			toRemove.push_back(i);

	int end = (int) toRemove.size();
	for (int i = 0; i < end; i++) {
		toRemove[i]->second->setUserData(0);
		mTextures.erase(toRemove[i]);
	}
}

void TextureManager::Reload()
{
  for (ContainerTexture::iterator i = mTextures.begin(); i != mTextures.end(); ++i) {
    const std::string& name = (*i).first;
    osg::Texture2D* texture = (*i).second.get();
    TextureInformation* info = dynamic_cast<TextureInformation*>(texture->getUserData());
    if (info)
      if (info->hasChanged())
	{
	  osg::Image* image = osgDB::readImageFile(name, mOptions.get());
	  texture->setImage(image);
	}
  }
}

void TextureManager::SetUseTrilinear(bool bUseTrilinear)
{
	mUseTrilinear = bUseTrilinear;
}

bool TextureManager::IsUseTrilinear() const
{
	return mUseTrilinear;
}
