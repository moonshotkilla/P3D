
#include <osgFX/OrenNayar>
#include <osgFX/Registry>

#include <osg/VertexProgram>
#include <osg/FragmentProgram>
#include <osg/Texture2D>

using namespace osgFX;

#ifndef NORMALIZE
#define NORMALIZE(a) "DP3 " #a ".w, " #a ", " #a ";\nRSQ " #a ".w, " #a ".w;\nMUL " #a ".xyz, " #a ".w, " #a ";\n"
#endif

namespace
{
    // register a prototype for this effect
	Registry::Proxy proxy(new OrenNayar);

	osg::Texture2D *sinTanTexture = NULL;

	float* generateSinTanLookup()
	{
		float *table = new float[512*512];

		float *ptr = table;

		for (int j = 0; j < 512; j++) {
			for (int i = 0; i < 512; i++) {
				float theta_l = i / 512.0f;
				float theta_v = j / 512.0f;

				float a = acosf(theta_l);
				float b = acosf(theta_v);

				float alpha = std::max(a, b);
				float beta = std::min(a, b);

				float res = sinf(alpha) * tanf(beta);

				*ptr++ = res;
			}
		}
		return table;
	}

	osg::Texture2D* getSinTanTexture()
	{
		if (!sinTanTexture) {
			float *table = generateSinTanLookup();
			osg::Image *img = new osg::Image();
			img->setImage(512, 512, 1, GL_LUMINANCE16F_ARB, GL_LUMINANCE, GL_FLOAT, (unsigned char*) table, osg::Image::USE_NEW_DELETE);

			sinTanTexture = new osg::Texture2D();
			sinTanTexture->setImage(img);
			sinTanTexture->setWrap( osg::Texture::WRAP_R, osg::Texture::CLAMP);
			sinTanTexture->setWrap( osg::Texture::WRAP_S, osg::Texture::CLAMP);
			sinTanTexture->setFilter(osg::Texture::MIN_FILTER, osg::Texture::NEAREST);
			sinTanTexture->setFilter(osg::Texture::MAG_FILTER, osg::Texture::NEAREST);
		}
		return sinTanTexture;
	}

	class DefaultTechnique : public Technique {

		void getRequiredExtensions(std::vector<std::string> &extensions) const
		{
			extensions.push_back("GL_ARB_vertex_program");
			extensions.push_back("GL_ARB_fragment_program");
			extensions.push_back("GL_ARB_texture_float");
		}

		void define_passes()
		{
			char vp_code[] =
			"!!ARBvp1.0\n"\
			"ATTRIB	pos = vertex.position;\n"\
			"PARAM	mv[4] = { state.matrix.modelview };\n"\
			"PARAM	mvp[4] = { state.matrix.mvp };\n"\
			"PARAM	mvinv[4] = { state.matrix.modelview.invtrans };\n"\
			"TEMP	tmp, vtx;\n"\
			"# vertex to clip space\n"\
			"DP4	result.position.x, mvp[0], vertex.position;\n"\
			"DP4	result.position.y, mvp[1], vertex.position;\n"\
			"DP4	result.position.z, mvp[2], vertex.position;\n"\
			"DP4	result.position.w, mvp[3], vertex.position;\n"\
			"# local normal to eye space\n"\
			"DP3	result.texcoord[3].x, mvinv[0], vertex.normal;\n"\
			"DP3	result.texcoord[3].y, mvinv[1], vertex.normal;\n"\
			"DP3	result.texcoord[3].z, mvinv[2], vertex.normal;\n"\
			"# vertex to eye space\n"\
			"DP4	vtx.x, mv[0], vertex.position;\n"\
			"DP4	vtx.y, mv[1], vertex.position;\n"\
			"DP4	vtx.z, mv[2], vertex.position;\n"\
			"DP4	vtx.w, mv[3], vertex.position;\n"\
			"# light to vertex vector\n"\
			"SUB	tmp, state.light[0].position, vtx;\n"\
			"MOV	result.texcoord[4], tmp;\n"\
			"MOV	result.texcoord[5], -vtx;\n"\
			"# diffuse color\n"\
			"MOV	result.color, state.lightprod[0].diffuse;\n"\
			"# tex coords 0&1\n"\
			"MOV	result.texcoord[0], vertex.texcoord[0];\n"\
			"MOV	result.texcoord[1], vertex.texcoord[1];\n"\
			"\n"\
			"END\n";

			char fp_code[] = 
			"!!ARBfp1.0\n"\
			"TEMP	norm, light, view, VdotN, LdotN, tmp, tmp2, sintan, cos_phi_diff, A, B;\n"\
			"PARAM	AB = program.local[0];\n"\
			"MOV	norm, fragment.texcoord[3];\n"\
			NORMALIZE(norm)
			"MOV	light, fragment.texcoord[4];\n"\
			NORMALIZE(light)
			"MOV	view, fragment.texcoord[5];\n"\
			NORMALIZE(view)
			"DP3	VdotN.x, view, norm;\n"\
			"DP3	LdotN.x, light, norm;\n"\

			"MUL	tmp.xyz, norm, VdotN.x;\n"\
			"SUB	tmp.xyz, view, tmp;\n"\
			NORMALIZE(tmp)
			"MUL	tmp2.xyz, norm, LdotN.x;\n"\
			"SUB	tmp2.xyz, light, tmp2;\n"\
			NORMALIZE(tmp2)
			"DP3_SAT	cos_phi_diff.x, tmp, tmp2;\n"\

			"MOV_SAT	tmp.x, LdotN.x;\n"\
			"MOV_SAT	tmp.y, VdotN.x;\n"\
			"TEX	sintan, tmp, texture[2], 2D;\n"\

			"MOV	A, AB.x;\n"\
			"MOV	B, AB.y;\n"\

			"MUL	B.x, B.x, cos_phi_diff.x;\n"\
			"MUL	B.x, B.x, sintan.x;\n"\
			"ADD	B.x, B.x, A.x;\n"\

			"MAX	LdotN.x, LdotN.x, 0;\n"\
			"MUL	LdotN.x, LdotN.x, B.x;\n"\

			"MUL	result.color, LdotN.x, 1;\n"\
			"END\n";

			osg::ref_ptr<osg::StateSet> ss = new osg::StateSet;

			osg::ref_ptr<osg::VertexProgram> vp = new osg::VertexProgram;
      vp->setVertexProgram(vp_code);
      ss->setAttributeAndModes(vp.get());

			osg::ref_ptr<osg::FragmentProgram> fp = new osg::FragmentProgram;
      fp->setFragmentProgram(fp_code);
      ss->setAttributeAndModes(fp.get());

			osg::Texture2D *texture = getSinTanTexture();
			ss->setTextureAttributeAndModes(2, texture, osg::StateAttribute::ON);

			addPass(ss.get());
		}
	};
}

OrenNayar::OrenNayar()
{
}

OrenNayar::OrenNayar(const OrenNayar &copy, const osg::CopyOp &copyop) :
Effect(copy, copyop)
{
}

bool OrenNayar::define_techniques()
{
	osgFX::Technique *tech = new DefaultTechnique();
	addTechnique(tech);
	return true;
}
