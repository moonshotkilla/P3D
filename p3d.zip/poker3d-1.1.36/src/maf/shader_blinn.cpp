/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <maf/shader_blinn.h>

#include <osg/VertexProgram>
#include <osg/FragmentProgram>
#endif


char MAFVP_BLINN[] =
"!!ARBvp1.0\n"\
"ATTRIB	pos = vertex.position;\n"\
"PARAM	mv[4] = { state.matrix.modelview };\n"\
"PARAM	mvp[4] = { state.matrix.mvp };\n"\
"PARAM	mvinv[4] = { state.matrix.modelview.invtrans };\n"\
"TEMP	tmp, vtx;\n"\
"# vertex to clip space\n"\
"DP4	result.position.x, mvp[0], vertex.position;\n"\
"DP4	result.position.y, mvp[1], vertex.position;\n"\
"DP4	result.position.z, mvp[2], vertex.position;\n"\
"DP4	result.position.w, mvp[3], vertex.position;\n"\
"# local normal to eye space\n"\
"DP3	result.texcoord[2].x, mvinv[0], vertex.normal;\n"\
"DP3	result.texcoord[2].y, mvinv[1], vertex.normal;\n"\
"DP3	result.texcoord[2].z, mvinv[2], vertex.normal;\n"\
"# vertex to eye space\n"\
"DP4	vtx.x, mv[0], vertex.position;\n"\
"DP4	vtx.y, mv[1], vertex.position;\n"\
"DP4	vtx.z, mv[2], vertex.position;\n"\
"DP4	vtx.w, mv[3], vertex.position;\n"\
"# light to vertex vector\n"\
"SUB	tmp, state.light[0].position, vtx;\n"\
"MOV	result.texcoord[3], tmp;\n"\
"# half\n"\
MAFSHADER_NORMALIZE(tmp)
MAFSHADER_NORMALIZE(vtx)
"SUB	tmp, tmp, vtx;\n"\
"MUL	result.texcoord[4], tmp, 0.5;\n"\
"# diffuse color\n"\
"MOV	result.color, state.lightprod[0].diffuse;\n"\
"# tex coords 0 & 1\n"\
"MOV	result.texcoord[0], vertex.texcoord[0];\n"\
"MOV	result.texcoord[1], vertex.texcoord[1];\n"\
"\n"\
"END\n";


char MAFFP_BLINN[] = 
"!!ARBfp1.0\n"\
"TEMP	tex1, tex2, tmp, tmp2, alf, norm;\n"\
"TXP	tex1, fragment.texcoord[0], texture[0], 2D;\n"\
"TXP	tex2, fragment.texcoord[1], texture[1], 2D;\n"\
"PARAM	glos = program.local[0];\n"\
"MOV	norm, fragment.texcoord[2];\n"\

MAFSHADER_NORMALIZE(norm)

/*
"TEX	norm, norm, texture[2], CUBE;\n"\
"MAD	norm, norm, 2, -1;\n"\
*/
"MOV	tmp, fragment.texcoord[3];\n"\

MAFSHADER_NORMALIZE(tmp)

/*
"TEX	tmp, tmp, texture[2], CUBE;\n"\
"MAD	tmp, tmp, 2, -1;\n"\
*/
"DP3	tmp.x, norm, tmp;\n"\
"MOV	alf, fragment.texcoord[4];\n"\

MAFSHADER_NORMALIZE(alf)

/*
"TEX	alf, alf, texture[2], CUBE;\n"\
"MAD	alf, alf, 2, -1;\n"\
*/
"DP3	tmp.y, norm, alf;\n"\
"MOV	tmp.w, glos;\n"\
"LIT	tmp, tmp;\n"\
"MUL	tmp2, tex1, tmp.y;\n"\
"MAD	tmp2, tex2, tmp.z, tmp2;\n"\
"MOV	tmp2.w, 1;\n"\

"MOV	result.color, tmp2;\n"\
"END\n";


MAFShaderBlinn::MAFShaderBlinn()
{
	vp_->setVertexProgram(MAFVP_BLINN);
	fp_->setFragmentProgram(MAFFP_BLINN);
	setGlossiness(10);
}

MAFShaderBlinn::~MAFShaderBlinn()
{
}

void MAFShaderBlinn::writeProgramToDisk(const char *_vertex_file, const char *_fragment_file)
{
	Parent::writeProgramToDisk(_vertex_file, _fragment_file, MAFVP_BLINN, MAFFP_BLINN);
}

void MAFShaderBlinn::configureStateSet(osg::StateSet &_ss)
{
	Parent::configureStateSet(_ss);

//	osg::TextureCubeMap *cubeMap = MAFShader::getCubeMapNormalize();
	//_ss.setTextureAttributeAndModes(2, cubeMap, osg::StateAttribute::ON);
}

void MAFShaderBlinn::setGlossiness(float _glos)
{
	fp_->setProgramLocalParameter(0, osg::Vec4f(_glos, _glos, _glos, _glos) );
}
