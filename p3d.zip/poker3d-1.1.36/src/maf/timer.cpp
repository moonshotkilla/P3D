/**
   Copyright (C) 2004 Cedric Pinson <cpinson@freesheep.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

   ****************************************************************************
   * @file   profile_timer.cpp
   *
   * @brief   Profile system
   *
   *****************************************************************************
   *
   * @author  Cedric Pinson, Based from article on Gems Game programming 3
   *	    Original authors GregHjelstrom and Byon Garrabrant
   *
   * @date    Created 2002/11
   *
   * @version $Id: timer.cpp,v 1.5 2006/06/30 15:28:00 izidor79 Exp $
   *
   ****************************************************************************/

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <maf/maferror.h>
#include <maf/timer.h>

#include <iostream>
#include <cstdio>

#endif

#include <osg/Timer>

double GetRealTime() { return osg::Timer::instance()->tick()*osg::Timer::instance()->getSecondsPerTick();}
double GetRealTimeInMS() { return osg::Timer::instance()->tick()*osg::Timer::instance()->getSecondsPerTick()*1e3;}
