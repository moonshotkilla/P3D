/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 *  Henry Precheur <henry at precheur dot org>
 *  Igor kravtchenko <igor@tsarevitch.org>
 *
 */

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <maf/maferror.h>
#include <maf/camera.h>
#include <maf/data.h>
#include <maf/wnc_desktop.h>
#include <maf/wnc_source.h>
#include <maf/scene.h>
#include <maf/split.h>
#include <maf/audio.h>

#include <sys/types.h>
#include <signal.h>
#include <errno.h>
#include <set>
#include <vector>

#include <glib.h>
#include <evalpath.h>

#include <vorbis/vorbisfile.h>

#include <cal3d/cal3d.h>

#include <osgDB/Registry>
#include <osgDB/ReadFile>
#include <osgDB/WriteFile>
#include <osgText/Font>
#include <osg/Geode>
#include <osg/Drawable>
#include <osg/MatrixTransform>
#include <osg/LightSource>
#include <osg/PositionAttitudeTransform>
#include <osg/Geometry>
#include <osg/NodeVisitor>
#include <osgText/Font>

#include <libxml/tree.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <libxml/xpathInternals.h>

#include <maf/wnc_window.h>

#include <maf/osghelper.h>

#endif

// MAFVisionData

static std::map<std::string, osg::ref_ptr<osgText::Font> > g_filename2font;
static std::map<std::string, osg::ref_ptr<osg::Image> > g_filename2image;

MAFCameraController* MAFVisionData::GetCamera(const std::string& name)
{
  if(mCameras.find(name) == mCameras.end())
    throw new MAFError(UNDERWARE_MAF_ERROR_CAMERA, "MAFVisionData::GetCamera: camera %s is not known", name.c_str());

  return mCameras[name].get();
}

MAFCameraController* MAFVisionData::getFirstCamera()
{
	if (mCameras.size() == 0)
		return NULL;
	std::map<std::string, osg::ref_ptr<MAFCameraController> >::iterator it = mCameras.begin();
	osg::ref_ptr<MAFCameraController> &cam = (*it).second;
	return cam.get();
}


// MAFVisionData

osg::ref_ptr<osg::LightSource> MAFVisionData::getLightByIndex(int _index) const
{
	return mLights[_index];
}


// MAFOSGData


#include <iostream>
#include <string>

#if 0
#include <osg/io_utils>
#endif

#include <osgDB/Registry>
#include <osgDB/Input>
#include <osgDB/Output>
#include <osgDB/ParameterOutput>

class OsgProxy : public osg::Node
{
public:

  OsgProxy(MAFVisionData* consumer, const char* className, const char* libraryName) : _consumer(consumer), _className(className), _libraryName(libraryName) {}
  OsgProxy(const OsgProxy& o, const osg::CopyOp& copyop=osg::CopyOp::SHALLOW_COPY) : osg::Node(o, copyop) {}

  virtual osg::Object* cloneType() const { return new OsgProxy(_consumer, _className, _libraryName); }
  virtual osg::Object* clone(const osg::CopyOp& copyop) const { return new OsgProxy(*this,copyop); }
  virtual bool isSameKindAs(const osg::Object* obj) const { return dynamic_cast<const OsgProxy*>(obj)!=NULL; }
  virtual const char* className() const { return _className; }
  virtual const char* libraryName() const { return _libraryName; }

  MAFVisionData* _consumer;

  const char* _className;
  const char* _libraryName;
};

#if 0
static bool readMatrix(osg::Matrix& matrix, osgDB::Input& fr)
{
    bool iteratorAdvanced = false;
    
    if (fr.matchSequence("Matrix {"))
    {

        int entry = fr[0].getNoNestedBrackets();

        fr += 2;

        int row=0;
        int col=0;
        double v;
        while (!fr.eof() && fr[0].getNoNestedBrackets()>entry)
        {
            if (fr[0].getFloat(v))
            {
                matrix(row,col)=v;
                ++col;
                if (col>=4)
                {
                    col = 0;
                    ++row;
                }
                ++fr;
            }
            else fr.advanceOverCurrentFieldOrBlock();
        }
        iteratorAdvanced = true;
    }        
        
    return iteratorAdvanced;
}
#endif

#if 0
static bool Camera_readLocalData(osg::Object &obj, osgDB::Input &fr)
{
  OsgProxy &proxy = static_cast<OsgProxy &>(obj);
  bool itAdvanced = false;

  MAFCameraController* controller = new MAFCameraController();
  proxy._consumer->mCameras[proxy.getName()] = controller;

  controller->Init();
  MAFCameraModel* camera = controller->GetModel();

  osg::Matrix matrix; 
  if (readMatrix(matrix,fr)) {
    camera->SetMatrix(matrix);
    itAdvanced = true;
  }

  if (fr[0].matchWord("ratio")) {
    float ratio;
    if (fr[1].getFloat(ratio)) {
      //          
      fr += 2;
      itAdvanced = true;
    }
  }

  if (fr[0].matchWord("lens")) {
    float lens;
    if (fr[1].getFloat(lens)) {
      //          
      fr += 2;
      itAdvanced = true;
    }
  }

  return itAdvanced;
}
#endif

MAFData* MAFOSGData::Clone(unsigned int cloneFlag)
{
  MAFOSGData* copy = new MAFOSGData;
  copy->mGroup = dynamic_cast<osg::Group*>(mGroup->clone(cloneFlag));
  g_assert(copy->mGroup != 0);
  copy->mCameras = mCameras;
  return copy;
}

bool MAFOSGData::Load(const std::string& path, osgDB::ReaderWriter::Options* options)
{
#if 0
  osgDB::DotOsgWrapper* wrapper_camera = new osgDB::DotOsgWrapper(new OsgProxy(this, "Camera", "maf"),
                                                                  "Camera",
                                                                  "Object Node Camera",
                                                                  Camera_readLocalData,
                                                                  0,
                                                                  osgDB::DotOsgWrapper::READ_ONLY);
  osgDB::Registry::instance()->addDotOsgWrapper(wrapper_camera);
#endif
  osg::Node* node = osgDB::readNodeFile(path, options);
#if 0
  osgDB::Registry::instance()->removeDotOsgWrapper(wrapper_camera);
#endif
  if(!node)
    throw new MAFError(UNDERWARE_MAF_ERROR_DATALOAD, "MAFOSGData::Load: osgDB::readNodeFile(%s) failed", path.c_str()); 

  mGroup = node->asGroup();

  if(!mGroup) {
    g_warning("MAFOSGData::Load: root node of %s is not a osg::Group", path.c_str());
    return false;
  }

  int dot = path.rfind('.');
  std::string lcfile = path;
  std::transform(lcfile.begin(), lcfile.end(), lcfile.begin(), tolower);
  std::string suffix = lcfile.substr(dot);
  return true;
}

osg::Node* MAFOSGData::GetNode(const std::string& name) {
  return ::GetNode(mGroup.get(), name);
}

void MAFOSGData::GroupAnchors(osg::Group* group, const std::vector<std::string>& names)
{
  osg::Group* parent = 0;
  std::vector<std::string>::const_iterator name;
  for(name = names.begin();
      name != names.end();
      name++) {
    MAFAnchor* anchor = GetAnchor(*name);
    if(parent == 0)
      parent = anchor->getParent(0);
    if(parent != anchor->getParent(0))
      g_error("MAFOSGData::GroupAnchors: %s ... can't group anchors with different parents", name->c_str());
    group->addChild(anchor);
    parent->removeChild(anchor);
  }

  if(!parent)
    g_critical("MAFOSGData::GroupAnchors: %s ... no anchor found", (*(names.begin()+0)).c_str());
  else
    parent->addChild(group);
}

class AnchorVisitor : public osg::NodeVisitor {
public:
  AnchorVisitor(const std::string& name) : osg::NodeVisitor(osg::NodeVisitor::TRAVERSE_ALL_CHILDREN), mAnchor(0), mName(name) {
    setNodeMaskOverride(MAF_VISIBLE_MASK | MAF_COLLISION_MASK);
  }

  virtual void apply(osg::Transform& node) {
		const std::string node_name = node.getName();
    if(node_name.find(mName) != std::string::npos) {
      mAnchor = dynamic_cast<MAFAnchor*>(&node);
      if(node.getName() != mName)
	g_critical("anchor searched %s but found anchor %s (AMBIGUOUS MUST BE FIXED)", mName.c_str(), node.getName().c_str());
    } else
      traverse(node);
  }

  MAFAnchor* mAnchor;
  const std::string& mName;
};

MAFAnchor* MAFOSGData::GetAnchor(const std::string& name)
{
  AnchorVisitor visitor(name);
  mGroup->accept(visitor);
  if(visitor.mAnchor == 0)
    throw new MAFError(UNDERWARE_MAF_ERROR_ANCHOR, "MAFOSGData::GetAnchor: %s not found", name.c_str()); 
  return visitor.mAnchor;
}

osg::BoundingBox MAFOSGData::GetBound()
{
  g_assert(mGroup.valid());

  osg::Geode* geode = GetGeode(mGroup.get());
  g_assert(geode != 0);

  return geode->getBoundingBox();

  /*
  osg::BoundingBox bb;
  unsigned int num_drawables = geode->getNumDrawables();
  for(unsigned int i = 0; i < num_drawables; i++) {
    osg::Drawable* drawable = geode->getDrawable(i);
    osg::BoundingBox f = drawable->getBound();
    bb.expandBy(drawable->getBound());
  }
  return bb;
  */
}

void MAFOSGData::SetDescription(const std::string& name)
{
  g_assert(mGroup.valid());

  mGroup->addDescription(name);
}


// MAFAudioData

MAFAudioData::~MAFAudioData()
{
}

bool MAFAudioData::Reload()
{
	return LoadAudio(mPath,0);
}

void MAFAudioData::Error(const openalpp::Error& error)
{
  std::ostringstream str;
#ifndef WIN32 // help me. It does not compile with it on windows
  error.put(str);
#else
  str.str("can't find error");
#endif
  g_critical("MAFAudioData::Error: %s", str.str().c_str());
  ALenum alerror = alGetError();
  if(alerror != AL_NO_ERROR)
    g_critical("MAFAudioData::Error: alGetError() = %s", alGetString(alerror));
}

bool MAFAudioDataWAV::LoadAudio(const std::string& path, osgDB::ReaderWriter::Options* options) {
  try {
		if (MAFAudioDevice::GetInstance()->IsSoundDeviceValid())
			mSoundData = new openalpp::Sample(path.c_str());
  } catch(openalpp::Error error) {
		Error(error);
  }
  return true;
}


#if 1
#define BUFFER_OGG 32768

bool MAFAudioDataOGG::LoadAudio(const std::string& path, osgDB::ReaderWriter::Options* options) {
	if (!MAFAudioDevice::GetInstance()->IsSoundDeviceValid())
		return true;
  int endian = 0;                         // 0 for Little-Endian, 1 for Big-Endian
  int bitStream;
  long bytes;
  char array[BUFFER_OGG];                // Local fixed size array
  std::vector<char> buffer;
  ALsizei  freq;
  ALenum   format;

  FILE *file = fopen(path.c_str(), "rb");

  if(file == NULL) {
    g_debug("Cannot open %s for reading", (char*)path.c_str());
    return false;
  }

  vorbis_info *pInfo;
  OggVorbis_File oggFile;

  if(ov_open(file, &oggFile, NULL, 0) != 0) {
    g_debug("ov_open failed for %s", (char*)path.c_str());
    fclose(file);
    return false;
  }

  pInfo = ov_info(&oggFile, -1);

  if (pInfo->channels == 1)
    format = AL_FORMAT_MONO16;
  else
    format = AL_FORMAT_STEREO16;

  freq = pInfo->rate;

  do {
    bytes = ov_read(&oggFile, array, BUFFER_OGG, endian, 2, 1, &bitStream);

    if (bytes < 0) {
      ov_clear(&oggFile);
      g_debug("read failed for %s", (char*)path.c_str());
      fclose(file);
      return false;
    }
    buffer.insert(buffer.end(), array, array + bytes);
  } while(bytes > 0);

  ov_clear(&oggFile);

  void* vb=&buffer.front();
  int sz=buffer.size();

  try {
	mSoundData = new openalpp::Sample(format,vb,sz,freq);
  } catch (...) {
	g_debug("Can't play ogg no sound");
  }

  return true;
}
#else

bool MAFAudioDataOGG::LoadAudio(const std::string& path, osgDB::ReaderWriter::Options* options) {
  try {
    mSoundData = new openalpp::FileStream(path.c_str());
  } catch(openalpp::Error error) {
    Error(error);
  }
  return true;
}
#endif

// MAFXmlData

MAFXmlData::MAFXmlData() : mDocument(NULL) {
}

MAFXmlData::~MAFXmlData() {
  if (mDocument != NULL)
    xmlFreeDoc(mDocument);
}

bool MAFXmlData::Load(const std::string &path, osgDB::ReaderWriter::Options* options) {
  mDocument = xmlParseFile(path.c_str());
  if (!mDocument)
	  return false;
  return true;
}


std::string MAFXmlData::Get(const std::string& path)
{
  const std::list<std::string> &result = GetList(path);
  return result.size() > 0 ? result.front() : "";
}

std::list<std::string> MAFXmlData::GetList(const std::string& path)
{
  
  std::list<std::string> result;

  
  xmlDocPtr header = mDocument;
  /* Create xpath evaluation context */
  xmlXPathContextPtr xpathCtx = xmlXPathNewContext(header);
  if(xpathCtx == NULL)
    g_error("MAFXmlData::GetList: unable to create new XPath context");

  /* Evaluate xpath expression */
  xmlXPathObjectPtr xpathObj = xmlXPathEvalExpression((xmlChar*)path.c_str(), xpathCtx);
  if(xpathObj == NULL) {
    g_error("Error: unable to evaluate xpath expression %s", path.c_str());
    xmlXPathFreeContext(xpathCtx); 
    throw this;
  }
  
  xmlNodeSetPtr nodes = xpathObj->nodesetval;
  if(nodes && nodes->nodeNr >= 1) {
    for(int i = 0; i < nodes->nodeNr; i++) {
      xmlNodePtr node = nodes->nodeTab[i];
      switch(node->type) {
      case XML_ELEMENT_NODE:
      case XML_ATTRIBUTE_NODE:
	{
	  const char* content = (const char*)xmlNodeGetContent(node);
	  result.push_back(content);
	  xmlFree((void*)content);
	}
	break;
      default:
	break;
      }
    }
  }
  
  xmlXPathFreeObject(xpathObj);
  xmlXPathFreeContext(xpathCtx); 
  return result;
}

MAFCursorData::MAFCursorData() : mCursor(NULL)
{
}

MAFCursorData::~MAFCursorData()
{
  SDL_FreeCursor(mCursor);
}

bool MAFCursorData::Load(const std::string &path, osgDB::ReaderWriter::Options* options)
{
  FILE *f = fopen(path.c_str(), "rb");
  if (!f)
	  return false;
  int result = fread(mData, sizeof(char), CURSOR_SIZE, f);
  assert(result == CURSOR_SIZE);
  fclose(f);
  return true;
}

SDL_Cursor *MAFCursorData::GetCursor()
{
  return mCursor;
}

SDL_Cursor *MAFCursorData::CreateCursor()
{
  mCursor = SDL_CreateCursor(mData, mData+CURSOR_SIZE/2, CURSOR_W, CURSOR_H, 0, 0);
  return mCursor;
}

SDL_Cursor *MAFCursorData::GetOrCreateCursor()
{
  if (mCursor == NULL)
    CreateCursor();
  return mCursor;
}

std::string EvalPath(const std::string& path)
{
  if (path.empty())
    g_error("EvalPath: path is empty");

  GError* error = NULL;
  gchar* result = evalpath(path.c_str(), &error);
  if(!result)
    throw new MAFError(error);
  std::string result_string = result;
  return result_string;
}

// MAFRepositoryData

MAFRepositoryData::~MAFRepositoryData() {
  for(std::map<std::string, MAFVisionData*>::iterator i = mVisionMap.begin();
      i != mVisionMap.end();
      i++)
    delete i->second;

  for(std::map<std::string, MAFAudioData*>::iterator j = mAudioMap.begin();
      j != mAudioMap.end();
      j++)
    delete j->second;
  for(std::map<std::string, MAFXmlData*>::iterator j = mXmlMap.begin();
      j != mXmlMap.end();
      j++)
    delete j->second;
  for(std::map<std::string, MAFCursorData*>::iterator j = mCursorMap.begin();
      j != mCursorMap.end();
      j++)
    delete j->second;
  for(std::map<std::string, MAFRepositoryData*>::iterator j = mRepositoryMap.begin();
      j != mRepositoryMap.end();
      j++)
    delete j->second;
  if(mDesktop) delete mDesktop;
}

std::string MAFRepositoryData::mLevel="";
std::string MAFRepositoryData::mDirectoryBase="";

std::string MAFRepositoryData::GetItem(const std::string& item) 
{
  std::string path;
  if (!mDirectoryBase.empty())
    path=mDirectoryBase+G_DIR_SEPARATOR_S;

  if (!mLevel.empty())
    path=path+mLevel+G_DIR_SEPARATOR_S;
  
  return EvalPath(path+item);
}

bool MAFRepositoryData::LoadItem(const std::string &item, MAFMonitor *_mon)
{
	osg::ref_ptr<osgDB::ReaderWriter::Options> options = new osgDB::ReaderWriter::Options;
	options->setObjectCacheHint(osgDB::ReaderWriter::Options::CACHE_NONE);
	std::string dir = g_dirname(item.c_str());
	std::string file = g_basename(item.c_str());
	int dot = file.rfind('.');
	if(dot >= 0) {
		std::string lcfile = file;
		std::transform(lcfile.begin(), lcfile.end(), lcfile.begin(), tolower);
		std::string suffix = lcfile.substr(dot);
		std::string path = item;
		if(suffix == ".wav") {
			MAFAudioDataWAV* data = new MAFAudioDataWAV;
			if(data->Load(path, options.get()))
				mAudioMap[item] = data;
			else
				delete data;
		} else if(suffix == ".ogg") {
			MAFAudioDataOGG* data = new MAFAudioDataOGG;
			if(data->Load(path, options.get()))
				mAudioMap[item] = data;
			else
				delete data;
		} else if(suffix == ".osg") {
			MAFOSGData* data = new MAFOSGData;
			if(data->Load(path, options.get()))
				mVisionMap[item] = data;
			else
				delete data;
		} else if(suffix == ".escn") {
			MAFESCNData * data = new MAFESCNData();
			if(data->Load(path, dir, file, options.get(), _mon))
				mVisionMap[item] = data;
			else
				delete data;
			data->setupRootStateSet( data->GetGroup()->getOrCreateStateSet() );
		} else if (suffix == ".xml" || suffix == ".xfg") {
			MAFXmlData* data = new MAFXmlData;
			if(data->Load(path, options.get()))
				mXmlMap[item] = data;
			else
				delete data;
		}	else if(suffix ==  ".cursor") {
			MAFCursorData *data = new MAFCursorData();
			if(data->Load(path, options.get()))
				mCursorMap[item] = data;
			else
				delete data;
		} else if(suffix != ".jpg" && suffix != ".tga") {
			return false;
		}
	}
	return true;
}

MAFVisionData* MAFRepositoryData::GetVision(const std::string& name, MAFMonitor *_mon)
{
  std::string newname = GetItem(name);
  if (newname.empty())
    throw new MAFError(UNDERWARE_MAF_ERROR_DATALOAD, "MAFVisionData::GetVision: no %s", name.c_str());

  if(mVisionMap.find(newname) == mVisionMap.end())
    if (!LoadItem(newname, _mon))
      throw new MAFError(UNDERWARE_MAF_ERROR_DATALOAD, "MAFVisionData::GetVision: no %s", name.c_str());

  return mVisionMap[newname];
}

MAFAudioData* MAFRepositoryData::GetAudio(const std::string& name, MAFMonitor *_mon) 
{
  std::string newname=GetItem(name);
  if (newname.empty())
    throw new MAFError(UNDERWARE_MAF_ERROR_DATALOAD, "MAFAudioData::GetAudio: no %s", name.c_str());

  if(mAudioMap.find(newname) == mAudioMap.end())
    if (!LoadItem(newname, _mon))
      throw new MAFError(UNDERWARE_MAF_ERROR_DATALOAD, "MAFAudioData::GetAudio: no %s", name.c_str());

  return mAudioMap[newname];
}

MAFXmlData* MAFRepositoryData::GetXml(const std::string &name) 
{
  std::string newname=GetItem(name);
  if (newname.empty())
    throw new MAFError(UNDERWARE_MAF_ERROR_DATALOAD, "MAFXmlData::GetXml: no %s", name.c_str());
    
  if(mXmlMap.find(newname) == mXmlMap.end())
    if (!LoadItem(newname))
      throw new MAFError(UNDERWARE_MAF_ERROR_DATALOAD, "MAFXmlData::GetXml: no %s", name.c_str());
      
  return mXmlMap[newname];
}

MAFCursorData* MAFRepositoryData::GetCursor(const std::string &name) 
{
  std::string newname=GetItem(name);
  if (newname.empty())
    throw new MAFError(UNDERWARE_MAF_ERROR_DATALOAD, "MAFCursorData::GetCursor: no %s", name.c_str());
    
  if(mCursorMap.find(newname) == mCursorMap.end())
    if (!LoadItem(newname))
      throw new MAFError(UNDERWARE_MAF_ERROR_DATALOAD, "MAFCursorData::GetCursor: no %s", name.c_str());
      
  return mCursorMap[newname];
}

void MAFRepositoryData::ReloadAudio()
{
	for (std::map<std::string,MAFAudioData*>::iterator it = mAudioMap.begin(); it != mAudioMap.end(); it++)
		if (!it->second->Reload())
			g_critical("MAFRepositoryData::ReloadAudio can't reload audio %s",it->first.c_str());
}


void MAFRepositoryData::XwncConnect(const std::string& url) {
  g_debug("MAFRepositoryData::XwncConnect");
  mDesktop = new XwncDesktop((char*)url.c_str(), "foldable");
}

osgText::Font* MAFLoadFont(const std::string &_filename)
{
	osgText::Font *font;
	if (g_filename2font.find(_filename) == g_filename2font.end()) {
		font = dynamic_cast<osgText::Font*> (osgDB::readObjectFile(_filename));
		if (!font)
			g_critical("unable to load font %s", _filename.c_str());
		g_filename2font[_filename] = font;
	}
  return g_filename2font[_filename].get(); // null font is the default font
}

osg::Image* MAFLoadImage(const std::string &_filename)
{
  osg::Image*	img;

	if (g_filename2image.find(_filename) == g_filename2image.end()) {
		img = osgDB::readImageFile(_filename);
		if (!img)
			g_critical("unable to load image file %s", _filename.c_str());
		g_filename2image[_filename] = img;
	}
  return g_filename2image[_filename].get();
}

