/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH

#include <libxml/tree.h>
#include <libxml/xpath.h>
#include <libxml/xpathInternals.h>

#include <osg/StateSet>

#include <maf/renderbin.h>
#endif

MAFRenderBin *g_renderbin = NULL;

MAFRenderBin& MAFRenderBin::Instance()
{
	if (!g_renderbin)
		g_renderbin = new MAFRenderBin();
	return *g_renderbin;
}

void MAFRenderBin::Read(struct _xmlDoc *_doc, const std::string &_xpath)
{
  xmlXPathContextPtr context = xmlXPathNewContext(_doc);
  xmlXPathObjectPtr object = xmlXPathEvalExpression( (xmlChar*)_xpath.c_str(), context);
  xmlNodeSetPtr nodes = object->nodesetval;

	for (int i = 0; i < nodes->nodeNr; i++) {
		xmlNodePtr node = nodes->nodeTab[i];

		xmlNodePtr parent = node->parent;
		std::string rbin_name;
		int rbin_index;
		xmlAttr *attribute;

		for(attribute = parent->properties; attribute; attribute = attribute->next) {
			const char *value = (const char*) xmlNodeGetContent((xmlNode*)attribute);
			const char *name = (const char*)attribute->name;
			if (!strcmp(name, "index"))
				rbin_index = atoi(value);
			else if (!strcmp(name, "name"))
				rbin_name = value;
		}

		std::pair<int, std::string> rbin;
		rbin.first = rbin_index;
		rbin.second = rbin_name;

		for(attribute = node->properties; attribute; attribute = attribute->next) {
			const char *value = (const char*) xmlNodeGetContent((xmlNode*)attribute);
                        //			const char *name = (const char*)attribute->name;

			mName2rbin[value] = rbin;
		}
	}

  xmlXPathFreeContext(context); 
}

bool MAFRenderBin::SetupRenderBin(const std::string &_entityName, osg::StateSet *_ss) const
{
	if (mName2rbin.find(_entityName) == mName2rbin.end())
		return false;

	const std::pair<int, std::string> &rbin = mName2rbin.find(_entityName)->second;
	int rbin_index = rbin.first;
	const std::string &rbin_name = rbin.second;
	_ss->setRenderBinDetails(rbin_index, rbin_name);
	return true;
}

bool MAFRenderBin::GetRenderBinIndexOfEntity(const std::string &_entityName, int &_rbinIndex) const
{
	if (mName2rbin.find(_entityName) == mName2rbin.end())
		return false;

	_rbinIndex = mName2rbin.find(_entityName)->second.first;
	return true;
}

bool MAFRenderBin::GetRenderBinNameOfEntity(const std::string &_entityName, std::string &_rbinName) const
{
	if (mName2rbin.find(_entityName) == mName2rbin.end())
		return false;

	_rbinName = mName2rbin.find(_entityName)->second.first;
	return true;
}
