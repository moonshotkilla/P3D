/*
*
* Copyright (C) 2005, 2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <maf/textwriter.h>
#include <osgDB/ReadFile>
#include <maf/utils.h>
#include <maf/assert.h>
#include <maf/renderbin.h>
#include <varseditor/varseditor.h>
#endif

MAFTextWriter::MAFTextWriter(const std::string &_basePath, const std::vector<FontElement> &_elements)
{
	int size = _elements.size();
	for (int i = 0; i < size; i++) {
		char code = _elements[i].code;

		std::string fname;
		if (_elements[i].filename)
			fname = _basePath + _elements[i].filename;
		else
			fname = _basePath + code + ".tga";
		osg::Image *img = osgDB::readImageFile(fname, NULL);

		int img_w = img->s();
		int img_h = img->t();

		int simg_w = MAFGetNearestHighPow2(img_w);
		int simg_h = MAFGetNearestHighPow2(img_h);

		osg::Image *simg = new osg::Image();
		simg->allocateImage(simg_w, simg_h, 1, img->getPixelFormat(), GL_UNSIGNED_BYTE);

		if (img->getPixelFormat() == GL_RGBA) {
			unsigned char *pixs = simg->data();
			for (int j = 0; j < simg_w*simg_h; j++) {
				pixs[3] = 0;
				pixs += 4;
			}
		}
		simg->copySubImage(0, 0, 0, img);

		osg::Texture2D *tex = new osg::Texture2D();
		tex->setImage(simg);
		tex->setUnRefImageDataAfterApply(true);

//		tex->setFilter(osg::Texture2D::MIN_FILTER, osg::Texture2D::NEAREST);
	//	tex->setFilter(osg::Texture2D::MAG_FILTER, osg::Texture2D::NEAREST);

		charToGlyph_[code].texture = tex;
		charToGlyph_[code].uvmin = osg::Vec2f(0, 0);
		charToGlyph_[code].uvmax = osg::Vec2f( float(img_w) / simg_w, float(img_h) / simg_h);

		charToGlyph_[code].width = img_w;
		charToGlyph_[code].height = img_h;
	}

	textHAlign_ = TEXT_HALIGN_CENTER;
	textVAlign_ = TEXT_VALIGN_CENTER;
}

MAFTextWriter::~MAFTextWriter()
{
}

void MAFTextWriter::setText(const std::string &_txt)
{
	removeChild(0, getNumChildren());

	int nbChars = _txt.size();

	float startx = 0;
	if (textHAlign_ == TEXT_HALIGN_CENTER)
		startx = -getTextWidth(_txt) / 2;
	else if (textHAlign_ == TEXT_HALIGN_RIGHT)
		startx = -getTextWidth(_txt);

	MAF_OSGQuadParams param;
	param.bInvertUV = false;
	param.bDisableWriteMask = false;

	for (int i = 0; i < nbChars; i++) {
		char c = _txt[i];

		if (charToGlyph_.find(c) == charToGlyph_.end())
			continue;

		float w = charToGlyph_[c].width;
		float h = charToGlyph_[c].height;
		osg::Texture2D *tex = charToGlyph_[c].texture.get();

		float starty = 0;
		if (textVAlign_ == TEXT_VALIGN_CENTER)
			starty = -h / 2;
		else if (textVAlign_ == TEXT_VALIGN_TOP)
			starty = -h;

		param.minUV = charToGlyph_[c].uvmin;
		param.maxUV = charToGlyph_[c].uvmax;
		param.minPt = osg::Vec2f(startx, starty);
		param.maxPt = osg::Vec2f(startx+w, starty + h);
		param.z = 0.4f;
		MAF_OSGQuad *quad = new MAF_OSGQuad(param);
		quad->setTexture(tex);
		quad->getGeometry()->getOrCreateStateSet()->setTextureAttributeAndModes(0, tex);

//		if (!MAFRenderBin::Instance().SetupRenderBin("MAFTextWriter", quad->getGeometry()->getOrCreateStateSet()))
	//		MAF_ASSERT(0 && "MAFTextWriter not found in client.xml");

		//quad->getGeometry()->getOrCreateStateSet()->setRenderBinDetails(rbtextwriter, "DepthSortedBin");

		addChild( quad->getGeode() );

		startx += w;
	}
}

float MAFTextWriter::getTextWidth(const std::string &_txt) const
{
	int size = _txt.size();
	float w = 0;
	for (int i = 0; i < size; i++) {
		char c = _txt[i];
		std::map<char, Glyph>::const_iterator it = charToGlyph_.find(c);
		if (it != charToGlyph_.end())
			w += (*it).second.width;
	}
	return w;
}

int MAFTextWriter::getNbCharacters() const
{
	return getNumChildren();
}

std::vector<osg::Geode*> MAFTextWriter::getCharacters() const
{
	std::vector<osg::Geode*> vec;
	int nb = getNumChildren();
	for (int i = 0; i < nb; i++) {
		osg::Geode* geode = (osg::Geode*) getChild(i);
		vec.push_back(geode);
	}

	return vec;
}
