/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#ifndef WIN32
#define GL_GLEXT_PROTOTYPES
#endif

#include <osg/GLExtensions>
#include <osg/Stencil>
#include <osg/TexEnvCombine>

#include <maf/pbuffer.h>
#include <maf/glow_fx.h>
#endif

static GLuint g_glowTexture = 0;
static int g_glowTextureSize = 0;

static GLuint g_backBufferToTexture[8*8];
static int g_backBufferToTextureSize = 0;
static int g_nbTexPortions = 0;

static int g_backBufferWidth = 0;
static int g_backBufferHeight = 0;

static osg::ref_ptr<MAFPBuffer> g_pbuffer = NULL;

static float g_matrixCoef[15];

static float g_glowTextureOpacity = 1.0f;

class TextureBlock {
public:
	float x0, y0;
	float x1, y1;
	float u1, v1;
};

static TextureBlock g_textureBlocks[8*8];

#ifdef WIN32
typedef void (APIENTRY * ActiveTextureProc) (GLenum texture);
static ActiveTextureProc glActiveTexture;
#endif // WIN32

void MAFGlowFX::init(int _glowTextureSize, bool _bUsePBuffer, MAFPBuffer *_pbuffer, int _pbufferSize)
{
	int i;

	// codeguard against init more than once
	if (g_glowTextureSize != 0)
		return;

	g_glowTextureSize = _glowTextureSize;

	glGetIntegerv(GL_MAX_TEXTURE_SIZE, &g_backBufferToTextureSize);
	//g_backBufferToTextureSize = 256;
	if (g_backBufferToTextureSize > 2048)
		g_backBufferToTextureSize = 2048;

	for (i = 0; i < 8*8; i++)
		g_backBufferToTexture[i] = 0;

	int nbToGen = 1;
	if (g_backBufferToTextureSize == 1024)
		nbToGen = 2*2;
	else if (g_backBufferToTextureSize == 512)
		nbToGen = 4*4;
	else if (g_backBufferToTextureSize == 256)
		nbToGen = 8*8;

	for (i = 0; i < nbToGen; i++)  {
		glGenTextures(1, &g_backBufferToTexture[i]);
		glBindTexture(GL_TEXTURE_2D, g_backBufferToTexture[i]);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, g_backBufferToTextureSize, g_backBufferToTextureSize, 0, GL_RGB, GL_UNSIGNED_BYTE, NULL);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	}

	glGenTextures(1, &g_glowTexture);
	glBindTexture(GL_TEXTURE_2D, g_glowTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, g_glowTextureSize, g_glowTextureSize, 0, GL_RGB, GL_UNSIGNED_BYTE, NULL);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);

	if (_bUsePBuffer) {
		if (_pbuffer) {
			g_pbuffer = _pbuffer;
		}
		else {
			g_pbuffer = new MAFPBuffer(_pbufferSize, _pbufferSize);
			if (g_pbuffer->_create() == false) {
				g_pbuffer = NULL;
			}
		}
	}

#ifdef WIN32
	glActiveTexture = (ActiveTextureProc) osg::getGLExtensionFuncPtr("glActiveTexture", "glActiveTextureARB");
#endif // WIN32

	// calcul one default matrix
	calculMatrixConvolution(3.0f);
}

void MAFGlowFX::uninit()
{
	int i;

	if (g_glowTexture) {
		glDeleteTextures(1, &g_glowTexture);
		g_glowTexture = 0;
	}

	for (i = 0; i < 8*8; i++) {
		if (g_backBufferToTexture[i]) {
			glDeleteTextures(1, &g_backBufferToTexture[i]);
			g_backBufferToTexture[i] = 0;
		}
	}

	g_pbuffer = NULL;
	g_glowTextureSize = 0;
	g_backBufferToTextureSize = 0;
}

void MAFGlowFX::markNodeAsGlowing(osg::Node *_node, bool _bDefineRBin, int _rbin)
{
	osg::StateSet *state = _node->getOrCreateStateSet();

	// mark glowing object in the backbuffer with 7th bit set to 1
    osg::Stencil *stencil = new osg::Stencil;
    stencil->setFunction(osg::Stencil::ALWAYS, 0x80, 0xffffffff);
    stencil->setOperation(osg::Stencil::KEEP, osg::Stencil::KEEP, osg::Stencil::REPLACE);
	//stencil->setWriteMask(0x80);
    state->setAttributeAndModes(stencil);

	if (_bDefineRBin)
		state->setRenderBinDetails(_rbin, "RenderBin");
}

void MAFGlowFX::captureBackBufferToGlowTexture(int _backBufferWidth, int _backBufferHeight)
{
	glPushAttrib(GL_STENCIL_BUFFER_BIT);

	g_backBufferWidth = _backBufferWidth;
	g_backBufferHeight = _backBufferHeight;

	glColorMask(false, false, false, true);

	glDisable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);

	glEnable(GL_STENCIL_TEST);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glMatrixMode(GL_PROJECTION);
	glOrtho(-1, 1, -1, 1, -1, 1);

	glViewport(0, 0, g_backBufferWidth, g_backBufferHeight);

	glStencilFunc(GL_NOTEQUAL, 0x80, 0x80);
	glStencilMask(0x80);
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);

	glBegin(GL_QUADS);

	glColor4f(0.0f, 0.0f, 0.0f, 0.0f);
	glVertex3f(-1.0f, 1.0f, 0.0f);

	glColor4f(0.0f, 0.0f, 0.0f, 0.0f);
	glVertex3f(1.0f, 1.0f, 0.0f);

	glColor4f(0.0f, 0.0f, 0.0f, 0.0f);
	glVertex3f(1.0f, -1.0f, 0.0f);

	glColor4f(0.0f, 0.0f, 0.0f, 0.0f);
	glVertex3f(-1.0f, -1.0f, 0.0f);

	glEnd();

	int iTex = 0;
	int bb_x0 = 0;
	int bb_y0 = 0;
	int sx, sy;

	//float stepx = float(g_glowTextureSize) / g_backBufferWidth * 2;
	//float stepy = float(g_glowTextureSize) / g_backBufferHeight * 2;

	while(1) {

		glBindTexture(GL_TEXTURE_2D, g_backBufferToTexture[iTex]);

		g_textureBlocks[iTex].x0 = float(bb_x0) / g_backBufferWidth;
		g_textureBlocks[iTex].y1 = float(bb_y0) / g_backBufferHeight;

		if (bb_x0 + g_backBufferToTextureSize <= g_backBufferWidth) {
			sx = g_backBufferToTextureSize;
			g_textureBlocks[iTex].u1 = 1;
		}
		else {
			sx = g_backBufferWidth - bb_x0;
			g_textureBlocks[iTex].u1 = float(g_backBufferWidth - bb_x0) / g_backBufferToTextureSize;
		}

		if (bb_y0 + g_backBufferToTextureSize <= g_backBufferHeight) {
			sy = g_backBufferToTextureSize;
			g_textureBlocks[iTex].v1 = 1;
		}
		else {
			sy = g_backBufferHeight - bb_y0;
			g_textureBlocks[iTex].v1 = float(g_backBufferHeight - bb_y0) / g_backBufferToTextureSize;
		}

//		int t1 = timeGetTime();
		glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, bb_x0, bb_y0, sx, sy);
	//	int t2 = timeGetTime();

//		char str[200];
	//	sprintf(str, "%ld\n", t2-t1);
		//OutputDebugString(str);

		g_textureBlocks[iTex].x1 = float(bb_x0 + sx) / g_backBufferWidth;
		g_textureBlocks[iTex].y0 = float(bb_y0 + sy) / g_backBufferHeight;

		bb_x0 += sx;

		if (bb_x0 == g_backBufferWidth) {
			bb_x0 = 0;
			bb_y0 += sy;
		}

		iTex++;

		if (bb_y0 == g_backBufferHeight)
			break;
	}

	g_nbTexPortions = iTex;

	glPopAttrib();
}

void MAFGlowFX::workOnGlowTexture()
{
	int i;

	int vp_w = g_backBufferWidth;
	int vp_h = g_backBufferHeight;

	if (g_pbuffer.valid()) {
		g_pbuffer->use();

		vp_w = g_pbuffer->getWidth();
		vp_h = g_pbuffer->getHeight();
	}
	else {
		glPushAttrib(GL_COLOR_BUFFER_BIT);
		glPushAttrib(GL_ENABLE_BIT);
	}

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glMatrixMode(GL_PROJECTION);
	glOrtho(-1, 1, -1, 1, -1, 1);

	glViewport(0, 0, vp_w, vp_h);

	glColorMask(true, true, true, true);
	glDisable(GL_STENCIL_TEST);
	glDisable(GL_ALPHA_TEST);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	glActiveTexture( GL_TEXTURE0+1 );
	glDisable(GL_TEXTURE_2D);
	glActiveTexture( GL_TEXTURE0 );
	glEnable(GL_TEXTURE_2D);

	glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ZERO);

	//int iTex = 0;
	//int bb_x0 = 0;
	//int bb_y0 = 0;

	float umax, vmax, xmax, ymax;

	float vx0, vy0;
	float vx1, vy1;

	for (i = 0; i < g_nbTexPortions; i++) {

		glBindTexture(GL_TEXTURE_2D, g_backBufferToTexture[i]);

		umax = g_textureBlocks[i].u1;
		vmax = g_textureBlocks[i].v1;
		vx0 = g_textureBlocks[i].x0;
		vy0 = g_textureBlocks[i].y0;
		vx1 = g_textureBlocks[i].x1;
		vy1 = g_textureBlocks[i].y1;

		vx0 = -1 + vx0 * float(g_glowTextureSize) / vp_w * 2;
		vy0 = -1 + vy0 * float(g_glowTextureSize) / vp_h * 2;
		vx1 = -1 + vx1 * float(g_glowTextureSize) / vp_w * 2;
		vy1 = -1 + vy1 * float(g_glowTextureSize) / vp_h * 2;

		glBegin(GL_QUADS);

		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
		glTexCoord2f(0.0f, vmax);
		glVertex3f(vx0, vy0, 0.0f);

		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
		glTexCoord2f(umax, vmax);
		glVertex3f(vx1, vy0, 0.0f);

		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
		glTexCoord2f(umax, 0.0f);
		glVertex3f(vx1, vy1, 0.0f);

		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(vx0, vy1, 0.0f);

		glEnd();
	}

	glBindTexture(GL_TEXTURE_2D, g_glowTexture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, g_glowTextureSize, g_glowTextureSize);

	umax = 1;
	vmax = 1;
	xmax = -1 + float(g_glowTextureSize) / vp_w * 2;
	ymax = -1 + float(g_glowTextureSize) / vp_h * 2;

	float step_u = 1.0f / g_glowTextureSize;
	float u_off = -step_u * 7;

	for (i = 0; i < 15; i++) {

		if (i == 0)
			glBlendFunc(GL_SRC_ALPHA, GL_ZERO);
		else
			glBlendFunc(GL_SRC_ALPHA, GL_ONE);

		float alpha = g_matrixCoef[i];

		glBegin(GL_QUADS);

		glColor4f(1.0f, 1.0f, 1.0f, alpha);
		glTexCoord2f(0.0f + u_off, vmax);
		glVertex3f(-1.0f, ymax, 0.0f);

		glColor4f(1.0f, 1.0f, 1.0f, alpha);
		glTexCoord2f(umax + u_off, vmax);
		glVertex3f(xmax, ymax, 0.0f);

		glColor4f(1.0f, 1.0f, 1.0f, alpha);
		glTexCoord2f(umax + u_off, 0.0f);
		glVertex3f(xmax, -1.0f, 0.0f);

		glColor4f(1.0f, 1.0f, 1.0f, alpha);
		glTexCoord2f(0.0f + u_off, 0.0f);
		glVertex3f(-1.0f, -1.0f, 0.0f);

		glEnd();

		u_off += step_u;
	}
	glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, g_glowTextureSize, g_glowTextureSize);

	float step_v = 1.0f / g_glowTextureSize;
	float v_off = -step_v * 7;

	for (i = 0; i < 15; i++) {

		if (i == 0)
			glBlendFunc(GL_SRC_ALPHA, GL_ZERO);
		else
			glBlendFunc(GL_SRC_ALPHA, GL_ONE);

		float alpha = g_matrixCoef[i];

		glBegin(GL_QUADS);

		glColor4f(1.0f, 1.0f, 1.0f, alpha);
		glTexCoord2f(0.0f, vmax + v_off);
		glVertex3f(-1.0f, ymax, 0.0f);

		glColor4f(1.0f, 1.0f, 1.0f, alpha);
		glTexCoord2f(umax, vmax + v_off);
		glVertex3f(xmax, ymax, 0.0f);

		glColor4f(1.0f, 1.0f, 1.0f, alpha);
		glTexCoord2f(umax, 0.0f + v_off);
		glVertex3f(xmax, -1.0f, 0.0f);

		glColor4f(1.0f, 1.0f, 1.0f, alpha);
		glTexCoord2f(0.0f, 0.0f + v_off);
		glVertex3f(-1.0f, -1.0f, 0.0f);

		glEnd();

		v_off += step_v;
	}
	glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, g_glowTextureSize, g_glowTextureSize);

	/*
	char *pixs = new char[_vp_w * _vp_h];
	glReadPixels(0, 0, _vp_w, _vp_h, GL_ALPHA, GL_UNSIGNED_BYTE, pixs);

	FILE *handle = fopen("c:/alpha_mask.raw", "wb");
	fwrite(pixs, 1, _vp_w * _vp_h, handle);
	fclose(handle);
	delete [] pixs;
	*/

	if (g_pbuffer.valid())
		g_pbuffer->release();
	else {
		glPopAttrib();
		glPopAttrib();
	}
}

void MAFGlowFX::drawGlowTexture()
{
	glPushAttrib(GL_COLOR_BUFFER_BIT);
	glPushAttrib(GL_ENABLE_BIT);

	int vp_w = g_backBufferWidth;
	int vp_h = g_backBufferHeight;

	glActiveTexture( GL_TEXTURE0+1 );
	glDisable(GL_TEXTURE_2D);
	glActiveTexture( GL_TEXTURE0 );
	glEnable(GL_TEXTURE_2D);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glMatrixMode(GL_PROJECTION);
	glOrtho(-1, 1, -1, 1, -1, 1);

	glViewport(0, 0, vp_w, vp_h);

	glBindTexture(GL_TEXTURE_2D, g_glowTexture);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColorMask(true, true, true, true);
	glDisable(GL_STENCIL_TEST);
	glDisable(GL_ALPHA_TEST);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);

	glBegin(GL_QUADS);

	glColor4f(1.0f, 1.0f, 1.0f, g_glowTextureOpacity);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-1.0f, 1.0f, 0.0f);

	glColor4f(1.0f, 1.0f, 1.0f, g_glowTextureOpacity);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(1.0f, 1.0f, 0.0f);

	glColor4f(1.0f, 1.0f, 1.0f, g_glowTextureOpacity);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(1.0f, -1.0f, 0.0f);

	glColor4f(1.0f, 1.0f, 1.0f, g_glowTextureOpacity);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-1.0f, -1.0f, 0.0f);

	glEnd();

	glPopAttrib();
	glPopAttrib();
}

float MAFGlowFX::getGlowTextureOpacity()
{
	return g_glowTextureOpacity;
}

void MAFGlowFX::setGlowTextureOpacity(float _opa)
{
	g_glowTextureOpacity = _opa;
}

MAFPBuffer* MAFGlowFX::getPBuffer()
{
	return g_pbuffer.get();
}

bool MAFGlowFX::isUsePBuffer()
{
	return g_pbuffer.get() == NULL ? false : true;
}

// based on Pascal's Triangle
// i.e.: each coef in the matrix is the sum of its upper coef
void MAFGlowFX::calculMatrixConvolution(float _r)
{
	int i;

	/*
	g_matrixCoef[0] = 1;
	g_matrixCoef[1] = 12;
	g_matrixCoef[2] = 66;
	g_matrixCoef[3] = 220;
	g_matrixCoef[4] = 495;
	g_matrixCoef[5] = 792;
	g_matrixCoef[6] = 924;
	g_matrixCoef[7] = 792;
	g_matrixCoef[8] = 495;
	g_matrixCoef[9] = 220;
	g_matrixCoef[10] = 66;
	g_matrixCoef[11] = 12;
	g_matrixCoef[12] = 1;
	*/

	/*
	g_matrixCoef[0] = 1;
	g_matrixCoef[1] = 13;
	g_matrixCoef[2] = 78;
	g_matrixCoef[3] = 286;
	g_matrixCoef[4] = 715;
	g_matrixCoef[5] = 1287;
	g_matrixCoef[6] = 1716;
	g_matrixCoef[7] = 1716;
	g_matrixCoef[8] = 1287;
	g_matrixCoef[9] = 715;
	g_matrixCoef[10] = 286;
	g_matrixCoef[11] = 78;
	g_matrixCoef[12] = 13;
	g_matrixCoef[13] = 1;
	*/

	g_matrixCoef[0] = 1*16;
	g_matrixCoef[1] = 14*8;
	g_matrixCoef[2] = 91*2;
	g_matrixCoef[3] = 364;
	g_matrixCoef[4] = 715;
	g_matrixCoef[5] = 1001;
	g_matrixCoef[6] = 3003;
	g_matrixCoef[7] = 3432;
	g_matrixCoef[8] = 3003;
	g_matrixCoef[9] = 1001;
	g_matrixCoef[10] = 715;
	g_matrixCoef[11] = 364;
	g_matrixCoef[12] = 91 * 2;
	g_matrixCoef[13] = 14 * 8;
	g_matrixCoef[14] = 1 * 16;

	/*
	float tmp[30][30];

	tmp[0][0] = 1;
	tmp[1][0] = 1;

	j = 0;
	for (k = 2; k < 12; k++) {
		tmp[0][j+1] = 1;
		tmp[k+1][j+1] = 1;
		for (i = 0; i < k-1; i++)
			tmp[i+1][j+1] = tmp[i][j] + tmp[i+1][j];
		j++;
	}
*/
	float sigma = 0;
	for (i = 0; i < 15; i++)
		sigma += g_matrixCoef[i];

	sigma *= 0.6f;
	for (i = 0; i < 15; i++)
		g_matrixCoef[i] /= sigma;

/*
	_r = 10.0f;
	float n = 5;
	float r = n * _r;
	float pr = 2 * r * r;
	i = 0;
	float sigma = 0;
	for (int ix = -19; ix <= 19; ix++) {
		float a = ix*ix;
		float w = exp(-(a/r));
		g_matrixCoef[i++] = w;
		sigma += w;
	}
*/
}
