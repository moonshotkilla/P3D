/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <maf/tangentspace.h>
#include <math.h>
#endif

osg::Vec3f MAFGetTangent(const osg::Vec3f &_pt1,
						 const osg::Vec3f &_pt2,
						 const osg::Vec3f &_pt3,
						 const osg::Vec2f &_uv1,
						 const osg::Vec2f &_uv2,
						 const osg::Vec2f &_uv3)
{
	osg::Vec3f vec1 = _pt3 - _pt2;
	osg::Vec3f vec2 = _pt1 - _pt2;
	float delta_u1 = _uv3.x() -_uv2.x(); 
	float delta_u2 = _uv1.x() -_uv2.x();

	osg::Vec3f a = vec1 * delta_u2;
	osg::Vec3f b = vec2 * delta_u1;
	osg::Vec3f tangent = a - b;
	tangent.normalize();

	return tangent;
}
