/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 */

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <varseditor/varseditor.h>
#include <assert.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <libxml/xpathInternals.h>
#include <libxml/xmlreader.h>
#endif

VarsEditor::~VarsEditor()
{
	ClearCache();
}

static void GetNodeParameters(xmlNodePtr node,std::map<std::string,std::string>& map) 
{
	map.clear();
	xmlAttr* attribute;
	for(attribute = node->properties; attribute; attribute = attribute->next) {
		const char* value = (const char*)xmlNodeGetContent((xmlNode*)attribute);
		const char* variable = (const char*)attribute->name;
		map[variable] = value;
		xmlFree((void*)value);
	}
}

bool VarsEditor::Read(struct _xmlDoc* doc, const std::string& xpath) 
{
	if (!doc || xpath.empty())
		return false;

	ClearCache();

	std::string method = "varseditor";
  xmlXPathContextPtr context = xmlXPathNewContext(doc);
	std::string allnodes = xpath + "//var";
  xmlXPathObjectPtr object = xmlXPathEvalExpression((xmlChar*)allnodes.c_str(), context);

  if(object == NULL) {
    std::cout << method << " failed to eval " << xpath << " in file " << doc->URL << std::endl;
		xmlXPathFreeContext(context); 
    return false;
  }

  xmlNodeSetPtr nodes = object->nodesetval;
  if(!nodes || !nodes->nodeNr) {
    std::cout << method << " no element found " << xpath << " in file " << doc->URL << std::endl;
		xmlXPathFreeObject(object);
		xmlXPathFreeContext(context); 
    return false;
  }
	
	std::map<std::string,std::string> parameters;
	for (int i = 0; i < nodes->nodeNr; i++) {
		GetNodeParameters(nodes->nodeTab[i],parameters);
		if (parameters.find("name") != parameters.end() && parameters.find("value") != parameters.end()) {
			_varsString[parameters["name"]].SetString(parameters["value"]);
		}
  }
  
  xmlXPathFreeObject(object);
  xmlXPathFreeContext(context); 
  return true;
}

bool VarsEditor::Read(const std::string& fileName) 
{
	xmlDocPtr doc = xmlReadFile(fileName.c_str(), NULL, XML_PARSE_NONET|XML_PARSE_PEDANTIC);
  if(!doc) {
		std::cout << "VarsEditor::Read can't load xml document " << fileName << std::endl;
		return false;
	}
  bool result = Read(doc,"/varseditor");
  xmlFreeDoc(doc);
  return result;
}
