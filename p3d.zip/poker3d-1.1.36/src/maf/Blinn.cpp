
#include <osgFX/Blinn>
#include <osgFX/Registry>

#include <osg/VertexProgram>
#include <osg/FragmentProgram>

using namespace osgFX;

#ifndef NORMALIZE
#define NORMALIZE(a) "DP3 " #a ".w, " #a ", " #a ";\nRSQ " #a ".w, " #a ".w;\nMUL " #a ".xyz, " #a ".w, " #a ";\n"
#endif

namespace
{
    // register a prototype for this effect
	Registry::Proxy proxy(new Blinn);

	class DefaultTechnique : public Technique {

		void getRequiredExtensions(std::vector<std::string> &extensions) const
		{
			extensions.push_back("GL_ARB_vertex_program");
			extensions.push_back("GL_ARB_fragment_program");
		}

		void define_passes()
		{
			char vp_code[] =
			"!!ARBvp1.0\n"\
			"ATTRIB	pos = vertex.position;\n"\
			"PARAM	mv[4] = { state.matrix.modelview };\n"\
			"PARAM	mvp[4] = { state.matrix.mvp };\n"\
			"PARAM	mvinv[4] = { state.matrix.modelview.invtrans };\n"\
			"TEMP	tmp, vtx;\n"\
			"# vertex to clip space\n"\
			"DP4	result.position.x, mvp[0], vertex.position;\n"\
			"DP4	result.position.y, mvp[1], vertex.position;\n"\
			"DP4	result.position.z, mvp[2], vertex.position;\n"\
			"DP4	result.position.w, mvp[3], vertex.position;\n"\
			"# local normal to eye space\n"\
			"DP3	result.texcoord[2].x, mvinv[0], vertex.normal;\n"\
			"DP3	result.texcoord[2].y, mvinv[1], vertex.normal;\n"\
			"DP3	result.texcoord[2].z, mvinv[2], vertex.normal;\n"\
			"# vertex to eye space\n"\
			"DP4	vtx.x, mv[0], vertex.position;\n"\
			"DP4	vtx.y, mv[1], vertex.position;\n"\
			"DP4	vtx.z, mv[2], vertex.position;\n"\
			"DP4	vtx.w, mv[3], vertex.position;\n"\
			"# light to vertex vector\n"\
			"SUB	tmp, state.light[0].position, vtx;\n"\
			"MOV	result.texcoord[3], tmp;\n"\
			"# half\n"\
			NORMALIZE(tmp)
			NORMALIZE(vtx)
			"SUB	tmp, tmp, vtx;\n"\
			"MUL	result.texcoord[4], tmp, 0.5;\n"\
			"# diffuse color\n"\
			"MOV	result.color, state.lightprod[0].diffuse;\n"\
			"# tex coords 0 & 1\n"\
			"MOV	result.texcoord[0], vertex.texcoord[0];\n"\
			"MOV	result.texcoord[1], vertex.texcoord[1];\n"\
			"\n"\
			"END\n";

			char fp_code[] = 
			"!!ARBfp1.0\n"\
			"TEMP	tex1, tex2, tmp, tmp2, alf, norm;\n"\
			"TXP	tex1, fragment.texcoord[0], texture[0], 2D;\n"\
			"TXP	tex2, fragment.texcoord[1], texture[1], 2D;\n"\
			"PARAM	glos = program.local[0];\n"\
			"MOV	norm, fragment.texcoord[2];\n"\
			NORMALIZE(norm)
			"MOV	tmp, fragment.texcoord[3];\n"\
			NORMALIZE(tmp)
			"DP3	tmp.x, norm, tmp;\n"\
			"MOV	alf, fragment.texcoord[4];\n"\
			NORMALIZE(alf)
			"DP3	tmp.y, norm, alf;\n"\
			"MOV	tmp.w, glos;\n"\
			"LIT	tmp, tmp;\n"\
			"MUL	tmp2, tex1, tmp.y;\n"\
			"MAD	tmp2, tex2, tmp.z, tmp2;\n"\
			"MOV	tmp2.w, 1;\n"\
			"MOV	result.color, tmp2;\n"\
			"END\n";

			osg::ref_ptr<osg::StateSet> ss = new osg::StateSet;

			osg::ref_ptr<osg::VertexProgram> vp = new osg::VertexProgram;
      vp->setVertexProgram(vp_code);
      ss->setAttributeAndModes(vp.get());

			osg::ref_ptr<osg::FragmentProgram> fp = new osg::FragmentProgram;
      fp->setFragmentProgram(fp_code);
      ss->setAttributeAndModes(fp.get());

			addPass(ss.get());
		}
	};
}

Blinn::Blinn()
{
}

Blinn::Blinn(const Blinn &copy, const osg::CopyOp &copyop) :
Effect(copy, copyop)
{
}

void Blinn::setGlossiness(float glos)
{
	osgFX::Technique *tech = getTechnique(0);
	osg::StateSet *ss = tech->getPassStateSet(0);
	osg::FragmentProgram *fp = (osg::FragmentProgram*) ss->getAttribute(osg::StateAttribute::FRAGMENTPROGRAM);
	fp->setProgramLocalParameter(0, osg::Vec4f(glos, glos, glos, glos) );
}

bool Blinn::define_techniques()
{
	osgFX::Technique *tech = new DefaultTechnique();
	addTechnique(tech);
	return true;
}
