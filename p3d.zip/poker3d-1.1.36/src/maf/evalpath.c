/*
 *
 * Copyright (C) 2005, 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 */

#include <string.h>

#include <glib.h>

#include <evalpath.h>

#define PATH_SEPARATORS "/\\"

GQuark
evalpath_error_quark (void)
{
  static GQuark q = 0;
  if (q == 0)
    q = g_quark_from_static_string ("eval-path-error-quark");

  return q;
}

struct evalpath_context {
  const gchar* path_original;
  gchar* root;
  gchar* path;
  GList* path_list;
  GList* path_list_index;
  GSList* splitted;
  GError* error;
};

/**
 * g_strsplit_set:
 * @string: The string to be tokenized
 * @delimiters: A nul-terminated string containing bytes that are used
 *              to split the string.
 * @max_tokens: The maximum number of tokens to split @string into. 
 *              If this is less than 1, the string is split completely
 * 
 * Splits @string into a number of tokens not containing any of the characters
 * in @delimiter. A token is the (possibly empty) longest string that does not
 * contain any of the characters in @delimiters. If @max_tokens is reached, the
 * remainder is appended to the last token.
 *
 * For example the result of g_strsplit_set ("abc:def/ghi", ":/", -1) is a
 * %NULL-terminated vector containing the three strings "abc", "def", 
 * and "ghi".
 *
 * The result if g_strsplit_set (":def/ghi:", ":/", -1) is a %NULL-terminated
 * vector containing the four strings "", "def", "ghi", and "".
 * 
 * As a special case, the result of splitting the empty string "" is an empty
 * vector, not a vector containing a single string. The reason for this
 * special case is that being able to represent a empty vector is typically
 * more useful than consistent handling of empty elements. If you do need
 * to represent empty elements, you'll need to check for the empty string
 * before calling g_strsplit_set().
 *
 * Note that this function works on bytes not characters, so it can't be used 
 * to delimit UTF-8 strings for anything but ASCII characters.
 * 
 * Return value: a newly-allocated %NULL-terminated array of strings. Use 
 *    g_strfreev() to free it.
 * 
 * Since: 2.4
 **/
static gchar **
my_g_strsplit_set (const gchar *string,
	        const gchar *delimiters,
	        gint         max_tokens)
{
  gboolean delim_table[256];
  GSList *tokens, *list;
  gint n_tokens;
  const gchar *s;
  const gchar *current;
  gchar *token;
  gchar **result;
  
  g_return_val_if_fail (string != NULL, NULL);
  g_return_val_if_fail (delimiters != NULL, NULL);

  if (max_tokens < 1)
    max_tokens = G_MAXINT;

  if (*string == '\0')
    {
      result = g_new (char *, 1);
      result[0] = NULL;
      return result;
    }
  
  memset (delim_table, FALSE, sizeof (delim_table));
  for (s = delimiters; *s != '\0'; ++s)
    delim_table[*(guchar *)s] = TRUE;

  tokens = NULL;
  n_tokens = 0;

  s = current = string;
  while (*s != '\0')
    {
      if (delim_table[*(guchar *)s] && n_tokens + 1 < max_tokens)
	{
	  gchar *token;

	  token = g_strndup (current, s - current);
	  tokens = g_slist_prepend (tokens, token);
	  ++n_tokens;

	  current = s + 1;
	}
      
      ++s;
    }

  token = g_strndup (current, s - current);
  tokens = g_slist_prepend (tokens, token);
  ++n_tokens;

  result = g_new (gchar *, n_tokens + 1);

  result[n_tokens] = NULL;
  for (list = tokens; list != NULL; list = list->next)
    result[--n_tokens] = list->data;

  g_slist_free (tokens);
  
  return result;
}

static void evalpath_cleanup(struct evalpath_context* context)
{
  GSList* pointer = NULL;
  for(pointer = context->splitted; pointer; pointer = g_slist_next(pointer))
    g_strfreev(pointer->data);
  if(context->splitted) g_slist_free(context->splitted);
  if(context->path_list) g_list_free(context->path_list);
  if(context->root) g_free(context->root);
  if(context->path) g_free(context->path);

  context->root = NULL;
  context->path = NULL;
  context->path_list = NULL;
  context->path_list_index = NULL;
  context->splitted = NULL;
}

static void evalpath_set_path(struct evalpath_context* context)
{
  if(context->path) g_free(context->path);

  if(context->path_list_index) {
    gchar** path_array = (gchar**)g_malloc(sizeof(gchar*) * ( g_list_length(context->path_list) + 2));
    GList* pointer = NULL;
    int path_array_index = 0;
    if(context->root) path_array[path_array_index++] = context->root;
    for(pointer = context->path_list; pointer; pointer = g_list_next(pointer)) {
      if(pointer == context->path_list_index)
        break;
      path_array[path_array_index++] = (gchar*)pointer->data;
    }
    path_array[path_array_index] = NULL;
    context->path = g_strjoinv(G_DIR_SEPARATOR_S, path_array);
    g_free(path_array);

  } else {
    context->path = g_strconcat(context->root, G_DIR_SEPARATOR_S, NULL);
  }
}

static void evalpath_reduce(struct evalpath_context* context)
{
  GList* path_element = NULL;
  for(path_element = context->path_list; path_element; ) {
    gchar* filename = (gchar*)path_element->data;
    gboolean is_index = context->path_list_index == path_element;

    if(!strcmp(filename, "") || !strcmp(filename, ".")) {
      GList* to_remove = path_element;
      if(g_list_next(path_element))
        path_element = g_list_next(path_element);
      else 
        path_element = g_list_previous(path_element);
      context->path_list = g_list_remove_link(context->path_list, to_remove);
      g_list_free(to_remove);
      if(is_index) context->path_list_index = path_element;

    } else if(!strcmp(filename, "..")) {
      gboolean is_relative = !strcmp(context->root, ".");
      GList* dotdot = NULL;
      GList* previous = NULL;
      dotdot = path_element;
      previous = g_list_previous(dotdot);
      path_element = g_list_next(path_element);

      if(!is_relative || (previous && strcmp(previous->data, ".."))) {
        context->path_list = g_list_remove_link(context->path_list, dotdot);
        g_list_free(dotdot);

        if(previous) {
          context->path_list = g_list_remove_link(context->path_list, previous);
          g_list_free(previous);
        }
        if(is_index) context->path_list_index = path_element;
      }

    } else {
      path_element = g_list_next(path_element);

    }
  }

  evalpath_set_path(context);
}

static gboolean evalpath_iterate(struct evalpath_context* context);

static gboolean evalpath_start(const gchar* path, struct evalpath_context* context)
{
  gboolean status = TRUE;

  evalpath_cleanup(context);

  if(g_path_is_absolute(path)) {
    gchar* after_root = (gchar*)g_path_skip_root(path);
    if(after_root - path < 1) {
      g_set_error(&context->error, EVALPATH_ERROR, EVALPATH_ERROR_INCONSISTENT_ROOT, "evalpath: %s: root has a length < 1", context->path_original);
      status = FALSE;
    } else {
      context->root = g_strndup(path, (after_root - path) - 1);
      path = after_root;
    }
  } else {
    context->root = g_strdup(".");
  }

  if(status == TRUE) {
    gchar** pointer = NULL;
    gchar** splitted_path = my_g_strsplit_set(path, PATH_SEPARATORS, 0);
    context->splitted = g_slist_append(context->splitted, splitted_path);
    if(*splitted_path != NULL) {
      for(pointer = splitted_path; *pointer; pointer++)
        context->path_list = g_list_append(context->path_list, *pointer);
      context->path_list_index = g_list_first(context->path_list);
      evalpath_reduce(context);
      status = evalpath_iterate(context);
    } else {
      context->path = strdup(context->root);
    }
  }

  return status;
}

static gboolean evalpath_iterate(struct evalpath_context* context)
{
  gboolean status = TRUE;
  gchar* path_element = NULL;
  gchar* path_new = NULL;
  gchar* path_ref = NULL;
  gchar* path_symlink = NULL;

  if(context->path_list_index == NULL)
    return TRUE;

  path_element = (gchar*)context->path_list_index->data;
  path_ref = g_strconcat(context->path, G_DIR_SEPARATOR_S, path_element, ".ref", NULL);
  if(g_file_test(path_ref, G_FILE_TEST_EXISTS)) {
    /*
     * Follow links found in .ref files
     */
    if(g_file_test(path_ref, G_FILE_TEST_IS_REGULAR)) {
      if(!g_file_get_contents(path_ref, &path_symlink, NULL, &context->error)) {
        status = FALSE;
        goto finish;
      }
      g_strstrip(path_symlink);
    } else {
      g_set_error(&context->error, EVALPATH_ERROR, EVALPATH_ERROR_REF_NOT_REGULAR, "evalpath: %s: %s is not a regular file", context->path_original, path_ref);
      status = FALSE;
      goto finish;
    }

    if(g_path_is_absolute(path_symlink)) {
      /*
       * The link is an absolute path name, start over
       */
      status = evalpath_start(path_symlink, context);
    } else {
      /*
       * The link is relative, substitute the .ref file with the content of the link
       */
      GList* path_list_pointer = NULL;
      gchar** pointer = NULL;
      gchar** splitted_path = my_g_strsplit_set(path_symlink, PATH_SEPARATORS, 0);
      context->splitted = g_slist_append(context->splitted, splitted_path);
      if(*splitted_path == NULL) {
        g_set_error(&context->error, EVALPATH_ERROR, EVALPATH_ERROR_REF_EMPTY, "evalpath: %s: %s is empty", context->path_original, path_ref);
        status = FALSE;
      } else {
        path_list_pointer = context->path_list_index;
        context->path_list_index = g_list_previous(path_list_pointer);
        for(pointer = splitted_path; *pointer; pointer++)
          context->path_list = g_list_insert_before(context->path_list, path_list_pointer, *pointer);
        context->path_list_index = g_list_next(context->path_list_index);
        {
          context->path_list = g_list_remove_link(context->path_list, path_list_pointer);
          g_list_free(path_list_pointer);
        }
        evalpath_reduce(context);
        status = evalpath_iterate(context);
      }
    }
  } else {
    /*
     * Check for existence and proceeed to the next path element.
     */
    path_new = g_strconcat(context->path, G_DIR_SEPARATOR_S, path_element, NULL);
    if(g_file_test(path_new, G_FILE_TEST_EXISTS)) {
      g_free(context->path);
      context->path = path_new;
      path_new = NULL;
      context->path_list_index = g_list_next(context->path_list_index);
      status = evalpath_iterate(context);
    } else {
      g_set_error(&context->error, EVALPATH_ERROR, EVALPATH_ERROR_DOES_NOT_EXIST, "evalpath: %s: %s does not exist", context->path_original, path_new);
      status = FALSE;
    }
  }

 finish:
  if(path_ref) g_free(path_ref);
  if(path_new) g_free(path_new);
  if(path_symlink) g_free(path_symlink);

  return status;
}

gchar* evalpath(const gchar* path, GError** error)
{
  gboolean status = FALSE;
  gchar* result = NULL;
  struct evalpath_context context;
  context.path_original = path;
  context.error = NULL;
  context.root = NULL;
  context.path = NULL;
  context.path_list = NULL;
  context.path_list_index = NULL;
  context.splitted = NULL;

  status = evalpath_start(path, &context);

  if(status) {
    if(!strcmp(context.root, ".")) {
      int after_dot = strlen(context.path) > 1 ? 2 : 1;
      result = g_strdup(context.path + after_dot);
    } else {
      result = g_strdup(context.path);
    }
  }

  evalpath_cleanup(&context);

  *error = context.error;

  return status ? result : NULL;
}

#ifdef EVALPATH_TEST

#include <stdlib.h>
#include <stdio.h>

const char* script_prepare = 
"mkdir -p foo bar\n"
"mkdir -p /tmp/foo/1/2 /tmp/bar/3/4\n"

"echo -n ../bar > foo/a.ref\n"
"echo -n ../bar > /tmp/foo/a.ref\n"
"echo -n ../../../../../.. > /tmp/foo/b.ref\n"
"echo -n .././bar > /tmp/foo/c.ref\n"
"echo -n ..////./bar > /tmp/foo/d.ref\n"
"echo -n 1/f > /tmp/foo/e.ref\n"
"echo -n 2 > /tmp/foo/1/f.ref\n"
"echo -n ../../../.. > foo/g.ref\n"
"echo -n ../../../../../../../../../../../../../../../../../../../../../../../../../tmp > foo/h.ref\n"
"echo -n /tmp/bar/3 > /tmp/foo/i.ref\n"
"echo -n ../../../../../../../../../../../../../../../../../../../../../../../../../tmp/foo/i > foo/j.ref\n"

"echo -n glouglou > foo/ea.ref\n"
"mkdir -p foo/eb.ref\n"
"touch foo/ec.ref\n"
"\n"
;

const char* script_cleanup = 
"rm -fr foo bar /tmp/foo /tmp/bar"
;

int main(int argc, char** argv)
{
  GError* error = NULL;
  char* input[] = {
    "",
    "foo/a",
    "/tmp/foo/1",

    "/tmp/foo/a",
    "/tmp/foo/b",
    "/tmp/foo/c",

    "/tmp/foo/d",
    "/tmp/foo/e",
    "foo/g",

    "foo/h",
    "/tmp/foo/i",
    "foo/j",
    NULL,
  };
  char* output[] = {
    "",
    "bar",
    "/tmp/foo/1",

    "/tmp/bar",
    "/",
    "/tmp/bar",

    "/tmp/bar",
    "/tmp/foo/1/2",
    "../../..",

    "../../../../../../../../../../../../../../../../../../../../../../../../tmp",
    "/tmp/bar/3",
    "/tmp/bar/3",
    NULL,
  };
  char** pointer;
  int failures = 0;
  system(script_cleanup);
  system(script_prepare);
  int index;
  for(pointer = input, index = 0; *pointer; pointer++, index++) {
    gchar* result = evalpath(*pointer, &error);
    if(!result) {
      printf("Failure");
      if(error) printf(": error: %s\n", error->message);
      failures++;
    } else if(!strcmp(result, output[index])) {
      printf("Success : '%s' -> '%s'\n", *pointer, result);
    } else {
      printf("Failure: '%s' -> '%s' (expected %s)\n", *pointer, result, output[index]);
      failures++;
    }
    if(result) g_free(result);
  }

  char* input_error[] = {
    "/unlikely",
    "unlikely",
    "foo/ea",
    "foo/eb",
    "foo/ec",
    NULL
  };

  int output_error[] = {
    EVALPATH_ERROR_DOES_NOT_EXIST,
    EVALPATH_ERROR_DOES_NOT_EXIST,
    EVALPATH_ERROR_DOES_NOT_EXIST,
    EVALPATH_ERROR_REF_NOT_REGULAR,
    EVALPATH_ERROR_REF_EMPTY,
    0
  };
  for(pointer = input_error, index = 0; *pointer; pointer++, index++) {
    gchar* result = evalpath(*pointer, &error);
    if(!result && error && error->code == output_error[index]) {
      printf("Success: error: %s\n", error->message);
    } else if(result) {
      printf("Failure : '%s' -> '%s'\n", *pointer, result);
      failures++;
    } else {
      printf("Failure");
      if(error) printf(": error: %s\n", error->message);
      failures++;
    }
    if(result) g_free(result);
  }
  system(script_cleanup);

  return failures;
}

#endif // EVALPATH_TEST

/*
 * Local variables:
 * compile-command: "gcc -g -DEVALPATH_TEST -Wall -Wstrict-prototypes -I../../include `pkg-config --cflags glib-2.0` `pkg-config --libs glib-2.0` -o evalpath evalpath.c ; valgrind --show-reachable=yes --leak-check=full ./evalpath"
 * End:
 */
