/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <maf/shader_embm.h>
#endif

#include <osg/VertexProgram>
#include <osg/FragmentProgram>

// EMBM


char MAFVP_EMBM[] =
"!!ARBvp1.0\n"\
"ATTRIB	pos = vertex.position;\n"\
"PARAM	mv[4] = { state.matrix.modelview };\n"\
"PARAM	mvp[4] = { state.matrix.mvp };\n"\
"PARAM	mvinv[4] = { state.matrix.modelview.invtrans };\n"\
"TEMP	tmp, vtx;\n"\
"# vertex to clip space\n"\
"DP4	result.position.x, mvp[0], vertex.position;\n"\
"DP4	result.position.y, mvp[1], vertex.position;\n"\
"DP4	result.position.z, mvp[2], vertex.position;\n"\
"DP4	result.position.w, mvp[3], vertex.position;\n"\
"# local normal to eye space\n"\
"DP3	result.texcoord[2].x, mvinv[0], vertex.normal;\n"\
"DP3	result.texcoord[2].y, mvinv[1], vertex.normal;\n"\
"DP3	result.texcoord[2].z, mvinv[2], vertex.normal;\n"\
"# vertex to eye space\n"\
"DP4	vtx.x, mv[0], vertex.position;\n"\
"DP4	vtx.y, mv[1], vertex.position;\n"\
"DP4	vtx.z, mv[2], vertex.position;\n"\
"DP4	vtx.w, mv[3], vertex.position;\n"\
"# light to vertex vector\n"\
"SUB	tmp, state.light[0].position, vtx;\n"\
"MOV	result.texcoord[3], tmp;\n"\
"# half\n"\
"DP3	tmp.w, tmp, tmp;\n"\
"RSQ	tmp.w, tmp.w;\n"\
"MUL	tmp.xyz, tmp.w, tmp;\n"\
"DP3	vtx.w, vtx, vtx;\n"\
"RSQ	vtx.w, vtx.w;\n"\
"MUL	vtx.xyz, vtx.w, vtx;\n"\
"SUB	tmp, tmp, vtx;\n"\
"MUL	result.texcoord[4], tmp, 0.5;\n"\
"# diffuse color\n"\
"MOV	result.color, state.lightprod[0].diffuse;\n"\
"# tex coords 0 & 1\n"\
"MOV	result.texcoord[0], vertex.texcoord[0];\n"\
"MOV	result.texcoord[1], vertex.texcoord[1];\n"\
"\n"\
"END\n";


char MAFFP_EMBM[] = 
"!!ARBfp1.0\n"\
"TEMP	tex1, tex2, tmp, tmp2, alf, norm;\n"\
"TXP	tex1, fragment.texcoord[0], texture[0], 2D;\n"\
"TXP	tex2, fragment.texcoord[1], texture[1], 2D;\n"\
"MAD	tex2, tex2, 2, -1;\n"\
"MOV	tex2.z, 0;\n"\
"MOV	tex2.w, 0;\n"\
"MOV	norm, fragment.texcoord[2];\n"\
"ADD	norm, norm, tex2;\n"\
"DP3	norm.w, norm, norm;\n"\
"RSQ	norm.w, norm.w;\n"\
"MUL	norm.xyz, norm.w, norm;\n"\
"MOV	tmp, fragment.texcoord[3];\n"\
"DP3	tmp.w, tmp, tmp;\n"\
"RSQ	tmp.w, tmp.w;\n"\
"MUL	tmp.xyz, tmp.w, tmp;\n"\
"DP3	norm.w, norm, tmp;\n"\
"MUL	tex1, tex1, norm.w;\n"\
"MOV	result.color, tex1;\n"\
"END\n";

MAFShaderEMBM::MAFShaderEMBM()
{
	vp_->setVertexProgram(MAFVP_EMBM);
	fp_->setFragmentProgram(MAFFP_EMBM);
}

MAFShaderEMBM::~MAFShaderEMBM()
{
}

void MAFShaderEMBM::writeProgramToDisk(const char *_vertex_file, const char *_fragment_file)
{
	Parent::writeProgramToDisk(_vertex_file, _fragment_file, MAFVP_EMBM, MAFFP_EMBM);
}
