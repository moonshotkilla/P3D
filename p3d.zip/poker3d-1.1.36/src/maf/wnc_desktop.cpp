/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Vincent Caron <zerodeux@gnu.org>
 *  Henry Precheur <henry@precheur.org
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */
/*
 *
 * wncdesktop/XwncDesktop.cxx --
 *
 * Copyright (C) Nicolas Roussel
 * Copyright (C) Olivier Chapuis
 *
 * See the file LICENSE for information on usage and redistribution of
 * this file, and for a DISCLAIMER OF ALL WARRANTIES.
 *
 */

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <varseditor/varseditor.h>
#include <maf/assert.h>
#include <maf/maferror.h>
#include <maf/animate2d.h>
#define DISABLE_ANIMATE
#include <maf/wnc_source.h>
#include <maf/wnc_desktop.h>
#include <maf/wnc_window.h>
#include <maf/url.h>
#include <maf/renderbin.h>
#include <CustomAssert/CustomAssert.h>

#include <cstdio> // for snprintf
#include <algorithm>

#endif
#include <iostream>

#include <maf/alpha_fx.h>

// uncomment this to enable debug output in xwnc

//#ifdef	_DEBUG_XWNC_
//#	ifdef __GNUC__
//#		define XWNC_FUNC()	g_debug("%s %lX", __PRETTY_FUNCTION__, id)
//#	else // __GNUC__
//#		define XWNC_FUNC()	g_debug("%s %lX", __FUNCTION__, id)
//#	endif // __GNUC__
//#else	// !_DEBUG_XWNC_
//#	define XWNC_FUNC()
//#endif	// _DEBUG_XWNC_


#define XWNC_FUNC() std::cout << __FUNCTION__ << id << std::endl


typedef std::map<int, std::vector<XwncWindow*> > PriorityStackContainer;

template<typename It>
static void	redo_group_order_with_priority(It begin, It end,osg::Group* grp)
{
  for (It it = begin; it != end; it++)
    for (int i = 0; i < (int)it->second.size(); i++)
      grp->addChild(it->second[i]);
}

template<typename It>
static void	redo_group(It begin, It end, XwncDesktop::WindowMapping& windows,	osg::Group* grp, PriorityStackContainer& priorityStack)
{
  grp->removeChild(0, grp->getNumChildren());
  for (It i = begin; i != end; i++) {
    XwncDesktop::WindowMapping::iterator	it = windows.find(*i);
    g_assert(it != windows.end());
    XwncWindow*	group = it->second.get();
    if (group->IsMapped())
      priorityStack[group->getStackPriority()].push_back(group);
  }
}


void	XwncDesktop::_redoGroup()
{
  {
  PriorityStackContainer priorityStack;
  redo_group<WindowOrder::iterator>(_wo.begin(),
                                    _wo.end(),
                                    _windows,
                                    mDisplayGroup.get(),
                                    priorityStack);
  redo_group_order_with_priority<PriorityStackContainer::iterator>(priorityStack.begin(),priorityStack.end(),mDisplayGroup.get());
  }

  {
  PriorityStackContainer priorityStack;
  redo_group<WindowOrder::reverse_iterator>(_wo.rbegin(),
                                            _wo.rend(),
                                            _windows,
                                            mHitGroup.get(),
                                            priorityStack);
  redo_group_order_with_priority<PriorityStackContainer::reverse_iterator>(priorityStack.rbegin(),priorityStack.rend(),mHitGroup.get());
  }
}

void	XwncDesktop::_restack(Window up, Window down)
{
  WindowOrder::iterator	up_it = find(_wo.begin(), _wo.end(), up);
  WindowOrder::iterator	down_it = find(_wo.begin(), _wo.end(), down);

  if (_windows.find(up) == _windows.end())
    g_critical("XwncDesktop::_restack: unknown window id %ld", (unsigned long)up);
  else if(_windows[up]->isRootWindow())  // FIXME evil hack to get rid of
				     // root window
    return;

  if (down == 0)
    _up(up);
  else
    {
      g_assert(up_it != _wo.end() && down_it != _wo.end());
      
      std::swap(*up_it, *down_it);
      _redoGroup();
    }
}

void	XwncDesktop::_down(Window id)
{
  WindowOrder::iterator	it = find(_wo.begin(), _wo.end(), id);
  
  g_assert(it != _wo.end());
  
  _wo.erase(it);
  _wo.push_front(id);
  _redoGroup();
}

void	XwncDesktop::_up(Window id)
{
  WindowOrder::iterator	it = find(_wo.begin(), _wo.end(), id);
  
  g_assert(it != _wo.end());
  
  _wo.erase(it);
  _wo.push_back(id);
  _redoGroup();
}

void	XwncDesktop::_add(Window id)
{
  _wo.push_back(id);
  _redoGroup();
}

void	XwncDesktop::_remove(Window id)
{
  WindowOrder::iterator	it = find(_wo.begin(), _wo.end(), id);
  
  g_assert(it != _wo.end());
  
  _wo.erase(it);
  _redoGroup();
}

std::map<std::string,int>& XwncDesktop::GetStackPriority() { return mPriorityWindowByName;}

XwncWindow*	XwncDesktop::GetWindow(const std::string& name)
{
  for (WindowMapping::iterator	i = _windows.begin(); i != _windows.end(); i++) {
    if(i->second.valid()) {
      if (i->second->GetTitle() == name)
				return i->second.get();
    } else {
      g_debug("null window for id %ld", i->first);
    }
  }
  return 0;
}

XwncWindow*	XwncDesktop::GetWindow(Window id)
{
  return _windows.find(id) != _windows.end() ? _windows.find(id)->second.get() : 0;
}

void XwncDesktop::_addWindow(Window id,
														 int x, int y,
														 unsigned int width, unsigned int height,
														 bool map,
														 const char* window_name)
{
  g_assert(_wncServer);

  XwncWindow*	window = new XwncWindow(window_name, id, _wncServer,
					x, y, width, height);

  setWindowPriority(window);
  _windows[id] = window;

  if (map)
		_setMappedWindow(window, true);
  else
		_setMappedWindow(window, false);
  _add(id); // add and focus new window
}

void XwncDesktop::_setMappedWindow(XwncWindow* window, bool state)
{
	if (!window)
		return;

 	std::cout << "XwncDesktop Window mapped " << window->GetTitle() << " " << state << std::endl;
	if (!state) {
		window->setMapped(false);
	} else {
		window->setMapped(true);
	}
}


void XwncDesktop::handleConfigureWindow(Window id, int isroot,
																				int x, int y,
																				int width, int height,
																				const char* window_name)
{
  std::cout << "window name : " << window_name << std::endl;
	_eventCount++;
  XWNC_FUNC();
  WindowMapping::iterator i = _windows.find(id);

  osg::ref_ptr<XwncWindow> win = GetWindow(id);

  if (!win)
    {
			if (! isroot)
				{
					_addWindow(id, x, y, width, height, true, window_name);
				}
      else
				{
					_addWindow(id, x, y, width, height, false, window_name);
					g_assert(_windows.find(id) != _windows.end());
					_windows[id]->setRootWindow();
				}
    }
  else
    {
      win->configure(x, y, width, height);
    }
  if(mName2Animate.find(window_name) != mName2Animate.end()) {
		MAFApplication2DAnimate* animate = mName2Animate[window_name];
		if(_windows.find(id) != _windows.end()) {
			unsigned int width;
			unsigned int height;
			int x;
			int y;
			int window_width;
			int window_height;
  
			getSize(&width, &height);
			_windows[id]->getSize(&window_width, &window_height);
			_windows[id]->getPosition(&x, &y, height);

			animate->Configure(GetMovingWindows(), _windows[id].get(), osg::Vec2(x, y), osg::Vec2(window_width, window_height), osg::Vec2(width, height));
		}
  }
}

bool XwncDesktop::hasTransientWindow()
{
	std::vector<std::string> windowStack;
	getStackWindowName(windowStack);
	std::string transientWindowName;
#ifdef WIN32
	transientWindowName = "poker3d-interface";
#else
	transientWindowName = "poker-interface";
#endif
	bool transient = false;
	for (unsigned int i = 0; i < windowStack.size(); i++)
		if (windowStack[i] == transientWindowName) {
			transient = true;
			break;
		}
	return transient;
}

void XwncDesktop::handleImageFramebufferUpdate(XwncWindow* win, bool isRoot,
					       WncImage *img, int x, int y,
					       unsigned int w, unsigned int h)
{
	_eventCount++;
  if (!win)
    {
      g_warning("handleImageFramebufferUpdate for a window we do not know");
      return;
    }
// 		std::cout << win->getName() << ":" << win->mUpdateCount;
// 		std::cout << " " << w << "x" << h << std::endl;
		{
			float wH, wW;
			win->getSize(&wW, &wH);
			if (!(x + w > (unsigned int)wW || y + h > (unsigned int)wH))
				win->updateTexture(img, x, y, w, h);
		}
		win->mUpdateCount++;
}

void XwncDesktop::handleUnmapWindow(Window id)
{
	_eventCount++;
  XWNC_FUNC();  
  WindowMapping::iterator i = _windows.find(id);
  
  if (i == _windows.end())
    {
      g_warning("Trying to unmap a window we don't know (%lX)", id);
      return;
    }
  
  osg::ref_ptr<XwncWindow> win = (*i).second ;
  if (win->IsMapped())
    {
		WindowMapping::iterator i = _windows.find(id);
	  
		if (i == _windows.end())
		{
			g_warning("Trying to unmap a window we don't know (%lX)", id);
			return;
		}
	  
		osg::ref_ptr<XwncWindow> win = (*i).second ;
	  
		if (win->IsMapped())
		{
			std::cout << "XwncDesktop handleUnmapWindow " << win->GetTitle() << std::endl;

			const std::string& window_name = win->GetTitle();
			if(mName2Animate.find(window_name) != mName2Animate.end()) {
  				MAFApplication2DAnimate* animate = mName2Animate[window_name];
  				animate->Unmap(GetMappedWindows()->getParent(0));
			}

			_setMappedWindow(win.get(),false);
			_redoGroup();
		}
	}
}

void XwncDesktop::handleDestroyWindow(Window id)
{
	_eventCount++;
  XWNC_FUNC();
  WindowMapping::iterator i = _windows.find(id) ;
  if (i==_windows.end())
    {
      g_warning("Trying to remove a window we don't know (%lX)", id);
      return ;
    }

  osg::ref_ptr<XwncWindow> win = (*i).second ;

  const std::string& window_name = win->GetTitle();

  if(mName2Animate.find(window_name) != mName2Animate.end()) {
   MAFApplication2DAnimate* animate = mName2Animate[window_name];
   osg::ref_ptr<osg::MatrixTransform> window = win->staticCopy();
   animate->Destroy(GetMappedWindows()->getParent(0), window.get());
  }

  _windows.erase(id);
  _remove(id);
  mDisplayGroup->removeChild(win.get());
  mHitGroup->removeChild(win.get());
}

#if 0
bool XwncDesktop::findTransientWindow(Window id, Transient& transient, Transient& result)
{
	Transient::iterator found = transient.find(id);
	if (found == transient.end()) {
		for (Transient::iterator it = transient.begin(); it != transient.end(); it++) {
			Transient::iterator res = findTransientWindow(id, it->second);
			if (res != it->second.end()) {
				result =  res->second;
				return true;
			}
		}
	} else {
		result = found->second;
		return true;
	}
	result = found->second;
	return false;
}
#endif

void XwncDesktop::handleRestackWindow(Window id,
																			Window nextId,
																			Window transientFor,
																			unsigned long flags)
{
	_eventCount++;
  XWNC_FUNC();
  WindowMapping::iterator i = _windows.find(id);
  WindowMapping::iterator j = _windows.find(nextId);

  // g_debug("id %lx / nextid %lx / transientfor %lx", id, nextId, transientFor);

  if (i == _windows.end())
    {
      g_warning("Trying to restack a window we don't know (%lX)", id);
      return;
    }


  osg::ref_ptr<XwncWindow> win = (*i).second;
  // osg::ref_ptr<XwncWindow> nextWin = (*j).second;

//   if ((flags & rfbWindowFlagsOverrideRedirect) ||
//       (flags & rfbWindowFlagsUnmanaged))
//     win->setUnmanaged();

//   if (flags & rfbWindowFlagsEwmhDesktop)
//     win->setEwmhDesktop();

//   if (flags & rfbWindowFlagsNetChecking)
//     win->hide();

//   if (flags & rfbWindowFlagsTransient)
//     win->setTransientFor(transientFor);

  if (flags & rfbWindowFlagsInputOnly)
    g_warning("Input Only window %lX", id);

  // FIXME
  if (win->IsMapped())
    {
      //		_ascr->root->restack(win, nextWin, false);
      //		_ascr->draw(false);
      //		_ascr->resetSelection(true);
    }
  else
    {
      //		_ascr->root->restack(win, nextWin, true);
      //		if (!win->isUnmanaged() && win->neverMapped())
      //			_ascr->root->translateForWindow(win);
      if (!win->isRootWindow())
	{
	  const std::string& window_name = win->GetTitle();

	  if(mName2Animate.find(window_name) != mName2Animate.end()) {
	   MAFApplication2DAnimate* animate = mName2Animate[window_name];
	   animate->Map(GetMappedWindows()->getParent(0));
	  }

		_setMappedWindow(win.get(),true);
	  //_redoGroup();
	}
      //		_ascr->draw(false);
      //		_ascr->resetSelection(true);
    }
  _restack(id, nextId);
}

// ----------------------------------------------------------------------------

void	XwncDesktop::rootPointerEvent(int x, int y, unsigned long button_mask)
{
  _wncServer->pointerEvent(0, x, y, button_mask);
}

void	XwncDesktop::rootKeyEvent(unsigned long key, bool down_flag)
{
  _wncServer->keyEvent(key, down_flag);
}

void XwncDesktop::check(float delta)
{
  getServer()->check();
  return;
}

void	XwncDesktop::getSize(unsigned int*	width, unsigned int* height)
{
  _wncServer->getSize(width, height);
}

// -------------------------------------------------------------------------

void	XwncDesktop::startRequest(void)
{
  _wncServer->updateRequest(true);
}

XwncDesktop::XwncDesktop(const std::string& rfburl, const std::string& style)
{
  _style = style ;
  //  _xdisplay = 0 ;

  URL url(rfburl) ;

  std::string	vncdisplay = url.getHost() + std::string(":") + url.getPort();

  _wncServer = new wncSource(this, WncImage::RGBA, url);
  if (!_wncServer)
    throw new MAFError(UNDERWARE_MAF_ERROR_DATALOAD,
		       "[XwncDesktop] Can't create wncSource");

  if (!_wncServer->start())
    throw new MAFError(UNDERWARE_MAF_ERROR_DATALOAD,
		       "unable to connect to wnc server %s",
		       rfburl.c_str());

  mDisplayGroup = new osg::Group;
  mDisplayGroup->setName("wncDesktop(display)");
  mHitGroup = new osg::Group;
  mHitGroup->setName("wncDesktop(hit)");
  mMovingGroup = new osg::Group;
  mMovingGroup->setName("wncDesktop(moving)");
}

XwncDesktop::~XwncDesktop()
{  
  delete _wncServer;
}

void XwncDesktop::setWindowPriority(XwncWindow* window)
{
  CUSTOM_ASSERT(window);
  const std::string& wn = window->GetTitle();
  bool rc = MAFRenderBin::Instance().SetupRenderBin("WNC_"+wn, window->getOrCreateStateSet());
  if (!rc)
    MAFRenderBin::Instance().SetupRenderBin("WNC_DEFAULT_RENDER_BIN", window->getOrCreateStateSet());

  if (mPriorityWindowByName.find(wn) != mPriorityWindowByName.end())
    window->setStackPriority(mPriorityWindowByName[wn]);
}

void XwncDesktop::showWindow(const std::string& window_name, bool show)
{
	XwncWindow* win = GetWindow(window_name);
	if (win != NULL)
		{
			std::cout <<  "XwncDesktop " << window_name << " " << show <<std::endl;
			if (show)
				{
					if (!win->IsMapped()) {
						_setMappedWindow(win,true);
						int id = win->getFrameID();
						if(mName2Animate.find(window_name) != mName2Animate.end()) {
							MAFApplication2DAnimate* animate = mName2Animate[window_name];
							if(_windows.find(id) != _windows.end()) {
								unsigned int width;
								unsigned int height;
								int x;
								int y;
								int window_width;
								int window_height;
  
								getSize(&width, &height);
								_windows[id]->getSize(&window_width, &window_height);
								_windows[id]->getPosition(&x, &y, height);

								animate->Configure(GetMovingWindows(), _windows[id].get(), osg::Vec2(x, y), osg::Vec2(window_width, window_height), osg::Vec2(width, height));
								animate->Map(GetMovingWindows());
							}
						}
					}
					_up(win->getFrameID());
				}
			else
				{
					_setMappedWindow(win,false);
					if(mName2Animate.find(window_name) != mName2Animate.end()) {
						MAFApplication2DAnimate* animate = mName2Animate[window_name];
						animate->Unmap(GetMovingWindows());
					}
				}
			_redoGroup();
		} else {

			if(mName2Animate.find(window_name) != mName2Animate.end()) {
				MAFApplication2DAnimate* animate = mName2Animate[window_name];
				if (animate->IsVirtualWindow()) {
					if (show)
						{
							if(mName2Animate.find(window_name) != mName2Animate.end()) {
								MAFApplication2DAnimate* animate = mName2Animate[window_name];
								unsigned int width;
								unsigned int height;
								getSize(&width, &height);
								int window_width = (int)0;
								int window_height = (int)0;
								int x = width/2;
								int y = height/2;
								animate->Configure(GetMovingWindows(), 0, osg::Vec2(x, y), osg::Vec2(window_width, window_height), osg::Vec2(width, height));
								animate->Map(GetMovingWindows());
							}
						}
					else
						{
							if(mName2Animate.find(window_name) != mName2Animate.end()) {
								MAFApplication2DAnimate* animate = mName2Animate[window_name];
								animate->Unmap(GetMovingWindows());
							}
						}
				}
			}
		}
}

void XwncDesktop::hideAllWindows()
{
	for (WindowMapping::iterator	i = _windows.begin(); i != _windows.end(); i++) {
    if(i->second.valid()) {
			if (i->second->IsMapped())
				std::cout << "Title " << i->second->GetTitle() << " show false\n";
				showWindow(i->second->GetTitle(), false);
    } else {
      g_debug("null window for id %ld", i->first);
    }
  }
	//	_redoGroup();
}

unsigned int XwncDesktop::getWindowCount()
{
	return _windows.size();
}

void XwncDesktop::getStackWindowName(std::vector<std::string>& stack)
{
	stack.clear();

  osg::Group*	g = GetHitableWindows();
  for (unsigned i = 0; i < g->getNumChildren(); i++) {
		XwncWindow*	win = dynamic_cast<XwncWindow*>(g->getChild(i));
		stack.push_back(win->GetTitle());
	}
}
