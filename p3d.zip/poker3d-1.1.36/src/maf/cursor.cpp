/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH

#include <maf/data.h>
#include <maf/cursor.h>
#include <maf/application.h>
#include <maf/window.h>
#include <varseditor/varseditor.h>
#include <osg/Group>
#include <osg/StateSet>
#include <osg/MatrixTransform>
#include <osg/Projection>
#include <osg/PositionAttitudeTransform>
#include <osg/Material>
#include <iostream>

#endif

MAFCursorModel* MAFCursorModelFactory(MAFApplication* application, const std::string& base)
{
	const std::string& type = application->HeaderGet("sequence", base + "/@type");
	if (type == "sdl")
		return new MAFCursorModelSDL;
	else if (type == "gl")
		return new MAFCursorModelGL(application);
	else if (type == "animated")
		return new MAFCursorModelAnimated;
	g_error("MAFCursorModelFactory: failed to create cursor of type %s", type.c_str());
	return 0;
}

MAFCursorModelSDL::MAFCursorModelSDL()
{
}
void MAFCursorModelSDL::Init(MAFApplication* application, const std::string& base)
{
	const std::string& url = application->HeaderGet("sequence", base + "/@url");
	MAFCursorData* cursor = application->mDatas->GetCursor(url);
	if (!cursor)
		g_error("MAFCursor %s not found", url.c_str());
	SDL_Cursor* mouseData = cursor->GetOrCreateCursor();
	if (!mouseData)
		g_error("SDL_Cursor creation failed");
	mCursors.push_back(mouseData);
}
void MAFCursorModelSDL::SetCursor(int cursor)
{
	int nbCursors = mCursors.size();
  g_assert(cursor >= 0 && cursor < nbCursors);

  SDL_SetCursor(mCursors[cursor]);
}
int MAFCursorModelSDL::GetNbCursor()
{
  return mCursors.size();
}
void MAFCursorModelSDL::ShowCursor(bool state)
{
  SDL_ShowCursor(state ? SDL_ENABLE : SDL_DISABLE);
}

void MAFCursorModelSDL::WarpMouse(int x,int y)
{
  SDL_WarpMouse(x, y);
}

MAFCursorModelGL::MAFCursorModelGL(MAFApplication* application)
{
  mApplication=application;
  if (!application)
    g_error("MAFCursorModelGL::MAFCursorModelGL can't use gl cursor without application");
}
void MAFCursorModelGL::Init(MAFApplication* application, const std::string& base)
{
	const std::string& url = application->HeaderGet("sequence", base + "/@url");
	const std::string& node = application->HeaderGet("sequence", base + "/@node");
	MAFVisionData *visionData = application->mDatas->GetVision(url);
	g_assert(visionData);
	MAFOSGData* mouseData =  dynamic_cast<MAFOSGData *>(visionData);
	g_assert(mouseData);
	osg::Node* cursorGL = mouseData->GetNode(node);
	g_assert(cursorGL);
	mCursors.push_back(cursorGL); 

  mWarpMouseOccur=false;
  mPAT = new osg::PositionAttitudeTransform;
  osg::Quat q;

  // SHOULD BE PUT IN HUDGROUP INSTEAD

  osg::StateSet* stateset = mPAT->getOrCreateStateSet();
  stateset->setMode(GL_LIGHTING, osg::StateAttribute::OVERRIDE|osg::StateAttribute::OFF);
  // disable depth test, and make sure that the hud is drawn after everything 
  // else so that it always appears ontop.
  stateset->setMode(GL_DEPTH_TEST, osg::StateAttribute::OVERRIDE|osg::StateAttribute::OFF);
	{
	int rb = 11;
	VarsEditor::Instance().Get("RB_CursorGL",rb);
  stateset->setRenderBinDetails(rb,"RenderBin");
	}
  osg::Material *mat = new osg::Material;
  mat->setColorMode(osg::Material::AMBIENT_AND_DIFFUSE);
  stateset->setAttributeAndModes(mat, osg::StateAttribute::OVERRIDE|osg::StateAttribute::ON);
      
  // create the hud.
  osg::MatrixTransform* modelview_abs = new osg::MatrixTransform;
  modelview_abs->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
  modelview_abs->setMatrix(osg::Matrix::identity());
  modelview_abs->addChild(mPAT.get());
    
  osg::Projection *project = new osg::Projection;
  project->addChild(modelview_abs);
  project->setName("MAFCursor");
  mNode = project;
}
void MAFCursorModelGL::WarpMouse(int x,int y)
{ 
  mWarpMouseOccur=true;
  mWarpX=x;
  mWarpY=y;
}
void MAFCursorModelGL::UpdatePosition(int screenX, int screenY)
{
  struct ScreenToGL
  {
    static inline float doit(float screenPos, float screenL) {return screenPos*2.0f/screenL - 1.0f;}
  };
  float mX = ScreenToGL::doit(screenX*1.0,mApplication->GetWindow(true)->GetWidth());
  float mY = -ScreenToGL::doit(screenY*1.0, mApplication->GetWindow(true)->GetHeight());
  mPAT->setPosition(osg::Vec3(mX, mY, 0.0f));
}
void MAFCursorModelGL::Update(MAFApplication* application)
{
  if (mWarpMouseOccur) {
    UpdatePosition(mWarpX,mWarpY);
  }
  mWarpMouseOccur=false;
  mWarpX=mWarpY=0;
}
void MAFCursorModelGL::SetCursor(int cursor)
{
  g_assert(cursor>=0 && cursor<(int)mCursors.size());
  mPAT->removeChild(0,mPAT->getNumChildren());
  mPAT->addChild(mCursors[cursor].get());
}
void MAFCursorModelGL::ShowCursor(bool state)
{
  if (state)
    mPAT->setNodeMask(MAF_VISIBLE_MASK);
  else
    mPAT->setNodeMask(~(MAF_VISIBLE_MASK | MAF_COLLISION_MASK));

}
void MAFCursorModelGL::InitCursor()
{
  g_assert(mApplication);
  mApplication->GetScene()->GetModel()->mGroup->addChild(mNode.get());
  SDL_ShowCursor(SDL_DISABLE);
}
void MAFCursorModelGL::ReleaseCursor()
{
  g_assert(mApplication);
  mApplication->GetScene()->GetModel()->mGroup->removeChild(mNode.get());
  SDL_ShowCursor(SDL_ENABLE);
  mNode=0;
}
int MAFCursorModelGL::GetNbCursor()
{
  return mCursors.size();
}

MAFCursorModelAnimated::MAFCursorModelAnimated()
{
	mCurrentFrame = 0;
	mFrameTime = 500.0f;
	mCurrentTime = mFrameTime;
}
void MAFCursorModelAnimated::Init(MAFApplication* application, const std::string& base)
{
	const std::list<std::string>& names = application->HeaderGetList("sequence", base + "/cursor/@name");
	std::list<std::string>::const_iterator begin = names.begin(), end = names.end();
	while(begin != end)
		{
			std::string path = base + "/cursor[@name='" + *begin + "']";
			MAFCursorModel* model = MAFCursorModelFactory(application, path);
			model->Init(application, path);
			mFrames.push_back(model);
			begin++;
		}
}
void MAFCursorModelAnimated::SetCursor(int cursor)
{
	mFrames[mCurrentFrame]->SetCursor(0);
}
void MAFCursorModelAnimated::ShowCursor(bool state)
{
	mFrames[mCurrentFrame]->SetCursor(0);
}
void MAFCursorModelAnimated::WarpMouse(int x,int y)
{
	mFrames[mCurrentFrame]->WarpMouse(x, y);
}
void MAFCursorModelAnimated::Update(MAFApplication* application)
{
	if (mCurrentFrame >= 0)
		{
			mCurrentTime -= application->GetDeltaFrame();
			if (mCurrentTime < 0.0f)
				{
					//std::cout << mCurrentFrame << std::endl;
					mFrames[mCurrentFrame]->SetCursor(0);
					mCurrentFrame = (mCurrentFrame + 1) % mFrames.size();
					mFrames[mCurrentFrame]->SetCursor(0);
					mCurrentTime += mFrameTime;
				}
		}
}
void MAFCursorModelAnimated::InitCursor()
{
}
void MAFCursorModelAnimated::ReleaseCursor()
{
}
void MAFCursorModelAnimated::UpdatePosition(int x,int y)
{
	mFrames[mCurrentFrame]->UpdatePosition(x, y);
}

MAFCursorController::~MAFCursorController()
{
  ReleaseCursor();
}
MAFCursorController::MAFCursorController():mShowCursor(true)
{
}
void MAFCursorController::Init(MAFApplication* application)
{
  MAFController::Init();	
	const std::list<std::string>& names = application->HeaderGetList("sequence", "/sequence/cursors/cursor/@name");
	std::list<std::string>::const_iterator begin = names.begin(), end = names.end();
	while(begin != end)
		{
			std::string base = "/sequence/cursors";
			std::string name = *begin;
			std::string path = base + "/cursor[@name='" + name + "']";
			MAFCursorModel* model = MAFCursorModelFactory(application, path);
			model->Init(application, path);
			mModels[name] = model;
			begin++;
		}
}
void MAFCursorController::ShowCursor(bool state)
{
  GetModel()->ShowCursor(state);
  mShowCursor=state;
}
void MAFCursorController::InitCursor()
{
	if (GetModel())
		GetModel()->InitCursor();
}
void MAFCursorController::ReleaseCursor()
{
  GetModel()->ReleaseCursor();
}
void MAFCursorController::SetCursor(const std::string& cursor)
{
  mPreviousCursor=mCurrentCursor;
  mCurrentCursor=cursor;
	GetModel()->SetCursor(0);
}
int MAFCursorController::GetNbCursors()
{
  return GetModel()->GetNbCursor();
}
void MAFCursorController::RestoreCursor()
{
  std::string a=mCurrentCursor;
  mCurrentCursor=mPreviousCursor;
  mPreviousCursor=a;
  GetModel()->SetCursor(0);
}
void MAFCursorController::WarpMouse(int x,int y)
{
  GetModel()->WarpMouse(x,y);
}
bool MAFCursorController::Update(MAFApplication* application)
{
  SDL_Event*	event = application->GetLastEvent(this);
  if (event) {
    switch (event->type) {
    case SDL_MOUSEBUTTONDOWN:
      switch (event->button.button) {
      case SDL_BUTTON_LEFT:
	break;
      case SDL_BUTTON_RIGHT:
	break;
      }
      break;
    case SDL_MOUSEBUTTONUP:
      break;
    case SDL_MOUSEMOTION:
      GetModel()->UpdatePosition(event->motion.x,event->motion.y);
      break;
    }
  } else {
    GetModel()->Update(application);
  }
  return true;
}

