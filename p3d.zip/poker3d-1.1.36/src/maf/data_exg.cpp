/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Henry Precheur <henry at precheur dot org>
 *  Cedric Pinson <cpinson@freesheep.org>
 *  Igor kravtchenko <igor@tsarevitch.org>
 *
 */

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <cal3d/tinyxml.h>
#if CAL3D_VERSION >= 11
using namespace cal3d;
#endif

#ifdef USE_NPROFILE
#include <nprofile/profile.h>
#else  //USE_NPROFILE
#define NPROFILE_SAMPLE(a)
#endif //USE_NPROFILE

#include <maf/maferror.h>
#include <maf/billboard.h>
#include <maf/data.h>
#include <maf/camera.h>
#include <maf/MultipleAnimationPathCallback.h>
#include <maf/osghelper.h>
#include <maf/depthmask.h>
#include <maf/glow_fx.h>
#include <maf/shader.h>
#include <maf/shader_blinn.h>
#include <maf/shader_brdf.h>
#include <maf/shader_mosaic.h>
#include <maf/shader_orennayar.h>

#include <maf/glow_fx.h>
#include <maf/shadow.h>
#include <maf/emboss.h>
#include <maf/application.h>

#include <maf/monitor.h>

#include <sys/types.h>
#include <signal.h>

#include <glib.h>

#include <osgDB/FileNameUtils>
#include <osgDB/FileUtils>
#include <osgDB/Registry>
#include <osgDB/Input>
#include <osgDB/Output>
#include <osgDB/ReadFile>
#include <osgDB/WriteFile>

#include <osg/Node>
#include <osg/Group>
#include <osg/MatrixTransform>
#include <osg/Geode>
#include <osg/Matrix>
#include <osg/AutoTransform>
#include <osg/BlendFunc>
#include <osg/NodeVisitor>
#include <osg/Geometry>
#include <osg/Material>
#include <osg/Texture1D>
#include <osg/Texture2D>
#include <osg/TextureCubeMap>
#include <osg/StateSet>
#include <osg/Stencil>
#include <osg/Light>
#include <osg/LightModel>
#include <osg/LightSource>
#include <osg/Billboard>
#include <osg/Geode>
#include <osg/Drawable>
#include <osg/ShapeDrawable>
#include <osg/MatrixTransform>
#include <osg/LightSource>
#include <osg/LightModel>
#include <osg/PositionAttitudeTransform>
#include <osg/Geometry>
#include <osg/CullStack>
#include <osg/Fog>
#include <osg/NodeVisitor>
#include <osgUtil/TriStripVisitor>
#include <osgUtil/Optimizer>
#include <osg/TexEnvCombine>
#include <osg/TexGen>
#include <osg/TexMat>
#include <osg/Stencil>
#include <osg/VertexProgram>
#include <osg/FragmentProgram>

#include <osgText/Font>

#include <vserial/meshserializer.h>
#include <vserial/string.h>

#endif

#include <osgFX/Blinn>
#include <osgFX/GenericBRDF>

#include <maf/mesh.h>

MAF_EXPORT void MAFSaveTexture(osg::Texture2D *_tex)
{
	glBindTexture(GL_TEXTURE_2D, _tex->getTextureObject(0)->_id );

	unsigned char *tex = new unsigned char [64*64*3];
	glGetTexImage( GL_TEXTURE_2D, 0, GL_RGB, GL_UNSIGNED_BYTE, tex);

	delete [] tex;
}

#define MAX_LIGHT 7

static int nbTotalFaces=0;
static int nbTotalDrawable=0;


#define NEW_TEXTURE_LOADING


MAFESCNData::MAFESCNData(void)
{
	//  g_debug("MAFESCNData::MAFESCNData: 0x%08x", (int)this);
	mAmbientColor = osg::Vec4f(0, 0, 0, 1);
	mBackGroundColor = osg::Vec4f(0, 0, 0, 1);
	mFogColor = osg::Vec4f(0, 0, 0, 1);
	mbUseFog = false;
}

MAFESCNData::~MAFESCNData(void)
{
	//	g_assert(!mGroup.valid() || mGroup->referenceCount() <= 2);
	if (!(!mGroup.valid() || mGroup->referenceCount() <= 2))
		g_debug("fix me %s",mFile.c_str());

	assert(!mGroup.valid() || mGroup->referenceCount() <= 2);
	//	g_debug("MAFESCNData::~MAFESCNData: 0x%08x", (int)this);
}

// Data from escn file
bool MAFESCNData::Load(const std::string &path,
											 const std::string &dir,
											 const std::string &file,
											 osgDB::ReaderWriter::Options *options,
											 MAFMonitor *_mon)
{
	mCurrentLight = 0;
	mPath = path;
	mDir = dir;
	mFile = file;

	g_debug("MAFESCNData::Load: %s", path.c_str());

	if (_mon) {
		xmlDocPtr doc = xmlParseFile(path.c_str());
		xmlXPathContextPtr xpath = xmlXPathNewContext(doc);
		xmlXPathObjectPtr xpathObj;
		xpathObj = xmlXPathEvalExpression((xmlChar*)"/.//*/node[@type=\"mesh\"]", xpath);
		int nbMeshes = xpathObj->nodesetval->nodeNr;
		_mon->setProgressLength(nbMeshes);
	}

	mGroup = new osg::MatrixTransform;
	mGroup->setNodeMask(MAF_VISIBLE_MASK);

	TiXmlDocument doc;
	if (!doc.LoadFile(path.c_str()))
    {
      g_critical("MAFESCNData::Load:%s: object null", mPath.c_str());
      return false;
    }

	TiXmlElement * pRoot = doc.RootElement();
	if (NULL == pRoot)
    {
      g_critical("MAFESCNData::Load:%s: no root", mPath.c_str());
      return false;
    }

	TiXmlNode * pChild = NULL ;
	while ((pChild = pRoot->IterateChildren(pChild)))
    {
      TiXmlElement * pElt = pChild->ToElement() ;
      if (NULL != pElt)
        {
          std::string strTag = pElt->Value();
          if (strTag == "node")
            {
              Convert(pElt, mGroup.get(), mPath, options, _mon);
            }
        }
      else
        {
          g_critical("MAFESCNData::Load:%s: node root element", mPath.c_str());
        }
    }

	mGroup->setName(path);

	osg::LightModel *lightmodel = new osg::LightModel();
	lightmodel->setAmbientIntensity( osg::Vec4f(mAmbientColor[0], mAmbientColor[1], mAmbientColor[2], mAmbientColor[3]) );
	mGroup->getOrCreateStateSet()->setAttributeAndModes(lightmodel);

	g_debug("MAFESCNData::Load: Total faces %d with %d drawables", nbTotalFaces, nbTotalDrawable);
	return true;
}

osg::Node* MAFESCNData::Convert(TiXmlElement *pElt,
																osg::Group *parent,
																const std::string &parentPath,
																osgDB::ReaderWriter::Options *options,
																MAFMonitor *_mon)
{
	if (!pElt)
		return NULL;

	osg::Node * node = NULL;
	const char * szNodeType = pElt->Attribute("type");
	const char * szNodeName = pElt->Attribute("name");
	g_debug("\t%s", szNodeName);

	if (!strcmp(szNodeType, "camera")) {
		MAFCameraController * camera = new MAFCameraController(0);
		camera->Init();
		MAFCameraModel * camera_model = camera->GetModel();
		camera_model->SetName(szNodeName);
/*
		exg::Matrix4f cmat;
		getAttribute(pElt, "matrix", cmat);
		osg::Matrixf mm = convert(cmat);
*/

		osg::Matrixf mm;
		getAttribute(pElt, "matrix", mm);

		camera_model->SetPosition(osg::Vec3(mm(3, 0), mm(3, 1), mm(3, 2)) );

		osg::Vec4f tgp;
		getAttribute(pElt, "target_pos", tgp);
		camera_model->SetTarget(osg::Vec3(tgp[0],tgp[1],tgp[2])); 
		camera_model->SetRoll(0);

		float fov = atof(pElt->Attribute("fov"));
		camera_model->SetFov(fov);

		float zNear = atof(pElt->Attribute("near_plane"));
		camera_model->SetNear(zNear);

		float zFar = atof(pElt->Attribute("far_plane"));
		camera_model->SetFar(zFar);

		if (pElt->Attribute("fog_near_plane")) {
		  float fogNear = atof(pElt->Attribute("fog_near_plane"));
		  camera_model->SetFogNear(fogNear);
		}

		if (pElt->Attribute("fog_far_plane")) {
		  float fogFar = atof(pElt->Attribute("fog_far_plane"));
		  camera_model->SetFogFar(fogFar);
		}

		camera_model->SetMatrix(mm);

		mCameras[szNodeName] = camera;
	}
	else if (!strcmp(szNodeType, "group")) {

		node = new osg::Group;
		node->setNodeMask(MAF_VISIBLE_MASK);

		if (node) {
			TiXmlNode * pChild = NULL;

			while ((pChild = pElt->IterateChildren(pChild))) {
				TiXmlElement * pChildElt = pChild->ToElement();

				if (pChildElt) {
					std::string strTag = pChildElt->Value();
					if (strTag == "node") {
						Convert(pChildElt, static_cast<osg::Group*>(node), parentPath, options, _mon);
					}
				}
			}
		}
	}
	else if (!strcmp(szNodeType, "transform")) {

		const char * szBillboardType = pElt->Attribute("billboard_type");

		if (!strcmp(szBillboardType, "none")) {
			osg::MatrixTransform* matrixTransform = new osg::MatrixTransform;
			osg::Matrixf mt;
			getAttribute(pElt, "matrix", mt);
			/*
			osg::Matrix mt(m[0][0],m[1][0],m[2][0],m[3][0],
                     m[0][1],m[1][1],m[2][1],m[3][1],
                     m[0][2],m[1][2],m[2][2],m[3][2],
                     m[0][3],m[1][3],m[2][3],m[3][3]);
*/
			matrixTransform->setMatrix(mt);
			node = matrixTransform;
		}
		else if (!strcmp(szBillboardType, "plane_facing")) {
			g_debug("\t\tautoTransform type plane facing");

			MAFBillBoard *transform = new MAFBillBoard;
			transform->setActive(false);

			node = transform;
		}
		else if (!strcmp(szBillboardType, "center_facing")) {
			g_debug("\t\tautoTransform type center facing");
			osg::AutoTransform *bb = new osg::AutoTransform;
			node = bb;
		}

		if (node) {
			TiXmlNode *pChild = NULL;

			node->setNodeMask(MAF_VISIBLE_MASK);

			while ((pChild = pElt->IterateChildren(pChild))) {
				TiXmlElement * pChildElt = pChild->ToElement();
				if (pChildElt) {
					std::string strTag = pChildElt->Value();
					if (strTag == "node") {
						Convert(pChildElt, static_cast<osg::Group*>(node), parentPath, options, _mon);
					}
					else if (strTag == "animation") {
						if (!ParseAnimation(pChildElt, static_cast<osg::Group*>(node))) {
							g_error("MAFESCNData::Convert: failed to exg::Load %s [ParseAnimation]", parentPath.c_str());
						}
					}
					else if (strTag == "matrix") {
					}
				}
			}
		}
	}

	// Note about lights: in the EXG file format, a light IS A transformation.
	// However this is not the case in the engine...

	else if (!strcmp(szNodeType, "light")) {
	}
	else if (!strcmp(szNodeType, "light_directional")) {
		osg::Matrixf mt;
		osg::Vec4f color;

		getAttribute(pElt, "matrix", mt);
		getAttribute(pElt, "color", color);

		/*
		exg::Matrix4f m;
		exg::Vector4f col;
		getAttribute(pElt, "matrix", m);
		getAttribute(pElt, "color", col);

		osg::Vec4 color(col[0], col[1], col[2], 1);

		osg::Matrix mt(m[0][0],m[1][0],m[2][0],m[3][0],
                   m[0][1],m[1][1],m[2][1],m[3][1],
                   m[0][2],m[1][2],m[2][2],m[3][2],
                   m[0][3],m[1][3],m[2][3],m[3][3]);
*/
		osg::LightSource *ls = new osg::LightSource();
		osg::Light *lgt = new osg::Light();
		lgt->setLightNum( mCurrentLight );
		lgt->setAmbient( OSGVEC4F_BLACK );
		lgt->setDiffuse(color);
		lgt->setSpecular(color);

		osg::Vec4f dir(-mt(0, 1), mt(1, 1), -mt(2, 1), 0);
		lgt->setPosition( dir );
		ls->setLight(lgt);

		ls->getOrCreateStateSet()->setMode(GL_LIGHT0 + mCurrentLight, osg::StateAttribute::ON);

		mCurrentLight++;
		node = ls;
	}
	else if (!strcmp(szNodeType, "light_omni")) {
	  //		const char *name = pElt->Attribute("name");

	  //		osg::MatrixTransform *lgtMatrix = new osg::MatrixTransform();
		/*
		exg::Matrix4f m;
		exg::Vector4f col;
		getAttribute(pElt, "matrix", m);
		getAttribute(pElt, "color", col);

		osg::Vec4 color(col[0], col[1], col[2], 1);

		osg::Matrix mt(m[0][0],m[1][0],m[2][0],m[3][0],
                   m[0][1],m[1][1],m[2][1],m[3][1],
                   m[0][2],m[1][2],m[2][2],m[3][2],
                   m[0][3],m[1][3],m[2][3],m[3][3]);
*/

		osg::Matrixf mt;
		osg::Vec4f color;
		getAttribute(pElt, "matrix", mt);
		getAttribute(pElt, "color", color);

		osg::LightSource *ls = new osg::LightSource();
		osg::Light *lgt = new osg::Light();
		lgt->setLightNum( mCurrentLight );
		lgt->setAmbient( OSGVEC4F_BLACK );
		lgt->setDiffuse( color );
		lgt->setSpecular( color);

		osg::Vec4f pos(mt(3, 0), mt(3, 1), mt(3, 2), 1);
		//osg::Vec4f pos(0, 1000, 0, 1);
		//osg::Vec4f pos(1, 0, 0, 0);
		lgt->setPosition( pos );
		ls->setLight(lgt);

		ls->getOrCreateStateSet()->setMode(GL_LIGHT0 + mCurrentLight, osg::StateAttribute::ON);

		mCurrentLight++;
		node = ls;
	}
	else if (!strcmp(szNodeType, "light_spot")) {
	}
	else if (!strcmp(szNodeType, "mesh")) {
		std::string filename;
		char szFileName[512];
		const char *fn = pElt->Attribute("file_name");
		strcpy(szFileName, fn);

		bool isLighted = false;
		bool isGlow = false;

		const char *lighted = pElt->Attribute("lighted");
		const char *glow = pElt->Attribute("glow");
		const char *far_object = pElt->Attribute("far_object");

		if (lighted && !stricmp(lighted, "1"))
			isLighted = true;

		if (glow && !stricmp(glow, "1"))
			isGlow = true;

		if (strstr(szFileName, ".umesh")) {

			underware::Mesh *mesh;
			std::string fullname = underware::obtainFilename(szFileName, mDir.c_str());
			gchar *basePath = g_path_get_dirname( (const gchar*) fullname.c_str());

			bool res = underware::MeshSerializer::load(szFileName, mDir.c_str(), &mesh);
			if (res) {
				osg::Geode *geode = MAFMesh::convertUMH(*mesh, basePath, !isLighted);
				node = geode;
			}

			if (_mon)
				_mon->progress();

		}

		if(node) {
			osg::StateSet *state = node->getOrCreateStateSet();

			if (isLighted)
				state->setMode(GL_LIGHTING, osg::StateAttribute::ON);
			else
				state->setMode(GL_LIGHTING, osg::StateAttribute::OFF);

			if (isGlow) {
				MAFGlowFX::markNodeAsGlowing(node, true);
			}

			state->setMode(GL_CULL_FACE, osg::StateAttribute::ON);

			if (far_object && !stricmp(far_object, "1")) {
				state->setRenderBinDetails(10000, "RenderBin");
				DepthMask *dp = new DepthMask(false);
				state->setAttributeAndModes(dp);
			}
		}

	}
	else if (!strcmp(szNodeType, "ambient")) {
		getAttribute(pElt, "color", mAmbientColor);
	}
	else if (!strcmp(szNodeType, "background")) {
		getAttribute(pElt, "color", mBackGroundColor);
	}
	else if (!strcmp(szNodeType, "fog")) {
		getAttribute(pElt, "color", mFogColor);
		mbUseFog = true;
	}

	if (node) {
		if (szNodeName)
			node->setName(szNodeName);

		if (parent)
			parent->addChild(node);
	}

	return node;
}

void MAFESCNData::getAttribute(TiXmlElement * pElt, const std::string & strName, osg::Matrixf & m)
{
	TiXmlNode * pChild = NULL ;

	while ((pChild = pElt->IterateChildren(pChild)))
	{
		TiXmlElement * pChildElt = pChild->ToElement();
		if (NULL != pChildElt)
		{
			std::string strTag = pChildElt->Value();
			if (strTag == strName)
			{
				TiXmlNode * pMatrixChild = NULL ;
				while ((pMatrixChild = pChildElt->IterateChildren(pMatrixChild)))
				{
					TiXmlElement * pMatrixChildElt = pMatrixChild->ToElement();
					if (NULL != pMatrixChildElt)
					{
						std::string strTag = pMatrixChildElt->Value();
						if (strTag == "l1") 
						{
							m(0, 0) = atof(pMatrixChildElt->Attribute("x"));
							m(1, 0) = atof(pMatrixChildElt->Attribute("y"));
							m(2, 0) = atof(pMatrixChildElt->Attribute("z"));
							m(3, 0) = atof(pMatrixChildElt->Attribute("w")); 
						}

						if (strTag == "l2") 
						{
							m(0, 1) = atof(pMatrixChildElt->Attribute("x"));
							m(1, 1) = atof(pMatrixChildElt->Attribute("y"));
							m(2, 1) = atof(pMatrixChildElt->Attribute("z"));
							m(3, 1) = atof(pMatrixChildElt->Attribute("w"));
						}

						if (strTag == "l3")
						{
							m(0, 2) = atof(pMatrixChildElt->Attribute("x"));
							m(1, 2) = atof(pMatrixChildElt->Attribute("y"));
							m(2, 2) = atof(pMatrixChildElt->Attribute("z"));
							m(3, 2) = atof(pMatrixChildElt->Attribute("w"));
						}

						if (strTag == "l4")
						{
							m(0, 3) = atof(pMatrixChildElt->Attribute("x"));
							m(1, 3) = atof(pMatrixChildElt->Attribute("y"));
							m(2, 3) = atof(pMatrixChildElt->Attribute("z"));
							m(3, 3) = atof(pMatrixChildElt->Attribute("w"));
						}
					}
				}
			}
		}
	}
}

void MAFESCNData::getAttribute(TiXmlElement * pElt, const std::string & strName, osg::Vec4f & v)
{
	TiXmlNode * pChild = NULL ;

	while ((pChild = pElt->IterateChildren(pChild)))
    {
      TiXmlElement * pChildElt = pChild->ToElement() ;
      if (NULL != pChildElt)
        {
          std::string strTag = pChildElt->Value();
          if (strTag == strName)
            {
              v[0] = atof(pChildElt->Attribute("x"));
              v[1] = atof(pChildElt->Attribute("y"));
              v[2] = atof(pChildElt->Attribute("z"));
              v[3] = atof(pChildElt->Attribute("w"));
            }
        }
    }
}

void MAFESCNData::setupRootStateSet(osg::StateSet *_ss)
{
	osg::LightModel *lightmodel = new osg::LightModel();
	lightmodel->setAmbientIntensity( osg::Vec4f(mAmbientColor[0], mAmbientColor[1], mAmbientColor[2], mAmbientColor[3]) );
	_ss->setAttributeAndModes(lightmodel);

	_ss->setMode(GL_LIGHTING, osg::StateAttribute::ON);
	_ss->setMode(GL_ALPHA_TEST, osg::StateAttribute::OFF);
	_ss->setMode(GL_CULL_FACE, osg::StateAttribute::ON);
}


class CTimeBlock
{
public:

	explicit CTimeBlock(void)
	{

	}

	CTimeBlock(const CTimeBlock & tb)
	{
		(*this)=tb;
	}

	void operator = (const CTimeBlock & tb)
	{
		m_strName = tb.m_strName;
		startTime = tb.startTime;
		endTime = tb.endTime;
	}

	std::string m_strName;
	float startTime;
	float endTime;

};




static int FindKeyIn(const std::vector<float>& lTimes, float wanted)
{
  int end = lTimes.size();
  int currentIndex = 0;

  while(currentIndex < end - 1) {
    float val = lTimes[currentIndex];
    if (val >= wanted && val < lTimes[currentIndex+1])
      return currentIndex;
    currentIndex++;
  }

  return end - 1;
}

bool MAFESCNData::ParseAnimation(TiXmlElement * pElt, osg::Group* parent)
{
	if (NULL == parent)
    {
      return(false);
    }

	if (NULL == pElt)
    {
      return(false);
    }

	//
	// For the moment, assume that all the track have the same number of keys.
	// In the future, it could be great to be able to have separated controllers in AnimationPaths
	std::vector<float> lTimes;
	std::vector<osg::Vec3f> lPos;
	std::vector<osg::Quat> lRot;
	std::vector<osg::Vec3f> lScl;
	std::vector<CTimeBlock> lTimeBlocks;

	TiXmlNode * pAnimationChild = NULL ;
	while ((pAnimationChild = pElt->IterateChildren(pAnimationChild)))
    {
      TiXmlElement * pAnimationChildElt = pAnimationChild->ToElement();
      if (NULL != pAnimationChildElt)
        {
          std::string strTag = pAnimationChildElt->Value();
			
          if (strTag == "track_position")
            {

              TiXmlNode * pTrackPosChild = NULL;
              while ((pTrackPosChild = pAnimationChildElt->IterateChildren(pTrackPosChild)))
                {
                  TiXmlElement * pTrackPosChildElt = pTrackPosChild->ToElement();

                  if (NULL != pTrackPosChildElt)
                    {
                      std::string strTag = pTrackPosChildElt->Value();
                      if (strTag == "key")
                        {
                          //
                          // time
                          float time = atof(pTrackPosChildElt->Attribute("time"));
                          lTimes.push_back(time);

                          //
                          // posX, posY, posZ
                          float posX = atof(pTrackPosChildElt->Attribute("x"));
                          float posY = atof(pTrackPosChildElt->Attribute("y"));
                          float posZ = atof(pTrackPosChildElt->Attribute("z"));
                          lPos.push_back(osg::Vec3f(posX, posY, posZ));
                        }
                    }
                }
            }
          else if (strTag == "track_rotation")
            {
              TiXmlNode * pTrackRotChild = NULL;
              while ((pTrackRotChild = pAnimationChildElt->IterateChildren(pTrackRotChild)))
                {
                  TiXmlElement * pTrackRotChildElt = pTrackRotChild->ToElement();
                  if (NULL != pTrackRotChildElt)
                    {
                      std::string strTag = pTrackRotChildElt->Value();
                      if (strTag == "key")
                        {
                          //
                          // rotX, rotY, rotZ, rotW
                          float rotX = atof(pTrackRotChildElt->Attribute("x"));
                          float rotY = atof(pTrackRotChildElt->Attribute("y"));
                          float rotZ = atof(pTrackRotChildElt->Attribute("z"));
                          float rotW = atof(pTrackRotChildElt->Attribute("w"));
                          lRot.push_back(osg::Quat(rotX, rotY, rotZ, rotW));
                        }
                    }
                }
            }
          else if (strTag == "track_scale")
            {
              TiXmlNode * pTrackSclChild = NULL;
              while ((pTrackSclChild = pAnimationChildElt->IterateChildren(pTrackSclChild)))
                {
                  TiXmlElement * pTrackSclChildElt = pTrackSclChild->ToElement();
                  if (NULL != pTrackSclChildElt)
                    {
                      std::string strTag = pTrackSclChildElt->Value();
                      if (strTag == "key")
                        {
                          //
                          // sclX, sclY, sclZ
                          float sclX = atof(pTrackSclChildElt->Attribute("x"));
                          float sclY = atof(pTrackSclChildElt->Attribute("y"));
                          float sclZ = atof(pTrackSclChildElt->Attribute("z"));
                          lScl.push_back(osg::Vec3f(sclX, sclY, sclZ));
                        }
                    }
                }
            }
          else if (strTag == "timeblocks")
            {
              TiXmlNode * pTrackTBChild = NULL;
              while ((pTrackTBChild = pAnimationChildElt->IterateChildren(pTrackTBChild)))
                {
                  TiXmlElement * pTrackTBChildElt = pTrackTBChild->ToElement();
                  if (NULL != pTrackTBChildElt)
                    {
                      std::string strTag = pTrackTBChildElt->Value();
                      if (strTag == "timeblock")
                        {
                          CTimeBlock tb;
                          tb.m_strName = pTrackTBChildElt->Attribute("name");
                          tb.startTime = atof(pTrackTBChildElt->Attribute("start_time"));
                          tb.endTime   = atof(pTrackTBChildElt->Attribute("end_time"));
                          lTimeBlocks.push_back(tb);
                        }
                    }
                }
            }
        }
    }

	//
	// Create AnimationPaths
	if (lTimeBlocks.size() == 0)
    {
      CTimeBlock tb;
      tb.m_strName="noname";
      tb.startTime=lTimes.front();
      tb.endTime=lTimes.back();
    }

  // 	else
	{
		osg::MultipleAnimationPathCallback * pMultipleAnimationPathCallBack = new osg::MultipleAnimationPathCallback;//(pAnimationPath);
		g_assert(NULL != pMultipleAnimationPathCallBack);

		for (unsigned int nTimeBlock = 0 ; nTimeBlock < lTimeBlocks.size() ; ++nTimeBlock)
      {
        osg::AnimationPath * pAnimationPath = new osg::AnimationPath();
        pAnimationPath->setLoopMode(osg::AnimationPath::LOOP);

        const CTimeBlock & tb = lTimeBlocks[nTimeBlock];

        int startKey=FindKeyIn(lTimes,tb.startTime);
        int endKey=FindKeyIn(lTimes,tb.endTime);
        for (int nKey = startKey ; nKey <= endKey ; ++nKey) {
          osg::Vec3f    pos = lPos[nKey];
          osg::Quat rot = lRot[nKey];
          osg::Vec3f    scl = lScl[nKey];
          float time = lTimes[nKey] - lTimes[startKey];
			  
          osg::Vec3 position(pos[0], pos[1], pos[2]);
          osg::Quat rotation(rot[0], rot[1], rot[2], rot[3]);
          osg::Vec3 scale(scl[0], scl[1], scl[2]);
			  
          osg::AnimationPath::ControlPoint controlPoint(position, rotation, scale);
          pAnimationPath->insert(time, controlPoint);
        }

        pMultipleAnimationPathCallBack->addAnimationPath(tb.m_strName, pAnimationPath);
      }

		//
		// Set paused by default
		pMultipleAnimationPathCallBack->setPause(true);

		//
		// affect animation callback to the node
		parent->setUpdateCallback(pMultipleAnimationPathCallBack);
		parent->setDataVariance(osg::Object::DYNAMIC);
	}

	return(true);
}

//
// OSG interface to read from a file.
//
class ReaderWriterexg : public osgDB::ReaderWriter {
public:
  virtual const char* className() { return "escn object reader"; }

  virtual bool acceptsExtension(const std::string& extension) const {
    return osgDB::equalCaseInsensitive(extension, "escn");
  }

  virtual ReadResult readNode(const std::string& fileName, const Options* options = NULL) const {
    std::string ext = osgDB::getLowerCaseFileExtension(fileName);
    if (!acceptsExtension(ext)) return ReadResult::FILE_NOT_HANDLED;

    std::string path = osgDB::findDataFile(fileName, options);
    if(path.empty()) return ReadResult::FILE_NOT_FOUND;

    std::string dir = g_dirname(fileName.c_str());
    std::string file = g_basename(fileName.c_str());

    MAFESCNData * data = new MAFESCNData();
    data->Load(fileName, dir, file, const_cast<Options*>(options));

    ReadResult result(data->GetGroup());

    delete data;

    return result;
  }

};

static osgDB::RegisterReaderWriterProxy<ReaderWriterexg> static_readerWriter_exg_Proxy;
