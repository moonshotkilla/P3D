/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <memory.h>
#include <vector>

#include <glib.h>

#include <vserial/vserial.h>
#include <vserial/rle.h>
#endif

ENTER_NAMESPACE_UNDERWARE

RLE::EncodeRes RLE::encode(void *_mem, int _size)
{
	int i;
	int occus[256];

	if (_mem == NULL) {
		g_warning("RLE:encode - encoded buffer is NULL pointer");
		return EncodeRes(NULL, 0, 0);
	}

	if (_size < 2) {
		g_warning("RLE:encode - encoded buffer should be as least 2 byte length");
		return EncodeRes(NULL, 0, 0);
	}

	// search for the best key
	memset(occus, 0, sizeof occus);

	for (i = 0; i < _size; i++) {
		unsigned char byte = ((unsigned char *)_mem)[i];
		occus[byte]++;
	}

	unsigned char key;
	int minOccu = INT_MAX;
	for (i = 0; i < 256; i++) {
		int occu = occus[i];
		if (occu < minOccu) {
			minOccu = occu;
			key = i;
			if (occu == 0)
				break; // unbeatable key
		}
	}

	// now compress with that key

	void *dst = malloc(_size * 2);
	char *dstbuf = (char*) dst;

	unsigned char byte = ((unsigned char *)_mem)[0];
	unsigned char next_byte;
	int nbOccus = 1;
	for (i = 0; i < _size; i++) {

		if (i+1 < _size && nbOccus < 65535) {
			next_byte = ((unsigned char *)_mem)[i+1];
			if (next_byte == byte) {
				nbOccus++;
				continue;
			}
		}

		if (nbOccus < 4 && byte != key) {
			while(nbOccus-- > 0)
				*dstbuf++ = byte;
			byte = next_byte;
			nbOccus = 1;
			continue;
		}

		*dstbuf++ = key;
		*dstbuf++ = byte;
		*((unsigned short*)dstbuf) = nbOccus;
		dstbuf += 2;
		byte = next_byte;
		nbOccus = 1;
	}

	int crunched_size = dstbuf - ((char*)dst);
	void *crunched_buf = malloc(crunched_size);
	memcpy(crunched_buf, dst, crunched_size);
	free(dst);

	return EncodeRes(crunched_buf, crunched_size, key);
}

RLE::DecodeRes RLE::decode(void *_mem, int _size, char _key)
{
	std::vector<char> decrunched;

	if (_mem == NULL) {
		g_warning("RLE:decode - encoded buffer is NULL pointer");
		return DecodeRes(NULL, 0);
	}

	if (_size < 2) {
		g_warning("RLE:decode - size of encoded buffer should be at least 2 bytes length");
		return DecodeRes(NULL, 0);
	}

	char *src = (char*) _mem;
	while(_size > 0) {

		char byte = *src++;
		_size--;

		if (byte != _key) {
			decrunched.push_back(byte);
		}
		else {
			char val = *src++;
			unsigned short nbOccus = *((unsigned short*)src);
			src += 2;
			_size -= 3;
			while(nbOccus-- > 0)
				decrunched.push_back(val);
		}
	}

	int size = decrunched.size();
	void *final = malloc(size);
	memcpy(final, &decrunched[0], size);
	return DecodeRes(final, size);
}

RLE::DecodeRes RLE::decode(void *_mem, int _size, char _key, int _orgSize)
{
	if (_mem == NULL) {
		g_warning("RLE:decode - encoded buffer is NULL pointer");
		return DecodeRes(NULL, 0);
	}

	if (_size < 2) {
		g_warning("RLE:decode - size of encoded buffer should be at least 2 bytes length");
		return DecodeRes(NULL, 0);
	}

	void *decrunched = malloc(_orgSize);
	char *ptr = (char*) decrunched;
	char *src = (char*) _mem;

	while(_size > 0) {

		char byte = *src++;
		_size--;

		if (byte != _key) {
			*ptr++ = byte;
		}
		else {
			unsigned char val = (unsigned char) *src++;
			unsigned short nbOccus = *((unsigned short*)src);
			src += 2;
			_size -= 3;

			int nbBlocksOf4 = nbOccus >> 2;
			int nbBlocksOf1 = nbOccus & 0x3;

			int dword = val | (val << 8);
			dword |= dword << 16;

			while(nbBlocksOf4-- > 0) {
				*((int*)ptr) = dword;
				ptr += 4;
			}

			while(nbBlocksOf1-- > 0)
				*ptr++ = val;
		}
	}

	return DecodeRes(decrunched, _orgSize);
}

LEAVE_NAMESPACE
