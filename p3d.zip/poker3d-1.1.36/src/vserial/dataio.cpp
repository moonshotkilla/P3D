/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>
#include <vserial/dataio.h>

#include <glib.h>
#include <assert.h>
#include <math.h>
#include <cstring>
#include <cerrno>
#endif

#ifdef WIN32
#include <winsock.h>
#else
#include <netinet/in.h>
#endif

ENTER_NAMESPACE_UNDERWARE

// convert from a "standard" float32 (IEEE754 formated) to local FPU intern protocol and vice-versa
#ifndef FPU_IEEE754
static int float2buffer(float x, unsigned char *p, int littleEndian);
static float buffer2float(const unsigned char *p, int littleEndian);
#endif //FPU_IEEE754

// DATA IN

DataIn::DataIn()
{
	fileHandle_ = NULL;
	mem_ = NULL;
	memSize_ = 0;
	byteOff_ = 0;
};

DataIn::~DataIn()
{
};

bool DataIn::open(const std::string &_fileName)
{
	input_ = SOURCE_DISK;
	fileName_ = _fileName;

	fileHandle_ = fopen(fileName_.c_str(), "rb");
	if (fileHandle_ == NULL) {
		g_critical("dataio.cpp: DataIn::open - cannot open file (\"%s\") - system error %s", fileName_.c_str(), strerror(errno));
		return false;
	}

	byteOff_ = 0;
	return true;
}

void DataIn::open(void *_mem, int _size)
{
	input_ = SOURCE_MEMORY;
	mem_ = (char*) _mem;
	memSize_ = _size;
}

DataIn::SOURCE_TYPE DataIn::getSourceType() const
{
	return input_;
}

bool DataIn::close()
{
	if (input_ == SOURCE_DISK) {
		if (fileHandle_ && fclose(fileHandle_) != 0)
			return false;
	}
	fileHandle_ = NULL;

	return true;
}

bool DataIn::isOpen() const
{
	if (input_ == SOURCE_DISK)
		return fileHandle_ ? true : false;
	else
		return true;
}

bool DataIn::eof() const
{
	if (input_ == SOURCE_DISK)
		return feof(fileHandle_) == 0 ? false : true;

	return byteOff_ >= getSize() ? true : false;
}

bool DataIn::error() const 
{
	if (input_ == SOURCE_DISK)
		return ferror(fileHandle_) == 0 ? false : true;
	return false;
}

const std::string& DataIn::getFileName() const
{
	return fileName_;
}

bool DataIn::advance(int _n)
{
	if (input_ == SOURCE_DISK)
		return fseek(fileHandle_, _n, SEEK_CUR);
	byteOff_ += _n;
	return true;
}

bool DataIn::seek(int _n)
{
	if (input_ == SOURCE_DISK) {
		if (fseek(fileHandle_, _n, SEEK_SET) == 0)
			return true;
	}
	else {
		if (byteOff_ < 0 || byteOff_ > memSize_)
			return false;
		else {
			byteOff_ = _n;
			return true;
		}
	}

	return false;
}

int DataIn::tell() const
{
	if (input_ == SOURCE_DISK)
		return ftell( fileHandle_ );
	return byteOff_;
}

int DataIn::getSize() const
{              
	int res;
	if (input_ == SOURCE_DISK) {
		int savePos, fileSize;
		savePos = ftell( fileHandle_ );
		res = fseek(fileHandle_, 0L, SEEK_END);
		fileSize = ftell( fileHandle_ );
		res = fseek(fileHandle_, savePos, SEEK_SET);
		return fileSize;
	}
	return memSize_;
}

int DataIn::read(void *_dest, int _nbBytes)
{
	if (input_ == SOURCE_DISK) {
		size_t nbRead;
		nbRead = fread(_dest, 1, _nbBytes, fileHandle_);
		if (nbRead != (size_t)_nbBytes)
		  g_warning("dataio.cpp: DataIn::read - %d bytes read instead of %ld in file (\"%s\")", (int)nbRead, (long int)_nbBytes, fileName_.c_str());
		if (ferror(fileHandle_))
			g_critical("dataio.cpp: DataIn::read - read error in file (\"%s\") - system error %s", fileName_.c_str(), strerror(errno));
		return nbRead;
	}

	size_t toRead;
	if (byteOff_ + _nbBytes <= memSize_)
		toRead = _nbBytes;
	else
		toRead = memSize_ - byteOff_;

	if (toRead == 0)
		return 0;
	memcpy(_dest, (char*)mem_ + byteOff_, toRead);
	byteOff_ += toRead;
	return toRead;
}

int DataIn::readStrZ(char *_dest)
{
	char *buf = _dest;
	int nb = 0;
	while(!eof() && !error()) {
		char c = readByte(); nb++;
		*buf++ = c;
		if (!c)
			break;
	}
	return nb;
}

char DataIn::readByte()
{
	char c = 0;
	int res = read(&c, 1); 
	if (res != 1) {
		g_critical("DataIn::readByte() failed");
		c = 0;
	}

	return c;
}

short DataIn::readWord()
{
	short s = 0;
	int res = read(&s, 2);
	if (res != 2) {
		g_critical("DataIn::readWord() failed, read %d instead of 2", res);
		s = 0;
	}
	return ntohs(s);
}

int DataIn::readDword()
{
	int i = 0;
	int res = read(&i, 4);
	if (res != 4) {
		g_critical("DataIn::readDword() failed, read %d instead of 4", res);
		i = 0;
	}
	return ntohl(i);
}

float DataIn::readFloat()
{
	int a;
	int res = read(&a, 4);
	if (res != 4) {
		g_critical("DataIn::readFloat() failed, read %d instead of 4", res);
		return 0.0f;
	}

	float f;
#ifdef FPU_IEEE754
	int n = ntohl(a);
	memcpy(&f, &n, 4);
#else
	f = buffer2float((const unsigned char*)&a, 0);
#endif

	return f;
}

// DATA OUT

DataOut::DataOut()
{
	fileHandle_ = NULL;
};

DataOut::~DataOut()
{
};

bool DataOut::open(const std::string &_fileName)
{
	fileName_ = _fileName;

	fileHandle_ = fopen(fileName_.c_str(), "wb");
	if (fileHandle_ == NULL) {
		g_critical("dataio.cpp: DataOut::open - cannot open file (\"%s\") - system error %s", fileName_.c_str(), strerror(errno));
		return false;
	}

	return true;
}

bool DataOut::close()
{
	if (fileHandle_ && fclose(fileHandle_) != 0)
		return false;
	fileHandle_ = NULL;
	return true;
}

bool DataOut::isOpen() const
{
	return fileHandle_ ? true : false;
}

bool DataOut::eof() const
{
	return feof(fileHandle_) == 0 ? false : true;
}

const std::string& DataOut::getFileName() const
{
	return fileName_;
}

bool DataOut::advance(int _n)
{
	int res = fseek(fileHandle_, _n, SEEK_CUR);
	if (res) {
		g_critical("dataio.cpp: DataOut::advance - cannot advance in file (\"%s\") - system error %s", fileName_.c_str(), strerror(errno));
		return false;
	}
	return true;
}

bool DataOut::seek(int _n)
{
	int res = fseek(fileHandle_, _n, SEEK_SET);
	if (res) {
		g_critical("dataio.cpp: DataOut::seek - cannot seek in file (\"%s\") - system error %s", fileName_.c_str(), strerror(errno));
		return false;
	}
	return true;
}

int DataOut::tell() const
{
	return ftell( fileHandle_ );
}

int DataOut::write(const void *_src, int _nbBytes)
{
	int res =  fwrite(_src, 1, _nbBytes, fileHandle_);
	if (res != _nbBytes)
		g_critical("dataio.cpp: DataIn::write - cannot write to file (\"%s\") - system error %s", fileName_.c_str(), strerror(errno));
	return res;
}

int DataOut::writeStr(const char *_str)
{
	return write((const void*)_str, strlen(_str));
}

int DataOut::writeStrZ(const char *_str)
{
	int res = 0;
	int nb = strlen(_str);
	if (nb)
		res = fwrite(_str, 1, nb, fileHandle_);
	res = fputc(0, fileHandle_);
	if (res == EOF)
		g_critical("dataio.cpp: DataIn::writeStrZ - cannot write to file (\"%s\") - system error %s", fileName_.c_str(), strerror(errno));
	res++;
	return res;
}

int DataOut::writeByte(char _val)
{
	return write(&_val, 1);
}

int DataOut::writeWord(short _val)
{
	short n = htons(_val);
	return write(&n, 2);
}

int DataOut::writeDword(int _val)
{
	int n = htonl(_val);
	return write(&n, 4);
}

int DataOut::writeFloat(float _val)
{
#ifndef FPU_IEEE754
	unsigned char ieee[4];
	float2buffer(_val, ieee, 0);
	return write(ieee, 4);
#else
	int i;
	memcpy(&i, &_val, 4);
	int n = htonl(i);
	return write(&n, 4);
#endif
}

#ifndef FPU_IEEE754
static int float2buffer(float x, unsigned char *p, int littleEndian)
{
	unsigned char sign;
	int e;
	double f;
	unsigned int fbits;
	int incr = 1;

	if (littleEndian) {
		p += 3;
    incr = -1;
	}

	if (x < 0) {
		sign = 1;
    x = -x;
	}
	else
		sign = 0;

	f = frexp(x, &e);

	// Normalize f to be in the range [1.0, 2.0)
	if (0.5 <= f && f < 1.0) {
		f *= 2.0;
		e--;
	}
	else if (f == 0.0)
		e = 0;
	else {
		return -1;
	}

	if (e >= 128)
		goto overflow;
	else if (e < -126) {
		// Gradual underflow
		f = ldexp(f, 126 + e);
		e = 0;
	}
	else if (!(e == 0 && f == 0.0)) {
		e += 127;
		f -= 1.0; // Get rid of leading 1
	}

	f *= 8388608.0; // 2**23
	fbits = (unsigned int)(f + 0.5); /* Round */
	assert(fbits <= 8388608);
	if (fbits >> 23) {
		// The carry propagated out of a string of 23 1 bits.
		fbits = 0;
		++e;
		if (e >= 255)
			goto overflow;
	}

	// First byte
	*p = (sign << 7) | (e >> 1);
	p += incr;

	// Second byte
	*p = (char) (((e & 1) << 7) | (fbits >> 16));
	p += incr;

  // Third byte
	*p = (fbits >> 8) & 0xFF;
	p += incr;

	// Fourth byte
	*p = fbits & 0xFF;

	// Done 
	return 0;

overflow:
	return -1;
}

static float buffer2float(const unsigned char *p, int littleEndian)
{
	unsigned char sign;
	int e;
	unsigned int f;
	double x;
	int incr = 1;

	if (littleEndian) {
		p += 3;
		incr = -1;
	}

	// First byte
	sign = (*p >> 7) & 1;
	e = (*p & 0x7F) << 1;
	p += incr;

	// Second byte
	e |= (*p >> 7) & 1;
	f = (*p & 0x7F) << 16;
	p += incr;

  // Third byte
	f |= *p << 8;
	p += incr;

  // Fourth byte
	f |= *p;

	x = (double)f / 8388608.0;

	// XXX This sadly ignores Inf/NaN issues
	if (e == 0)
		e = -126;
	else {
		x += 1.0;
		e -= 127;
	}
	x = ldexp(x, e);

	if (sign)
		x = -x;

	return x;
}
#endif //FPU_IEEE754

LEAVE_NAMESPACE
