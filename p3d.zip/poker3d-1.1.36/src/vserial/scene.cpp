/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>
#include <vserial/scene.h>
#include <vserial/scenebone.h>
#include <vserial/scenelight.h>
#include <vserial/scenemesh.h>
#include <vserial/scenenullobject.h>
#endif

ENTER_NAMESPACE_UNDERWARE

Scene::Scene()
{
}

Scene::~Scene()
{
}

static void collectBone(SceneItem *_item, std::vector<SceneBone*> &_list)
{
	SceneBone *bone = dynamic_cast<SceneBone*>(_item);
	if (bone)
		_list.push_back(bone);

	int nbChildren = _item->getNbChildren();
	for (int i = 0; i < nbChildren; i++) {
		SceneItem *item = _item->getChildByIndex(i);
		collectBone(item, _list);
	}
}

static void collectMesh(SceneItem *_item, std::vector<SceneMesh*> &_list)
{
	SceneMesh *mesh = dynamic_cast<SceneMesh*>(_item);
	if (mesh)
		_list.push_back(mesh);

	int nbChildren = _item->getNbChildren();
	for (int i = 0; i < nbChildren; i++) {
		SceneItem *item = _item->getChildByIndex(i);
		collectMesh(item, _list);
	}
}

static void collectLight(SceneItem *_item, std::vector<SceneLight*> &_list)
{
	SceneLight *lgt = dynamic_cast<SceneLight*>(_item);
	if (lgt)
		_list.push_back(lgt);

	int nbChildren = _item->getNbChildren();
	for (int i = 0; i < nbChildren; i++) {
		SceneItem *item = _item->getChildByIndex(i);
		collectLight(item, _list);
	}
}

static void collectNullObject(SceneItem *_item, std::vector<SceneNullObject*> &_list)
{
	SceneNullObject *nullobj = dynamic_cast<SceneNullObject*>(_item);
	if (nullobj)
		_list.push_back(nullobj);

	int nbChildren = _item->getNbChildren();
	for (int i = 0; i < nbChildren; i++) {
		SceneItem *item = _item->getChildByIndex(i);
		collectNullObject(item, _list);
	}
}

void Scene::getBonesList(std::vector<SceneBone*> &_list) const
{
	getBonesListFrom(root_, _list);
}

void Scene::getBonesListFrom(SceneItem *_from, std::vector<SceneBone*> &_list) const
{
	_list.clear();
	collectBone(_from, _list);
}

void Scene::getMeshesList(std::vector<SceneMesh*> &_list) const
{
	getMeshesListFrom(root_, _list);
}

void Scene::getMeshesListFrom(SceneItem *_from, std::vector<SceneMesh*> &_list) const
{
	_list.clear();
	collectMesh(_from, _list);
}

void Scene::getLightsList(std::vector<SceneLight*> &_list) const
{
	getLightsListFrom(root_, _list);
}

void Scene::getLightsListFrom(SceneItem *_from, std::vector<SceneLight*> &_list) const
{
	_list.clear();
	collectLight(_from, _list);
}

void Scene::getNullObjectsList(std::vector<SceneNullObject*> &_list) const
{
	getNullObjectsListFrom(root_, _list);
}

void Scene::getNullObjectsListFrom(SceneItem *_from, std::vector<SceneNullObject*> &_list) const
{
	_list.clear();
	collectNullObject(_from, _list);
}

LEAVE_NAMESPACE
