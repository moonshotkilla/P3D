/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>
#include <vserial/dataio.h>
#include <vserial/envelope.h>
#include <vserial/keyframe.h>
#endif

ENTER_NAMESPACE_UNDERWARE

EnvelopeBase::EnvelopeBase()
{
	behaviors_[0] = BEH_RESET;
	behaviors_[1] = BEH_RESET;
}

EnvelopeBase::~EnvelopeBase()
{
}

float EnvelopeBase::getDuration() const
{
	int size = keyFrames_.size();
	if (!size)
		return 0;
	return keyFrames_[size-1]->time_;
}

void EnvelopeBase::write(DataOut &_out) const
{
	int nbKeys = keyFrames_.size();
	for (int i = 0; i < nbKeys; i++) {
		KeyBase *key = keyFrames_[i];

		_out.writeFloat( key->time_ );
		_out.writeByte( key->shape_ );
		_out.writeFloat( key->tension_ );
		_out.writeFloat( key->continuity_ );
		_out.writeFloat( key->bias_ );
		_out.writeFloat( key->params_[0] );
		_out.writeFloat( key->params_[1] );
		_out.writeFloat( key->params_[2] );
		_out.writeFloat( key->params_[3] );
	}
}

void EnvelopeFloat::write(DataOut &_out) const
{
	EnvelopeBase::write(_out);

	int nbKeys = keyFrames_.size();
	for (int i = 0; i < nbKeys; i++) {
		KeyFloat *key = (KeyFloat*) keyFrames_[i];
		_out.writeFloat( key->value_ );
	}
}

void EnvelopeQuaternion::write(DataOut &_out) const
{
	EnvelopeBase::write(_out);

	int nbKeys = keyFrames_.size();
	for (int i = 0; i < nbKeys; i++) {
		KeyQuaternion *key = (KeyQuaternion*) keyFrames_[i];
		_out.writeFloat( key->value_.x );
		_out.writeFloat( key->value_.y );
		_out.writeFloat( key->value_.z );
		_out.writeFloat( key->value_.w );
	}
}

LEAVE_NAMESPACE
