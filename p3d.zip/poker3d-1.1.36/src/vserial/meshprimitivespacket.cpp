/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <float.h>
#include <memory.h>
#include <stdio.h>

#include <vserial/vserial.h>
#include <vserial/meshprimitivespacket.h>
#endif

ENTER_NAMESPACE_UNDERWARE

MeshPrimitivesPacket::MeshPrimitivesPacket(MeshLayer &_ml, MESHPRIM_PACKET_TYPE _type)
{
	owner_ = &_ml;
	type_ = _type;

	material_ = NULL;

	indexBuffer_ = NULL;
	nbIndices_ = 0;

	vertices_ = NULL;
	nbVertices_ = 0;
	vertexFormat_ = 0;
}

MeshPrimitivesPacket::MeshPrimitivesPacket(MeshLayer &_ml)
{
	owner_ = &_ml;
	type_ = (MESHPRIM_PACKET_TYPE)0;

	material_ = NULL;

	indexBuffer_ = NULL;
	nbIndices_ = 0;

	vertices_ = NULL;
	nbVertices_ = 0;
	vertexFormat_ = 0;
}

MeshPrimitivesPacket::~MeshPrimitivesPacket()
{
	if (indexBuffer_)
		delete [] indexBuffer_;

	if (vertices_)
		delete [] vertices_;
}

int MeshPrimitivesPacket::getNbPrimitives() const 
{
	if (type_ == MESHPRIM_TRIANGLES)
		return nbIndices_ / 3;
	else if (type_ == MESHPRIM_LINES)
		return nbIndices_ / 2;
	else if (type_ == MESHPRIM_POINTS)
		return nbIndices_;

	return 0;
}

void MeshPrimitivesPacket::setIndexBuffer(unsigned short *_ib, int _nbIndices)
{
	if (indexBuffer_)
		delete [] indexBuffer_;

	indexBuffer_ = new unsigned short[_nbIndices];
	memcpy(indexBuffer_, _ib, sizeof(unsigned short) * _nbIndices);
	nbIndices_ = _nbIndices;
}

void MeshPrimitivesPacket::setVertexBuffer(Vertex *_vertices, int _nbVertices, int _vertexFormat)
{
	if (vertices_)
		delete [] vertices_;

	vertices_ = new Vertex[_nbVertices];
	memcpy(vertices_, _vertices, sizeof(Vertex) * _nbVertices);
	nbVertices_ = _nbVertices;
	vertexFormat_ = _vertexFormat;
}

void MeshPrimitivesPacket::setPrimitiveBuffer(short* _indexes, int _nbIndexes, MESHPRIM_PACKET_TYPE _primitive_type)
{
	if (indexBuffer_)
		delete [] indexBuffer_;

	indexBuffer_ = new unsigned short[_nbIndexes];
	memcpy(indexBuffer_, _indexes, sizeof(unsigned short) * _nbIndexes);
	nbIndices_ = _nbIndexes;
	type_ = _primitive_type;
}

bool Vertex::isSameVertex(const Vertex &_vtx, int _format, float _threshold)
{
	int i;

	if (_format & FMT_GEOBIND) {
		if (geoBind != _vtx.geoBind)
			return false;
	}

	if (_format & FMT_NORMAL) {
		if (normalx != _vtx.normalx || normaly != _vtx.normaly)
			return false;
	}

	int nbUVS = getNbUVs(_format);
	for (i = 0; i < nbUVS; i++) {
		float diffU = uvs[i].x - _vtx.uvs[i].x;
		float diffV = uvs[i].y - _vtx.uvs[i].y;

		if (diffU > _threshold || diffU < -_threshold ||
			  diffV > _threshold || diffV < -_threshold)
			return false;
	}

	// finally all tests passed
	return true;
}

int Vertex::getNbUVs(int _format)
{
	return (_format & UVMASK) >> UVSHIFT;
}

int Vertex::getSize(int _format)
{
	int size = 0;

	if (_format & FMT_GEOBIND)
		size += 2;

	if (_format & FMT_NORMAL)
		size += 4;

	if (_format & FMT_COLOR1)
		size += 4;

	if (_format & FMT_COLOR2)
		size += 4;

	int nbUVS = getNbUVs(_format);
	size += nbUVS * 8;

	return size;
}

Vec3f Vertex::unpackNormal(short _normalx, short _normaly)
{
	float nx = _normalx / 32767.0f;
	float ny = short(_normaly & 0xfffe) / 32767.0f;
	float nz = 1 - (nx*nx) - (ny*ny);
	if (nz > FLT_EPSILON)
		nz = sqrt(nz);
	if (_normaly & 1)
		nz = -nz;

	if (nx < -1) nx = -1;
	else if (nx > 1) nx = 1;

	if (ny < -1) ny = -1;
	else if (ny > 1) ny = 1;

	if (nz < -1) nz = -1;
	else if (nz > 1) nz = 1;

	return Vec3f(nx, ny, nz);
}

void Vertex::packNormal(const Vec3f &_normal, short &_normalx, short &_normaly)
{
	short inx = _normal.x * 32767;
	short iny = _normal.y * 32767;
	iny &= 0xffffe;
	if (_normal.z < 0)
		iny |= 1;

	_normalx = inx;
	_normaly = iny;
}

LEAVE_NAMESPACE
