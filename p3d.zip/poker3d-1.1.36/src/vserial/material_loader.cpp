/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>

#include <iostream>
#include <glib.h>

#include <vserial/dataio.h>
#include <vserial/material.h>
#include <vserial/materialserializer.h>
#include <vserial/technique.h>
#include <vserial/pass.h>
#include <vserial/texture.h>
#endif

ENTER_NAMESPACE_UNDERWARE

bool MaterialSerializer::load(const char *_fileName, Material **_res)
{
	DataIn data;

	if (!data.open(_fileName))
		return false;

	return load(data, _res);
}

bool MaterialSerializer::load(DataIn &_in, Material **_res)
{
	MaterialSerializer ms;
	ms.material_ = new Material;
	ms.in_ = &_in;
	if (!ms.load()) {
		delete ms.material_;
		return false;
	}

	if (_res)
		*_res = ms.material_;

	return true;
}

bool MaterialSerializer::load()
{
	char name[256];
	char tag[4];
	int tagid;
	int subChunkSize;
	Technique *tech;

	if (in_->read(tag, 4) != 4) {
		g_critical("MaterialSerializer::load - cannot read first tag");
		return false;
	}

	tagid = MID(tag[0], tag[1], tag[2], tag[3]);
	if (tagid != MID('U','M','T','0')) {
		g_critical("MaterialSerializer::load - expected UMT0 (found %d)", tagid);
		return false;
	}

	int startPos = in_->tell();
	int chunkSize = in_->readDword();

	while (in_->tell() < startPos+chunkSize && !in_->error()) {

		in_->read(tag, 4);
		subChunkSize = in_->readDword();
		int pos0 = in_->tell();

		tagid = MID(tag[0], tag[1], tag[2], tag[3]);
		switch (tagid) {

		case MID('N','A','M','E'):
			in_->readStrZ(name);
			material_->setFileName(name);
			break;

		case MID('T','E','C','H'):
			tech = material_->addTechnique();
			if (!readTECHchunk(*tech, subChunkSize))
				return false;
			break;

		default:
			in_->advance(subChunkSize);
			break;
		}

		int pos1 = in_->tell();
		if (pos1 - pos0 != subChunkSize) {
			g_warning("MaterialSerializer::load - a subchunk has an incorrect size in file \"%s\" (read %d bytes instead of %d)", in_->getFileName().c_str(), pos1-pos0, subChunkSize);
			in_->seek( pos0 + subChunkSize );
		}
	}

	return true;
}

bool MaterialSerializer::readTECHchunk(Technique &_tech, int _chunkSize)
{
	char name[256];
	char tag[4];
	int tagid;
	Pass *pass;

	int startPos = in_->tell();

	while (in_->tell() < startPos+_chunkSize && !in_->error()) {

		in_->read(tag, 4);
		int subChunkSize = in_->readDword();
		int pos0 = in_->tell();

		tagid = MID(tag[0], tag[1], tag[2], tag[3]);
		switch (tagid) {

		case MID('N','A','M','E'):
			in_->readStrZ(name);
			_tech.setName(name);
			break;

		case MID('P','A','S','S'):
			pass = _tech.addPass();
			if (!readPASSchunk(*pass, subChunkSize))
				return false;
			break;

		default:
			in_->advance(subChunkSize);
			break;
		}

		int pos1 = in_->tell();
		if (pos1 - pos0 != subChunkSize) {
			g_warning("MaterialSerializer::readTECHchunk - a subchunk has an incorrect size in file \"%s\" (read %d bytes instead of %d)", in_->getFileName().c_str(), pos1-pos0, subChunkSize);
			in_->seek( pos0 + subChunkSize );
		}
	}

	return true;
}

bool MaterialSerializer::readPASSchunk(Pass &_pass, int _chunkSize)
{
	int i;
	char tag[4];
	int tagid;
	int col;
	Col4f colf;
	float glos;
	PIXOP pixop;
	unsigned char pixopa;
	int itl = 0;
	int itlb = 0;
	TEXOP texelOp;
	unsigned char texelOpa;
	char str[200];

	int startPos = in_->tell();

	while (in_->tell() < startPos+_chunkSize && !in_->error()) {

		in_->read(tag, 4);
		int subChunkSize = in_->readDword();
		int pos0 = in_->tell();

		tagid = MID(tag[0], tag[1], tag[2], tag[3]);
		switch (tagid) {

		case MID('D','I','F','C'):
			col = in_->readDword();
			colf.fromDword(col);
			_pass.setDiffuse(colf);
			break;

		case MID('E','M','I','C'):
			col = in_->readDword();
			colf.fromDword(col);
			_pass.setEmissive(colf);
			break;

		case MID('S','P','E','C'):
			col = in_->readDword();
			colf.fromDword(col);
			_pass.setSpecular(colf);
			break;

		case MID('A','M','B','C'):
			col = in_->readDword();
			colf.fromDword(col);
			_pass.setAmbient(colf);
			break;

		case MID('G','L','O','S'):
			glos = in_->readFloat();
			_pass.setGlossiness(glos);
			break;

		case MID('P','X','O','P'):
			pixop = (PIXOP) in_->readByte();
			pixopa = in_->readByte();
			_pass.setPixelOperation(pixop);
			_pass.setPixelOpacity( ((unsigned char)pixopa) / 255.0f);
			break;

		case MID('N','B','T','L'):
			i = in_->readByte();
			_pass.setNbTextureLayers(i);
			break;

		case MID('T','E','X','L'):
			if (!readTEXLchunk(_pass.getTextureLayer(itl++), subChunkSize))
				return false;
			break;

		case MID('T','E','X','B'):
			texelOp = (TEXOP) in_->readDword();
			texelOpa = in_->readByte();
			_pass.getTextureLayerBind(itlb).setTexelOperation(texelOp);
			_pass.getTextureLayerBind(itlb).setOpacity(texelOpa/255.0f);
			itlb++;
			break;

		case MID('V','N','A','M'):
			in_->readStrZ(str);
			_pass.getVertexProgram().setName(str);
			break;

		case MID('F','N','A','M'):
			in_->readStrZ(str);
			_pass.getFragmentProgram().setName(str);
			break;

		case MID('D','S','I','D'):
			_pass.setFlag( Pass::FLAG_DOUBLESIDED );
			break;

		case MID('N','L','G','T'):
			_pass.setFlag( Pass::FLAG_IGNORELIGHTING );
			break;

		default:
			in_->advance(subChunkSize);
			break;
		}

		int pos1 = in_->tell();
		if (pos1 - pos0 != subChunkSize) {
			g_warning("MaterialSerializer::readPASSchunk - a subchunk has an incorrect size in file \"%s\" (read %d bytes instead of %d)", in_->getFileName().c_str(), pos1-pos0, subChunkSize);
			in_->seek( pos0 + subChunkSize );
		}
	}

	return true;
}

bool MaterialSerializer::readTEXLchunk(TextureLayer &_tl, int _chunkSize)
{
	int i;
	char tag[4];
	char str[256];
	int tagid;
	TMAP_TYPE type;
	TMAP_TILE_TYPE tile_u, tile_v;
	Texture *texture;

	int startPos = in_->tell();

	while (in_->tell() < startPos+_chunkSize && !in_->error()) {

		in_->read(tag, 4);
		int subChunkSize = in_->readDword();
		int pos0 = in_->tell();

		tagid = MID(tag[0], tag[1], tag[2], tag[3]);
		switch (tagid) {

		case MID('T','E','X',' '):
			in_->readStrZ(str);
			texture = Texture::getByName(str);
			if (!texture) {
				texture = new Texture();
				texture->setFileName(str);
			}
			_tl.setTexture(texture);
			break;

		case MID('T','Y','P','E'):
			type = (TMAP_TYPE) in_->readByte();
			_tl.setMapType(type);
			break;

		case MID('T','I','L','E'):
			tile_u = (TMAP_TILE_TYPE) in_->readByte();
			tile_v = (TMAP_TILE_TYPE) in_->readByte();
			_tl.setMapTileU(tile_u);
			_tl.setMapTileU(tile_v);
			break;

		case MID('U','V','X',' '):
			i = in_->readByte();
			_tl.setUVIndex(i);
			break;

		default:
			in_->advance(subChunkSize);
			break;
		}

		int pos1 = in_->tell();
		if (pos1 - pos0 != subChunkSize) {
			g_warning("MaterialSerializer::readTEXLchunk - a subchunk has an incorrect size in file \"%s\" (read %d bytes instead of %d)", in_->getFileName().c_str(), pos1-pos0, subChunkSize);
			in_->seek( pos0 + subChunkSize );
		}
	}

	return true;
}

LEAVE_NAMESPACE
