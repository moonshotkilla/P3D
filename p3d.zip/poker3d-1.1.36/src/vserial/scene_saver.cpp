/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH

//#include <map>
//#include <iostream>

//#include <glib.h>

#include <vserial/vserial.h>

#include <vserial/dataio.h>
#include <vserial/mesh.h>
#include <vserial/motion.h>
#include <vserial/motionserializer.h>
#include <vserial/scene.h>
#include <vserial/scenebone.h>
#include <vserial/scenelight.h>
#include <vserial/scenemesh.h>
#include <vserial/scenenullobject.h>
#include <vserial/sceneserializer.h>

#endif

ENTER_NAMESPACE_UNDERWARE

bool SceneSerializer::save(Scene &_scene, const char *_fileName, SaveOptions *_options)
{
	DataOut data;

	if (!data.open(_fileName))
		return false;

	save(_scene, data, _options);

	return data.close();
}

bool SceneSerializer::save(Scene &_scene, DataOut &_out, SaveOptions *_options)
{
	SceneSerializer ss;
	ss.scene_ = &_scene;
	ss.out_ = &_out;
	ss.saveOptions_ = _options;
	ss.save();

	return true;
}

void SceneSerializer::save()
{
	int i;

	out_->writeStr("USC0");
	int oldPos = out_->tell();
	out_->advance(4);

	std::vector<SceneMesh*> meshes;
	std::vector<SceneBone*> bones;
	std::vector<SceneNullObject*> nullObjects;
	std::vector<SceneLight*> lights;

	scene_->getMeshesList(meshes);
	scene_->getBonesList(bones);
	scene_->getNullObjectsList(nullObjects);
	scene_->getLightsList(lights);

	int nbMeshes = meshes.size();
	int nbBones = bones.size();
	int nbNullObjects = nullObjects.size();
	int nbLights = lights.size();

	int id = 0;

	for (i = 0; i < nbMeshes; i++)
		items2id_[ meshes[i] ] = id++;

	for (i = 0; i < nbBones; i++)
		items2id_[ bones[i] ] = id++;

	for (i = 0; i < nbNullObjects; i++)
		items2id_[ nullObjects[i] ] = id++;

	for (i = 0; i < nbLights; i++)
		items2id_[ lights[i] ] = id++;

	for (i = 0; i < nbMeshes; i++) {
		SceneMesh *sceneMesh = meshes[i];
		writeMESHchunk(*sceneMesh);
	}

	for (i = 0; i < nbNullObjects; i++) {
		SceneNullObject *sceneNullObject = nullObjects[i];
		writeNULOchunk(*sceneNullObject);
	}

	for (i = 0; i < nbLights; i++) {
		SceneLight *sceneLight = lights[i];
		writeLGTchunk(*sceneLight);
	}

	if (!saveOptions_ || saveOptions_->bDontSaveAnimations == false) {
		std::map<Motion*, bool>::iterator it = motions_.begin();
		for ( ; it != motions_.end(); ++it) {
			Motion *mot = it->first;
			MotionSerializer::save(*mot, *out_);
		}
	}

	int pos = out_->tell();
	out_->seek(oldPos);
	int size = pos - oldPos - 4;
	out_->writeDword(size);
	out_->seek(pos);
}

void SceneSerializer::writeMESHchunk(const SceneMesh &_sceneMesh)
{
	out_->writeStr("MESH");
	int oldPos = out_->tell();
	out_->advance(4);

	Mesh *mesh = _sceneMesh.getMesh();
	if (mesh) {
		const std::string &meshFileName = mesh->getFileName();
		out_->writeStr("REF ");
		out_->writeDword( meshFileName.size()+1 );
		out_->writeStrZ( meshFileName.c_str() );
	}

	writeCommonItemAttributes(_sceneMesh);

	int pos = out_->tell();
	out_->seek(oldPos);
	int size = pos - oldPos - 4;
	out_->writeDword(size);
	out_->seek(pos);
}

void SceneSerializer::writeLGTchunk(const SceneLight &_sceneLight)
{
	out_->writeStr("LGT ");
	int oldPos = out_->tell();
	out_->advance(4);

	const SceneLight::Data &data = _sceneLight.data();

	out_->writeStr("TYPE");
	out_->writeDword(1);
	out_->writeByte(data.type);

	out_->writeStr("FOFF");
	out_->writeDword(1);
	out_->writeByte(data.fallOff);

	out_->writeStr("COL ");
	out_->writeDword(4);
	out_->writeDword( data.color.toDword() );

	out_->writeStr("DIR ");
	out_->writeDword(12);
	out_->writeFloat(data.direction.x);
	out_->writeFloat(data.direction.y);
	out_->writeFloat(data.direction.z);

	out_->writeStr("RNGE");
	out_->writeDword(4);
	out_->writeFloat(data.range);

	out_->writeStr("PARM");
	out_->writeDword(20);
	out_->writeFloat(data.att0);
	out_->writeFloat(data.att1);
	out_->writeFloat(data.att2);
	out_->writeFloat(data.theta);
	out_->writeFloat(data.phi);

	writeCommonItemAttributes(_sceneLight);

	int pos = out_->tell();
	out_->seek(oldPos);
	int size = pos - oldPos - 4;
	out_->writeDword(size);
	out_->seek(pos);
}

void SceneSerializer::writeNULOchunk(const SceneNullObject &_sceneNullObject)
{
	out_->writeStr("NULO");
	int oldPos = out_->tell();
	out_->advance(4);

	writeCommonItemAttributes(_sceneNullObject);

	int pos = out_->tell();
	out_->seek(oldPos);
	int size = pos - oldPos - 4;
	out_->writeDword(size);
	out_->seek(pos);
}

void SceneSerializer::writeNAMEchunk(const char *_name)
{
	out_->writeStr("NAME");
	out_->writeDword( strlen(_name)+1 );
	out_->writeStrZ( _name );
}

void SceneSerializer::writeCommonItemAttributes(const SceneItem &_item)
{
	const std::string &name = _item.getName();
	writeNAMEchunk(name.c_str());

	out_->writeStr("ID  ");
	int id = items2id_[ (SceneItem*) &_item ];
	out_->writeDword(4);
	out_->writeDword(id);

	const Vec3f &pos = _item.getPosition();
	if (pos != ZEROVEC3F) {
		out_->writeStr("POS ");
		out_->writeDword(12);
		out_->writeFloat(pos.x);
		out_->writeFloat(pos.y);
		out_->writeFloat(pos.z);
	}

	const Quaternion &quat = _item.getQuaternion();
	//if (quat != ZEROVEC3F)
	{
		out_->writeStr("QUAT");
		out_->writeDword(16);
		out_->writeFloat(quat.x);
		out_->writeFloat(quat.y);
		out_->writeFloat(quat.z);
		out_->writeFloat(quat.w);
	}

	const Vec3f &pivot = _item.getPivot();
	if (pivot != ZEROVEC3F) {
		out_->writeStr("PIVO");
		out_->writeDword(12);
		out_->writeFloat(pivot.x);
		out_->writeFloat(pivot.y);
		out_->writeFloat(pivot.z);
	}

	SceneItem *parent = _item.getParent();
	if (parent) {
    int id = items2id_[parent];
		out_->writeStr("PRNT");
		out_->writeDword(4);
		out_->writeDword(id);
	}

	Motion *motion = _item.getMotion();
	if (motion) {
		const std::string &name = motion->getFileName();
		out_->writeStr("MOT ");
		out_->writeDword(name.size()+1);
		out_->writeStrZ(name.c_str());
		motions_[motion] = true;
	}
}

LEAVE_NAMESPACE
