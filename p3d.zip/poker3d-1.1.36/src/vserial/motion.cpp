/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>
#include <vserial/motion.h>
#include <vserial/string.h>
#endif

ENTER_NAMESPACE_UNDERWARE

static std::vector<Motion*> g_motions;

int Motion::getNb()
{
	return g_motions.size();
}

Motion* Motion::getByIndex(int i)
{
	return g_motions[i];
}

Motion* Motion::getByName(const std::string &_name)
{
	std::string name1 = fileName2Name(_name.c_str());
	int nb = g_motions.size();
	for (int i = 0; i < nb; i++) {
		Motion *motion = g_motions[i];
		std::string name = fileName2Name( motion->getFileName() );
		if (name == name1)
			return motion;
	}
	return NULL;
}

Motion::Motion()
{
	g_motions.push_back(this);
}

Motion::~Motion()
{
	int nb = g_motions.size();
	for (int i = 0; i < nb; i++) {
		Motion *motion = g_motions[i];
		if (motion == this) {
			g_motions.erase( g_motions.begin() + i);
			break;
		}
	}
}

void Motion::addEnvelope(EnvelopeBase *_env)
{
	envelopes_.push_back(_env);
}

LEAVE_NAMESPACE
