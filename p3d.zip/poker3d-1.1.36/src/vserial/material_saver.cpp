/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */
#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>

#include <iostream>
#include <glib.h>

#include <vserial/dataio.h>
#include <vserial/material.h>
#include <vserial/materialserializer.h>
#include <vserial/technique.h>
#include <vserial/pass.h>
#include <vserial/texture.h>
#endif

ENTER_NAMESPACE_UNDERWARE

bool MaterialSerializer::save(Material &_material, const char *_fileName)
{
	DataOut data;

	if (!data.open(_fileName))
		return false;

	save(_material, data);

	return data.close();
}

bool MaterialSerializer::save(Material &_material, DataOut &_out)
{
	MaterialSerializer ms;
	ms.material_ = &_material;
	ms.out_ = &_out;
	ms.save();

	return true;
}

void MaterialSerializer::save()
{
	int i;

	out_->writeStr("UMT0");
	int oldPos = out_->tell();
	out_->advance(4);

	const std::string &name = material_->getFileName();
	out_->writeStr("NAME");
	out_->writeDword( name.size()+1 );
	out_->writeStrZ(name.c_str());

	int nbTechniques = material_->getNbTechniques();
	for (i = 0; i < nbTechniques; i++) {
		Technique *technique = material_->getTechniqueByIndex(i);
		writeTECHchunk(technique);
	}

	int pos = out_->tell();
	out_->seek(oldPos);
	int size = pos - oldPos - 4;
	out_->writeDword(size);
	out_->seek(pos);
}

void MaterialSerializer::writeTECHchunk(Technique *_tech)
{
	out_->writeStr("TECH");
	int oldPos = out_->tell();
	out_->advance(4);

	const std::string &techName = _tech->getName();
	out_->writeStr("NAME");
	out_->writeDword( (int) techName.size()+1 );
	out_->writeStrZ( techName.c_str() );

	int nbPasses = _tech->getNbPasses();
	for (int i = 0; i < nbPasses; i++) {
		Pass *pass = _tech->getPassByIndex(i);
		writePASSchunk(pass);
	}

	int pos = out_->tell();
	out_->seek(oldPos);
	int size = pos - oldPos - 4;
	out_->writeDword(size);
	out_->seek(pos);
}

void MaterialSerializer::writePASSchunk(Pass *_pass)
{
	int i;

	out_->writeStr("PASS");
	int oldPos = out_->tell();
	out_->advance(4);

	out_->writeStr("DIFC");
	out_->writeDword(4);
	out_->writeDword( _pass->getDiffuse().toDword() );

	out_->writeStr("EMIC");
	out_->writeDword(4);
	out_->writeDword( _pass->getEmissive().toDword() );

	out_->writeStr("SPEC");
	out_->writeDword(4);
	out_->writeDword( _pass->getSpecular().toDword() );

	out_->writeStr("AMBC");
	out_->writeDword(4);
	out_->writeDword( _pass->getAmbient().toDword() );

	out_->writeStr("GLOS");
	out_->writeDword(4);
	out_->writeFloat( _pass->getGlossiness() );

	out_->writeStr("PXOP");
	out_->writeDword(2);
	out_->writeByte( _pass->getPixelOperation() );
	int pixelOpa = int(_pass->getPixelOpacity() * 255.0f);
	out_->writeByte( pixelOpa  );

	int nbTL = _pass->getNbTextureLayers();
	out_->writeStr("NBTL");
	out_->writeDword(1);
	out_->writeByte(nbTL);

	for (i  = 0; i < nbTL; i++) {
		TextureLayer &tl = _pass->getTextureLayer(i);
		writeTEXLchunk(&tl);
	}

	for (i  = 0; i < nbTL; i++) {
		TextureLayerBind &tlb = _pass->getTextureLayerBind(i);
		writeTEXBchunk(&tlb);
	}

	const std::string &vprogName = _pass->getVertexProgram().getName();
	if (!vprogName.empty()) {
		out_->writeStr("VNAM");
		int size = vprogName.size()+1;
		out_->writeDword( size );
		out_->writeStrZ( vprogName.c_str() );
	}

	const std::string &fprogName = _pass->getFragmentProgram().getName();
	if (!fprogName.empty()) {
		out_->writeStr("FNAM");
		int size = fprogName.size()+1;
		out_->writeDword( size );
		out_->writeStrZ( fprogName.c_str() );
	}

	int flags = _pass->getFlags();

	if (flags & Pass::FLAG_DOUBLESIDED) {
		out_->writeStr("DSID");
		out_->writeDword(0);
	}

	if (flags & Pass::FLAG_IGNORELIGHTING) {
		out_->writeStr("NLGT");
		out_->writeDword(0);
	}

	int pos = out_->tell();
	out_->seek(oldPos);
	int size = pos - oldPos - 4;
	out_->writeDword(size);
	out_->seek(pos);
}

void MaterialSerializer::writeTEXLchunk(TextureLayer *_tlayer)
{
	out_->writeStr("TEXL");
	int oldPos = out_->tell();
	out_->advance(4);

	Texture *texture = _tlayer->getTexture();
	if (texture) {
		const std::string &textureFileName = texture->getFileName();
		out_->writeStr("TEX ");
		int size = textureFileName.size()+1;
		out_->writeDword( size );
		out_->writeStrZ( textureFileName.c_str() );
	}

	out_->writeStr("TYPE");
	out_->writeDword(1);
	out_->writeByte( _tlayer->getMapType() );

	out_->writeStr("TILE");
	out_->writeDword(2);
	out_->writeByte( _tlayer->getMapTileU() );
	out_->writeByte( _tlayer->getMapTileV() );

	out_->writeStr("UVX ");
	out_->writeDword(1);
	out_->writeByte( _tlayer->getUVIndex() );

	int pos = out_->tell();
	out_->seek(oldPos);
	int size = pos - oldPos - 4;
	out_->writeDword(size);
	out_->seek(pos);
}

void MaterialSerializer::writeTEXBchunk(TextureLayerBind *_tlb)
{
	out_->writeStr("TEXB");
	out_->writeDword(5);
	out_->writeDword( _tlb->getTexelOperation() );
	out_->writeByte( int(_tlb->getOpacity() * 255.0f) );
}

LEAVE_NAMESPACE
