/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>

#include <iostream>

#include <glib.h>

#include <vserial/dataio.h>
#include <vserial/floatmap.h>
#include <vserial/material.h>
#include <vserial/materialserializer.h>
#include <vserial/mesh.h>
#include <vserial/meshlayer.h>
#include <vserial/meshserializer.h>
#include <vserial/string.h>
#include <vserial/vector3map.h>
#endif

/*
#include <assert.h>
#include <d3dx9mesh.h>
*/

//#include "NvTriStrip.h"

ENTER_NAMESPACE_UNDERWARE

bool MeshSerializer::load(const char *_fileName, const char *_basePath, Mesh **_res)
{
	DataIn data;

	std::string fname = obtainFilename(_fileName, _basePath);
	if (!data.open(fname))
		return false;

	return load(data, _basePath, _res);
}

bool MeshSerializer::load(DataIn &_in, const char *_path, Mesh **_res)
{
	MeshSerializer ms;
	ms.mesh_ = new Mesh;
	ms.in_ = &_in;
	ms.path_ = _path;

	if (!ms.load()) {
		delete ms.mesh_;
		return false;
	}

	if (_res)
		*_res = ms.mesh_;

	return true;
}

bool MeshSerializer::load()
{
	MeshLayer *meshLayer;

	char tag[4];
	int tagid;
	int subChunkSize;

	if (in_->read(tag, 4) != 4) {
		return false;
	}

	tagid = MID(tag[0], tag[1], tag[2], tag[3]);
	if (tagid != MID('U','M','H','0')) {
		g_critical("MeshSerializer::load - expected UMH0 (found %d)", tagid);
		return false;
	}

	int startPos = in_->tell();
	int chunkSize = in_->readDword();

	while (in_->tell() < startPos+chunkSize && !in_->error()) {

		in_->read(tag, 4);
		subChunkSize = in_->readDword();
		int pos0 = in_->tell();

		tagid = MID(tag[0], tag[1], tag[2], tag[3]);
		switch (tagid) {

		case MID('M','L','A','Y'):
			meshLayer = mesh_->addLayer();
			if (!readMLAYchunk(*meshLayer, subChunkSize))
				return false;
			break;

		case MID('U','M','T','0'):
			in_->advance(-8);
			MaterialSerializer::load(*in_);
			break;

		default:
			in_->advance(subChunkSize);
			break;
		}

		int pos1 = in_->tell();
		if (pos1 - pos0 != subChunkSize) {
			g_warning("MeshSerializer::load - a subchunk has an incorrect size in file \"%s\" (read %d bytes instead of %d)", in_->getFileName().c_str(), pos1-pos0, subChunkSize);
			in_->seek( pos0 + subChunkSize );
		}
	}

	// resolve materials reference
	for (std::map<MeshPrimitivesPacket*, std::string>::iterator it = mpp2mat_.begin(); it != mpp2mat_.end(); ++it) {
		MeshPrimitivesPacket *mpp = it->first;
		const std::string &matname = it->second;
		Material *mat = Material::getByName(matname);
		mpp->setMaterial(mat);
	}

	return true;
}

bool MeshSerializer::readMLAYchunk(MeshLayer &_mlayer, int _chunkSize)
{
	char name[256];
	std::vector<Vec3f> pnts;
	MeshPrimitivesPacket *packet;
	char tag[4];
	int tagid;

	int startPos = in_->tell();

	while (in_->tell() < (startPos+_chunkSize) && !in_->error()) {

		in_->read(tag,4);
		int subChunkSize = in_->readDword();
		int pos0 = in_->tell();

		tagid = MID(tag[0],tag[1],tag[2],tag[3]);

		switch (tagid) {

 		case MID('N','A','M','E'):
			in_->readStrZ(name);
			_mlayer.setName(name);
			break;

		case MID('P','N','T','S'):
			if (!readPNTSchunk(pnts, subChunkSize))
				return false;
			_mlayer.setPoints(&pnts.front(), pnts.size());
			break;

		case MID('V','M','A','P'):
			if (!readVMAPchunk(_mlayer, subChunkSize))
				return false;
			break;

		case MID('P','C','K','T'):
			packet = _mlayer.addPrimitivesPacket();
			if (!readPCKTchunk(*packet, subChunkSize))
				return false;
			break;

		default:
			in_->advance(subChunkSize);
			break;
		}

		int pos1 = in_->tell();
		if (pos1 - pos0 < subChunkSize) {
			g_warning("MeshSerializer::readMLAYchunk - a subchunk has an incorrect size in file \"%s\" (read %d bytes instead of %d)", in_->getFileName().c_str(), pos1-pos0, subChunkSize);
			in_->seek( pos0 + subChunkSize );
		}
	}

	return true;
}

bool MeshSerializer::readPCKTchunk(MeshPrimitivesPacket &_packet, int _chunkSize)
{
	std::string materialName;
	std::vector<Vertex> vertexes;
	int vertex_format;
	std::vector<short> primitives;
	char primitive_type;
	char tag[4];
	int tagid;
	char str[256];

	int startPos = in_->tell();

	while (in_->tell() < (startPos+_chunkSize) && !in_->error()) {
		
		in_->read(tag, 4);
		int subChunkSize = in_->readDword();
		int pos0 = in_->tell();

		tagid = MID(tag[0], tag[1], tag[2], tag[3]);

		switch (tagid) {

		case MID('M','A','T',' '):
			in_->readStrZ(str);
			mpp2mat_[&_packet] = str;
			break;

		case MID('V','E','R','T'):
			if (!readVERTchunk(vertexes, vertex_format, subChunkSize))
				return false;
			_packet.setVertexBuffer(&vertexes.front(), vertexes.size(), vertex_format);
			break;

		case MID('P','R','I','M'):
			if (!readPRIMchunk(primitives, primitive_type, subChunkSize))
				return false;
			_packet.setPrimitiveBuffer(&primitives.front(), primitives.size(), (MESHPRIM_PACKET_TYPE)primitive_type);
			break;

		default:
			in_->advance(subChunkSize);
			break;
		}

		int pos1 = in_->tell();
		if (pos1 - pos0 != subChunkSize) {
			g_warning("MeshSerializer::readPCKTchunk - a subchunk has an incorrect size in file \"%s\" (read %d bytes instead of %d)", in_->getFileName().c_str(), pos1-pos0, subChunkSize);
			in_->seek( pos0 + subChunkSize );
		}
	}
/*
	Vertex *vertices = _packet.getVertexBuffer();
	int nbVertices = _packet.getNbVertices();

	unsigned short *indices = _packet.getIndexBuffer();
	int nbIndices = _packet.getNbIndices();

	PrimitiveGroup *grp[10];
	unsigned short nbGrp;
	SetListsOnly(true);
	SetCacheSize(24);
	GenerateStrips(indices, nbIndices, grp, &nbGrp);

	_packet.setIndexBuffer(grp[0]->indices, grp[0]->numIndices);
	//_packet.setType(underware::MESHPRIM_STRIP);
*/
/*
	Vertex *vertices = _packet.getVertexBuffer();
	int nbVertices = _packet.getNbVertices();

	unsigned short *indices = _packet.getIndexBuffer();
	int nbIndices = _packet.getNbIndices();

	int nbFaces = nbIndices / 3;

	DWORD *faceRemap = new DWORD[nbFaces];
	D3DXOptimizeFaces(indices, nbFaces, nbVertices, FALSE, faceRemap);

	unsigned short *orderedIndices = new unsigned short[nbIndices];
	for (int i = 0; i < nbFaces; i++) {
		int iFace = faceRemap[i];
		memcpy(&orderedIndices[i*3], &indices[iFace*3], 6);
	}

	DWORD *vertexRemap = new DWORD[nbVertices];
	D3DXOptimizeVertices(orderedIndices, nbFaces, nbVertices, FALSE, vertexRemap);

	Vertex *orderedVertex = new Vertex[nbVertices];
	int *oldIndex2New = new int[nbVertices];

	for (int i = 0; i < nbVertices; i++) {
		unsigned iVertex = vertexRemap[i];
		oldIndex2New[iVertex] = i;
		memcpy(&orderedVertex[i], &vertices[iVertex], sizeof(Vertex));
	}

	for (int i = 0; i < nbIndices; i++) {
		int before = orderedIndices[i];
		int after = oldIndex2New[before];
		orderedIndices[i] = after;
	}

	_packet.setIndexBuffer(orderedIndices, nbIndices);
	_packet.setVertexBuffer(orderedVertex, nbVertices, _packet.getVertexFormat());
*/
	return true;
}

bool MeshSerializer::readPNTSchunk(std::vector<Vec3f> &_pnts, int _chunkSize)
{
	int nbPoints = _chunkSize / sizeof(Vec3f);
	_pnts.resize(nbPoints);
	int sizeRead = in_->read(&_pnts.front(), _chunkSize);
	if (sizeRead != _chunkSize) {
		g_critical("MeshSerializer::readPNTSchunk - invalid chunk");
		return false;
	}
	return true;
}

bool MeshSerializer::readVMAPchunk(MeshLayer &_ml, int _chunkSize)
{
	int i;
	char name[200];
	in_->readStrZ(name);

	VMAP_TYPE type = (VMAP_TYPE) in_->readByte();
	int nb = in_->readWord();

	if (type == VMAP_FLOAT) {
		FloatMap *fmap = (FloatMap*) _ml.addVertexMap(name, VMAP_FLOAT);
		for (i = 0; i < nb; i++) {
			unsigned short index = in_->readWord();
			float value = in_->readFloat();
			fmap->mapTable_[index] = value;
		}
	}
	else if (type == VMAP_FLOAT) {
		Vector3Map *fmap = (Vector3Map*) _ml.addVertexMap(name, VMAP_VECTOR3);
		for (i = 0; i < nb; i++) {
			unsigned short index = in_->readWord();
			float x = in_->readFloat();
			float y = in_->readFloat();
			float z = in_->readFloat();
			fmap->mapTable_[index] = Vec3f(x, y, z);
		}
	}
	else {
		g_critical("MeshSerializer::readVMAPchunk - %d is an unknown vmap type (not FLOAT or VECTOR3)", type);
		return false;
	}

	return true;
}

bool MeshSerializer::readVERTchunk(std::vector<Vertex> &_vertices, int &_vertex_format, int _chunkSize)
{
	int startPos = in_->tell();

	_vertex_format = in_->readDword();

	while (in_->tell() < (startPos+_chunkSize) && !in_->error()) {

		Vertex vertex;

		if (_vertex_format & Vertex::FMT_GEOBIND)
			vertex.geoBind = in_->readWord();

		if (_vertex_format & Vertex::FMT_NORMAL) {
			vertex.normalx = in_->readWord();
			vertex.normaly = in_->readWord();
		}

		if (_vertex_format & Vertex::FMT_COLOR1)
			vertex.color1 = in_->readDword();

		if (_vertex_format & Vertex::FMT_COLOR2)
			vertex.color2 = in_->readDword();

		int nbUVs = Vertex::getNbUVs(_vertex_format);
		if (nbUVs > Vertex::MAXNB_UVS) {
			g_critical("MeshSerializer::readVERTchunk - invalid number of UVs (found %d but maximum allowed is %d)", nbUVs, Vertex::MAXNB_UVS);
			return false;
		}

		for (int j = 0; j < nbUVs; j++) {
			vertex.uvs[j].x = in_->readFloat();
			vertex.uvs[j].y = in_->readFloat();
		}

		_vertices.push_back(vertex);
	}
	return true;
}

bool MeshSerializer::readPRIMchunk(std::vector<short> &_prim,  char &_type, int _chunkSize)
{
	_type = in_->readByte();
	int nbIndices = (_chunkSize-1)/2;
	_prim.resize(nbIndices);
	in_->read(&_prim.front(), nbIndices*2);

	return true;
}

LEAVE_NAMESPACE
