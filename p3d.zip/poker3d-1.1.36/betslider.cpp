/*
 *
 * Copyright (C) 2004, 2005, 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *
 */

#include <osg/AutoTransform>

#include <osgDB/Registry>
#include <osgDB/ReadFile>
#include <osgDB/WriteFile>

#include <osgProducer/Viewer>
#include <osgProducer/OsgCameraGroup>

#include <ugame/BetSlider>
#include <iostream>

osgProducer::Viewer* Viewer = 0;
class Handler : public osgGA::GUIEventHandler {
public:
  Handler(betslider::BetSlider* slider): _slider(slider), _sample(-1) {}

  bool handle(const osgGA::GUIEventAdapter &ea, osgGA::GUIActionAdapter &)
  {
    if (ea.getEventType() == osgGA::GUIEventAdapter::KEYDOWN) {
      if (ea.getKey() == osgGA::GUIEventAdapter::KEY_Space) {
	osgDB::writeObjectFile(*Viewer->getSceneData(),"betslider.osg");
	return true;
      } else if (ea.getKey() == osgGA::GUIEventAdapter::KEY_Right) {
	_slider->moveCursor(.01f);
	return true;
      } else if (ea.getKey() == osgGA::GUIEventAdapter::KEY_Left) {
	_slider->moveCursor(-.01f);
	return true;
      } else if (ea.getKey() == osgGA::GUIEventAdapter::KEY_Up) {
	_slider->moveCursor(.1f);
	return true;
      } else if (ea.getKey() == osgGA::GUIEventAdapter::KEY_Down) {
	_slider->moveCursor(-.1f);
	return true;
      } else if (ea.getKey() == osgGA::GUIEventAdapter::KEY_Page_Up) {
	_slider->moveCursor(1.f);
	return true;
      } else if (ea.getKey() == osgGA::GUIEventAdapter::KEY_Page_Down) {
	_slider->moveCursor(-1.f);
	return true;
      } else if (ea.getKey() == osgGA::GUIEventAdapter::KEY_Space) {
	_sample += 1;
	if(_sample > 12) _sample = 0;
        // setLimits(		   call,raise,	raise_max,      all_in, pot,    step)
	switch(_sample) {
	case 0 : _slider->setLimits(5,	20,	1000,		2000,	2000,	5); break; // call 5/raise 20/Max 1000; step 5
	case 1 : _slider->setLimits(5,	0,	0,		2000,	2000,	5); break; // call 5
	case 2 : _slider->setLimits(5,	20,	0,		2000,	2000,	5); break; // call 5/raise 20
	case 3 : _slider->setLimits(5,	20,	1000,		2000,	1000,	5); break; // call 5/raise 20/Pot 1000; step 5
	case 4 : _slider->setLimits(5,	20,	1000,		1000,	1000,	5); break; // call 5/raise 20/Pot All In 1000; step 5
	case 5 : _slider->setLimits(5,	20,	1000,		2000,	2000,	1); break; // call 5/raise 20/Max 1000; step 1
	case 6 : _slider->setLimits(5,	20,	2000,		500,	1000,	5); break; // call 5/raise 20/All-In 500; step 5
	case 7 : _slider->setLimits(5,	20,	1000,		15,	1000,	5); break; // call 5/raise All-In 15
	case 8 : _slider->setLimits(5,	20,	1000,		3,	1000,	1); break; // call All-In 3
	case 9 : _slider->setLimits(0,	20,	1000,		2000,	2000,	5); break; // bet 20/Max 1000; step 5
	case 10: _slider->setLimits(0,	20,	1000,		20,	2000,	5); break; // bet All-In 20
	case 11: _slider->setLimits(10,	20,	5000,		30000,	2000,	5); break; // call 10/raise 20/Pot 2000/Max 5000
	case 12: _slider->setLimits(15,	30,	2955,		2955,	10250,	5); break; // call 15/raise 30/All-In 2955
	default: break;
	}
	return true;
      }
    }
    return false;
  }

private:
  osg::ref_ptr<betslider::BetSlider> _slider;
  int _sample;
};

int main( int argc, char **argv )
{
  // use an ArgumentParser object to manage the program arguments.
  osg::ArgumentParser arguments(&argc,argv);
    
  // set up the usage document, in case we need to print out how to use this program.
  arguments.getApplicationUsage()->setApplicationName(arguments.getApplicationName());
  arguments.getApplicationUsage()->setDescription("standalone demonstration of the " + arguments.getApplicationName() + " 3D object.");
  arguments.getApplicationUsage()->setCommandLineUsage(arguments.getApplicationName()+" [options]");
  arguments.getApplicationUsage()->addCommandLineOption("-h or --help","Display command line paramters");
  arguments.getApplicationUsage()->addCommandLineOption("--help-env","Display environmental variables available");
  arguments.getApplicationUsage()->addCommandLineOption("--help-keys","Display keyboard & mouse bindings available");
  arguments.getApplicationUsage()->addCommandLineOption("--help-all","Display all command line, env vars and keyboard & mouse bindigs.");
    

  // construct the viewer.
  osgProducer::Viewer viewer(arguments);

  // set up the value with sensible default event handlers.
  viewer.setUpViewer(osgProducer::Viewer::STANDARD_SETTINGS);

  // get details on keyboard and mouse bindings used by the viewer.
  viewer.getUsage(*arguments.getApplicationUsage());

  // if user request help write it out to cout.
  bool helpAll = arguments.read("--help-all");
  unsigned int helpType = ((helpAll || arguments.read("-h") || arguments.read("--help"))? osg::ApplicationUsage::COMMAND_LINE_OPTION : 0 ) |
    ((helpAll ||  arguments.read("--help-env"))? osg::ApplicationUsage::ENVIRONMENTAL_VARIABLE : 0 ) |
    ((helpAll ||  arguments.read("--help-keys"))? osg::ApplicationUsage::KEYBOARD_MOUSE_BINDING : 0 );
  if (helpType)
    {
      arguments.getApplicationUsage()->write(std::cout, helpType);
      return 1;
    }

  // report any errors if they have occured when parsing the program aguments.
  if (arguments.errors())
    {
      arguments.writeErrorMessages(std::cout);
      return 1;
    }
    

	Viewer = &viewer;

  //
  // In the source tree the data is located in the data directory. 
  //
  osgDB::Registry::instance()->getDataFilePathList().push_front("examples/poker/data");

  betslider::BetSlider* slider = dynamic_cast<betslider::BetSlider*>(osgDB::readNodeFile("default.betslider"));
  slider->setLimits(1, 10, 1000, 2000, 2000, 5);

  if(slider) {
    viewer.getEventHandlerList().push_front(new Handler(slider));

    osg::StateSet* state = slider->getOrCreateStateSet();
    state->setMode(GL_LIGHTING, osg::StateAttribute::OFF);

    osg::AutoTransform* transform = new osg::AutoTransform;
    transform->setAutoRotateMode(osg::AutoTransform::ROTATE_TO_SCREEN);
    transform->addChild(slider);
    viewer.setSceneData(transform);
    //    viewer.setSceneData(slider);
	
    viewer.realize();

    while ( !viewer.done() ) 
      {
	viewer.sync();
	viewer.update();
	viewer.frame();
      }
    viewer.sync();
  }
}
