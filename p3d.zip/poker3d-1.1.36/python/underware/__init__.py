"""Package for the
Underware library. It contains python functions and classes
that communicates with the C++ underware library.
"""

__revision__ = "$Id: __init__.py,v 1.1 2004/01/15 01:00:36 loic Exp $"

__version__ = "0.1"
