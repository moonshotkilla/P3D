/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This Program Is Distributed In The Hope That It Will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Henry Pr�cheur <henry@precheur.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#ifndef _poker_h
#define _poker_h

#define LEVEL_CLONE_SETTING (osg::CopyOp::DEEP_COPY_OBJECTS | osg::CopyOp::DEEP_COPY_NODES )
//#define LEVEL_CLONE_SETTING (osg::CopyOp::DEEP_COPY_OBJECTS | osg::CopyOp::DEEP_COPY_NODES | osg::CopyOp::DEEP_COPY_DRAWABLES | osg::CopyOp::DEEP_COPY_STATESETS| osg::CopyOp::DEEP_COPY_STATEATTRIBUTES)
//#define LEVEL_CLONE_SETTING (osg::CopyOp::DEEP_COPY_OBJECTS | osg::CopyOp::DEEP_COPY_NODES | osg::CopyOp::DEEP_COPY_DRAWABLES | osg::CopyOp::DEEP_COPY_STATESETS| osg::CopyOp::DEEP_COPY_STATEATTRIBUTES | osg::CopyOp::DEEP_COPY_ARRAYS | osg::CopyOp::DEEP_COPY_PRIMITIVES | osg::CopyOp::DEEP_COPY_SHAPES )
//#define LEVEL_CLONE_SETTING (osg::CopyOp::DEEP_COPY_ALL)

#define LEVEL_CLONE_SETTING_ALLEXCEPT_IMG_AND_TEX (osg::CopyOp::DEEP_COPY_ALL & (~(osg::CopyOp::DEEP_COPY_TEXTURES | osg::CopyOp::DEEP_COPY_IMAGES)))

#ifndef POKER_USE_VS_PCH
#include <map>
#include <vector>
#include <string>

#include <maf/model.h>
#include <maf/view.h>
#include <maf/controller.h>

#include <PokerCard.h>
#include <PokerSeat.h>
#include <PokerPot.h>
#include <PokerDoor.h>

#endif

#define POKER_SERVER_STATE_NULL		0
#define POKER_SERVER_STATE_BEGIN	1
#define POKER_SERVER_STATE_FLOP		2
#define POKER_SERVER_STATE_TURN		3
#define POKER_SERVER_STATE_RIVER	4

class PokerApplication;
class PokerPlayer;
class PokerSeatManager;
class PokerDoorController;
class MAFPacket;
class PokerMoveChips;
class PokerBoardController;
struct PokerBubbleManager;
class PokerCameraController;
class PokerPotController;
class UGAMEArtefactController;
class MAFMonitor;
class PokerSplashScreenController;
class PokerHUD;
class PokerHUDController;

namespace osg { class TexMat; }

class PokerModel : public MAFModel
{
public:
	PokerModel(PokerApplication* game,unsigned int id, const std::string &levelName, MAFMonitor *mon=NULL);
  virtual ~PokerModel();

  /// access PokerPlayer of localhost (aka client)
  PokerPlayer*  GetLocalPlayer();

  MAFOSGData* mDataDealerButton;
  osg::ref_ptr<MAFAudioController> mSoundCard;

	MAFESCNData* mDataGroundShadow;
  MAFOSGData* mSetData;
  osg::Group *mShadowedGroup;
  osg::Texture2D *mShadowMap;
  osg::BoundingBox shadowBB_;
  osg::Vec3f shadowUVScaler_;

  float mCameraTimeToReach;
  MAFCameraModel mDefaultCamera;
  MAFCameraModel mPreviousCamera;

	std::string mLevelName;
	osg::ref_ptr<PokerCameraController> mCamera;

	osg::ref_ptr<osg::TexMat> mCloudTexMat;
	osg::ref_ptr<osg::Drawable> mLensFlare;
	osg::ref_ptr<osg::Geode> mLampe;
	osg::Vec3f mUVTranslateCloudSpeed;

  typedef std::map<guint,osg::ref_ptr<PokerPlayer> > Serial2Player;
  typedef std::vector<guint> Seat2Serial;
  Serial2Player mSerial2Player;
  std::vector<osg::ref_ptr<PokerPlayer> > mSeat2Player;
  std::vector<guint> mSeat2Serial;
  std::list<osg::ref_ptr<UGAMEArtefactController> > mArtefacts;
  osg::ref_ptr<PokerSeatManager> mSeatManager;	
  osg::ref_ptr<PokerPotController> mPotCenter;
  osg::ref_ptr<PokerDoorController> mFrontDoor;
  //  osg::ref_ptr<PokerDoorController> mBackDoor;
  osg::ref_ptr<osg::Node> mDealerButton;
	osg::ref_ptr<PokerBubbleManager> mBubbleManager;
  osg::ref_ptr<PokerMoveChips> mPokerMoveChips;

  int mCurrent1Card;
  int mDealCard;
  float mDealTime;
  guint mLastPlayerDealedCard;
  
  osg::ref_ptr<PokerBoardController> mBoard;

  float mParamTimeToDealCard;
  int mNbCardToDealPerPlayer;

  std::map<int,int> mChipValue2Index;
  unsigned mPosition;
  int mSeats;
  guint	mMe;
  int mDealerButtonSeatIndex;
  int mServerState;
  unsigned int mGameSerial;
  bool	mShowStackToolTip;
  PokerApplication* mGame;

	float mGroundShadowFactor;
	float mTableShadowFactor;

  bool mBatchMode;

  std::vector<int> mDealPlayerCards;
  int mCurrentPlayerToSendCard;

  // sound data 
  // no cat for the demo
  guint	mGameId;
  osg::ref_ptr<PokerHUD> mHUD;
  osg::ref_ptr<PokerHUDController> mHUDController;  
  unsigned int mMeLastSeat;
};

typedef MAFView PokerView;

class PokerController : public MAFController
{
public:
	typedef std::vector<PokerModel*> VectorTable;

	VectorTable mTables;

private:
	PokerApplication* mGame;
  guint	mMe;

public:
  PokerController(PokerApplication* game,unsigned int id, MAFMonitor *mon=NULL);
  virtual ~PokerController();

  PokerModel* GetModel() { return dynamic_cast<PokerModel*>(MAFController::GetModel()); }

	void PlayerLeave(guint serial);
  void SetPot(const std::vector<int>& amount,int index=0);
  void SetCards(const std::vector<int>& cards); 
  void FoldCards(void); 
  virtual bool Update(MAFApplication* application);
  void PythonAccept(MAFPacket* packet);
  template<typename T>
    void GameAccept(const T&);
  //  void GameAccept(const std::string& message);
	void CreateOrUseLevel(unsigned int gameID,const std::string& level);
  bool IsLevelExist(unsigned int tableId);
  PokerModel* GetLevelFromId(unsigned int tableId);
	void DeleteLevel(unsigned int gameID);
  void DeleteAllLevels();
	void DealerChangeToSeat(int seat);
	float GetShadowFactorForCurrentLevel(const std::string &type);

#ifdef TEST_PERFORMANCE
  int mPerfCharacteres;
#endif

protected:

	void UpdateModel(PokerApplication *);

	osg::ref_ptr<PokerSplashScreenController> loader_;
	unsigned int nbPlayersAtTable_;
	int nbGames_;
};

#endif // _poker_h
