#
# Copyright (C) 2004-2006 Mekensleep
#
# Mekensleep
# 24 rue vieille du temple
# 75004 Paris
#       licensing@mekensleep.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
# Authors:
#  Loic Dachary <loic@gnu.org>
#
import socket

import sys
import os
from time import sleep
from shutil import copy
from string import split, replace
from os.path import exists

from twisted.internet import reactor
from twisted.internet import defer

from pokernetwork.pokerchildren import PokerChild
from pokerui import pokerinterface

def expand(url, command, substitute):
    args = []
    for arg in split(command):
        for (original, destination) in substitute.iteritems():
            arg = replace(arg, original, destination)
        args.append(arg)
    if not exists(args[0]):
        raise Exception, "ERROR: %s, as found in %s at line %s is not an existing file." % ( args[0], url, command )
    return args

from twisted.internet.protocol import ProcessProtocol
from twisted.internet import defer

import platform
if platform.system() == "Windows":
	from underware import python_mywin32
	import win32process

PROCESS_XWNC_STARTED = "//event/poker3d/pokerchildren/xwncstarted"
PROCESS_XWNC_STOPPED = "//event/poker3d/pokerchildren/xwncstopped"
class PokerChildXwnc(PokerChild, ProcessProtocol):

    def __init__(self, config, settings):
        PokerChild.__init__(self, config, settings)
        self.display = None
        self.ready = self.configure()
        self.deferred = defer.Deferred()
        self.registerHandler(PROCESS_XWNC_STOPPED, lambda: self.deferred.callback(True))
        self.kill()
        
    def configure(self):
        config = self.config
        settings = self.settings

        screen = self.settings.headerGetProperties("/settings/screen")[0]
        datadir = settings.headerGet("/settings/data/@path")
        self.display = settings.headerGet("/settings/metisse/@display")
        substitutions = {}
        substitutions["%width%"] = screen["width"]
        substitutions["%height%"] = screen["height"]
        substitutions["%display%"] = self.display

        if not settings.headerGetList("/settings/metisse/xwnc"):
            print "no <xwnc> found in config file (ignored)"
            return False
        self.spawnInDir = replace(settings.headerGet("/settings/metisse/xwnc/@chdir"), "%datadir%", datadir)
        self.commandLine = expand(self.settings.path, settings.headerGet("/settings/metisse/xwnc"), substitutions)
        self.commandName = split(self.commandLine[0],"/").pop()
        self.pidFile = self.commandName + self.display
        if self.verbose:
            print "command name of xwnc : " + self.commandName
        return True

    def spawn(self):
	dir = self.spawnInDir
	import platform
        if platform.system() == "Windows":
            self.proc = reactor.spawnProcess(self, self.commandLine[0], args = self.commandLine, path = dir, win32flags = win32process.DETACHED_PROCESS)
        else:
            childFDs = { 1: 'r', 2: 'r' }
            self.proc = reactor.spawnProcess(self, self.commandLine[0], args = self.commandLine, path = dir,
                                             childFDs = childFDs)
        retry = 5
        if self.verbose:
            print "Wait for xwnc to respond (will try for %d seconds) " % retry
        for i in xrange(retry):
            try:
                fd = socket.socket()
                fd.settimeout(2)
                fd.connect(('127.0.0.1', 5900 + int(self.display)))
                fd.close()
                return True
                break
            except socket.error:
                print ".",
                sys.stdout.flush()
                sleep(1)
        return False

    def kill(self):
	if platform.system() == "Windows":
	    python_mywin32.killProcessByName(self.commandName)
	else:
	    if self.transport != None:
	        if self.transport.pid != None:
		    os.kill(self.transport.pid, 9)

    def connectionMade(self):
	self.publishEvent(PROCESS_XWNC_STARTED)

    def processEnded(self, status_object):
	self.publishEvent(PROCESS_XWNC_STOPPED)

    def outReceived(self, data):
	for line in data.split('\n'):
	    print "PokerChildXwnc: %s" % line

    def errReceived(self, data):
	for line in data.split('\n'):
            print "PokerChildXwnc: %s" % line

CHILD_INTERFACE_READY = "//event/poker3d/pokerchildren/lobbyready"
CHILD_INTERFACE_GONE= "//event/poker3d/pokerchildren/lobbygone"
PROCESS_INTERFACE_STARTED = "//event/poker3d/pokerchildren/interfacestarted"
PROCESS_INTERFACE_STOPPED = "//event/poker3d/pokerchildren/interfacestopped"

class PokerChildInterface(PokerChild, ProcessProtocol):
    def __init__(self, config, settings):
        PokerChild.__init__(self, config, settings)
        self.verbose = settings.headerGetInt("/settings/@verbose")
        self.port = settings.headerGetInt("/settings/metisse/lobby/@port")
        self.ready = ( settings.headerGetList("/settings/metisse/lobby") and
                       self.configure() )
        self.listener = None
        self.deferred = defer.Deferred()
        self.registerHandler(PROCESS_INTERFACE_STOPPED, lambda: self.deferred.callback(True))
        self.kill()

    def configure(self):
        config = self.config
        settings = self.settings

        display = settings.headerGet("/settings/metisse/@display")
        datadir = settings.headerGet("/settings/data/@path")
        substitutions = {}
        substitutions["%port%"] = str(self.port)
        substitutions["%display%"] = display
        substitutions["%verbose%"] = str(self.verbose)
        substitutions["%datadir%"] = datadir

        if not settings.headerGetList("/settings/metisse/lobby"):
            print "no <lobby> found in config file (ignored)"
            return False
        self.spawnInDir = replace(settings.headerGet("/settings/metisse/lobby/@chdir"), "%datadir%", datadir)
        self.commandLine = expand(self.settings.path, settings.headerGet("/settings/metisse/lobby"), substitutions)
        self.commandName = split(self.commandLine[0],"/").pop()
        self.pidFile = self.commandName + str(self.port)
        if self.verbose:
            print "command name of lobby : " + self.commandName
        return True

    def lobbyReady(self, lobby, lobbyFactory):
        self.publishEvent(CHILD_INTERFACE_READY, self, lobby, lobbyFactory)

    def lobbyGone(self, lobby, lobbyFactory):
        self.publishEvent(CHILD_INTERFACE_GONE, self, lobby, lobbyFactory)
        
    def spawn(self):
        lobby = pokerinterface.PokerInterfaceFactory(verbose = self.verbose)
        lobby.registerHandler(pokerinterface.INTERFACE_READY, self.lobbyReady)
        lobby.registerHandler(pokerinterface.INTERFACE_GONE, self.lobbyGone)
        self.listener = reactor.listenTCP(self.port, lobby)
	dir = self.spawnInDir
	import platform
	print self.commandLine
        if platform.system() == "Windows":
            environment = {"PANGO_RC_FILE" : "conf/pangorc", "FONTCONFIG_PATH" : "conf", "GTK_PATH" :  "./", "GDK_PIXBUF_MODULE_FILE" :  "conf/gdk-pixbuf.loaders"}
            environment.update(os.environ)
            self.proc = reactor.spawnProcess(self, self.commandLine[0], args = self.commandLine, env = environment, path = dir, win32flags = win32process.DETACHED_PROCESS)
        else:
            childFDs = { 1: 'r', 2: 'r' }
            self.proc = reactor.spawnProcess(self, self.commandLine[0], args = self.commandLine, env = os.environ, path = dir,
                                             childFDs = childFDs)
	return True

    def kill(self):
	if platform.system() == "Windows":
	    python_mywin32.killProcessByName(self.commandName)
	else:
	    if self.transport != None:
	        if self.transport.pid != None:
	            os.kill(self.transport.pid, 9)

    def connectionMade(self):
        self.publishEvent(PROCESS_INTERFACE_STARTED)

    def processEnded(self, status_object):
        self.publishEvent(PROCESS_INTERFACE_STOPPED)

    def outReceived(self, data):
	for line in data.split('\n'):
	    print "PokerChildInterface: %s" % line

    def errReceived(self, data):
	for line in data.split('\n'):
            print "PokerChildInterface: %s" % line
