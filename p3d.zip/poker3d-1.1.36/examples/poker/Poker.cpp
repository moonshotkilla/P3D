/**
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Henry Pr�cheur <henry@precheur.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 *  Igor Kravtchenko <igor@tsarevitch.org>
 */

#include "pokerStdAfx.h"
#include  <PokerEvent.h>

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */
#ifdef WIN32
#include <cstdio>
# define snprintf _snprintf
#endif

#ifndef WIN32
#include <unistd.h>
#endif

#ifndef POKER_USE_VS_PCH
#ifdef USE_NPROFILE
#include <nprofile/profile.h>
#else  //USE_NPROFILE
#define NPROFILE_SAMPLE(a)
#endif //USE_NPROFILE

#include <maf/osghelper.h>
#include <maf/wnc_desktop.h>
#include <maf/assert.h>
#include <varseditor/varseditor.h>
#include <osg/MatrixTransform>
#include <osg/BlendFunc>
#include <osg/AlphaFunc>
#include <osg/Depth>
#include <osg/LightSource>
#include <osg/VertexProgram>
#include <osg/FragmentProgram>
#include <osg/Stencil>
#include <osg/Material>
#include <osg/TextureCubeMap>

#include <osgUtil/Optimizer>

#include <maf/maferror.h>
#include <maf/packets.h>
#include <maf/scene.h>
#include <maf/cursor.h>
#include <maf/utils.h>
#include <maf/animate2d.h>
#include <maf/MultipleAnimationPathCallback.h>
#include <maf/window.h>
#include <maf/shadow.h>
#include <maf/renderbin.h>
#include <maf/osghelper.h>
#include <ugame/animated.h>
#include <ugame/BetSlider>
#include <ugame/debug.h>
#include <string>

#	include "PokerApplication.h"
#	include "PokerPlayer.h"
#	include "PokerCard.h"
#	include "Poker.h"
#	include "PokerChipsStack.h"
#	include "PokerSeat.h"
#	include "PokerMoveChips.h"
#	include "PokerCamera.h"
# include "PokerCursor.h"
# include "PokerSceneView.h"

#include <osgDB/Registry>
#include <osgDB/ReadFile>
#include <osgDB/WriteFile>
#include <PokerBoard.h>
#include <PokerBody.h>
#include "PokerBubbleManager.h"
#include "PokerSceneView.h"
#include "PokerMultiTable.h"
#include "PokerPlayerCamera.h"
#include "PokerInteractor.h"
#endif

#include <maf/wnc_source.h>
#include "CustomAssert/CustomAssert.h"
#include "PokerHUD/PokerHUD.h"

#include "osgSprite/osgSprite.h"

#define DEFAULT_LEVEL_SKIN "level00"

static int iFrame = 0;

static void Plop()
{
  ;
}

struct PokerTableController : UGAMEArtefactController
{
};

template <>
void PokerController::GameAccept<PokerEventPotChips>(const PokerEventPotChips& event)
{
  if (!GetModel())
    return;
  GetModel()->mPokerMoveChips->GameAccept(event);
}

template <>
void PokerController::GameAccept<PokerEventPlayerLeave>(const PokerEventPlayerLeave& event)
{
  if (!GetModel())
    return;
  GetModel()->mPokerMoveChips->GameAccept(event);
}

template <>
void PokerController::GameAccept<PokerEventChipsBet2Pot>(const PokerEventChipsBet2Pot& event)
{
  if (!GetModel())
    return;
  GetModel()->mPokerMoveChips->GameAccept(event);
}

template <>
void PokerController::GameAccept<PokerEventChipsPot2Player>(const PokerEventChipsPot2Player& event)
{
  if (!GetModel())
    return;
  GetModel()->mPokerMoveChips->GameAccept(event);
}

template <>
void PokerController::GameAccept<PokerEventQuit>(const PokerEventQuit& event)
{
  mGame->SendPythonEvent("QUIT");
}


template <>
void PokerController::GameAccept<PokerEventSwitchToExistingTable>(const PokerEventSwitchToExistingTable& event)
{
  if (!GetModel())
    return;
  GetModel()->mPokerMoveChips->GameAccept(event);
}

template <>
void PokerController::GameAccept<PokerEventGameStart>(const PokerEventGameStart& event)
{
  if (!GetModel())
    return;
  GetModel()->mPokerMoveChips->GameAccept(event);
}

template<>
void PokerController::GameAccept<PokerEventEndRound>(const PokerEventEndRound& event)
{
  if (!GetModel())
    return;
  GetModel()->mPokerMoveChips->GameAccept(event);
}

template <>
void PokerController::GameAccept<PokerEventPlayerFold>(const PokerEventPlayerFold& event)
{
  if (!GetModel())
    return;
  GetModel()->mPokerMoveChips->GameAccept(event);
}

template <>
void PokerController::GameAccept<PokerEventEndLeaveFirstPerson>(const PokerEventEndLeaveFirstPerson& event)
{
  if (!GetModel())
    return;
  GetModel()->mBubbleManager->GameAccept(event);
}

template <>
void PokerController::GameAccept<PokerEventStartFirstPerson>(const PokerEventStartFirstPerson& event)
{
  PokerModel* model = GetModel();
  if (!model)
    return;

  mGame->PythonCall("setPlayerInFirstPerson");
  model->mHUD->Show(model->mMeLastSeat);
  for(std::map<guint,osg::ref_ptr<PokerPlayer> >::iterator i = model->mSerial2Player.begin(); i != model->mSerial2Player.end(); ++i) {
    PokerPlayer* player = i->second.get();
    player->GetShowdown()->DisableProjector();
  }
  model->mBubbleManager->GameAccept(event);
}

template <>
void PokerController::GameAccept<PokerEventEndFirstPerson>(const PokerEventEndFirstPerson& event)
{
  PokerModel* model = GetModel();
  if (!model)
    return;

  mGame->PythonCall("setPlayerNotInFirstPerson");
  model->mHUD->Hide(model->mMeLastSeat);
  for(std::map<guint,osg::ref_ptr<PokerPlayer> >::iterator i = model->mSerial2Player.begin(); i != model->mSerial2Player.end(); ++i) {
    PokerPlayer* player = i->second.get();
    player->GetShowdown()->EnableProjector();
  }
}


class StopXwncWhileSlide : public MAFApplication2DAnimateCallBack
{
	wncSource* mSource;
	PokerApplication* mGame;
public:
	StopXwncWhileSlide(wncSource* source,PokerApplication* game) { mSource = source; mGame = game;}

	virtual void Process(MAFApplication2DAnimate* caller) {
		MAFApplication2DAnimate* animate = caller;
		int mCountSwitching = 0;
		if (animate) {
			for (unsigned int i = 0; i < animate->size(); i++) {

				MAFApplication2DSlide* slide = dynamic_cast<MAFApplication2DSlide*>((*animate)[i].get());
				if (slide)
					if (slide->GetSwitching())
						mCountSwitching++;
			}
		}
		if (mCountSwitching) {
			mSource->freeze();
		}
	}
};



PokerModel::PokerModel(PokerApplication* game,unsigned int controllerID, const std::string &levelName, MAFMonitor *_mon) :
  mSeats(0), mMe(0), mGameSerial(0), mShowStackToolTip(false), mGame(game), mGameId(0), mHUD(0), mHUDController(0), mMeLastSeat(0)
{
  std::string seats_string = game->HeaderGet("sequence", "/sequence/seat/@count");
  if(seats_string == "") g_error("PokerModel::PokerModel: failed to read /sequence/seat/@count");
  mSeats = atoi(seats_string.c_str());

  mBatchMode=false;

  for(int seat = 0; seat < mSeats; seat++) {
    mSeat2Serial.push_back(0);
    mSeat2Player.push_back(0);
  }

  {
    std::string set_name = game->HeaderGet("sequence", "/sequence/set/@url");
    mSetData = dynamic_cast<MAFOSGData*>(game->mDatas->GetVision(set_name, _mon ));
    mSetData = static_cast<MAFOSGData*>(mSetData->Clone(LEVEL_CLONE_SETTING));
    game->mSetData=mSetData;
  }

	{
    std::string u = game->HeaderGet("sequence", "/sequence/levelParameters[@index=3]/cloudUVSpeed/@u");
    std::string v = game->HeaderGet("sequence", "/sequence/levelParameters[@index=3]/cloudUVSpeed/@v");
    std::string w = game->HeaderGet("sequence", "/sequence/levelParameters[@index=3]/cloudUVSpeed/@w");

		mUVTranslateCloudSpeed = osg::Vec3f(0, 0, 0);

		if (u.size() > 0)
			mUVTranslateCloudSpeed._v[0] = atof( u.c_str() );

		if (v.size() > 0)
			mUVTranslateCloudSpeed._v[1] = atof( v.c_str() );

		if (w.size() > 0)
			mUVTranslateCloudSpeed._v[2] = atof( w.c_str() );
	}

  const std::string &shadow = game->HeaderGet("settings", "/settings/shadow");
	bool shadowFlag=false;
  if (shadow == "on" || shadow == "yes")
    shadowFlag=true;

  osg::Group *setData = mSetData->GetGroup();

	mDataGroundShadow=0;
	{
		mGroundShadowFactor = 0.8f;
		mTableShadowFactor = 0.8f;

		char str[200];
		int indexLevel = atoi (levelName.c_str() + 5);

		sprintf(str, "/sequence/levelParameters[@index=%d]/groundShadow/@factor", indexLevel);
		std::string strShadowFactor = mGame->HeaderGet("sequence", str);
		if (strShadowFactor.size())
			mGroundShadowFactor = atof( strShadowFactor.c_str() );

		sprintf(str, "/sequence/levelParameters[@index=%d]/tableShadow/@factor", indexLevel);
		strShadowFactor = mGame->HeaderGet("sequence", str);
		if (strShadowFactor.size())
			mTableShadowFactor = atof( strShadowFactor.c_str() );
	}

  if (shadowFlag) {
	  MAFESCNData *data = (MAFESCNData*) game->mDatas->GetVision("groundShadow.escn");
		data=(MAFESCNData*) data->Clone(LEVEL_CLONE_SETTING);
		mDataGroundShadow=data;
	  osg::Group *groundShadow = data->GetGroup();

	  osg::MatrixTransform *shad = (osg::MatrixTransform*) GetNode(setData, "transform_groundShadow");
	  shad->addChild(groundShadow);
	  setData->addChild(shad);
	  osg::Stencil *stencil = new osg::Stencil;
	  stencil->setFunction(osg::Stencil::ALWAYS, 0x2, 0xffffffff);
	  stencil->setOperation(osg::Stencil::REPLACE, osg::Stencil::KEEP, osg::Stencil::REPLACE);
	  shad->getOrCreateStateSet()->setAttributeAndModes(stencil, osg::StateAttribute::ON);

		if (!MAFRenderBin::Instance().SetupRenderBin("GroundShadow", shad->getOrCreateStateSet()))
			MAF_ASSERT(0 && "GroundShadow not found in client.xml");

	  osg::ColorMask *cmask = new osg::ColorMask;
	  cmask->setMask(false, false, false, false);
	  shad->getOrCreateStateSet()->setAttributeAndModes(cmask, osg::StateAttribute::ON);

	  osg::Geode *geode = (osg::Geode*) groundShadow->getChild(0);
	  shadowBB_ = geode->getBoundingBox();
	  shadowUVScaler_.set(1.0f/(shadowBB_._max._v[0] - shadowBB_._min._v[0]),
		  1.0f/(shadowBB_._max._v[1] - shadowBB_._min._v[1]),
		  1.0f/(shadowBB_._max._v[2] - shadowBB_._min._v[2]) );
  }

	// set collision to table
	// add collision from root to transform
	{
		osg::NodePath pathToAddCollisionMask;
		osg::Node *shad = (osg::MatrixTransform*) GetNode(setData, "mesh_Table");
		if (shad) {
			MAFCreateNodePath(shad, pathToAddCollisionMask);
			for (osg::NodePath::iterator it = pathToAddCollisionMask.begin(); it != pathToAddCollisionMask.end(); it++) {
				unsigned int mask = (*it)->getNodeMask();
				mask =  mask | MAF_COLLISION_MASK;
				(*it)->setNodeMask(mask);
			}
		} else {
			g_error("PokerModel::PokerModel mesh_table not found in set.escn");
		}
	}

	{
		osg::Geode *geode = OSGHelper_getGeodeByName(*setData, "mesh_flare");
		if (geode) {
			geode->getOrCreateStateSet()->setAttributeAndModes( new DepthMask(false) );
			geode->getOrCreateStateSet()->setRenderBinDetails(10, "DepthSortedBin");
			osg::Drawable *draw = geode->getDrawable(0);
			draw->getOrCreateStateSet()->setRenderBinDetails(1, "RenderBin");
			mLensFlare = draw;
		}
	}

	{
		osg::Geode *geode = OSGHelper_getGeodeByName(*setData, "mesh_lampe");
		if (geode) {
			geode->getOrCreateStateSet()->setRenderBinDetails(10, "DepthSortedBin");
			geode->getOrCreateStateSet()->setAttributeAndModes( new osg::BlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA) );
			osg::Drawable *draw = geode->getDrawable(0);
			mLampe = geode;
		}
	}

	{
		osg::Geode *geode = OSGHelper_getGeodeByName(*setData, "mesh_globeNuages");
		if (geode) {
			osg::Drawable *draw = geode->getDrawable(0);
			mCloudTexMat = new osg::TexMat();
			draw->getOrCreateStateSet()->setTextureAttributeAndModes(0, mCloudTexMat.get());
		}
	}

	{
		osg::Geode *geode = OSGHelper_getGeodeByName(*setData, "mesh_wygne");
		if (geode) {
			osg::Geometry *geom = (osg::Geometry*) geode->getDrawable(0);

			osg::AlphaFunc *af = new osg::AlphaFunc(osg::AlphaFunc::EQUAL, 1.0f);
			geom->getOrCreateStateSet()->setAttributeAndModes(af);

			osg::Texture2D *tex = (osg::Texture2D*) geom->getOrCreateStateSet()->getTextureAttribute(0, osg::StateAttribute::TEXTURE);
			tex->setFilter(osg::Texture2D::MIN_FILTER, osg::Texture2D::LINEAR);
			tex->setFilter(osg::Texture2D::MAG_FILTER, osg::Texture2D::LINEAR);
		}
	}

	{
		osg::Geode *geode = OSGHelper_getGeodeByName(*setData, "mesh_grass");
		if (geode) {
			osg::Geometry *geom = (osg::Geometry*) geode->getDrawable(0);

		//	osg::AlphaFunc *af = new osg::AlphaFunc(osg::AlphaFunc::EQUAL, 1.0f);
			//geom->getOrCreateStateSet	()->setAttributeAndModes(af);

			osg::Texture2D *tex = (osg::Texture2D*) geom->getOrCreateStateSet()->getTextureAttribute(0, osg::StateAttribute::TEXTURE);
			tex->setFilter(osg::Texture2D::MIN_FILTER, osg::Texture2D::LINEAR);
			tex->setFilter(osg::Texture2D::MAG_FILTER, osg::Texture2D::LINEAR);
		}
	}

	if (shadowFlag) {
	  osg::MatrixTransform *shad = (osg::MatrixTransform*) GetNode(setData, "transform_Table");
	  osg::Stencil *stencil = new osg::Stencil;
	  stencil->setFunction(osg::Stencil::ALWAYS, 0x1, 0xffffffff);
	  stencil->setOperation(osg::Stencil::REPLACE, osg::Stencil::KEEP, osg::Stencil::REPLACE);
	  shad->getOrCreateStateSet()->setAttributeAndModes(stencil, osg::StateAttribute::ON);

		if (!MAFRenderBin::Instance().SetupRenderBin("TableShadow", shad->getOrCreateStateSet()))
			MAF_ASSERT(0 && "TableShadow not found in client.xml");

	  osg::MatrixTransform *mt = new osg::MatrixTransform();
	  mt->setMatrix( shad->getMatrix() * MAFBuildShadowMatrix(osg::Plane(0, 1, 0, 0), osg::Vec4f(0, 1, 0, 0) ) );
	  setData->addChild(mt);

	  osg::Depth *dp = new osg::Depth();
	  dp->setWriteMask(FALSE);
	  mt->getOrCreateStateSet()->setAttributeAndModes(dp, osg::StateAttribute::OVERRIDE);

		if (!MAFRenderBin::Instance().SetupRenderBin("TableShadowProjected", mt->getOrCreateStateSet()))
			MAF_ASSERT(0 && "TableShadowProjected not found in client.xml");

	  mt->setNodeMask(MAF_VISIBLE_MASK);

	  osg::Material* material = new osg::Material;
	  material->setAmbient(osg::Material::FRONT_AND_BACK, osg::Vec4(0.0f, 0.0f, 0.0f, 0.0f));
	  material->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4(0.0f, 0.0f, 0.0f, 0.0f));
		material->setEmission(osg::Material::FRONT_AND_BACK, osg::Vec4(0.8f, 0.8f, 0.8f, 0.0f));
	  material->setShininess(osg::Material::FRONT_AND_BACK, 0.0f);
	  mt->getOrCreateStateSet()->setAttribute(material, osg::StateAttribute::OVERRIDE);

		mt->getOrCreateStateSet()->setTextureMode(0, GL_TEXTURE_2D, osg::StateAttribute::OVERRIDE | osg::StateAttribute::OFF);
		mt->getOrCreateStateSet()->setTextureMode(1, GL_TEXTURE_2D, osg::StateAttribute::OVERRIDE | osg::StateAttribute::OFF);
		mt->getOrCreateStateSet()->setTextureMode(2, GL_TEXTURE_2D, osg::StateAttribute::OVERRIDE | osg::StateAttribute::OFF);
		mt->getOrCreateStateSet()->setTextureMode(3, GL_TEXTURE_CUBE_MAP, osg::StateAttribute::OVERRIDE | osg::StateAttribute::OFF);

		mt->getOrCreateStateSet()->setMode(GL_VERTEX_PROGRAM_ARB, osg::StateAttribute::OVERRIDE | osg::StateAttribute::OFF);
		mt->getOrCreateStateSet()->setMode(GL_FRAGMENT_PROGRAM_ARB, osg::StateAttribute::OVERRIDE | osg::StateAttribute::OFF);

	  osg::BlendFunc *blend = new osg::BlendFunc;
	  blend->setFunction(GL_DST_COLOR, GL_ZERO);
	  mt->getOrCreateStateSet()->setAttributeAndModes(blend, osg::StateAttribute::OVERRIDE | osg::StateAttribute::ON);
	  mt->getOrCreateStateSet()->setMode(GL_LIGHTING, osg::StateAttribute::OVERRIDE | osg::StateAttribute::ON);

	  osg::Stencil *stenc = new osg::Stencil;
	  stenc->setFunction(osg::Stencil::EQUAL, 0x2, 0xffffffff);
	  stenc->setOperation(osg::Stencil::KEEP, osg::Stencil::ZERO, osg::Stencil::ZERO);
	  mt->getOrCreateStateSet()->setAttributeAndModes(stenc);
	  mt->getOrCreateStateSet()->setMode(GL_STENCIL_TEST, TRUE);

	  int nbChilds = shad->getNumChildren();
	  for (int i = 0; i < nbChilds; i++) {
		  osg::Node *child = shad->getChild(i);
		  mt->addChild(child);
	  }
  }

	if (shadowFlag) {
	  osg::MatrixTransform *shad = (osg::MatrixTransform*) GetNode(setData, "transform_tabcenter");
	  osg::MatrixTransform *mt = new osg::MatrixTransform();
	  mt->setMatrix( shad->getMatrix() * MAFBuildShadowMatrix(osg::Plane(0, 1, 0, 0), osg::Vec4f(0, 1, 0, 0) ) );
	  setData->addChild(mt);

	  osg::Depth *dp = new osg::Depth();
	  dp->setWriteMask(FALSE);
	  mt->getOrCreateStateSet()->setAttributeAndModes(dp, osg::StateAttribute::OVERRIDE);
		if (!MAFRenderBin::Instance().SetupRenderBin("TableCenterShadowProjected", mt->getOrCreateStateSet()))
			MAF_ASSERT(0 && "TableCenterShadowProjected not found in client.xml");

	  mt->setNodeMask(MAF_VISIBLE_MASK);

	  osg::Material* material = new osg::Material;
	  material->setAmbient(osg::Material::FRONT_AND_BACK, osg::Vec4(0.0f, 0.0f, 0.0f, 0.0f));
	  material->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4(0.0f, 0.0f, 0.0f, 0.0f));
		material->setEmission(osg::Material::FRONT_AND_BACK, osg::Vec4(0.8f, 0.8f, 0.8f, 0.0f));
	  material->setShininess(osg::Material::FRONT_AND_BACK, 0.0f);
	  mt->getOrCreateStateSet()->setAttribute(material, osg::StateAttribute::OVERRIDE);

		mt->getOrCreateStateSet()->setTextureMode(0, GL_TEXTURE_2D, osg::StateAttribute::OVERRIDE | osg::StateAttribute::OFF);
		mt->getOrCreateStateSet()->setTextureMode(1, GL_TEXTURE_2D, osg::StateAttribute::OVERRIDE | osg::StateAttribute::OFF);
		mt->getOrCreateStateSet()->setTextureMode(2, GL_TEXTURE_2D, osg::StateAttribute::OVERRIDE | osg::StateAttribute::OFF);
		mt->getOrCreateStateSet()->setTextureMode(3, GL_TEXTURE_CUBE_MAP, osg::StateAttribute::OVERRIDE | osg::StateAttribute::OFF);

		mt->getOrCreateStateSet()->setMode(GL_VERTEX_PROGRAM_ARB, osg::StateAttribute::OVERRIDE | osg::StateAttribute::OFF);
		mt->getOrCreateStateSet()->setMode(GL_FRAGMENT_PROGRAM_ARB, osg::StateAttribute::OVERRIDE | osg::StateAttribute::OFF);

	  osg::BlendFunc *blend = new osg::BlendFunc;
	  blend->setFunction(GL_DST_COLOR, GL_ZERO);
	  mt->getOrCreateStateSet()->setAttributeAndModes(blend, osg::StateAttribute::OVERRIDE | osg::StateAttribute::ON);
	  mt->getOrCreateStateSet()->setMode(GL_LIGHTING, osg::StateAttribute::OVERRIDE | osg::StateAttribute::ON);

	  osg::Stencil *stenc = new osg::Stencil;
	  stenc->setFunction(osg::Stencil::EQUAL, 0x2, 0xffffffff);
	  stenc->setOperation(osg::Stencil::KEEP, osg::Stencil::ZERO, osg::Stencil::ZERO);
	  mt->getOrCreateStateSet()->setAttributeAndModes(stenc);
	  mt->getOrCreateStateSet()->setMode(GL_STENCIL_TEST, TRUE);

	  int nbChilds = shad->getNumChildren();
	  for (int i = 0; i < nbChilds; i++) {
		  osg::Node *child = shad->getChild(i);
		  mt->addChild(child);
	  }
  }

  //
  // The board
  //
  mBoard=new PokerBoardController(game,controllerID);
  game->AddController(mBoard.get());
  
  {
    std::string dealer_name = mGame->HeaderGet("sequence", "/sequence/dealer/@url");
    MAFOSGData* data = dynamic_cast<MAFOSGData*>(mGame->mDatas->GetVision(dealer_name));
    if(data == 0)
      g_error("PokerModel: cannot do without dealer button");
		data=(MAFOSGData*)data->Clone(LEVEL_CLONE_SETTING);
		mDataDealerButton=data;
    mDealerButton = data->GetGroup();
  }


  mSeatManager = new PokerSeatManager(controllerID);
  mSeatManager->Init(game);
  game->AddController(mSeatManager.get());

  mPotCenter= new PokerPotController(game,controllerID);
  game->AddController(mPotCenter.get());

  mFrontDoor = new PokerDoorController(controllerID);
  mFrontDoor->Init(game, "/sequence/doors/door01");
  game->AddController(mFrontDoor.get());

  mPokerMoveChips = new PokerMoveChips(mSerial2Player);

	mBubbleManager = new PokerBubbleManager(controllerID);
	mBubbleManager->Init(game);
	

  mDealCard=0;
  mDealTime=0;
  mLastPlayerDealedCard=0;
  mDealPlayerCards.clear();

  std::string paramMinTimeToDealCard=game->HeaderGet("sequence", "/sequence/seat/@minTimeToDealCard");
  if (paramMinTimeToDealCard.empty())
    g_error("PokerModel::PokerModel /sequence/seat/@minTimeToDealCard not found");
  mParamTimeToDealCard=atof(paramMinTimeToDealCard.c_str());
	Plop();

	const std::string &sound_url_anchor = mGame->HeaderGet("sequence","/sequence/dealcard/@sound_anchor");
	if (sound_url_anchor.empty())
		g_error("PokerModel::PokerModel %s not found", sound_url_anchor.c_str());
	osg::Group* anchor = game->mSetData->GetAnchor(sound_url_anchor);
	if (!anchor) {
		g_error("PokerModel::PokerModel Anchor %s not found", sound_url_anchor.c_str());
	}
    
	const std::string &sound_url = mGame->HeaderGet("sequence","/sequence/dealcard/@sound");
	if (sound_url.empty())
		g_debug("PokerModel::PokerModel %s not found", sound_url.c_str());
	else {
		MAFAudioData *data = mGame->mDatas->GetAudio(sound_url);
		if (data) {

			const std::string &reference_distance_url = mGame->HeaderGet("sequence","/sequence/dealcard/@reference_distance");
			if (reference_distance_url.empty())
				g_error("PokerModel::PokerModel /sequence/dealcard/@reference_distance not found");
			float d = atof(reference_distance_url.c_str());

			const std::string &volume_url = mGame->HeaderGet("sequence","/sequence/dealcard/@volume");
			if (volume_url.empty())
				g_error("PokerModel::PokerModel /sequence/dealcard/@volume not found");
			float v = atof(volume_url.c_str());

			const std::string &rolloff_url = mGame->HeaderGet("sequence","/sequence/dealcard/@rolloff");
			if (rolloff_url.empty())
				g_error("PokerModel::PokerModel /sequence/dealcard/@rolloff not found");
			float r = atof(rolloff_url.c_str());

			MAFAudioModel* audio_model = new MAFAudioModel;
			audio_model->SetName("soundCardDealed");
			audio_model->SetData(data);
			audio_model->SetGain(v);
			audio_model->SetRolloff(r);
			audio_model->SetAmbient(false);
			audio_model->SetSoundEvent(true);
			audio_model->SetReferenceDistance(d);
			mSoundCard = new MAFAudioController;
			mSoundCard->SetModel(audio_model);
			mSoundCard->Init();
			mSoundCard->AttachTo(anchor);
		}
	}

  {
	  std::string camera_name = game->HeaderGet("sequence", "/sequence/set/@camera");
	  mCamera = new PokerCameraController(game,controllerID);
	  game->GetScene()->GetModel()->mCamera = mCamera.get();
	  MAFCameraModel* from_model = mSetData->GetCamera(camera_name)->GetModel();
	  mDefaultCamera = *from_model;
	  std::string time_to_reach_string = game->HeaderGet("sequence", "/sequence/cameras/@timeToReach");
	  mCameraTimeToReach = atof(time_to_reach_string.c_str());
	  const osg::Vec3 &position = from_model->GetPosition();
	  const osg::Vec3 &target = from_model->GetTarget();
	  const osg::Vec3 &up = from_model->GetUp();
	  float fov = from_model->GetFov();
	  mCamera->GetModel()->SetPosition(position);
	  mCamera->GetModel()->SetTarget(target);
	  mCamera->GetModel()->SetUp(up);
	  mCamera->GetModel()->SetFov(fov);
	  mCamera->Init();

	  game->AddController(mCamera.get());
  }

	{
	  unsigned int w = game->GetWindow(true)->GetWidth();
	  unsigned int h = game->GetWindow(true)->GetHeight();
	  CUSTOM_ASSERT(game->GetHeaders().find("sequence") != game->GetHeaders().end());
	  xmlDocPtr header = game->GetHeaders()["sequence"];
	  std::string dataDir = game->HeaderGet("settings", "/settings/data/@path") + "/";
	  mHUD = new PokerHUD();
	  mHUD->Load(header, "/sequence/hud", w, h, dataDir);
	  mHUDController = new PokerHUDController(mHUD.get());
	  if (!MAFRenderBin::Instance().SetupRenderBin("HUDFirstPerson", mHUD->getOrCreateStateSet()))
	  MAF_ASSERT(0 && "HUDFirstPerson not found in client.xml");
	  mSetData->GetGroup()->addChild(mHUD.get());
	}
}

PokerModel::~PokerModel() {
	Plop();

	g_debug("PokerModel::~PokerModel()");
  RecursiveClearUserData(mSetData->GetGroup());

	for(std::map<guint,osg::ref_ptr<PokerPlayer> >::iterator i = mSerial2Player.begin(); i != mSerial2Player.end(); i++) {
		PokerPlayer* player = i->second.get();
		// Leave the seat
		mSeat2Serial[player->GetSeatId()] = 0;
		mSeat2Player[player->GetSeatId()] = 0;
		player->SetSeatId(POKER_PLAYER_NO_SEAT);

		// remove player controler else the player is not deleted
		mGame->RemoveController(player);
	}
	mSerial2Player.clear();

  mGame->RemoveController(mSeatManager.get());
  mSeatManager = 0;

	mGame->RemoveController(mCamera.get());
	mCamera=0;

	mGame->RemoveController(mBoard.get());
	mBoard=0;
	
	if (mDataGroundShadow)
		delete mDataGroundShadow;

	delete mDataDealerButton;
	mDataDealerButton = NULL;
	delete mSetData;
	mSetData = NULL;

  mGame->RemoveController(mPotCenter.get());
  mPotCenter=0;

  RecursiveClearUserData(mFrontDoor->GetModel()->mDoorCollNode.get());
  mGame->RemoveController(mFrontDoor.get());
  mFrontDoor = 0;

	mBubbleManager->Finit();
	mBubbleManager = 0;

}

/// access PokerPlayer of localhost (aka client)
PokerPlayer* PokerModel::GetLocalPlayer()
{
  for (Serial2Player::iterator it=mSerial2Player.begin(); it!=mSerial2Player.end();++it)
  {
    if ( (*it).second.get()->GetMe() )
      return (*it).second.get();
  }

  return NULL;
}


/*
 * End chips animation related
 */ 


void PokerController::DeleteAllLevels()
{
	while (!mTables.empty())
		DeleteLevel(mTables[0]->mGameSerial);
#if 0		
	for (unsigned int i = 0; i < mTables.size(); i++) {
     mGame->GetScene()->GetModel()->mGroup->removeChild(mTables[i]->mSetData->GetGroup());
     delete mTables[i];
	}
#endif
  mTables.clear();
  SetModel(0);
}


void PokerController::DeleteLevel(unsigned int gameID)
{
  g_debug("Delete Level %d",gameID);
	PokerModel* candidate=0;
	VectorTable::iterator itToRemove;
	int indexToRemove=-1;
	unsigned int i=0;
	for (VectorTable::iterator it=mTables.begin();it!=mTables.end();it++) {
		if ((*it)->mGameSerial!=gameID) {
			if (!candidate)
				candidate=(*it);
		} else
			indexToRemove=i;
		i++;
	}
	mGame->GetScene()->GetModel()->mGroup->removeChild(GetModel()->mSetData->GetGroup());

	SetModel(candidate);
	if (candidate) {
		mGame->SetActiveController(candidate->mGameSerial);
		mGame->mDatas->SetLevel(candidate->mLevelName);
	} else {
		mGame->SetActiveController(0);
	}
	if (indexToRemove!=-1) {
		PokerModel* del = mTables[indexToRemove];
		int id = del->mGameSerial;
		delete del;
		mTables[indexToRemove] = 0;
		mTables.erase(mTables.begin()+indexToRemove);
		g_debug("Deleted PokerModel %d",id);
		mGame->ReportControllers();
	}
  // very important because PokerPlayer needs to remove data in top group
	mGame->mSetData=0;
}


class AllBirtyBound : public osg::NodeVisitor
{
public:
  AllBirtyBound(){}
  
  void apply(osg::Node& node) {
    node.dirtyBound();
  }
};


bool PokerController::IsLevelExist(unsigned int tableId)
{
  return (GetLevelFromId(tableId) != 0);
}


PokerModel* PokerController::GetLevelFromId(unsigned int tableId)
{
	for (VectorTable::iterator it=mTables.begin();it!=mTables.end();it++)
		if ((*it)->mGameSerial==tableId) {
			return (*it);
		}
  return 0;
}

void PokerController::CreateOrUseLevel(unsigned int gameID,const std::string& level)
{
	PokerModel* modelToUse=0;
	mGame->SetActiveController(gameID);

	if (GetModel()) {
		mGame->GetScene()->GetModel()->mGroup->removeChild( GetModel()->mSetData->GetGroup());

		// cut table sounds
  	GetModel()->mBoard->DisableSound();
    for (PokerModel::Serial2Player::iterator it=GetModel()->mSerial2Player.begin();it!=GetModel()->mSerial2Player.end();it++)
      it->second->DisableSound();
  }

	if (!loader_) {
		loader_ = new PokerSplashScreenController(mGame);
		mGame->GetScene()->GetView()->setUseGlow(false);
		//PokerSceneView::getInstance()->m_TLFGroup->setNodeMask(0);

		mGame->GetInterface()->ReleaseFocus();
		mGame->GetScene()->HUDInsert(loader_.get());
		mGame->SetCallRenderMethod(false);
	}
	MAFMonitor *mon = loader_->GetModel();

	mGame->mDatas->SetLevel(level);
  modelToUse = GetLevelFromId(gameID);
  bool bClearCamRot = false;
  if (!modelToUse){
    g_debug("Create Level %d with skin \"%s\"",gameID, level.c_str());

		//mon->write("Loading 3D Data...");
		mon->setMulAddFactor(1.0f, 0.0f);
		mon->write("Loading Level...");
		modelToUse = new PokerModel(mGame, gameID, level, mon);
		mTables.push_back(modelToUse);
		modelToUse->mMe = mMe;
		modelToUse->mLevelName = level;
		modelToUse->mGameSerial = gameID;
		//((MAFESCNData*)modelToUse->mSetData)->setupRootStateSet( modelToUse->mSetData->GetGroup()->getOrCreateStateSet() );
		mon->write("Loading Players...");
		mon->setProgressLength(nbPlayersAtTable_);
    bClearCamRot = true;
	} else {
    modelToUse->mBoard->EnableSound();
    for (PokerModel::Serial2Player::iterator it=modelToUse->mSerial2Player.begin();it!=modelToUse->mSerial2Player.end();it++)
      it->second->EnableSound();

    GameAccept(PokerEventSwitchToExistingTable());

    g_debug("Use existing Level %d",gameID);
		mon->setMulAddFactor(1.0f, 0.0f);
		mon->write("Rejoining The Game...");
		mon->setProgressLength(nbPlayersAtTable_);
  }

	SetModel(modelToUse);
  mGame->GetScene()->GetModel()->mCamera = modelToUse->mCamera.get();
  mGame->mSetData=modelToUse->mSetData;
	if (bClearCamRot)
		modelToUse->mCamera->RotateFreeMode(0,0,0);

	osg::Group *grp = GetModel()->mSetData->GetGroup();
	mGame->GetScene()->GetModel()->mGroup->addChild(grp);
	grp->setNodeMask( grp->getNodeMask() & (~MAF_VISIBLE_MASK) );

  for (PokerModel::Serial2Player::iterator it=modelToUse->mSerial2Player.begin();it!=modelToUse->mSerial2Player.end();it++)
    g_debug("serial on this table %d - %d",gameID,it->first);

	PokerSceneView *instance = PokerSceneView::getInstance();
	if (instance) {
		osg::Group *anchor = mGame->mSetData->GetAnchor("transform_dor01");
		osg::Geode *geode = GetGeode(anchor);
		int nbDrawables = geode->getNumDrawables();
		int doorRenderBinBeforeHelpMode = 0;
		if (!MAFRenderBin::Instance().GetRenderBinIndexOfEntity("Door", doorRenderBinBeforeHelpMode))
			MAF_ASSERT(0 && "Door not found in client.xml");
		int doorRenderBinValueInHelpMode;
		if (!MAFRenderBin::Instance().GetRenderBinIndexOfEntity("DoorInHelpMode", doorRenderBinValueInHelpMode))
			MAF_ASSERT(0 && "DoorInHelpMode not found in client.xml");

		for (int i = 0; i < nbDrawables; i++) {
			osg::Drawable *drawable = geode->getDrawable(i);
			instance->addDrawableThatStayInColor(drawable, doorRenderBinBeforeHelpMode, doorRenderBinValueInHelpMode, "RenderBin", 0);
		}
	}
}


PokerController::PokerController(PokerApplication* game, unsigned int id, MAFMonitor *_mon) :
MAFController(0), mGame(game), mMe(0)
{
  //SetModel(new PokerModel(game,id, _mon));
  //SetView(new PokerView());
  //Init();

#ifdef TEST_PERFORMANCE
  mPerfCharacteres=1;  
#endif
}

PokerController::~PokerController() {

}


void PokerController::PlayerLeave(guint serial)
{
	std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;

	if(serial2player.find(serial) == serial2player.end()) {
		g_critical("PokerController::PlayerLeave unexpected serial %d (ignored)\n", serial);

	} else {
		std::vector<osg::ref_ptr<PokerPlayer> >& seat2player = GetModel()->mSeat2Player;
		std::vector<guint>& seat2serial = GetModel()->mSeat2Serial;
		PokerPlayer* player = serial2player[serial].get();

		int index = player->GetSeatId();
		GetModel()->mSeatManager->PlayerLeave(index);

		PokerApplication* game = GetModel()->mGame;
		game->RemoveController(player);
		// Leave the seat
		seat2serial[player->GetSeatId()] = 0;
		seat2player[player->GetSeatId()] = 0;
		player->SetSeatId(POKER_PLAYER_NO_SEAT);	
		if(player->referenceCount() != 1)
			g_critical("PokerController::PlayerLeave: refcount: %d, should be 1", player->referenceCount());
		serial2player.erase(serial);

		//seatManager
		if (serial == GetModel()->mMe) {
			GetModel()->mSeatManager->MainPlayerLeave(GetModel()->mSeat2Serial);
		}
    GameAccept(PokerEventPlayerLeave(serial));
	}
}


void PokerController::SetPot(const std::vector<int>& amount,int index) {
  static_cast<PokerModel*>(GetModel())->mPotCenter->SetPotValue(amount,index);
}

void PokerController::SetCards(const std::vector<int>& cards) 
{
  GetModel()->mBoard->SetCards(cards);
}


void PokerController::FoldCards(void) 
{
  GetModel()->mBoard->FoldCards();
  GetModel()->mBoard->StopToDisplayShowDown();
}


void PokerController::DealerChangeToSeat(int seat)
{
	std::vector<guint>& seat2serial = GetModel()->mSeat2Serial;
	if (seat == -1 || seat >= (int)seat2serial.size()) {
		g_critical("dealer is on a seat (%d) that doesn't exist - ignore",seat);
		return;
	}

	if (GetModel()->mDealerButton->getParents().size() > 0)
		GetModel()->mDealerButton->getParent(0)->removeChild(GetModel()->mDealerButton.get());
	char tmp[32];
	snprintf(tmp, 32, "transform_button%02d", seat + 1);
	osg::Group* anchor = GetModel()->mGame->mSetData->GetAnchor(tmp);
	if(anchor == 0)
		g_critical("POKER_DEALER: could not find anchor %s", tmp);
	else
		anchor->addChild(GetModel()->mDealerButton.get());
}

float PokerController::GetShadowFactorForCurrentLevel(const std::string &type)
{
	float shadowFactor = 0.8f;

	char str[200];
	const std::string level = mGame->mDatas->GetLevel();
	int indexLevel = atoi (level.c_str() + 5);

	if (type == "ground")
		sprintf(str, "/sequence/levelParameters[@index=%d]/groundShadow/@factor", indexLevel);
	else if (type == "table")
		sprintf(str, "/sequence/levelParameters[@index=%d]/tableShadow/@factor", indexLevel);
	else
		return shadowFactor;

	std::string strShadowFactor = mGame->HeaderGet("sequence", str);
	if (strShadowFactor.size())
		shadowFactor = atof( strShadowFactor.c_str() );

	return shadowFactor;
}

void PokerController::PythonAccept(MAFPacket* packet)
{
	NPROFILE_SAMPLE("PokerController::PythonAccept");

	PokerApplication* game = mGame;
	PokerSceneView *uihelp = PokerSceneView::getInstance();

	bool bPokerPlayerArrivePacket = false;

#ifdef USE_NPROFILE
	double timeFuncA = nprf::GetRealTime();
#endif

	if (GetModel()) {
	  std::map<int, unsigned int> serial2seat;
	  unsigned int size = GetModel()->mSeat2Serial.size();
	  for (unsigned int i = 0; i < size; ++i)
	    serial2seat[GetModel()->mSeat2Serial[i]] = i;
	  GetModel()->mHUDController->PythonAccept(*packet, serial2seat);
	}

	if(packet->IsType("POKER_SEATS")) {

		std::vector<guint>& seat2serial = GetModel()->mSeat2Serial;
		std::vector<osg::ref_ptr<PokerPlayer> >& seat2player = GetModel()->mSeat2Player;
		std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
		std::vector<int> seats;
		packet->GetMember("seats", seats);
		for(unsigned int i = 0; i < seat2serial.size(); i++)
			g_debug("seat %d -> serial %d",i,seat2serial[i]);

		int index = 0;

		unsigned int seatsCount = GetModel()->mSeatManager->GetSeatsCount();
		if(seatsCount > seats.size())
		  g_error("PokerController::PythonAccept: seatsCount = %d > seats = %d", seatsCount, (unsigned int)seats.size());
		for(unsigned int i = 0; i < seatsCount; i++) {
			int serial = seats[i];
			if(serial == 0) {
				//player leave
				if (seat2serial[index] != 0) {
					PlayerLeave(seat2serial[index]);
				}
				seat2serial[index] = 0;
				seat2player[index] = 0;

				// warning maybe here we should serial2player.erase(previousSerial);

			} else {

				//player arrive
				if (seat2serial[index] == 0) {
					GetModel()->mSeatManager->PlayerSeated(index);
				}
				if(serial2player.find(serial) == serial2player.end())
					g_error("PokerController::Update: SEATS: serial %d not matching any player", serial);

				if (seat2serial[index] && (unsigned int)seats[index] && seat2serial[index] != (unsigned int)seats[index]) {
					PokerPlayer* player = seat2player[index].get();
					GetModel()->mSeatManager->PlayerLeave(index);
					game->RemoveController(player);
					guint previousSerial=seat2serial[index];
					serial2player.erase(previousSerial);
				}

				if (!seat2serial[index]) { // not seated
					PokerPlayer* player = serial2player[serial].get();
					seat2serial[index] = serial;
					seat2player[index] = player;
					player->SetSeatId(index);
				} else { //player already seated so we want to be sure they are visible
					PokerPlayer* player = serial2player[serial].get();
					player->GetBody()->Displayed(true);
				}
			}
			index++;
		}
	} else if(packet->IsType("POKER_TABLE") ||
						packet->IsType("POKER_TABLE_DESTROY")) { 
		
		unsigned int tableId = 0;
		std::string tableName;
		if(packet->IsType("POKER_TABLE")) {
			packet->GetMember("id", tableId);
			packet->GetMember("players", nbPlayersAtTable_);
			packet->GetMember("name", tableName);
		} else {
			packet->GetMember("game_id", tableId);
		}
		g_debug("PokerController::Update: POKER_TABLE(_DESTROY) %d",tableId);

		if(packet->IsType("POKER_TABLE")) {
			unsigned int seatsCount = 0;
			packet->GetMember("seats", seatsCount);
			g_assert((seatsCount > 0) && (seatsCount <= 10));
			std::vector<int> seatsAll;
			packet->GetMember("seats_all", seatsAll);
			g_assert(seatsAll.size() == seatsCount);


			// extract level skin
			std::string level="default";
			packet->GetMember("skin", level);
			if ( level.empty() || level == "default" ){
				level = DEFAULT_LEVEL_SKIN;
			}

			bool alreadyExist = IsLevelExist(tableId);
			CreateOrUseLevel(tableId, level);
			if (!alreadyExist) {
				GetModel()->mSeatManager->SetSeats(seatsAll);
				std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
				std::vector<osg::ref_ptr<PokerPlayer> >& seat2player = GetModel()->mSeat2Player;
				std::vector<guint>& seat2serial = GetModel()->mSeat2Serial;
				for(std::map<guint,osg::ref_ptr<PokerPlayer> >::iterator i = serial2player.begin(); i != serial2player.end(); i++) {
					PokerPlayer* player = i->second.get();
					int seatId = player->GetSeatId();
					// Leave the seat
					seat2serial[seatId] = 0;
					seat2player[seatId] = 0;
					player->SetSeatId(POKER_PLAYER_NO_SEAT);
				}
			}
				
			GetModel()->mCamera->SetRespondToEvents(true);
			game->mTableName->getText()->setText(tableName);
			GetModel()->mBatchMode=true; // if we go to an existing table then we start it as batch mode to re initialise state table 
			GetModel()->mPotCenter->ResetPots();

			// put player betstack in sync mode
			std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
			for(std::map<guint,osg::ref_ptr<PokerPlayer> >::iterator i = serial2player.begin(); i != serial2player.end(); i++) {
				PokerPlayer* player = i->second.get();
				if (player) {
					player->TimeoutAdvise(0.f);
					player->SyncBetStackWithPacket(true);
				}
			}
		} else {
				GetModel()->mSeatManager->DisableAllSeats();
				DeleteLevel(tableId);
			}

		} else if (packet->IsType("POKER_TABLE_QUIT")) {
			g_error("POKER_TABLE_QUIT");
			unsigned int tableId = 0;
			packet->GetMember("id", tableId);
			DeleteLevel(tableId);
			game->mTableName->getText()->setText("");

		} else if(packet->IsType("POKER_START")) {
			packet->GetMember("game_id", GetModel()->mGameId);
			std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
			for(std::map<guint,osg::ref_ptr<PokerPlayer> >::iterator i = serial2player.begin(); i != serial2player.end(); i++) {
				PokerPlayer* player = i->second.get();
				player->NoCards();
			}

			GetModel()->mBoard->SetHandValue("");

			int size = GetModel()->mSeat2Player.size();
			for (int i = 0; i < size; i++) {
				PokerPlayer *player = GetModel()->mSeat2Player[i].get();
				if (player) {
					player->SetLastActionString("");
				}
			}

      GameAccept(PokerEventGameStart());

		} else if(packet->IsType("POKER_PLAYER_NO_CARDS")) { 
			guint serial = 0;
			packet->GetMember("serial", serial);
			std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
			if(serial2player.find(serial) == serial2player.end()) {
				g_error("PokerController::Update: PLAYER_NO_CARDS: serial %d not in player list", serial);
			}
			else {
				PokerPlayer* player = serial2player[serial].get();
				player->NoCards();
			}

		} else if(packet->IsType("POKER_IN_GAME")) { 
			g_debug("PokerController::Update: POKER_IN_GAME");

			//
			// Build a map of the the InGame status for each player based
			// on the list of InGame players found in the packet.
			//
			std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
			std::map<guint,bool> serial2inGame;
			for(std::map<guint,osg::ref_ptr<PokerPlayer> >::iterator i = serial2player.begin();
				i != serial2player.end();
				i++) {
					serial2inGame[i->first] = false;
				}

				std::vector<int> serials;
				packet->GetMember("players", serials);

				for(std::vector<int>::iterator i = serials.begin(); i != serials.end(); i++) {
					int serial = *i;
					if(serial2player.find(serial) == serial2player.end())
						g_error("PokerController::Update: IN_GAME: serial %d not matching any player", serial);
					serial2inGame[serial] = true;
				}

				for(std::map<guint,osg::ref_ptr<PokerPlayer> >::iterator i = serial2player.begin();
					i != serial2player.end();
					i++) {
						PokerPlayer* player = (i->second).get();
						guint serial = i->first;
						player->SetInGame(serial2inGame[serial]);
						if(serial2inGame[serial] == false && player->GetInGame() == true)
							player->SetInGame(false);
					}

		} else if(packet->IsType("POKER_SIT")) {
			guint serial = 0;
			packet->GetMember("serial", serial);
			std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;

			if(serial2player.find(serial) != serial2player.end()) {
				PokerPlayer* player = serial2player[serial].get();

				if (GetModel()->mMe == serial) {
					std::vector<guint> &s2s = GetModel()->mSeat2Serial;
					unsigned int i;
					for (i = 0; i < s2s.size(); i++) {
						if (serial == s2s[i])
							break;
					}
					GetModel()->mSeatManager->SetMainPlayerSeat(i);
					GetModel()->mSeatManager->MainPlayerSit();
				}
				player->SetSit(true);
			}
			else {
				g_error("PokerController::Update: SIT: serial %d not in player list", serial);
			}

		} else if(packet->IsType("POKER_SIT_OUT")) { 
			guint serial = 0;
			packet->GetMember("serial", serial);
			std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
			if(serial2player.find(serial) != serial2player.end()) {
				PokerPlayer* player = serial2player[serial].get();
				player->FoldHoleCards();
				player->SetSit(false);

				if (serial == GetModel()->mMe) {
					if (GetModel()->mBatchMode)
						GetModel()->mSeatManager->MainPlayerSitOut();

					player->SetPlayerCameraToFreeMode();

					std::vector<guint> &s2s = GetModel()->mSeat2Serial;
					unsigned int i;
					for (i = 0; i < s2s.size(); i++) {
						if (serial == s2s[i])
							break;
					}

					GetModel()->mSeatManager->SetMainPlayerSeat(i);
				}

			}
			else {
				g_error("PokerController::Update: SIT_OUT: serial %d not in player list", serial);
			}
		} else if(packet->IsType("POKER_CALL") || packet->IsType("POKER_RAISE")) { 
			guint serial = 0;
			packet->GetMember("serial", serial);
			std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
			if(serial2player.find(serial) == serial2player.end())  {
				g_error("PokerController::Update: BET: serial %d not in player list", serial);
			}
			else {
				PokerPlayer* player = serial2player[serial].get();
				player->DisableWarningTimer();

				if (packet->IsType("POKER_CALL"))
					player->SetLastActionString("Call");
				else {
					int size = GetModel()->mSeat2Player.size();
					int i = 0;
					for (; i < size; i++) {
						PokerPlayer *player = GetModel()->mSeat2Player[i].get();
						if (player && player->bPlayed_) {
							const std::string &lastAction = player->GetLastActionString();
							if (lastAction == "Bet" || lastAction == "Blind")
								break;
						}
					}
					if (i == size)
						player->SetLastActionString("Bet");
					else
						player->SetLastActionString("Raise");
				}
			}
		} else if(packet->IsType("POKER_CLIENT_ACTION")) {
			std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
			if(serial2player.find(GetModel()->mMe) != serial2player.end()) {
				PokerPlayer* player = serial2player[GetModel()->mMe].get();
				std::string name;
				packet->GetMember("action", name);
				bool valid;
				packet->GetMember("display", valid);
				(void)player;

				//player->DisplayInteractor(name, valid);
			}
			else {
				g_debug("PokerController::Update: CLIENT_ACTION: cannot find self (%d) in player list", GetModel()->mMe);
			}
		} else if(packet->IsType("POKER_CHECK")) { 
			guint serial = 0;
			packet->GetMember("serial", serial);
			std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
			if(serial2player.find(serial) == serial2player.end())  {
				g_error("PokerController::Update: CHECK: serial %d not in player list", serial);
			}
			else {
				PokerPlayer* player = serial2player[serial].get();
				player->SetLastActionString("Check");
				player->DisableWarningTimer();
			}
		} else if(packet->IsType("POKER_FOLD")) {
			std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
			int serial;
			packet->GetMember("serial", serial);
			if(serial2player.find(serial) != serial2player.end()) {

				serial2player[serial]->GetShowdown()->Reset();
				serial2player[serial]->SetLastActionString("Fold");
				serial2player[serial]->DisableWarningTimer();


        GameAccept(PokerEventPlayerFold(serial));

			} else {
				g_critical("PokerController::Update: FOLD: serial %d not matching any player (ignored)", serial);
			}
		} else if(packet->IsType("POKER_BLIND")) {
			guint serial = 0;
			packet->GetMember("serial", serial);
			std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
			if(serial2player.find(serial) == serial2player.end()) 
				g_error("PokerController::Update: BLIND: serial %d not in player list", serial);
			else {
				PokerPlayer* player = serial2player[serial].get();
				player->SetLastActionString("Blind");
			}
		} else if(packet->IsType("POKER_CLIENT_PLAYER_CHIPS")) { 
			std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
			std::vector<int> amounts;
			packet->GetMember("bet", amounts);

			int money = 0;
			for(unsigned int i = 0; i < amounts.size(); i += 2) {
				money += amounts[i] * amounts[i + 1];
			}

			guint serial = 0;
			packet->GetMember("serial", serial);

			if(serial2player.find(serial) == serial2player.end()) {
				g_error("PokerController::Update: PLAYER_CHIPS: serial %d not matching any player", serial);
			}
			else {
				PokerPlayer* player = serial2player[serial].get();

				// here we hide the pot2player stack because:
				// if we switch table during a pot2player animation the chipstack will not be hidden when come back to this table because
				// the hide part of this chips stack is hidden (in normal case -> no switching table) by a callback that will not be call
				// because we are not on this table
				if (player && GetModel()->mBatchMode)
					player->DisplayPot2PlayerChipStack(false);

				if (!(amounts.empty() && GetModel()->mPokerMoveChips->IsAnyChipsToMoveToPotFromPlayer(serial)) || GetModel()->mBatchMode)
					player->SetBet(amounts);

				packet->GetMember("money", amounts);
				player->SetMoney(amounts);
				player->SetLastBet(money);
			}
		}
		else if(packet->IsType("POKER_POT_CHIPS")) 
    { 
			std::vector<int> amounts;
			int index=0;
			packet->GetMember("bet", amounts);
			packet->GetMember("index", index);
			if (GetModel()->mBatchMode)
				GetModel()->mPotCenter->SetPotValue(amounts,index);

      GameAccept(PokerEventPotChips(amounts,index));
		}
		else if(packet->IsType("POKER_PLAYER_CARDS") || packet->IsType("POKER_BEST_CARDS")) 
    {
      std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
			guint serial = 0;
			packet->GetMember("serial", serial);
			std::vector<int> cards;
			packet->GetMember("cards", cards);

			if(serial2player.find(serial) == serial2player.end()) 
      {
        g_error("PokerController::Update: {PLAYER|BEST}_CARDS: serial %d not matching any player", serial);
			}
			else 
      {
				PokerPlayer* player = serial2player[serial].get();
				if( packet->IsType("POKER_PLAYER_CARDS") ) 
        {
          std::string visibles;
					packet->GetMember("visibles", visibles);

					// first set pockets cards if any
					//const int visible_mask = ~(64 - 1);
					//const int value_mask = (64 - 1);

					//std::vector<int> tmp;

					//for (std::vector<int>::iterator i = cards.begin(); i != cards.end(); i++)
     //     {
					//	if (*i != 255) //(*i & visible_mask) 
     //       {
					//		tmp.push_back(*i & value_mask);
					//	}
     //     }

     //     player->SetPocketCards(tmp);

          player->SetPocketCards(cards);

          //// here get card to display it after animation of card
          //// display them now if no animation is applied
          if ((GetModel()->mBatchMode /*DealCard && !model->mDealPlayerCards.empty()*/)) 
          {
           // 	g_debug("Tmp size %d",tmp.size());
           for (int c=0;c<(int)cards.size();c++)
             player->ShowCard(c);
          }

          //tmp.clear();
          //for (std::vector<int>::iterator i = cards.begin(); i != cards.end(); i++)
          //  if (!(*i & visible_mask))
          //    tmp.push_back(*i & value_mask);
          //if(visibles == "hole") 
          //{
          //  player->SetHoleCards(tmp);
          //} 
          
          //else if(visibles == "best") 
          {
            //tmp.clear();
            //for (std::vector<int>::iterator i = cards.begin(); i != cards.end(); i++)
            //{
            //  if ((*i != 255) && (*i & visible_mask))
            //  {
            //    tmp.push_back(*i & value_mask);
            //  }
            //  else
            //  {
            //    tmp.push_back(32);// *i & value_mask);
            //  }
            //}

            //player->GetShowdown()->Set("high", tmp, "", false);

            std::vector<int> vEmptyDeck;
            if ( PokerDeck::HasKnownCards(cards) )
            {
              player->SetHoleCards(cards);
              //player->GetShowdown()->TurnProjectorOn();
            }
            else
            {
              player->SetHoleCards(vEmptyDeck);
              //player->GetShowdown()->TurnProjectorOff();
            }

            player->GetShowdown()->ResetWinner();
            player->GetShowdown()->SetCards(visibles, cards);
          }
				} 
        else if(packet->IsType("POKER_BEST_CARDS")) 
        {
					std::string side;
					std::string hand;
					std::vector<int> board;
					std::vector<int> bestcards;

					int besthand = 0;
					packet->GetMember("besthand", besthand);
					packet->GetMember("board", board);
					packet->GetMember("hand", hand);
					packet->GetMember("side", side);
					packet->GetMember("bestcards", bestcards);
					player->GetShowdown()->SetCards(side, cards);
          player->GetShowdown()->SetWinner(hand);
          player->GetShowdown()->TurnProjectorOn();

					std::map<guint, osg::ref_ptr<PokerPlayer> >::iterator it = serial2player.begin();
					for ( ; it != serial2player.end(); ++it) {
						PokerPlayer *other_player = (*it).second.get();
						bool res = other_player->HasEmptyHoleCards();
						if (!res)
							other_player->GetShowdown()->TurnProjectorOn();
					}

					if (besthand)
          { 
//					GetModel()->mBoard->ShadeUsedCardForBestHand(board);
						GetModel()->mBoard->SetHandValue(hand);
						GetModel()->mBoard->StartToDisplayShowDown(player);

						std::vector<int> winCards;
						int k = 0;
						for (int j = 0; j < 5; j++) {
							for (int i = 0; i < 5; i++) {
								if (board[i] == bestcards[j]) {
									winCards.push_back( board[i] );
									k++;
									break;
								}
							}
						}
						GetModel()->mBoard->SetWinningCards(winCards);
					}
				} 
        else 
        {
					g_error("PokerController::Update: {PLAYER|BEST}_CARDS: unknown packet type");
				}
			}
		}
		else if(packet->IsType("POKER_BOARD_CARDS")) {
			std::vector<int> cards;
			packet->GetMember("cards", cards);
			SetCards(cards);
			//    SetCards(cards, model->mBatchMode);

		} else if(packet->IsType("POKER_BET_LIMIT")) {
			std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
			if(serial2player.find(GetModel()->mMe) != serial2player.end()) {
				PokerPlayer* player = serial2player[GetModel()->mMe].get();
				int min_bet;
				packet->GetMember("min", min_bet);
				int max_bet;
				packet->GetMember("max", max_bet);
				int step;
				packet->GetMember("step", step);
				int call;
				packet->GetMember("call", call);
				int allin;
				packet->GetMember("allin", allin);
				int pot;
				packet->GetMember("pot", pot);
				player->BetLimits(min_bet, max_bet, step, call, allin, pot);
				if (call != 0) {
					if (call > max_bet && min_bet != 0 && max_bet != 0) // 12 jun 2006: TMP HACK FOR RELEASE!
						call = max_bet;

					std::string str = MAFformat_amount(call, true);

//					if (call % 100 != 0)
	//					sprintf(str, "%.2f", call/100.0f);
		//			else
			//			sprintf(str, "%d", call/100);

					player->mCallInteractor->SetText(str);
				}
			}
		} else if(packet->IsType("POKER_POSITION")) {
			std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
			unsigned	serial_in_position;
			packet->GetMember("serial", serial_in_position);
			PokerPlayer* player_in_position = 0;

			if(serial_in_position != 0) {
				if(serial2player.find(serial_in_position) == serial2player.end()) {
					g_error("PokerController::Update: POSITION: serial_in_position %d not matching any player", serial_in_position);
				}
				else {
					player_in_position = serial2player[serial_in_position].get();
//						if (mMe == serial_in_position) {
//						player_in_position->mCallInteractor->SetText("");
	//					player_in_position->mRaiseInteractor->SetText("");
		//			}
				}
			}

			std::vector<guint>& seat2serial = GetModel()->mSeat2Serial;
			for(std::vector<guint>::iterator i = seat2serial.begin();
					i != seat2serial.end();
					i++) {
				unsigned int serial = *i;
				if(serial != 0) {
					if(serial2player.find(serial) == serial2player.end()) {
						g_error("PokerController::Update: POSITION: found serial %d not matching any player", serial);
					} else {
						PokerPlayer* player = serial2player[serial].get();
						if(serial != serial_in_position) {
							//
							// Other players look at the player in position
							// and stop any animation they may have if they were previously
							// in position.
							//
							if(player_in_position  && player->GetInGame())
								player->LookAt(player_in_position);
							//
							// We are about to lose position: no interactor selected
							//
							if(serial_in_position != GetModel()->mMe && player->HasPosition())
								; //player->ToggleInteractor("none");
							player->LostPosition();
							//	  player->bPlayed_ = true;
							//	  player->lastActionRot_ = 0;

						} else {
							player->InPosition();
							player->bPlayed_ = true;
							player->SetLastActionString("");
							//	  player->lastActionRot_ = 0;

							//
							// We are in position: interactors that were selected
							// while we were not in position must return to their
							// unselected state.
							//
							if(serial_in_position == GetModel()->mMe) {
								/**
								 * Player me in position so we play a sound
								 */
								if (!GetModel()->mBatchMode)
									player->GetSoundSource()->Play("MeInPosition");
							}
						}
					}
				}
			}
		} else if(packet->IsType("POKER_DEALER")) {

					unsigned int dealer_seat;
					int prev_dealer_seat;
					packet->GetMember("dealer", dealer_seat);
					packet->GetMember("previous_dealer", prev_dealer_seat);

				// only in batch mode or with a previous dealer undefined because pokeranimation does not process packet if the game is in batch mode
				if (GetModel()->mBatchMode || prev_dealer_seat == -1) {
					g_debug("ChangeDealer in batch mode or prev dealer = -1");
					DealerChangeToSeat(dealer_seat);

					// display the dealer button if not displayed during animation of button remember:
					// player1 launch the button (animation)
					// player2 get the button (animation)
					// during the sequence the real dealer button is hidden
					// so if in batch mode we hide all button of all player at the table, and display the real button
					// we need to do that in order to avoid artefact when switching table

					//				if (model->mBatchMode) {
					GetModel()->mDealerButton->setNodeMask(MAF_VISIBLE_MASK);
					std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
					for (PokerModel::Serial2Player::iterator it = serial2player.begin(); it != serial2player.end(); it++)
						if (it->second.get())
							it->second->mAnimationDealer->setNodeMask(0);
				}
				GetModel()->mDealerButtonSeatIndex = dealer_seat;

			} else if(packet->IsType("SERIAL")) {
				guint serial = 0;
				packet->GetMember("serial", serial);
				g_debug("my serial is %d", serial);
				if (GetModel())
					GetModel()->mMe = serial;
				mMe=serial;

			} else if(packet->IsType("POKER_CHAT_HISTORY")) {
				std::string yesno;
				packet->GetMember("show", yesno);
#if 1
				game->GetInterface()->ShowWindow("chat_history_window",yesno=="yes");
#else
				MAFName2Animate& name2animate = game->GetInterface()->GetName2Animate();
				MAFApplication2DAnimate* animate = name2animate["chat_history_window"];
				g_assert(animate);
				for(MAFApplication2DAnimate::iterator i = animate->begin(); i != animate->end(); i++) {
					MAFApplication2DSlide* slide = dynamic_cast<MAFApplication2DSlide*>(i->get());
					if(slide)
						slide->SetVisible(yesno == "yes");
				}
#endif

			} else if(packet->IsType("POKER_PLAYER_ARRIVE")) { // new player
				bPokerPlayerArrivePacket = true;
				std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;

				guint serial = 0;
				packet->GetMember("serial", serial);
				g_debug("packet player arrives with serial %d", serial);

				if(serial2player.find(serial) == serial2player.end()) {

					std::string name;
					packet->GetMember("name", name);

					std::string skinUrl;
					packet->GetMember("url", skinUrl);

					std::string skinOutfit;
					packet->GetMember("outfit", skinOutfit);

					std::string display_body = game->HeaderGet("sequence", "/sequence/player/@display");

					unsigned int id=0;
					id = GetModel()->mGameSerial;

					g_debug(skinUrl.c_str());
					g_debug(skinOutfit.c_str());

					PokerPlayer *player = new PokerPlayer(game,id, GetModel()->mMe == serial, skinUrl, skinOutfit);
					if (serial == GetModel()->mMe) {
						GetModel()->mSeatManager->MainPlayerArrive(GetModel()->mSeat2Serial);
					}

					player->SetName(name);
					player->SetHasNeverReceivedABetStackOnTable(false);

					serial2player[serial] = player;
					game->AddController(player);

					/**
					 * Player arrive so we play a sound
					 */
					if (!GetModel()->mBatchMode)
						player->GetSoundSource()->Play("PlayerArrive");

				} else {
					g_debug("player %d is already here",serial);
				}

				if (loader_.valid())
					loader_->GetModel()->progress();

			} else if(packet->IsType("POKER_WIN")) { 

				std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
				std::vector<int> serials;
				packet->GetMember("serials", serials);

				int nbSerials = serials.size();
				for (int i = 0; i < nbSerials; i++) {
					int serial = serials[i];
					typedef std::map<guint,osg::ref_ptr<PokerPlayer> >::iterator It;
					It playerIt = serial2player.find(serial);
					if (playerIt != serial2player.end())
					{
						PokerPlayer* player = playerIt->second.get();
						player->SetLastActionString("Win");
					}
				}
			} else if (packet->IsType("POKER_CHAT")) {
				std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
				guint serial;
				packet->GetMember("serial", serial);
				typedef std::map<guint,osg::ref_ptr<PokerPlayer> >::iterator It;
				It playerIt = serial2player.find(serial);
				if (playerIt != serial2player.end())
				{
					PokerPlayer* player = playerIt->second.get();
					std::string message;
					packet->GetMember("message", message);
					player->SetTextMessage(message);
				}

// 				{
// 				  std::string message;
// 				  packet->GetMember("message", message);
// 				  std::string resultStr;
// 				  bool result = PokerEditor::Instance().Command(message, resultStr);
// 				  if (result)
// 				    {
// 				      osg::ref_ptr<MAFPacket> packet = mGame->GetPacketsModule()->Create("PacketPokerChat");
// 				      packet->SetMember("message", resultStr);
// 				      packet->SetMember("serial", model->mMe);
// 				      packet->SetMember("game_id", model->mGameSerial);
// 				      mGame->PythonCall("sendPacket", packet.get());
// 				    }
// 				}
			} else if(packet->IsType("POKER_PLAYER_LEAVE")) {
				guint serial;
				packet->GetMember("serial", serial);
				PlayerLeave(serial);

			} else if(packet->IsType("QUIT")) {
// 				g_debug("PokerController::QUIT");
				DeleteAllLevels();
				//				delete PokerSceneView::getInstance();
				game->Quit();
			} else if (packet->IsType("POKER_TIMEOUT_WARNING")) {
				std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
				guint serial;
				guint timeout;
				int when;
				packet->GetMember("serial", serial);
				packet->GetMember("timeout", timeout);
				packet->GetMember("when", when);

				if(serial2player.find(serial) == serial2player.end()) {
					g_critical("PokerController::Update POKER_TIMEOUT_WARNING, unexpected serial %d (ignored)\n", serial);
				}
				else {
					PokerPlayer* player = serial2player[serial].get();

					/*
					*  If i am on another table and I received a POKER_TIMEOUT_WARNING player=0 and it crashes
					*
					*/
					if (!player)
						g_critical("PokerController::PythonAccept POKER_TIMEOUT_WARNING received but no player with id %d on current game",serial);
					else {
						int t = time(0);
						int realTimeout = timeout - (t - when);
						player->TimeoutAdvise(realTimeout*1.0);
						player->SetLastActionString("TimeOut");
					}

					g_debug("timeout warning serial %d time %d",serial,timeout);
				}

    } else if(packet->IsType("POKER_CHIPS_BET2POT")) { 
      guint serial = 0;
      std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
      std::vector<int> amounts;
      int pot=0;
      packet->GetMember("serial", serial);
      packet->GetMember("chips", amounts);
      packet->GetMember("pot", pot);

      GameAccept(PokerEventChipsBet2Pot(GetModel()->mBatchMode, serial, amounts, pot));

    } else if(packet->IsType("POKER_CHIPS_POT2PLAYER")) { 
        guint serial = 0;
        std::vector<int> amounts;
        int pot;
        packet->GetMember("serial", serial);
        packet->GetMember("chips", amounts);
        packet->GetMember("pot", pot);

        GameAccept(PokerEventChipsPot2Player(GetModel()->mBatchMode, serial, amounts, pot));
    } else if(packet->IsType("POKER_CHIPS_PLAYER2BET")) { 

			} else if (packet->IsType("POKER_END_ROUND")) {

      GameAccept(PokerEventEndRound());
				int size = GetModel()->mSeat2Player.size();
				for (int i = 0; i < size; i++) {
					PokerPlayer *player = GetModel()->mSeat2Player[i].get();
					if (player) {
						player->bPlayed_ = false;
						player->lastActionRot_ = 0;
						//			player->SetLastActionString("");
					}
				}

			} else if (packet->IsType("POKER_CHIPS_POT_RESET")) {
				if (GetModel()->mBatchMode)
					GetModel()->mPotCenter->ResetPots();
				//     model->mResetPot=true;

			} else if (packet->IsType("POKER_DEAL_CARDS")) {

				//     if (!model->mDealPlayerCards.empty())
				//       assert(0);

				int nbCards=0;
				std::vector<int> serials;
				packet->GetMember("numberOfCards", nbCards);
				packet->GetMember("serials", serials);
				GetModel()->mNbCardToDealPerPlayer=nbCards;
				GetModel()->mDealCard=1;
				GetModel()->mDealTime=-1;
				GetModel()->mCurrentPlayerToSendCard=0;
				GetModel()->mDealPlayerCards=serials;

			} else if (packet->IsType("POKER_DISPLAY_NODE")) {

				std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
				if(serial2player.find(GetModel()->mMe) != serial2player.end()) {
					PokerPlayer* player = serial2player[GetModel()->mMe].get();
					std::string style;
					packet->GetMember("style", style);
					std::string name;
					packet->GetMember("name", name);

					// consider doing an std::map
					if (name == "check") {
						player->mCheckInteractor->Accept(packet);
						if (style == "")
							player->bSentCheckPacket = false;
					}
					else if (name == "fold") {
						player->mFoldInteractor->Accept(packet);
						if (style == "")
							player->bSentFoldPacket = false;
					}
					else if (name == "call") {
						player->mCallInteractor->Accept(packet);
						if (style == "") {
							player->bSentCallPacket = false;
							player->mCallInteractor->SetText(" ");
						}
					}
					else if (name == "raise") {
						if (style == "") {

							player->mRaiseInteractor->mForceToZoom = false;
							player->mRaiseInteractor->mWaitingForValid = false;
							player->mRaiseInteractor->mCanBeFocused = true;
							player->mRaiseInteractor->mGlowScale = 1.0f;
							player->bSentRaisePacket = false;
							player->mRaiseInteractor->SetText(" ");
						}

						player->mRaiseInteractor->Accept(packet);
					}
					else if (name == "shadowstacks")
					  player->DisplayShadowStacks(style);
					else if (name == "sitoutEnd") {
					  int state;
						unsigned int game_id;
					  packet->GetMember("state", state);
					  packet->GetMember("game_id", game_id);
					  
					  unsigned int serial = state; //atoi( state.c_str() );
					  if (serial == GetModel()->mMe && GetModel()->mGameSerial == game_id) {
					    GetModel()->mSeatManager->MainPlayerSitOut();
					  }
					}
				}
					
			} else if (packet->IsType("POKER_DISPLAY_CARD")) {
				guint game_id;
				packet->GetMember("game_id", game_id);

				if(game_id == GetModel()->mGameId) {
					std::vector<int> indexes;
					int state=0;
					guint serial;
					packet->GetMember("index", indexes);
					packet->GetMember("serial", serial);
					packet->GetMember("display", state);

					std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
					if(serial2player.find(serial) != serial2player.end()) {
						PokerPlayer* player = serial2player[serial].get();
						int end=(int)indexes.size();
						for (int i=0;i<end;i++)
							if (state)
								player->ShowCard(indexes[i]);
							else
								player->HideCard(indexes[i]);

					}
				}
			} else if (packet->IsType("POKER_ANIMATION_PLAYER_NOISE")) {
				guint serial;
				std::string action;

				//int t1 = timeGetTime();

				packet->GetMember("serial", serial);
				packet->GetMember("action", action);

				std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
				if(serial2player.find(serial) != serial2player.end()) {
					PokerPlayer* player = serial2player[serial].get();
					//      g_debug("noise action %s",action.c_str());
					if (action=="start") {
						// 	assert(0);
						player->GetBody()->PlayFacialNoise();
					} else if (action=="stop") {
						// 	assert(0);
						player->GetBody()->StopFacialNoise();
					}
				}


			} else if (packet->IsType("POKER_ANIMATION_PLAYER_FOLD")) {
				guint serial;
				std::string animation;
				packet->GetMember("serial", serial);
				packet->GetMember("animation", animation);

				std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
				if(serial2player.find(serial) != serial2player.end()) {
					PokerPlayer* player = serial2player[serial].get();
					g_debug("fold with animation %s",animation.c_str());
					player->GetBody()->GetModel()->PlayFold(animation);
				}
			} else if (packet->IsType("POKER_ANIMATION_PLAYER_BET")) {
			} else if (packet->IsType("POKER_ANIMATION_PLAYER_CHIPS")) {
				guint serial;
				std::string animation;
				std::string state;
				packet->GetMember("serial", serial);
				packet->GetMember("state", state);
				packet->GetMember("animation", animation);
				g_debug("POKER_ANIMATION_PLAYER_CHIPS serial %d state %s animation %s",serial, state.c_str(), animation.c_str());

				PokerPlayer* player=0;
				std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
				if (serial2player.find(serial) != serial2player.end())
					player = serial2player[serial].get();

				if (!GetModel()->mBatchMode) {

					if (player) {
						if (state=="show") {
							g_debug("POKER_ANIMATION_PLAYER_CHIPS show");
							std::vector<int> chips;
							packet->GetMember("chips",chips);
							player->DisplayChipsOfBetAnimation(true);
							player->SetValueChipsOfBetAnimation(chips);

							assert(!chips.empty());
							int sum = 0;
							for (unsigned int i = 0; i < chips.size() ; i++)
								sum+=chips[i];
							assert(sum);

							if (animation=="getPot") {
								g_debug("POKER_ANIMATION_PLAYER_CHIPS get pot show");
								player->SyncBetStackWithPacket(true);
								player->DisplayPot2PlayerChipStack(false);
							} else {
								// means we have run an animation bet
								player->SyncBetStackWithPacket(false);
								player->HasRunAnimationBet(true);
							}
						} else if (state=="hide") {
							g_debug("POKER_ANIMATION_PLAYER_CHIPS hide");
							player->DisplayChipsOfBetAnimation(false);
							if (animation=="bet" || animation=="betMore" || animation=="betAllIn" ) {
								// if we want to hide animation chips bet then we consider the animation finished
								// and it's right
								player->HasRunAnimationBet(false);

								std::vector<int> chips;
								packet->GetMember("chips", chips);

								player->GetBetStack()->SetChips(chips);
								player->SyncBetStackWithPacket(true);
								player->WriteFadeText(MAFformat_amount(player->GetAnimationBetChipStack()->GetChipsAmount()));
							} else {
								player->DisplayBetStack(true);
							}
						}
					}
				} else {

				}
			} else if (packet->IsType("POKER_ANIMATION_DEALER_CHANGE")) {
				if (!GetModel()->mBatchMode) {
					g_debug("POKER_ANIMATION_DEALER_CHANGE");
					guint serial;
					std::string state;
					packet->GetMember("serial", serial);
					packet->GetMember("state", state);
					if (state=="show") {
						DealerChangeToSeat(GetModel()->mDealerButtonSeatIndex);
						g_debug("ChangeDealer in POKER_ANIMATION_DEALER_CHANGE");
						GetModel()->mDealerButton->setNodeMask(MAF_VISIBLE_MASK);
						g_debug("POKER_ANIMATION_DEALER_CHANGE ON");
					} else {
						GetModel()->mDealerButton->setNodeMask(0);
						g_debug("POKER_ANIMATION_DEALER_CHANGE OFF");
					}
				}
 
			} else if (packet->IsType("POKER_ANIMATION_DEALER_BUTTON")) {
				if (!GetModel()->mBatchMode) {
// 					g_debug("POKER_ANIMATION_DEALER_BUTTON");
					guint serial;
					std::string state;
					packet->GetMember("serial", serial);
					packet->GetMember("state", state);

					PokerModel::Serial2Player& s2p = GetModel()->mSerial2Player;
					PokerModel::Serial2Player::iterator it=s2p.find(serial);
					if (it==s2p.end())
						g_error("POKER_ANIMATION_DEALER_BUTTON serial %d not found",serial);

					if (state=="hide") {
						g_debug("POKER_ANIMATION_DEALER_BUTTON OFF for serial %d", serial);
						s2p[serial]->mAnimationDealer->setNodeMask(0);
					} else if (state=="show") {
						g_debug("POKER_ANIMATION_DEALER_BUTTON ON for serial %d", serial);
						s2p[serial]->mAnimationDealer->setNodeMask(MAF_VISIBLE_MASK);
					}
				}
			} else if (packet->IsType("POKER_BATCH_MODE")) {
				//    model->mBatchMode=true;
			} else if (packet->IsType("POKER_STREAM_MODE")) {
				g_debug("POKER_BATCH_MODE false");

				// clear display of bet chipstack animation
				PokerModel::Serial2Player& s2p = GetModel()->mSerial2Player;
				for (PokerModel::Serial2Player::iterator it = s2p.begin(); it != s2p.end(); it++)
					if (it->second.get())
						it->second->DisplayChipsOfBetAnimation(false);

				GetModel()->mBatchMode = false;

				if (loader_.valid()) {
					mGame->GetScene()->GetView()->setUseGlow(mGame->mGlowFlag);
					mGame->GetScene()->HUDRemove(loader_.get());

					osg::Group *grp = GetModel()->mSetData->GetGroup();
					grp->setNodeMask( grp->getNodeMask() | MAF_VISIBLE_MASK );


					loader_ = NULL;
					mGame->SetCallRenderMethod(true);

					PokerModel::Serial2Player &s2p = GetModel()->mSerial2Player;
					for (PokerModel::Serial2Player::iterator it = s2p.begin(); it != s2p.end(); it++) {
						PokerPlayer *player = it->second.get();
						player->GetBody()->GetModel()->GetOsgCalModel()->freeAllLayersRessource();
					}

					osgCal::Model::freeLayersRessource();
				}
			}
			else if (packet->IsType("POKER_RENDERER_STATE")) {
				std::string state;
				packet->GetMember("state", state);
				bool playingState = ((state == "seating")
						     || (state == "idle")
						     || (state == "buy_in")
						     || (state == "buy_in_done")
						     || (state == "rebuy")
						     || (state == "rebuy_done")
						     || (state == "muck")
						     || (state == "pay_blind_ante")
						     || (state == "pay_blind_ante_send")
						     || (state == "pay_blind_ante_done")
						     || (state == "joining")
						     || (state == "joining_my")
						     || (state == "joining_done")
						     || (state == "leaving")
						     || (state == "leaving_done")
						     || (state == "leaving_cancel")
						     || (state == "leaving_confirm")
						     || (state == "canceled")
						     || (state == "sit_out"));

				if (GetModel())
					GetModel()->mCamera->SetRespondToEvents(playingState);

				if (state != "idle") {
					if (uihelp)
						uihelp->showActivateButton(false);

					if (loader_.valid()) {
						mGame->GetScene()->GetView()->setUseGlow(mGame->mGlowFlag);
						mGame->GetScene()->HUDRemove(loader_.get());
						loader_ = NULL;
						mGame->SetCallRenderMethod(true);
					}

					mGame->mPokerMultiTable->ShowButton(false);
				}
				else {
					if (uihelp)
						uihelp->showActivateButton(true);

					if (nbGames_ > 1)
						mGame->mPokerMultiTable->ShowButton(true);
					else
						mGame->mPokerMultiTable->ShowButton(false);
				}

				if(game->GetWindow(true)->GetFullScreen()) {
					MAFName2Animate& name2animate = game->GetInterface()->GetName2Animate();
					MAFApplication2DAnimate* animate = name2animate["menu_window"];
					g_assert(animate);
					for(MAFApplication2DAnimate::iterator i = animate->begin(); i != animate->end(); i++) {
						MAFApplication2DSlide* slide = dynamic_cast<MAFApplication2DSlide*>(i->get());
						if(slide) {
							if(state.find("idle") != std::string::npos || state.find("outfit") != std::string::npos || state.find("login") != std::string::npos) {
								slide->SetMouseTrigger(true);
							} else {
								slide->SetMouseTrigger(false);
							}
						}
					}
				}

			}
			else if (packet->IsType("POKER_CURRENT_GAMES")) {
				int count = 0;
				packet->GetMember("count", count);
				if (count > 1)
					mGame->mPokerMultiTable->ShowButton(true);
				else
					mGame->mPokerMultiTable->ShowButton(false);
				nbGames_ = count;

			}
			else if (packet->IsType("POKER_INTERFACE_COMMAND")) {
				std::string window;
				std::string command;
				packet->GetMember("window", window);
				packet->GetMember("command", command);
				if (command == "load") {
					StopXwncWhileSlide* slideCallback = new StopXwncWhileSlide(mGame->GetInterface()->GetModel()->GetDesktop()->getServer(), mGame);
					std::map<std::string, MAFApplication2DAnimate*>& animate = mGame->GetInterface()->GetName2Animate();
					for (std::map<std::string, MAFApplication2DAnimate*>::iterator it = animate.begin(); it != animate.end(); it++)
						it->second->SetCallback(slideCallback);
				} else if (command == "show") {
					mGame->GetInterface()->ShowWindow(window, true);
				} else if (command == "hide") {
					mGame->GetInterface()->ShowWindow(window, false);
				}
			} else if (packet->IsType("POKER_PLAYER_ME_LOOK_CARDS")) {
			} else {
				g_critical("PokerController::Update unknown packet type (%d)", (int)packet->GetType());
			}

#ifdef USE_NPROFILE
		double timeFuncB = nprf::GetRealTime();
		if (GetModel() && packet && GetModel()->mBatchMode == true && !packet->IsType("POKER_TABLE") && !packet->IsType("POKER_PLAYER_ARRIVE")) {
			static double cumul = 0;
			cumul += timeFuncB - timeFuncA;
			osg::notify(osg::WARN) << "OSGCAL: Unknown activity of Python Packet (type " << packet->GetType() << ") during batch mode. Took: " << (timeFuncB-timeFuncA)*1000 << "ms, cumul is: " << cumul << "s" << std::endl;
		}
#endif

}

bool PokerController::Update(MAFApplication* application)
{
	NPROFILE_SAMPLE("PokerController::Update");
	PokerApplication* game = dynamic_cast<PokerApplication*>(application);

	iFrame++;

	SDL_Event* event = game->GetLastEventIgnoreLocking();

	if (event) {

		if (event->type == SDL_MOUSEBUTTONDOWN && event->button.button == SDL_BUTTON_RIGHT) {
			MAFSceneView* view = dynamic_cast<MAFSceneView*>(game->GetScene()->GetView());
			g_debug("Picked element %s",view->GetLastPickedItem().c_str());
		}
		else if (event->type == SDL_KEYDOWN) {

			switch(event->key.keysym.sym) {

				case SDLK_ESCAPE:
					GameAccept(PokerEventQuit());
					break;

				case SDLK_F9:
					{
						const std::string &screenshot = mGame->HeaderGet("settings", "/settings/screenshot");
						if (screenshot == "yes" || screenshot =="on") {
							char str[200];
							static int index_image = 0;

							int x = 0;
							int y = 0;
							int w = mGame->GetWindow(true)->GetWidth();
							int h = mGame->GetWindow(true)->GetHeight();
							unsigned char *pixs = new unsigned char[w*h*3];
							glReadPixels(x, y, w, h, GL_RGB, GL_UNSIGNED_BYTE, pixs);

							osg::ref_ptr<osg::Image> img = new osg::Image();
							img->setImage(w, h, 1, 3, GL_RGB, GL_UNSIGNED_BYTE, pixs, osg::Image::USE_NEW_DELETE);
							img->flipVertical();

							sprintf(str, "screenshot_%d.raw", index_image++);

							FILE *file = fopen(str, "wb");
							fwrite(pixs, 1, w*h*3, file);
							fclose(file);
						}
					}
					break;

				case SDLK_r:
					{
						if (event->key.keysym.mod & KMOD_LCTRL)
							MAFApplication::GetTextureManager()->Reload();
						else {
							xmlDocPtr doc = xmlReadFile("conf/client.xml",0,0);
							VarsEditor::Instance().Read(doc,"/sequence/varseditor");
							VarsEditor::Instance().Dump();
							xmlFreeDoc(doc);
						}
					}
					break;

//#define TEST_OPTIONAL_KEYS
#ifdef TEST_OPTIONAL_KEYS
				case SDLK_s:
					{
						if (event->key.keysym.mod & KMOD_LCTRL)
							game->mDatas->ReloadAudio();
					}
					break;
				case SDLK_p:
					{
					}
					break;
				case SDLK_F1:
					{
						game->PythonCall("showMenu");
					}
					break;
				case SDLK_F2:
					{
						game->PythonCall("showUserInfo");
					}
					break;
				case SDLK_F3:
					{
						game->PythonCall("showOutfits");
					}
					break;
				case SDLK_F4:
					{

						model->mDealCard=1;
						model->mDealTime=-1;
						model->mLastPlayerDealedCard=(*model->mSerial2Player.begin()).first;
					}
					break;

				case SDLK_F5:

					{
						// 					osgDB::writeObjectFile(*(game->mSetData->GetGroup()),"dump.osg");
						osgDB::writeObjectFile(*(application->GetScene()->model->mScene->getSceneData()),"dump.osg");
						break;
					}
				case SDLK_F6:
					{
						//game->PythonCall("logout");
						game->PythonCall("linetrace");
					}
					break;

				case SDLK_F7:
					{
						PokerCameraController* camera = dynamic_cast<PokerCameraController*>(game->GetScene()->model->mCamera.get());
						PokerCameraModel::Mode mode = camera->model->GetMode();
						if (mode == PokerCameraModel::CAMERA_GAME_MODE)
							camera->model->SetMode(PokerCameraModel::CAMERA_LEAVE_MODE);
						game->PythonCall("queryHands");
					}
					break;
				case SDLK_F8:
					{
						game->PythonCall("queryAllHands");
					}
					break;

				case SDLK_F12:
					{
						game->PythonCall("replayStep");
					}
					break;
#endif
				default:
					break;
			}
		}
		else if (event->type == SDL_KEYUP) {
			switch(event->key.keysym.sym) {
					case SDLK_RSHIFT:
						break;
					default:
						break;
			}
		}
		else if (event->type == SDL_QUIT)
		{
			// see escape
			GameAccept(PokerEventQuit()); // FIXME input
		}
		else if (event->type == SDL_MOUSEBUTTONUP) {

			if (GetModel()) {
				std::map<guint,osg::ref_ptr<PokerPlayer> > &serial2player = GetModel()->mSerial2Player;
				guint me = GetModel()->mMe;
				if (serial2player.find(me) != serial2player.end()) {
					PokerPlayer *player = serial2player[me].get();
					if (player) {
						PokerChipsStackModel *model = player->GetBetStack()->GetModel();
						if (model->mSelected) {
							player->GetBetStack()->UninstallSlider(game);
							UNLOCK_MOUSE(game, this);
							int betValue = model->mSlider->getCurrentValue();

							player->mRaiseInteractor->mCanBeFocused = true;
							player->mCallInteractor->mCanBeFocused = true;
							player->mCheckInteractor->mCanBeFocused = true;
							player->mFoldInteractor->mCanBeFocused = true;

							player->mRaiseInteractor->mForceToZoom = false;

							if (betValue != 0) {
								player->mRaiseInteractor->mWaitingForValid = true;
								player->mRaiseInteractor->mGlowScale = 1.7f;
								player->mRaiseInteractor->mBetValue = model->mSlider->getCurrentValue();

								std::string str = MAFformat_amount(betValue, true);
								player->mRaiseInteractor->SetText( str );
							}
							else {
								player->mRaiseInteractor->SetText("");
								player->mRaiseInteractor->mForceToZoom = false;
								player->mRaiseInteractor->mWaitingForValid = false;
								player->mRaiseInteractor->mCanBeFocused = false;
								player->mRaiseInteractor->Update(game);
								player->mRaiseInteractor->mCanBeFocused = true;
							}

							game->mCursor->WarpMouse(model->mPreviousMouseX, model->mPreviousMouseY);
						}
					}
				}
			}
		}
	}
	else if(game->GetLastEvent(this) == NULL) {
		if (GetModel())
			UpdateModel(game);
	}

	return true;
}

void PokerController::UpdateModel(PokerApplication *game)
{
	float dt = GetDeltaFrame() / 1000.0f;
	PokerModel *model = GetModel();

	if (model->mCloudTexMat.valid()) {
		// we are in level03
		osg::Matrix mat = model->mCloudTexMat->getMatrix();
		mat *= osg::Matrix::translate( model->mUVTranslateCloudSpeed * dt );
		model->mCloudTexMat->setMatrix(mat);

		PokerSceneView *sceneView = (PokerSceneView*) mGame->GetScene()->GetView();
		osgUtil::SceneView* scene = sceneView->GetModel()->mScene.get();
		const osg::Matrix &viewMat = scene->getViewMatrix();
		osg::Matrix camMat = osg::Matrix::inverse(viewMat);

		float alpha = fabsf( camMat(1, 1) );
		osg::Material *material = (osg::Material*) model->mLensFlare->getStateSet()->getAttribute(osg::StateAttribute::MATERIAL);
		material->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(1, 1, 1, alpha) );

		int nbLampesDrawables = model->mLampe->getNumDrawables();
		for (int i = 0; i < nbLampesDrawables; i++) {
			osg::Material *material = (osg::Material*) model->mLampe->getDrawable(i)->getStateSet()->getAttribute(osg::StateAttribute::MATERIAL);
			material->setAlpha(osg::Material::FRONT_AND_BACK, alpha );
		}
	}

	{
	  std::map<int, unsigned int> serial2seat;
	  unsigned int size = GetModel()->mSeat2Serial.size();
	  for (unsigned int i = 0; i < size; ++i)
	    serial2seat[GetModel()->mSeat2Serial[i]] = i;
	  if (serial2seat.find(mMe) != serial2seat.end())
	    GetModel()->mMeLastSeat = serial2seat[mMe];
	  GetModel()->mHUD->UpdatePosition(dt, GetModel()->mMeLastSeat);
	}

	std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = GetModel()->mSerial2Player;
	if (serial2player.find(GetModel()->mMe) != serial2player.end()) {
		PokerPlayer* player = serial2player[GetModel()->mMe].get();
		if (player) {
			bool isCall = false;
			unsigned int value = player->GetBetValue(isCall);
			if (value != 0) {

				g_debug("PokerController::Update: raise / call");
				osg::ref_ptr<MAFPacket> packet;
				if(isCall) {
					packet = game->GetPacketsModule()->Create("PacketPokerCall");
					packet->SetMember("game_id", GetModel()->mGameSerial);
					packet->SetMember("serial", GetModel()->mMe);
				} else {
					packet = game->GetPacketsModule()->Create("PacketPokerRaise");
					packet->SetMember("game_id", GetModel()->mGameSerial);
					packet->SetMember("serial", GetModel()->mMe);
					packet->SetMember("amount", value);
				}
				game->PythonCall("interactorSelected", packet.get());
				player->ResetBetValue();
				player->bSentRaisePacket = true;
			}

			if (player->mCheckInteractor == 0)
				g_error("PokerController: player mMe has no CheckInteractor");
			bool checkInteractorSelected = player->mCheckInteractor->GetSelected();

			if (player->mFoldInteractor == 0)
				g_error("PokerController: player mMe has no FoldInteractor");
			bool foldInteractorSelected = player->mFoldInteractor->GetSelected();

			if (player->mCallInteractor == 0)
				g_error("PokerController: player mMe has no CallInteractor");
			bool callInteractorSelected = player->mCallInteractor->GetSelected();

			if (player->mRaiseInteractor == 0)
				g_error("PokerController: player mMe has no RaiseInteractor");
			bool raiseInteractorSelected = player->mRaiseInteractor->GetSelected();

			if (checkInteractorSelected) {
				g_debug("PokerController::Update: check");
				osg::ref_ptr<MAFPacket> packet = game->GetPacketsModule()->Create("PacketPokerCheck");
				packet->SetMember("game_id", GetModel()->mGameSerial);
				packet->SetMember("serial", GetModel()->mMe);
				game->PythonCall("interactorSelected", packet.get());
				player->mCheckInteractor->SetSelected(false);
				player->bSentCheckPacket = true;
				player->mRaiseInteractor->mWaitingForValid = false;
				player->mRaiseInteractor->mCanZoom = true;
				player->mRaiseInteractor->mGlowScale = 1.0f;
				player->mRaiseInteractor->mCanBeFocused = true;
				player->mRaiseInteractor->mDirtyDisplay = true;
			}

			if (foldInteractorSelected) {
				g_debug("PokerController::Update: fold");
				osg::ref_ptr<MAFPacket> packet = game->GetPacketsModule()->Create("PacketPokerFold");
				packet->SetMember("game_id", GetModel()->mGameSerial);
				packet->SetMember("serial", GetModel()->mMe);
				game->PythonCall("interactorSelected", packet.get());
				player->mFoldInteractor->SetSelected(false);
				player->bSentFoldPacket = true;
				player->mRaiseInteractor->mWaitingForValid = false;
				player->mRaiseInteractor->mCanZoom = true;
				player->mRaiseInteractor->mGlowScale = 1.0f;
				player->mRaiseInteractor->mCanBeFocused = true;
				player->mRaiseInteractor->mDirtyDisplay = true;
			}

			if (callInteractorSelected) {
				g_debug("PokerController::Update: call");
				osg::ref_ptr<MAFPacket> packet = game->GetPacketsModule()->Create("PacketPokerCall");
				packet->SetMember("game_id", GetModel()->mGameSerial);
				packet->SetMember("serial", GetModel()->mMe);
				game->PythonCall("interactorSelected", packet.get());
				player->mCallInteractor->SetSelected(false);
				player->bSentCallPacket = true;
				player->mRaiseInteractor->mWaitingForValid = false;
				player->mRaiseInteractor->mCanZoom = true;
				player->mRaiseInteractor->mGlowScale = 1.0f;
				player->mRaiseInteractor->mCanBeFocused = true;
				player->mRaiseInteractor->mDirtyDisplay = true;
			}

			if (raiseInteractorSelected) {
				g_debug("PokerController::Update: raise");

				osg::ref_ptr<MAFPacket> packet = game->GetPacketsModule()->Create("PacketPokerRaise");
				packet->SetMember("game_id", GetModel()->mGameSerial);
				game->PythonCall("interactorPreRaise", packet.get());

				player->mRaiseInteractor->SetSelected(false);

				bool bCanInstall = player->mRaiseInteractor->CanInstallSlider();
				
				PokerChipsStackModel *model = player->GetBetStack()->GetModel();
				if (model->mSelected == false && bCanInstall) { // && player->bSentRaisePacket == false && player->bSentCheckPacket == false && player->bSentCallPacket == false && player->bSentFoldPacket == false) {
					model->mX = game->getMouseX();
					model->mY = game->getMouseY();
					model->mPreviousMouseX = model->mX;
					model->mPreviousMouseY = model->mY;
					player->GetBetStack()->InstallSlider(game);
					LOCK_MOUSE(game, this);

					player->mCallInteractor->mCanBeFocused = false;
					player->mCheckInteractor->mCanBeFocused = false;
					player->mFoldInteractor->mCanBeFocused = false;
					player->mRaiseInteractor->mWaitingForValid = false;
					player->mRaiseInteractor->mForceToZoom = true;

					PokerCameraModel *camera = (dynamic_cast<PokerCameraController*>(game->GetScene()->GetModel()->mCamera.get()))->GetModel();
					PokerCameraModel::Mode pmode = camera->GetMode();

					if (pmode == PokerCameraModel::CAMERA_GAME_MODE || pmode == PokerCameraModel::CAMERA_DIRECT_MODE) {
						float x = game->GetWindow(true)->GetWidth() / 2.0f;
						float y = 200.0f;
						player->GetBetStack()->MoveSlider(game, x, y);
					}
					else {
						PokerInteractorRaise *inter = player->mRaiseInteractor.get();
						osg::MatrixTransform *anchor = (osg::MatrixTransform*) inter->GetModel()->GetArtefact();

						//PokerChipsStackModel *model = player->GetBetStack()->model;
						osgUtil::SceneView *sceneView = game->GetScene()->GetView()->GetModel()->mScene.get();
						osg::Matrixd proj = sceneView->getProjectionMatrix();
						osg::Matrixd camMat = sceneView->getViewMatrix();

						osg::Geode *geode = GetGeode( anchor );
						osg::BoundingBox bb = geode->getBoundingBox();

						osg::Matrixd fmat = MAFComputeLocalToWorld( anchor ) * camMat;

						osg::Vec3f up(0, bb._max[1], 0);
						up = up * fmat;

						osg::Vec4f trans = osg::Vec4(up, 0) ;

						float winx, winy, winz;

						osg::Vec4f t = trans * proj;

						winx = t._v[0] / t._v[3];
						winy = t._v[1] / t._v[3];
						winz = t._v[2] / t._v[3];

						int w = game->GetWindow(true)->GetWidth();
						int h = game->GetWindow(true)->GetHeight();

						winx = (winx + 1) * (w / 2);
						winy = (winy + 1) * (h / 2);

						float ty = 11 + 20;

						osg::BoundingBox sbb = player->GetBetStack()->GetModel()->mSlider->_background->_geometry->getBound();
						float sw = sbb._max[0] - sbb._min[0];
						float sh = sbb._max[1] - sbb._min[1];

						// clamp to screen
						if (winx - sw/2 < 0)
							winx = sw/2 + 20;
						else if (winx + sw/2 > w)
							winx = w - sw/2 - 20;

						if (winy + sh > h)
							winy = h - sh - 40;

						player->GetBetStack()->MoveSlider(game, winx, winy + ty);

						player->mRaiseInteractor->mCanBeFocused = false;
						player->mRaiseInteractor->mForceToZoom = true;
					}
				}
			}
		}
	}

	guint me = GetModel()->mMe;
	if (serial2player.find(me) != serial2player.end()) {
		PokerPlayer *player = serial2player[me].get();
		if (player) {

			PokerChipsStackModel *model = player->GetBetStack()->GetModel();

			if (player->mRaiseInteractor->mWaitingForValid == true) {
				player->mRaiseInteractor->mGlowScale -= dt * 0.5f;
				player->mRaiseInteractor->mScale -= dt * 0.5f;
				if (player->mRaiseInteractor->mScale < 1.0f)
					player->mRaiseInteractor->mScale = 1.0f;
				if (player->mRaiseInteractor->mGlowScale < 1) {
					player->mRaiseInteractor->mGlowScale = 1;
					player->mRaiseInteractor->mScale = 1.0f;

					if (player->mRaiseInteractor->mBetValue) {
						model->mBetValue = player->mRaiseInteractor->mBetValue;
						player->mRaiseInteractor->mBetValue = 0;
					}
				}
			}

			if (model->mSelected) {
				int pixel_delta = (model->mY - game->getMouseY() );
				if (pixel_delta) {
					float delta = ((float)pixel_delta) / game->GetWindow(true)->GetHeight();
					model->mSlider->moveCursor(delta);
					game->mCursor->WarpMouse(model->mX, model->mY);
				}
			}
		}
	}

	// Deal card for each player in game
	if (GetModel()->mDealCard && !GetModel()->mDealPlayerCards.empty()) {

		float mParamAnimationToDeal1Card=0;
		PokerModel::Serial2Player& s2p = GetModel()->mSerial2Player;
		PokerPlayer* player=0;
		if (!s2p.empty()) {
			player=s2p.begin()->second.get();
			osg::MultipleAnimationPathCallback* cbTmp=static_cast<osg::MultipleAnimationPathCallback*>(player->GetAnimationCard(0)->getUpdateCallback());
			mParamAnimationToDeal1Card=cbTmp->getAnimationDuration();
		}

		if (GetModel()->mDealCard <= GetModel()->mNbCardToDealPerPlayer) {

			// play only one sound per turn of table
			if (!GetModel()->mCurrentPlayerToSendCard) {
				mGame->GetPoker()->GetModel()->mSoundCard->Play();
			}

			if (GetModel()->mDealTime<0) {

				// play animation of a player
				PokerModel::Serial2Player::iterator it = s2p.find(GetModel()->mDealPlayerCards[GetModel()->mCurrentPlayerToSendCard]);
				player=0;
				if (it!=s2p.end()) {
					player=(*it).second.get();
					player->AnimateCard(GetModel()->mDealCard-1);

					GetModel()->mDealTime = GetModel()->mParamTimeToDealCard;

					// we have sent a card to all player, restart to the first
					GetModel()->mCurrentPlayerToSendCard++;
					if (GetModel()->mCurrentPlayerToSendCard == (int) GetModel()->mDealPlayerCards.size()) {
						GetModel()->mCurrentPlayerToSendCard=0;
						GetModel()->mDealCard++;
					}
				} else {
					GetModel()->mDealPlayerCards.erase(GetModel()->mDealPlayerCards.begin() + GetModel()->mCurrentPlayerToSendCard);
					if (GetModel()->mCurrentPlayerToSendCard == (int)GetModel()->mDealPlayerCards.size()) {
						GetModel()->mCurrentPlayerToSendCard=0;
						GetModel()->mDealCard++;
					}
				}
			}
		}

		// check if cards are at the target position
		int cardAtTheTarget=0;
		for (int i=0;i<(int)GetModel()->mDealPlayerCards.size();i++) {
			PokerModel::Serial2Player::iterator it=s2p.find(GetModel()->mDealPlayerCards[i]);
			player=0;
			if (it!=s2p.end())
				player=(*it).second.get();
			if (player)
				for (int j=0;j<GetModel()->mNbCardToDealPerPlayer;j++) {
					osg::MultipleAnimationPathCallback* cb=0;
					cb=static_cast<osg::MultipleAnimationPathCallback*>(player->GetAnimationCard(j)->getUpdateCallback());

					if (cb->getAnimationTime()>cb->getAnimationDuration()-1e-4) {
						player->HideAnimateCard(j);
						player->ShowCard(player->GetNbCardsDisplayed());
					} else if (cb->getAnimationTime()<1e-4)
						cardAtTheTarget++;
				}
			else
				cardAtTheTarget++; // we assume that card for this player is ok
		}

		if (GetModel()->mDealCard > GetModel()->mNbCardToDealPerPlayer && cardAtTheTarget >= (int)GetModel()->mDealPlayerCards.size()*GetModel()->mNbCardToDealPerPlayer) {
			GetModel()->mDealCard=0;
			GetModel()->mDealPlayerCards.clear();
		}
		GetModel()->mDealTime-=dt;
	}




	//Door interaction
	PokerDoorController &frontDoor = *GetModel()->mFrontDoor.get();
	//PokerDoorController &backDoor = *model->mBackDoor.get();

	if (frontDoor.mSelected)// || backDoor.GetSelected())
	{	
		PokerCameraController* camera = dynamic_cast<PokerCameraController*>(game->GetScene()->GetModel()->mCamera.get());
		PokerCameraModel::Mode mode = camera->GetModel()->GetMode();
		if (mode == PokerCameraModel::CAMERA_FREE_MODE) 
		{
			// wait to return in freemode
			// before handle door selection
			game->PythonCall("wantToLeave");
			frontDoor.mSelected = false;
			//backDoor.SetSelected(false);

		}
	}

  GetModel()->mPokerMoveChips->Update(game, GetModel()->mPotCenter.get());
	GetModel()->mBubbleManager->Update(game);
}

