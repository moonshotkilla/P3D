/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Johan Euphrosine <johan@mekensleep.com>
*
*/

#ifndef __POKER_EDITOR__
#define __POKER_EDITOR__
#include <string>
#include <map>
#include <sstream>
#include <iostream>
#include <libxml/tree.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <libxml/xpathInternals.h>
#include <libxml/xmlreader.h>

struct IGetterSetter
{
  virtual ~IGetterSetter() {};
	virtual void Get(std::string& result) const = 0;
	virtual void Set(const std::string& value) const = 0;
};

template<typename T>
struct GetterSetterT : IGetterSetter
{
	T& _var;
	GetterSetterT(T& var) : _var(var)
	{
	}
	void Get(std::string& result) const
	{
		std::ostringstream oss;
		oss << _var;
		result = oss.str();
	}
	void Set(const std::string& value) const
	{
		std::istringstream iss(value);
		iss >> _var;
	}
};

template<typename T>
struct Singleton
{
	static T& Instance()
	{
		static T instance;
		return instance;
	}
};


static bool xmlReaderSeekToElement(xmlTextReaderPtr reader, const std::string &element)
{
  while ((xmlTextReaderRead(reader) == 1))
    {
      const char* namePtr = ((const char*)xmlTextReaderConstName(reader));
      std::string name = namePtr;
      if ((xmlTextReaderNodeType(reader) == XML_READER_TYPE_ELEMENT) && (name == element))
	return true;
    }
  return false;
}

template<typename T>
static bool xmlReaderGetAttribute(xmlTextReaderPtr reader, const std::string &name, T& attribute)
{
  xmlChar* attributePtr = xmlTextReaderGetAttribute(reader, (const xmlChar*)name.c_str());
  if (attributePtr == 0)
    return false;
  std::istringstream iss((const char *)attributePtr);
  iss >> attribute;
  xmlFree(attributePtr);
  return true;
}

struct PokerEditor : Singleton<PokerEditor>
{
	friend struct Singleton<PokerEditor>;
	void Dump()
	{
		typedef std::map<std::string, const IGetterSetter*>::iterator It;
		It begin  = _vars.begin();
		It end = _vars.end();
		while(begin != end)
		{
			std::cout << (*begin).first << ":" <<  (*begin).second << std::endl;
			++begin;
		}
	}
	bool ReadFromXml(const std::string& path)
	{
	  xmlDocPtr document = xmlParseFile(path.c_str());
	  if (document == 0)
	    return false;
	  xmlTextReaderPtr reader = xmlReaderWalker(document);
	  if (reader == 0)
	    {
	      xmlFreeDoc(document);
	      return false;
	    }
	  if (xmlReaderSeekToElement(reader, "editor") == false)	    
	    {
	      xmlFreeTextReader(reader);
	      xmlFreeDoc(document);
	      return false;
	    }
	  bool result = true;
	  while (xmlReaderSeekToElement(reader, "var"))
	    {
	      std::string name;
	      xmlReaderGetAttribute(reader, "name", name);
	      std::string value;
	      xmlReaderGetAttribute(reader, "value", value);
	      if (Set(name, value) == false)		
		{
		  std::cout << "warning var " << name << " not found" << std::endl;
		  result = false;
		  break;
		}
	    }
	  xmlFreeTextReader(reader);
	  xmlFreeDoc(document);
	  return result;
	}
	template<typename T>
	bool Edit(const std::string& key, T& var)
	{
		if (_vars.find(key) != _vars.end())
			return false;
		_vars[key] = new GetterSetterT<T>(var);
		return true;
	}
	bool Get(const std::string& key, std::string& result)
	{
		if (_vars.find(key) == _vars.end())
			return false;
		_vars[key]->Get(result);
		return true;
	}	
	bool Set(const std::string& key, const std::string& var)
	{
		if (_vars.find(key) == _vars.end())
			return false;
		_vars[key]->Set(var);
		return true;
	}
	bool Command(const std::string& message, std::string &resultStr)
	{
		std::string::size_type pos = message.find_first_of(" ");				
		if (pos == std::string::npos)
			pos = message.find_first_of("\n");
		if (pos == std::string::npos)
			pos = message.size();
			{
				if (message.substr(0, pos) == "/get")
					{
						if (message.size() > pos + 1)
							{
								std::string key = message.substr(pos + 1);
								std::string value;
								bool result = Get(key, value);
								std::ostringstream oss;
								if (result)
									oss << "=>get: " << key << "=" << value;
								else
									oss << "=>get: " << key << " not found";
								resultStr = oss.str();
								return true;
							}
						else
							{
								resultStr = "=>get: usage: /get variableName";
								return true;
							}
					}
				else if (message.substr(0, pos) == "/set")
					{
						if (message.size() > pos + 1)
							{
								std::string command = message.substr(pos + 1);
								pos = command.find_first_of(" ");
								if (pos == std::string::npos)
									pos = command.find_first_of("\n");
								if (pos == std::string::npos)
									pos = command.size();
								if (command.size() > pos + 1)
									{
										std::string key = command.substr(0, pos);
										std::string value = command.substr(pos+1);
										bool result = Set(key, value);
										std::ostringstream oss;
										if (result)
											oss << "=>set: " << key << "=" << value;
										else
											oss << "=>set: " << key << " not found";
										resultStr = oss.str();
										return true;
									}
								else
									{
										resultStr = "=>set: usage: /set variableName value";
										return true;
									}
							}
						else
							{
								resultStr = "=>set: usage: /set variableName value";
								return true;
							}
					}
				else if (message.substr(0, pos) == "/list")
					{
						if (_vars.size())
							{
								std::ostringstream oss;
								oss << "=>list: ";
								for (std::map<std::string, const IGetterSetter*>::iterator it = _vars.begin(); it != _vars.end(); it++)
									{
										std::string value;
										(*it).second->Get(value);
										oss << "(" << (*it).first << "=" << value << ") "; 
									}
								resultStr = oss.str();
							}
						else
							{
								resultStr = "=>list: empty";
							}
						return true;
					}
			}
		return false;		
	}
	private:
	std::map<std::string, const IGetterSetter*> _vars;
	PokerEditor()
	{
	}
	~PokerEditor()
	{
		for (std::map<std::string, const IGetterSetter*>::iterator it = _vars.begin(); it != _vars.end(); it++)
			delete((*it).second);
		_vars.clear();
	}
};

#define DISABLE_EDITOR
#ifdef DISABLE_EDITOR
#define EDITABLE(type, var, value)			static type var = value;
#define EDIT(key, var)
#define EDITABLE2(editor, type, var, value) static type var = value;
#else
#define EDITABLE(type, var, value)			static type var = value;\
																				PokerEditor::Instance().Edit(#var, var);
#define EDIT(key, var)									PokerEditor::Instance().Edit(key, var);
#define EDITABLE2(editor, type, var, value) static type var = value;\
																						if (editor) editor->Edit(#var, var);
#endif
#endif
