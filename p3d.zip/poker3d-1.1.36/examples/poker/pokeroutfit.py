#
# Copyright (C) 2004, 2005, 2006 Mekensleep
#
# Mekensleep
# 24 rue vieille du temple
# 75004 Paris
#       licensing@mekensleep.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
# Authors:
#  Loic Dachary <loic@gnu.org>
#  Cedric Pinson <cpinson@freesheep.org>

if __name__ == "__main__":
    import sys
    sys.path.insert(0, "../../python")

    sys.path.insert(0, "../../Python")
    sys.path.insert(0, "../../Python/Lib")
    sys.path.insert(0, "../../Python/Lib/site-packages")
    sys.path.insert(0, "../../Python/Lib/site-packages/win32")
    sys.path.insert(0, "../../Python/Lib/site-packages/win32/lib")
    sys.path.insert(0, "../../Python/DLLs")
    sys.path.insert(0, "../../Python/Lib/xml")
    sys.path.insert(0, "../../python/Lib/site-packages/libxmlmods")
    sys.path.insert(0, "../../python/Lib/site-packages/twisted")
    sys.path.insert(0, "../../python/Lib/site-packages/underware")

from operator import sub, add
from random import choice
from string import split
from pprint import pprint
import libxml2
import copy

from twisted.internet import reactor

from pokernetwork.pokernetworkconfig import Config
from pokerui import pokerinterface
from underware.outfit import Outfit

slot2index = {
    'head': 1,
    'hair': 2,
    'beard': 3,
    'dress': 3,
    'torso': 4,
    'legs': 5,
    'feet': 6,
    'accessory1': 7,
    'accessory2': 8,
    'accessory3': 9
    }

slot2slotindex = {
    'head': ('head', 0),
    'hair': ('hair', 0),
    'beard': ('beard', 0),
    'dress': ('dress', 0),
    'torso': ('torso', 0),
    'legs': ('legs', 0),
    'feet': ('feet', 0),
    'accessory1': ('accessory', 0),
    'accessory2': ('accessory', 1),
    'accessory3': ('accessory', 2)
    }

index2slot = {
    'male': {
    'outfit1': 'head',
    'outfit2': 'hair',
    'outfit3': 'beard',
    'outfit4': 'torso',
    'outfit5': 'legs',
    'outfit6': 'feet',
    'outfit7': 'accessory1',
    'outfit8': 'accessory2',
    'outfit9': 'accessory3'
    },
    'female': {
    'outfit1': 'head',
    'outfit2': 'hair',
    'outfit3': 'dress',
    'outfit4': 'torso',
    'outfit5': 'legs',
    'outfit6': 'feet',
    'outfit7': 'accessory1',
    'outfit8': 'accessory2',
    'outfit9': 'accessory3'
    }
}


class OutfitParameter:

    def __init__(self, value):
        self.name = value['name']
        self.default = value['default']
        self.entries = value['ids']
        self.preview = value['preview']
        self.text = value['text']
        self.preview_type = value['preview_type']
        self.showin_slottype = value['showin']
        self.last_value = self.default

    def isVisibleForSlottype(self, slot_type):
        if len(self.showin_slottype) == 0:
            return True
        
        if slot_type in self.showin_slottype:
            return True
        return False

    def getParameterName(self):
        return self.name

    def getEntries(self):
        return self.entries

    def getDefaultValue(self):
        return self.default

    def getLastValueSelected(self):
        return self.last_value

    def getPreview(self):
        return self.preview

    def getPreviewType(self):
        return self.preview_type

    def getText(self):
        return self.text

    def setPreview(self, preview):
        self.preview = preview[:]

    def setEntries(self, ids):
        self.entries = ids[:]

switchslotexclusif = {
    'male': {
    },
    'female': {
    'dress' : [ 'torso', 'legs' ],
    'torso' : [ 'dress' ],
    'legs' : [ 'dress' ],
    }
}

switchslotfemale = {
    'dress' : [ 'torso', 'legs' ],
    'torso' : [ 'dress' ],
    'legs' : [ 'dress' ],
    }

switchslotmale = { }

sex2path = {
    'male': "player.male.cal3d",
    'female': "player.female.cal3d"
    }

path2sex = dict(zip(sex2path.values(), sex2path.keys()))

MALE = 0
FEMALE = 1

class PokerOutfit:

    def __init__(self, settings):
        self.settings = settings
        self.load(settings)

    def getInfos(self, sex):
        return self.infos[sex]

    def installOutfit(self, object, outfit, sex):
        # it initialize the accessory slot else we can have 2 same object on different index and it's a problem
        object.setSlot("accessory", "none", 0)
        object.setSlot("accessory", "none", 1)
        object.setSlot("accessory", "none", 2)

        # reset incompatibilities_installed
        self.getInfos(sex)['incompatibilities_installed'] = [0] * len(self.getInfos(sex)['incompatibilities_installed'])

        for uislot_type in outfit.keys():
            ( slot_type, index ) = slot2slotindex[uislot_type]
            object.setSlot(slot_type, outfit[uislot_type]['NAME'], index)
            self.incompatibilitiesAdd(outfit[uislot_type]['NAME'], self.getInfos(sex)['incompatibilities'], self.getInfos(sex)['incompatibilities_installed'], self.getInfos(sex)['uislot2index'])
            print "Install Outfit: Set Slot %s - %s - %d" % (slot_type, outfit[uislot_type]['NAME'], index)
            
        for uislot_type in outfit.keys():
            ( slot_type, index ) = slot2slotindex[uislot_type]
            for value in outfit[uislot_type]['VALUES'].values():
                object.setParam(value['parameter'], value['name'], int(value['value']))
                print "Install Outfit: Set Param %s - %s - %s" % (value['parameter'],value['name'],value['value'])

        print "incompatibilities_installed %s" % self.getInfos(sex)['incompatibilities_installed']

    def getSlotsSortedByPriority(self, info):
        sorted = []
        for i in info:
            sorted.append( (i['PRIORITY'],i) )
        sort(sorted)
        return sorted


    def randomOutfit(self, sex):
        info = self.infos[sex]
        infos = info
        outfit = {}
        # reset incompatibilities installed
        uislot_count = len(infos['uislot2index'])
        infos['incompatibilities_installed'] = [0] * uislot_count


        # select switch element before assigning slot
        switchslot = infos['switchslot'].copy()
        # switchslot_remove contain slot_type to remove from priority2slottype map
        switchslot_to_remove = {} 

        if len(switchslot) != 0 :
            notfinished = True
            while notfinished == True:
                key = choice(switchslot.keys())
                items = switchslot[key]
                del switchslot[key]
                for i in items:
                    if switchslot.has_key(i):
                        switchslot_to_remove[i] = switchslot[i]
                        del switchslot[i]
                if len(switchslot) == 0:
                    notfinished = False

        # now build the priority2slottype without slot_type unwanted
        priority2slottype = filter(lambda x: switchslot_to_remove.has_key(x[1]) == False , infos['priority2slottype'])

        #print priority2slottype
        index_accessory_filled = 1

        # preselect accessory to fill inr order slot 1,2,3
        accessory_list = filter(lambda p: p[1] == 'accessory1' or p[1] == 'accessory2' or p[1] == 'accessory3' , priority2slottype)
        accessory_selected = [ 'none' , 'none' , 'none']
        index = 0
        for i in accessory_list:
            uislot_type = i[1]
            uislots = info['type2uislots'][uislot_type]
            selected = choice(uislots.keys())
            if selected != 'none':
                accessory_selected[index] = selected
                index = index + 1
        #print accessory_selected
        index_accessory = 0

        for i in priority2slottype:
            (priority, uislot_type) = i

            uislots = info['type2uislots'][uislot_type]

            uislots_filtered = self.incompatibilitiesFilter(infos['type2uislots'][uislot_type], infos['incompatibilities_installed'], infos['uislot2index'], "")
            #print "choice for type %s result %s " % (uislot_type,uislots_filtered.keys())

            # if we select a slot type that is a part of switch slot we exclude item none from selection
            #if switchslot.has_key(uislot_type) == True:
            #    del uislots_filtered['none']

            if infos['switchslot'].has_key(uislot_type):
                del uislots_filtered['none']
                
            uislot_key = choice(uislots_filtered.keys())

            if uislot_type == 'accessory1' or uislot_type == 'accessory2' or uislot_type == 'accessory3':
                found = 0
                for selected in range(len(accessory_selected)):
                    if uislots_filtered.has_key(accessory_selected[selected]):
                        uislot_key = accessory_selected[selected]
                        accessory_selected[selected] = 'none'
                        found = 1

                if found == 0:
                    uislot_key = 'none'
                    
            #print "selected %s " % uislot_key
            uislot = uislots_filtered[uislot_key]

            outfit[uislot_type] = { 'NAME': uislot_key }
            self.incompatibilitiesAdd(outfit[uislot_type]['NAME'], infos['incompatibilities'], infos['incompatibilities_installed'], infos['uislot2index'])

            definitions = {}
            values = {}
            for i in xrange(len(uislot['PARAMETERS'])):
                parameter = uislot['PARAMETERS'][i]
                value_definition = uislot['DEFINITIONS'][i]
                xpath = parameter + "/" + value_definition.getParameterName()
#before                xpath = parameter + "/" + value_definition['name']

                ids = value_definition.getEntries()
#before                ids = value_definition['ids']
                #print "ids0 %s" % ids
                mask = self.getParameterMask(outfit, infos['type2uislots'], uislot_key, uislot_type, parameter)

                if len(mask) != 0:
                    ids = []
                    for idsit in mask:
                        ids.append(str(idsit))
                #print "ids1 %s" % ids

                #                if parameter == 'global_skin_hue' and uislot_type != 'head':
                #                    ids = [ outfit['head']['VALUES'][xpath]['value'] ]
                #                print "ids2 %s" % ids

                ids_selected = choice(ids)
                if uislot_type != 'head' and parameter == 'global_skin_hue':
                    xp = parameter+'/color_set'
                    ids_selected = outfit['head']['VALUES'][xp]['value']
                value = {
                    'parameter': parameter,
#before                    'name': value_definition['name'],
                    'name': value_definition.getParameterName(),
                    'value': ids_selected
                    }
                #print "%s %s" % (xpath,value['value'])
                values[xpath] = self.getOrInsertReferencedParams(sex,xpath,value)
                definitions[xpath] = value_definition
            outfit[uislot_type]['DEFINITIONS'] = definitions
            outfit[uislot_type]['VALUES'] = values

        # reset incompatibilities installed
        infos['incompatibilities_installed'] = [0] * uislot_count

        # add empty switch with none, here we don't need incompatibilities_installed we just want a slot list
        for st in switchslot_to_remove.keys():
            item = {
                'DEFINITIONS': {},
                'VALUES': {},
                'NAME': 'none'
                }
            outfit[st] = item
            
        # fix last element that needs to be set to none for switch slot_type
        #self.computeHierarchicalIncompatibilities(sex, outfit, priority2slottype,"")

        return outfit

    def path2sex(self, path):
        return path2sex[path]

    def upgradeString(self, path, outfit):
        sex = self.path2sex(path)
        config = Config([])
        config.loadFromString(outfit)
        if self.infos[sex]['version'] == config.headerGet("/outfit/@version"):
            return outfit
        else:
            return "random"
        
    def setOutfitFromString(self, path, outfit):
        sex = self.path2sex(path)
        config = Config([])
        config.loadFromString(outfit)
        outfit = self.loadOutfit(self.infos[sex], sex, config, "")
        self.infos[sex]['outfit'] = outfit
        
    def outfitAsString(self, sex):
        info = self.infos[sex]
        doc = self.outfitAsXML(info['outfit'], info['version'])
        return doc.serialize()
    
    def randomOutfitAsString(self, sex):
        doc = self.outfitAsXML(self.randomOutfit(sex), self.infos[sex]['version'])
        return doc.serialize()
    
    def outfitAsXML(self, outfit, version):
        doc = libxml2.newDoc("1.0")
        root_node = libxml2.newNode("outfit")
        root_node.newProp('version', version)
        doc.setRootElement(root_node)
        for ( uislot_type, uislot ) in outfit.iteritems():
            if "accessory" in uislot_type:
                uislot_type = "accessory"
            new_uislot = root_node.newChild(None,'uislot',None)
            new_uislot.setProp('type', uislot_type)
            new_uislot.setProp('default', uislot['NAME'])
            for value in uislot['VALUES'].values():
                value_xml = new_uislot.newChild(None, 'value', None)
                value_xml.newProp('parameter', value['parameter'])
                value_xml.newProp('name', value['name'])
                value_xml.newProp('value', value['value'])
        return doc
    
    def getReferencedParams(self,sex):
        return self.getInfos(sex)['referenced_params']

    def getOrInsertReferencedParams(self,sex,xpath,value):
        values = self.getReferencedParams(sex)
        if not values.has_key(xpath):
            values[xpath] = value
        values[xpath]['value'] = value['value']
        return values[xpath]

    def loadOutfit(self, infos, sex, config, root_xpath):
        parameters = infos['parameters']
        #
        # Outfit
        #
        outfit = {}
        
        accessory_index = 1
        for uislot_xml in config.header.xpathEval(root_xpath + "/outfit/uislot"):
            uislot_properties = config.headerNodeProperties(uislot_xml)
            config.header.setContextNode(uislot_xml)
            values = {}
            definitions = {}
            #
            # Get parameters that have a custom values
            #
            for value_xml in config.header.xpathEval("child::value"):
                value = config.headerNodeProperties(value_xml)
                xpath = value['parameter'] + "/" + value['name']
                if not parameters.has_key(value['parameter']):
                    print "*CRITICAL* parameter %s is unknown" % value['parameter']
                    continue
                parameter = parameters[value['parameter']]
#before                if not parameter['map'].has_key(value['name']):
                found = None
                for param in parameter:
                    if param.getParameterName() == value['name']:
                        found = param
                if found == None:
                    print "*CRITICAL* value %s for parameter %s is unknown" % ( value['name'], value['parameter'] )
                    continue

                #values[xpath] = value
                values[xpath] = self.getOrInsertReferencedParams(sex,xpath,value)
#before                definitions[xpath] = parameters[value['parameter']]['map'][value['name']]
                definitions[xpath] = found #parameter[value['name']]

            uislot_type = uislot_properties['type']
            if uislot_type == "accessory":
                uislot_type = "accessory%d" % accessory_index
                accessory_index += 1
            outfit[uislot_type] = {
                'VALUES': values,
                'DEFINITIONS': definitions,
                'NAME': uislot_properties['default'],
                }
        type2uislots = infos['type2uislots']
        #
        # If parameters are missing assume the default value is the custom value
        #
        for uislot_type in index2slot[sex].values():
            if not outfit.has_key(uislot_type) or not outfit[uislot_type]['NAME']:
                outfit[uislot_type] = {
                'VALUES': {},
                'DEFINITIONS': {},
                'NAME': choice(type2uislots[uislot_type].keys())
                }
            if len(outfit[uislot_type]['DEFINITIONS']) == 0:
                definitions = {}
                values = {}
                uislot = type2uislots[uislot_type][outfit[uislot_type]['NAME']]
                for i in xrange(len(uislot['PARAMETERS'])):
                    parameter = uislot['PARAMETERS'][i]
                    value_definition = uislot['DEFINITIONS'][i]
                    value = {
                        'parameter': parameter,
                        'name': value_definition.getParameterName(),
#before                        'name': value_definition['name'],
                        'value': value_definition.getLastValueSelected()
#before                        'value': value_definition['default']
                        }
                    xpath = parameter + "/" + value_definition.getParameterName()
#before                    xpath = parameter + "/" + value_definition['name']
                    values[xpath] = self.getOrInsertReferencedParams(sex,xpath,value)
                        
                    definitions[xpath] = value_definition
                outfit[uislot_type]['DEFINITIONS'] = definitions
                outfit[uislot_type]['VALUES'] = values

        return outfit

    def loadParameters(self, config, result_parameters):
        parameters = {}
        for parameter_xml in config.header.xpathEval("/cal3d/parameters/parameter"):
            config.header.setContextNode(parameter_xml)
            parameter_properties = config.headerNodeProperties(parameter_xml)
            name = parameter_properties['id']
            values = []
            my_object_values = []
            color_preview_types = [ "basecolor", "detailcolor", "detailcolor", "detailcolor" ]
            showin = []
            for value_xml in config.header.xpathEval("showin/slot"):
                value_properties = config.headerNodeProperties(value_xml)
                print "SHOWIN %s" % value_properties
                showin.append(value_properties['type'])
                
            for value_xml in config.header.xpathEval("child::*[@alterable='true']"):
                value_properties = config.headerNodeProperties(value_xml)
                config.header.setContextNode(value_xml)
                preview = []
                preview_type = ""
                if value_xml.name == "opacity":
                    preview_type = "file"
                    preview = [ "opacity_%d.png" ]
                    ids = ['0', '25', '50', '75', '100']
                else:
                    ids = config.headerGetList("child::*/@id")
                hues_xml = config.header.xpathEval("child::hue")
                if len(hues_xml) > 0:
                    preview_type = color_preview_types.pop(0)
                    for hue_xml in hues_xml:
                        hue_properties = config.headerNodeProperties(hue_xml)
                        preview.append("#%02x%02x%02x" % ( int(hue_properties['tnr']), int(hue_properties['tng']), int(hue_properties['tnb'])))
                colors_xml = config.header.xpathEval("child::color")
                if len(colors_xml) > 0:
                    preview_type = color_preview_types.pop(0)
                    for color_xml in colors_xml:
                        color_properties = config.headerNodeProperties(color_xml)
                        preview.append("#%02x%02x%02x" % ( int(color_properties['r']), int(color_properties['g']), int(color_properties['b'])))
                my_value = {
                    "name": value_xml.name,
                    "default": value_properties["default"],
                    "text": value_properties["text"],
                    "ids": ids,
                    "preview_type": preview_type,
                    "preview": preview,
                    "showin": showin
                    }
                values.append(my_value)

                # new object parameter
                my_object_values.append(OutfitParameter(my_value))

            parameters[name] = {
                'map': dict(zip(map(lambda x: x['name'], values), values)),
                'ordered': my_object_values
                }

            #build an object Parameter
            result_parameters[name] = my_object_values


    def load(self, settings):
        dirs = split(settings.headerGet("/settings/data/@path"))
        self.infos = {}
        for (sex, path) in sex2path.iteritems():
            path = path + "/cal3d.xfg"
            config = Config(dirs)
            config.load(path)
            #
            # Parameters map
            #
            parameters = {}
            self.loadParameters(config, parameters)

            #
            # Slot type to slot parameters map
            #
            type2uislots = {}
            uislot2index = {}
            for uislots_xml in config.header.xpathEval("/cal3d/uislots"):
                property = uislots_xml.properties
                slot_type = None
                while property != None:
                    if property.name == "type":
                        slot_type = property.content
                    property = property.next
                
                uislots = {}
                config.header.setContextNode(uislots_xml)
                for uislot_xml in config.header.xpathEval("uislot"):
                    property = uislot_xml.properties
                    name = None
                    while property != None:
                        if property.name == "name":
                            name = property.content
                        property = property.next
                    if not uislot2index.has_key(name):
                        uislot2index[name] = len(uislot2index)
                    config.header.setContextNode(uislot_xml)
                    parameter_list = []
                    parameter_names = []
                    parameter_masks = []
##                     for parameter in config.headerGetList("child::*/child::*/@adjust_id"):
##                         if parameter != "":
##                             parameter_list.extend(parameters[parameter]['ordered'])
##                             for entry in range( len(parameters[parameter]['ordered']) ):
##                                 parameter_names.append(parameter)

                    for parameter_node in config.header.xpathEval("texture/layer"):
                        # get adjust_id and mask
                        property = parameter_node.properties
                        parameter_adjustid = ""
                        parameter_mask = None
                        while property != None:
                            if property.name == "adjust_id":
                                parameter_adjustid = property.content
                            elif property.name == "mask":
                                parameter_mask = property.content
                            property = property.next

                        if parameter_adjustid != "":
                            parameter_list.extend(parameters[parameter_adjustid])
#before                            parameter_list.extend(parameters[parameter_adjustid]['ordered'])
                            mask = []
                            if parameter_mask != None and parameter_mask != "":
                                mask = split(parameter_mask, ' ')
                                mask = map(int,mask)
#before                            for entry in range( len(parameters[parameter_adjustid]['ordered']) ):
                            for entry in range( len(parameters[parameter_adjustid]) ):
                                parameter_masks.append(mask)
                                parameter_names.append(parameter_adjustid)

                    uislots[name] = {
                        'DEFINITIONS': parameter_list,
                        'PARAMETERS': parameter_names,
                        'MASK': parameter_masks
                        }

                if slot_type == "accessory":
                    type2uislots["accessory1"] = uislots
                    type2uislots["accessory2"] = uislots
                    type2uislots["accessory3"] = uislots
                else:
                    type2uislots[slot_type] = uislots

            #
            # Slot priority
            #
            priority2slottype = []
            for uislot_xml in config.header.xpathEval("/cal3d/outfit/uislot"):
                uislot_properties = config.headerNodeProperties(uislot_xml)
                slot_priority = int(uislot_properties['priority'])
                slot_type = uislot_properties['type']
                priority2slottype.append( (slot_priority,slot_type) )
            priority2slottype.sort()
            priority2slottype.reverse()
            index = 1
            for i in range(len(priority2slottype)):
                if priority2slottype[i][1] == 'accessory':
                    priority2slottype[i] = (priority2slottype[i][0],'accessory'+str(index))
                    index = index + 1


            #
            # Incompatibilities
            #
            uislot_count = len(uislot2index)
            incompatibilities_installed = [0] * uislot_count
            incompatibilities = [[0] * uislot_count] * uislot_count
            #
            # Each uislot is incompatible with itself
            #
            for i in xrange(uislot_count):
                incompatibilities[i] = [0] * uislot_count
                incompatibilities[i][i] = 1

            # type none is an exception
            none_type = uislot2index.get("none")
            incompatibilities[none_type][none_type] = 0
            #
            # Load the incompatibility map
            #
            for item_xml in config.header.xpathEval("/cal3d/incompatibility/item"):
                item_properties = config.headerNodeProperties(item_xml)
                index1 = uislot2index.get(item_properties['name1'], -1)
                if index1 < 0:
                    print "*CRITICAL* incompatibility item " + item_properties['name1'] + " does not match any uislot"
                    continue
                index2 = uislot2index.get(item_properties['name2'], -1)
                if index2 < 0:
                    print "*CRITICAL* incompatibility item " + item_properties['name2'] + " does not match any uislot"
                    continue
                incompatibilities[index1][index2] = 1
                incompatibilities[index2][index1] = 1

            self.infos[sex] = {
                'switchslot': switchslotexclusif[sex],
                'priority2slottype': priority2slottype,
                'config': config,
                'parameters': parameters,
                'type2uislots': type2uislots,
                'uislot2index': uislot2index,
                'incompatibilities': incompatibilities,
                'incompatibilities_installed': incompatibilities_installed,
                'version': config.headerGet("/cal3d/@version"),
                }

            self.infos[sex]['referenced_params']={}
            self.infos[sex]['outfit'] = self.loadOutfit(self.infos[sex], sex, config, "/cal3d")


    def incompatibilitiesUpdate(self, uislot, incompatibilities, incompatibilities_installed, uislot2index, operator):
        incompatibilities = incompatibilities[uislot2index[uislot]]
        for i in xrange(len(incompatibilities)):
            incompatibilities_installed[i] = operator(incompatibilities_installed[i], incompatibilities[i])

    def incompatibilitiesRemove(self, uislot, incompatibilities, incompatibilities_installed, uislot2index):
        self.incompatibilitiesUpdate(uislot, incompatibilities, incompatibilities_installed, uislot2index, sub)
        
    def incompatibilitiesAdd(self, uislot, incompatibilities, incompatibilities_installed, uislot2index):
        self.incompatibilitiesUpdate(uislot, incompatibilities, incompatibilities_installed, uislot2index, add)
        
    def incompatibilitiesFilter(self, uislots, incompatibilities, uislot2index, keyinuse):
        zipped = []
        for (key, value) in uislots.iteritems() :
            if incompatibilities[uislot2index[key]] == 0 or key == keyinuse:
                zipped.append((key, value))
        return dict(zipped)

    def buildPrioritySlotTypeFromExcludeSlot(self, slot_type, priority2slottype, excludemap):
        result = priority2slottype[:]
        if not excludemap.has_key(slot_type):
            return []
        
        for i in excludemap[slot_type]:
            toremove = filter(lambda p: p[1] == i , result)
            for p in toremove:
                result.remove(p)
        return result


    def getSlotsForSwitchSlotType(self, infos, uislot_type, incompatibilities_installed):
        slot = infos['outfit'][uislot_type]['NAME']
        # get list of item i can select
        uislots = self.incompatibilitiesFilter(infos['type2uislots'][uislot_type], incompatibilities_installed, infos['uislot2index'],"")
        del uislots['none']
        return uislots

        
    def makeOutfitItem(self, sex, uislot_type, uislots, uislot_key):
        value = uislots.keys().index(uislot_key)
        definitions = {}
        values = {}
        for i in xrange(len(uislots[uislot_key]['DEFINITIONS'])):
            definition = uislots[uislot_key]['DEFINITIONS'][i]
            parameter = uislots[uislot_key]['PARAMETERS'][i]
            xpath = parameter + "/" + definition.getParameterName()
#before            xpath = parameter + "/" + definition['name']
            definitions[xpath] = definition

            value = {
                'parameter': parameter,
                'name': definition.getParameterName(),
                'value': definition.getDefaultValue()
                }

            # hack again
            if parameter == 'global_skin_hue' and uislot_type != 'head':
                value = self.getReferencedParams(sex)[xpath]
                
            values[xpath] = self.getOrInsertReferencedParams(sex,xpath,value)

        item = {
            'DEFINITIONS': definitions,
            'VALUES': values,
            'NAME': uislot_key
            }
        return item


    def manageSwitchSlotType(self, sex, slot_typeto_test, infos, incompatibilities_installed, uislot_type2update):

        outfit = infos['outfit']

        if outfit[slot_typeto_test]['NAME'] == 'none':
            slots = self.getSlotsForSwitchSlotType(infos, slot_typeto_test, incompatibilities_installed)
            if len(slots) != 0: # there is a slot that could fit in this slot_type
                slot_key = choice(slots.keys())
                slotfound = self.makeOutfitItem(sex,slot_typeto_test, slots, slot_key)
                outfit[slot_typeto_test] = slotfound
                uislot_type2update.append(slot_typeto_test)
        exclude_list = infos['switchslot'][slot_typeto_test]

        # assign none to switch slot excluded.
        for exclude in exclude_list:
            if outfit[exclude]['NAME'] != 'none':
                outfit[exclude]['NAME'] = 'none'
                uislot_type2update.append(exclude)
        


    def manageSwitchType(self, sex, uislot_type, infos, incompatibilities_installed, uislot_type2update):
        switchslot = infos['switchslot']
        if switchslot.has_key(uislot_type):
            self.manageSwitchSlotType(sex,uislot_type,infos,incompatibilities_installed,uislot_type2update)
            return True
        return False
        

    def computeHierarchicalIncompatibilities(self, sex, outfit, priority2slottype, uislot_type_request):
        infos = self.getInfos(sex)
        incompatibilities_installed = [0] * len(infos['incompatibilities_installed'])
        uislot_valide = {}
        slot_to_update = []
        priority_table = priority2slottype
        for i in priority_table:
            uislots = {}
            uislot_type = i[1]

            has_switch = self.manageSwitchType(sex,uislot_type,infos,incompatibilities_installed,slot_to_update)
            slot = outfit[uislot_type]['NAME']

            # get list of item i can select
            if has_switch is True:
                uislots = self.getSlotsForSwitchSlotType(infos,uislot_type,incompatibilities_installed)
            else:
                uislots = self.incompatibilitiesFilter(infos['type2uislots'][uislot_type], incompatibilities_installed, infos['uislot2index'],"")

                
#            if not uislots.has_key(slot) and has_switch == False:
            if not uislots.has_key(slot):
                # we prefer none as replacement, it's due to the nature of dual set/remove that can be a problem for accessory
                if uislots.has_key('none'):
                    slot = 'none'
                else:
                    slot = choice (uislots.keys())
                item_outfit = self.makeOutfitItem(sex,uislot_type,uislots,slot)
                outfit[uislot_type] = item_outfit
                slot_to_update.append(uislot_type)
                
            if uislot_type == uislot_type_request:
                uislot_valide = uislots

            self.incompatibilitiesAdd(outfit[uislot_type]['NAME'], infos['incompatibilities'], incompatibilities_installed, infos['uislot2index'])

        #self.slot_to_update = slot_to_update
        return (uislot_valide, slot_to_update)

    def getParameterMask(self, outfit, type2slots, slot_name, slot_type, param_name):
        # here it's a hack because we can't manage actually a mask for global parameters used by more than one uislot
        # typically for the global_skin_hue
        if slot_type != 'head' and param_name == 'global_skin_hue':
            uislots = type2slots['head']
            slot_name_head = outfit['head']['NAME']
            uislot = uislots[slot_name_head]
            index = uislot['PARAMETERS'].index('global_skin_hue')
            mask = uislot['MASK'][index]
        else:
            uislots = type2slots[slot_type]
            uislot = uislots[slot_name]
            index = uislot['PARAMETERS'].index(param_name)
            mask = uislot['MASK'][index]
        return mask
            
    def useParameterMask(self, type2slot, outfit, slot_type):
        uislots = type2slot[slot_type]
        slot_name = outfit[slot_type]['NAME']
        uislot = uislots[slot_name]
        x = copy.deepcopy(outfit[slot_type])

        key_to_remove = []

        for key in x['VALUES'].keys():
            param_name = x['VALUES'][key]['parameter']
            index = uislot['PARAMETERS'].index(param_name)
            param = uislot['PARAMETERS'][index]

            # check if the parameter can be editable in this slot type
            if x['DEFINITIONS'][key].isVisibleForSlottype(slot_type) == False:
                key_to_remove.append(key)
                continue
            
            mask = self.getParameterMask(outfit, type2slot, slot_name, slot_type, param_name)
            if len(mask) == 0:
                continue
            current_ids = x['DEFINITIONS'][key].getEntries()
            current_preview = x['DEFINITIONS'][key].getPreview()
            new_ids = []
            new_preview = []
            for i in range(len(current_ids)):
                if int(current_ids[i]) in mask:
                    new_ids.append(current_ids[i])
                    new_preview.append(current_preview[i])
            x['DEFINITIONS'][key].setEntries(new_ids)
            x['DEFINITIONS'][key].setPreview(new_preview)

        for key in key_to_remove:
            param_name = x['VALUES'][key]['parameter']
            index = uislot['PARAMETERS'].index(param_name)
            param = uislot['PARAMETERS'][index]
            del x['DEFINITIONS'][key]
            del x['VALUES'][key]

        return x
        

class PokerOutfitEditor:

    def __init__(self, poker_outfit):
        self.sex = None
        self.uislot_type = None
        self.interface = None
        self.poker_outfit = poker_outfit
        self.slot_to_update = []
        self.uislots_valide = {}
        self.priority2slottype = []
        
    def destroy(self):
        if hasattr(self, "display"):
            self.display.destroy()

    def setInterface(self, interface, display):
        self.interface = interface
        interface = self.interface
        if not interface:
            print "Cannot select outfit, no interface"
            return False
        interface.registerHandler(pokerinterface.INTERFACE_OUTFITS_SEX, self.selectSex)
        interface.registerHandler(pokerinterface.INTERFACE_OUTFITS_SLOT_TYPE, self.selectSlotType)
        interface.registerHandler(pokerinterface.INTERFACE_OUTFITS_SLOT, self.selectSlot)
        interface.registerHandler(pokerinterface.INTERFACE_OUTFITS_PARAMETER, self.selectParameter)
        interface.registerHandler(pokerinterface.INTERFACE_OUTFITS_RANDOM, self.selectRandom)
        interface.registerHandler(pokerinterface.INTERFACE_OUTFITS, self.selectOutfit)
        interface.registerHandler(pokerinterface.INTERFACE_SHOW_OUTFITS, self.showOutfits)
        self.display = Outfit(display.underware)

    def hideOutfits(self):
        self.display.hide()
        self.interface.hideOutfits()

    def showOutfits(self, path, end_callback):
        self.end_callback = end_callback
        self.uislot_type = 'head'
        self.display.show()
        self.selectSex(path2sex[path])
        #reactor.callLater(0.01, lambda: self.poker_outfit.installOutfit(self.display, self.poker_outfit.getInfos(self.sex)['outfit'],self.sex))
        self.installOutfitAndUpdateInterface()

    def selectSex(self, sex):
        self.sex = sex
        #self.priority2slottype = self.poker_outfit.getInfos(sex)['priority2slottype']

        # update priority table from outfit
        infos = self.poker_outfit.getInfos(sex)
        priority2slottype = infos['priority2slottype']
        for uislot_type in infos['outfit'].keys():
            slot = infos['outfit'][uislot_type]
            # print uislot_type
            if slot['NAME'] != 'none':
                priority2slottype_result = self.poker_outfit.buildPrioritySlotTypeFromExcludeSlot(uislot_type,priority2slottype,infos['switchslot'])
                if len(priority2slottype_result) != 0:
                    priority2slottype = priority2slottype_result
            # print priority2slottype
        self.priority2slottype = priority2slottype
        
        self.display.setSex(sex)
        self.installOutfitAndUpdateInterface()
        self.selectSlotType("outfit1", "on")


    def selectSlotType(self, index, onoff):
        if onoff == "on":
            self.uislot_type = index2slot[self.sex][index]

            infos = self.poker_outfit.getInfos(self.sex)
            switchslot = infos['switchslot']
            # rebuild a priority list to handle slot_type that can be switched
            # so if a slot_type is a switch and is selected, then we rebuild the priority list without others
            candidate = self.poker_outfit.buildPrioritySlotTypeFromExcludeSlot(self.uislot_type,infos['priority2slottype'],switchslot)
            if len(candidate) != 0:
                self.priority2slottype = candidate

            (self.uislots_valide,self.slot_to_update) = self.poker_outfit.computeHierarchicalIncompatibilities(self.sex,infos['outfit'],self.priority2slottype,self.uislot_type)
            self.updateInterface()


    def selectSlot(self, value):
        infos = self.poker_outfit.getInfos(self.sex)
        uislots = self.uislots_valide
        uislot_key = uislots.keys()[value]

        definitions = {}
        values = {}
        for i in xrange(len(uislots[uislot_key]['DEFINITIONS'])):
            definition = uislots[uislot_key]['DEFINITIONS'][i]
            parameter = uislots[uislot_key]['PARAMETERS'][i]
            xpath = parameter + "/" + definition.getParameterName()
#before            xpath = parameter + "/" + definition['name']
            definitions[xpath] = definition

            # hack
            val = definition.getDefaultValue()
            if xpath in self.poker_outfit.getReferencedParams(self.sex):
                val = self.poker_outfit.getReferencedParams(self.sex)[xpath]['value']

            value = {
                'parameter': parameter,
                'name': definition.getParameterName(),
                'value': val
                }
            if self.uislot_type != 'head' and parameter == 'global_skin_hue':
                value = self.poker_outfit.getReferencedParams(self.sex)[xpath]
                values[xpath] = value
            else:
                values[xpath] = self.poker_outfit.getOrInsertReferencedParams(self.sex,xpath,value)
            
        outfit = infos['outfit']
        outfit[self.uislot_type] = {
            'DEFINITIONS': definitions,
            'VALUES': values,
            'NAME': uislot_key
            }

        unused = None
        (unused,self.slot_to_update) = self.poker_outfit.computeHierarchicalIncompatibilities(self.sex,outfit,self.priority2slottype,"")

        # here we append the new slot to update at the end list
        # it's very important to put this item at the end of list
        # update the current slot at the end
        self.slot_to_update.append(self.uislot_type)
        #(slot_type, index) = slot2slotindex[self.uislot_type]
        #self.display.setSlot(slot_type, uislot_key, index)

        #for (xpath, value) in values.iteritems():
        #    ( parameter, name ) = split(xpath, '/')
        #    self.display.setParam(parameter,name, int(value['value']))

        self.updateInterface()


    def selectParameter(self, xpath, value):
        infos = self.poker_outfit.getInfos(self.sex)
        outfit = infos['outfit'][self.uislot_type]
        ( parameter, name ) = split(xpath, '/')

        uislots = infos['type2uislots'][self.uislot_type]
        slot_name = infos['outfit'][self.uislot_type]['NAME']
        uislot = uislots[slot_name]

        x = infos['outfit'][self.uislot_type]
        param_name = x['VALUES'][xpath]['parameter']
        index = uislot['PARAMETERS'].index(param_name)
        mask = uislot['MASK'][index]

        if len(mask) != 0:
            value = str(mask[int(value)])
        else:
            definition = outfit['DEFINITIONS'][xpath]
#before            value = definition['ids'][int(value)]
            value = definition.getEntries()[int(value)]
        value_map = outfit['VALUES'][xpath]
        value_map['value'] = value

        self.display.setParam(parameter, name, int(value))
        self.updateInterface()
    
    def selectRandom(self):
        infos = self.poker_outfit.getInfos(self.sex)
        infos['outfit'] = self.poker_outfit.randomOutfit(self.sex)
        #pprint(infos['outfit'])
        self.installOutfitAndUpdateInterface()
        #self.poker_outfit.installOutfit(self.display, infos['outfit'],self.sex)

    def updateInterface(self):
        infos = self.poker_outfit.getInfos(self.sex)
        outfit = infos['outfit']
        slotSortedFromNoneToUnnone = []

        for uislot_type in self.slot_to_update:
            ( slot_type, index ) = slot2slotindex[uislot_type]
            if outfit[uislot_type]['NAME'] == "none":
                slotSortedFromNoneToUnnone.insert(0,uislot_type)
            else:
                slotSortedFromNoneToUnnone.append(uislot_type)
        self.slot_to_update = slotSortedFromNoneToUnnone
        
        for uislot_type in self.slot_to_update:
            ( slot_type, index ) = slot2slotindex[uislot_type]
            self.display.setSlot(slot_type, outfit[uislot_type]['NAME'], index)
            print "updateInterface setSlot %s - %s" % (slot_type,outfit[uislot_type]['NAME'])

        for uislot_type in  self.slot_to_update:
            ( slot_type, index ) = slot2slotindex[uislot_type]
            for value in outfit[uislot_type]['VALUES'].values():
                self.display.setParam(value['parameter'], value['name'], int(value['value']))
                print "updateInterface setParam %s - %s - %s" % (value['parameter'],value['name'],value['value'])

        # here we filter parameter to handle mask feature, there is the inverse process when we receive parameter from interface
        # see selectParamater
        print "slottype %s currentvalue %s from %s" % (self.uislot_type, infos['outfit'][self.uislot_type]['NAME'], self.uislots_valide.keys())

        # here parameter is a duplcated data so we can use it without risk
        parameter_filtered = self.poker_outfit.useParameterMask(infos['type2uislots'],infos['outfit'],self.uislot_type)
        
        # check that value are correctly masked
        for (xpath, value) in parameter_filtered['VALUES'].iteritems():
            definition = parameter_filtered['DEFINITIONS'][xpath]
            entries = definition.getEntries()
            if value['value'] not in entries:
                print "WARNING Changing default value for %s because the default value is masked" % value['parameter']
                value['value'] = entries[0]
                self.poker_outfit.getOrInsertReferencedParams(self.sex,xpath,value)
                self.display.setParam(value['parameter'], value['name'], int(value['value']))
        
        self.interface.showOutfits(self.sex, slot2index[self.uislot_type], self.uislot_type, self.uislots_valide, parameter_filtered) #infos['outfit'][self.uislot_type]

    def selectOutfit(self, what):
        self.display.hide()
        self.end_callback(sex2path[self.sex], self.poker_outfit.outfitAsString(self.sex))

    def installOutfitAndUpdateInterface(self):
        infos = self.poker_outfit.getInfos(self.sex)
        self.poker_outfit.installOutfit(self.display, infos['outfit'],self.sex)
        self.selectSlotType("outfit1","on")

if __name__ == "__main__":

    import getopt
    
    def usage():
        print """
    pokeroutfit.py [--help] [--random=<count> [--sex={male,female}]] settings.xml 
    """

    def main():
        try:
            opts, args = getopt.getopt(sys.argv[1:], "hrs", ["help", "random=", "sex=" ])
        except getopt.GetoptError:
            usage()
            sys.exit(1)
        random = 0
        sex = 'male'
        for o, a in opts:
            if o in ("-h", "--help"):
                usage()
                sys.exit(0)
            if o in ("-r", "--random"):
                random = int(a)
            if o in ("-s", "--sex"):
                sex = a

        if len(args) != 1:
            print "missing settings.xml"
            usage()
            sys.exit(2)
            
        settings = Config([''])
        settings.load(args[0])

        outfit_info = PokerOutfit(settings)
        
        if random > 0:
            for x in xrange(random):
                outfit = outfit_info.randomOutfitAsString(sex)
                f = file("outfit%03d.xfg" % x, "w")
                f.write(outfit)
                f.close()
        else:
            print "specify --random=<count>"
            usage()
            sys.exit(3)

        return 0

    main()

#
# Local variables:
# compile-command: "../../underware pokeroutfit.py --random 30 --sex male ~/.poker3d/conf/client/mekensleep.xml"
# End:
#
