/*
 * * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *  Loic Dachary <loic@gnu.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 *  Igor Kravtchenko <igor@tsarevitch.org>
 */

#include "pokerStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */

#ifndef POKER_USE_VS_PCH

#ifdef USE_NPROFILE
#include <nprofile/profile.h>
#else  //USE_NPROFILE
#define NPROFILE_SAMPLE(a)
#endif //USE_NPROFILE

#include <sstream>
#include <iomanip>
#include <map>

#include <osg/Depth>
#include <osg/Geode>
#include <osg/FragmentProgram>
#include <osg/Material>
#include <osg/MatrixTransform>
#include <osg/NodeVisitor>
#include <osg/Shape>
#include <osg/ShapeDrawable>
#include <osg/Stencil>
#include <osg/VertexProgram>
#include <osg/BlendFunc>
#include <osgUtil/IntersectVisitor>

#include <maf/utils.h>
#include <maf/packets.h>
#include <maf/shadow.h>
#include <maf/assert.h>
#include <maf/renderbin.h>

#include <varseditor/varseditor.h>

#include <PokerSceneView.h>
#include <PokerSeat.h>
#include <PokerApplication.h>
#include <maf/interpolator.h>
#include <PokerError.h>
#endif

#ifdef WIN32
#define snprintf _snprintf
#endif

static void Plop()
{
  ;
}

//model
PokerSeatModel::PokerSeatModel() : mId(0), mFree(true), mArrowPAT(0)
{
}

PokerSeatModel::~PokerSeatModel()
{
  g_debug("PokerSeatModel::~PokerSeatModel()");
}

void PokerSeatModel::Init()
{
  UGAMEArtefactModel::Init();

  GetNode()->setName("PokerSeat");
  mArrowPAT = new osg::PositionAttitudeTransform;
  mScaleInterpolator.Init(osg::Vec3(1.0f, 1.0f, 1.0f), osg::Vec3(2.0f, 2.0f, 2.0f));
  mTimer.Init(0.5f);
}


class DisableVisitor : public osg::NodeVisitor {
public:
  DisableVisitor() : osg::NodeVisitor(osg::NodeVisitor::TRAVERSE_ALL_CHILDREN) {
  }
  virtual void apply(osg::Geode& geode) {
    geode.setNodeMask(0);
  }
};

class EnableVisitor : public osg::NodeVisitor {
public:
  EnableVisitor() : osg::NodeVisitor(osg::NodeVisitor::TRAVERSE_ALL_CHILDREN) {
  }
  virtual void apply(osg::Geode& geode) {
    geode.setNodeMask(MAF_VISIBLE_MASK | MAF_COLLISION_MASK);
  }
};

struct CloneAnchorNodePath
{
  static osg::Node *doit(osg::Node *anchor, osg::Node *child)
  {
    osg::MatrixTransform *t = new osg::MatrixTransform;
    osg::NodePath path;
    osg::Node* node = anchor;
    while(node) {
      path.push_back(node);
      if(node->getNumParents() >= 1) {
        if(node->getNumParents() > 1)
          g_critical("more than one parent");
        node = node->getParent(0);
      } else {
        node = 0;
      }
    }
    std::reverse(path.begin(), path.end());  
    t->setMatrix(osg::computeLocalToWorld(path));
    t->addChild(child);
    return t;
  }
};

struct BoxCreate
{
  static osg::Node *doit()
  {
    osg::Geode* d=new osg::Geode;
    osg::Box* dbox=new osg::Box(osg::Vec3(0,0,0),10.f);
    osg::ShapeDrawable* bd=new osg::ShapeDrawable(dbox);
    d->addDrawable(bd);
    return d;
  }
};


class KillAllGeode : public osg::NodeVisitor {
public:
  KillAllGeode() : osg::NodeVisitor(osg::NodeVisitor::TRAVERSE_ALL_CHILDREN) {
  }

  virtual void apply(osg::Geode& geode) {
    geode.setNodeMask(0x0);
  }
};

//controller
PokerSeatController::PokerSeatController(unsigned int id):PokerSelectableController(id)
{
  SetModel(new PokerSeatModel());
}

PokerSeatController::~PokerSeatController()
{
	PokerSceneView *instance = PokerSceneView::getInstance();
	if (instance) {
		osg::Geode *geode = GetGeode( GetModel()->mArrowPAT.get() );
		int nbDrawables = geode->getNumDrawables();
		for (int i = 0; i < nbDrawables; i++) {
			osg::Drawable *drawable = geode->getDrawable(i);
			instance->removeDrawableThatStayInColor(drawable);
		}
	}

  Anchor(0);

  GetModel()->mArrowPAT = 0;
  GetModel()->mSeatGeode=0;

	m_chairShadowMatrix = NULL;

  RecursiveClearUserData(GetModel()->GetNode());

  g_debug("PokerSeatController::~PokerSeatController");
	GetModel()->SetArtefact(0);
	osg::NodeVisitor* leakNodes = RecursiveLeakCollect(GetModel()->GetNode());
	RecursiveLeakCheck(leakNodes);
}

void PokerSeatController::Init(int id, PokerApplication *game)
{
  PokerSelectableController::Init(game);
  
  PokerSeatModel *model = GetModel();
  model->mId = id;  

  unsigned int copyop=osg::CopyOp::DEEP_COPY_OBJECTS | osg::CopyOp::DEEP_COPY_NODES | osg::CopyOp::DEEP_COPY_DRAWABLES | osg::CopyOp::DEEP_COPY_STATESETS;

  //
  // Set the artefact : Artefact()
  //
  Plop();
  {
    const std::string &url = game->HeaderGet("sequence", "/sequence/seat/@url");
    MAFOSGData *data = static_cast<MAFOSGData *>(game->mDatas->GetVision(url)->Clone(copyop));
    osg::Group* group = data->GetGroup();
    KillAllGeode visitor;
    group->accept(visitor);
    model->SetArtefact(group);
    delete data;
  }

  //
  // Grab a seat in the scene : Anchor()
  //
  {

    const std::string &anchorName = game->HeaderGet("sequence", "/sequence/seat/@anchor");
    char oss[64];
    snprintf(oss, 64, anchorName.c_str(), id + 1);
    MAFAnchor *anchor = game->mSetData->GetAnchor(oss);
    g_assert(anchor != 0);
    Anchor(anchor);
  }

  //
  // Figure out where the arrow should be placed in the artefact
  //
  osg::PositionAttitudeTransform *arrowPAT;
  {
    const std::string &url = game->HeaderGet("sequence", "/sequence/seat/arrow/@anchor");
    osg::Group *anchor = dynamic_cast<osg::Group*>(GetNode(model->GetArtefact(), url));
    g_assert(anchor != 0);
    arrowPAT = model->mArrowPAT.get();
    arrowPAT->setName("ArrowPAT");
    anchor->addChild(arrowPAT);
  }

  //
  // This controller reacts to events occuring on the arrow
  //
  BindToNode(arrowPAT);

  //
  // Add the arrow object in the artefact
  //
  {
    const std::string &url = game->HeaderGet("sequence", "/sequence/seat/arrow/@url");
    MAFOSGData *data_original=static_cast<MAFOSGData *>(game->mDatas->GetVision(url));
    if (!data_original)
      g_error("PokerSeatController::Init %s not found",url.c_str());
    MAFOSGData *data = static_cast<MAFOSGData *>(data_original->Clone(copyop));
    osg::Group *group = data->GetGroup();
    g_assert(group != 0);
    arrowPAT->addChild(group);

		PokerSceneView *instance = PokerSceneView::getInstance();
		if (instance) {
			osg::Geode *geode = GetGeode(group);

			// add collision from root to geode
			osg::NodePath pathToAddCollisionMask;
			MAFCreateNodePath(geode,pathToAddCollisionMask);
			for (osg::NodePath::iterator it = pathToAddCollisionMask.begin(); it != pathToAddCollisionMask.end(); it++) {
				unsigned int mask = (*it)->getNodeMask();
				mask =  mask | MAF_COLLISION_MASK;
				(*it)->setNodeMask(mask);
			}


			int arrowRenderBinBeforeHelpMode;
			if (!MAFRenderBin::Instance().GetRenderBinIndexOfEntity("SeatArrow", arrowRenderBinBeforeHelpMode))
				MAF_ASSERT(0 && "SeatArrow not found in client.xml");
	//		{
		//		if (!VarsEditor::Instance().Get("RB_SeatArrow",arrowRenderBinBeforeHelpMode))
			//		MAF_ASSERT(0 && "RB_SeatArrow not found in client.xml");
//			}
			int arrowRenderBinValueInHelpMode;
		//	{
			//	if (!VarsEditor::Instance().Get("RB_SeatArrowInHelpMode",arrowRenderBinValueInHelpMode))6
				//	MAF_ASSERT(0 && "RB_SeatArrowInHelpMode not found in client.xml");
			//}
			if (!MAFRenderBin::Instance().GetRenderBinIndexOfEntity("SeatArrowInHelpMode", arrowRenderBinValueInHelpMode))
				MAF_ASSERT(0 && "SeatArrowInHelpMode not found in client.xml");

			int nbDrawables = geode->getNumDrawables();
			for (int i = 0; i < nbDrawables; i++) {
				osg::Drawable *drawable = geode->getDrawable(i);
				instance->addDrawableThatStayInColor(drawable, arrowRenderBinBeforeHelpMode, arrowRenderBinValueInHelpMode, "RenderBin", 0);
			}
		}

    delete data;
  }

  //
  // Add the chair in the artefact
  //
  {
    const std::string &url = game->HeaderGet("sequence", "/sequence/seat/chair/@url");
    const std::string &anchor = game->HeaderGet("sequence", "/sequence/seat/chair/@anchor");
    MAFOSGData *data = static_cast<MAFOSGData *>(game->mDatas->GetVision(url)->Clone(copyop));
    g_assert(data != 0);
    osg::Group* group = dynamic_cast<osg::Group*>(GetNode(GetModel()->GetArtefact(), anchor));
		m_chairGroup = group;
    g_assert(group != 0);
    group->addChild(data->GetGroup());
    delete data;
    //
    // Keep this pointer to set transparency
    //
    GetModel()->mSeatGeode = dynamic_cast<osg::Geode*>(GetGeode(group));
    g_assert(GetModel()->mSeatGeode.valid());

    const std::string &shadow = game->HeaderGet("settings", "/settings/shadow");
    if (shadow == "on" || shadow == "yes") {

      osg::Group *setData	=	game->mSetData->GetGroup();

      osg::MatrixTransform *shad = (osg::MatrixTransform*) group;

      osg::MatrixTransform *mt = new osg::MatrixTransform();
      m_chairShadowMatrix = mt;

      osg::Matrix	mat	=	MAFComputeLocalToWorld(group);

      //osg::Matrix	shadowMatrix = MAFBuildShadowMatrix(osg::Plane(0,	1, 0,	-80),	osg::Vec4f(to.x(), to.y(), to.z(), 0)	);
      osg::Matrix	shadowMatrix = MAFBuildShadowMatrix(osg::Plane(0,	1, 0,	0),	osg::Vec4f(0,	650, 0,	1) );
      mt->setMatrix( mat * shadowMatrix	);
      setData->addChild(mt);

      osg::Depth *dp = new osg::Depth();
      dp->setWriteMask(FALSE);
      mt->getOrCreateStateSet()->setAttributeAndModes(dp,	osg::StateAttribute::OVERRIDE);
//			{
	//			int rbvalue;
		//		if (!VarsEditor::Instance().Get("RB_ChairShadow",rbvalue))
			//		MAF_ASSERT(0 && "RB_ChairShadow not found in client.xml");
				//mt->getOrCreateStateSet()->setRenderBinDetails(rbvalue,	"RenderBin");
			//}
			if (!MAFRenderBin::Instance().SetupRenderBin("ChairShadow", mt->getOrCreateStateSet()))
					MAF_ASSERT(0 && "ChairShadow not found in client.xml");
				
      mt->setNodeMask(MAF_VISIBLE_MASK);

			float shadowFactor = mGame->GetPoker()->GetShadowFactorForCurrentLevel("ground");

      osg::Material* material	=	new	osg::Material;
      material->setAmbient(osg::Material::FRONT_AND_BACK,	osg::Vec4(0.0f,	0.0f,	0.0f,	0.0f));
      material->setDiffuse(osg::Material::FRONT_AND_BACK,	osg::Vec4(0.0f,	0.0f,	0.0f,	0.0f));
      material->setEmission(osg::Material::FRONT_AND_BACK, osg::Vec4(shadowFactor, shadowFactor, shadowFactor, 0.0f));
      material->setShininess(osg::Material::FRONT_AND_BACK,	0.0f);
      mt->getOrCreateStateSet()->setAttribute(material,	osg::StateAttribute::OVERRIDE);

      mt->getOrCreateStateSet()->setTextureMode(0, GL_TEXTURE_2D,	osg::StateAttribute::OVERRIDE	|	osg::StateAttribute::OFF);
      mt->getOrCreateStateSet()->setTextureMode(1, GL_TEXTURE_2D,	osg::StateAttribute::OVERRIDE	|	osg::StateAttribute::OFF);
      mt->getOrCreateStateSet()->setTextureMode(2, GL_TEXTURE_2D,	osg::StateAttribute::OVERRIDE	|	osg::StateAttribute::OFF);

      mt->getOrCreateStateSet()->setMode(GL_VERTEX_PROGRAM_ARB,	osg::StateAttribute::OVERRIDE	|	osg::StateAttribute::OFF);
      mt->getOrCreateStateSet()->setMode(GL_FRAGMENT_PROGRAM_ARB,	osg::StateAttribute::OVERRIDE	|	osg::StateAttribute::OFF);

      osg::BlendFunc *blend	=	new	osg::BlendFunc;
      blend->setFunction(GL_DST_COLOR, GL_ZERO);
      mt->getOrCreateStateSet()->setAttributeAndModes(blend, osg::StateAttribute::OVERRIDE | osg::StateAttribute::ON);
      mt->getOrCreateStateSet()->setMode(GL_LIGHTING,	osg::StateAttribute::OVERRIDE	|	osg::StateAttribute::ON);

      osg::Stencil *stenc	=	new	osg::Stencil;
      stenc->setFunction(osg::Stencil::EQUAL,	0x2, 0xffffffff);
      stenc->setOperation(osg::Stencil::KEEP,	osg::Stencil::ZERO,	osg::Stencil::ZERO);
      mt->getOrCreateStateSet()->setAttributeAndModes(stenc);
      mt->getOrCreateStateSet()->setMode(GL_STENCIL_TEST,	TRUE);

      int	nbChilds = shad->getNumChildren();
      for	(int i = 0;	i	<	nbChilds;	i++) {
        osg::Node	*child = shad->getChild(i);
        mt->addChild(child);
      }
    }
  }
  
  Disable();
  DisableArrow();
  //chairNode->getOrCreateStateSet()->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
}

void PokerSeatController::Disable()
{
  GetModel()->GetArtefact()->setNodeMask(0);
  if (m_chairShadowMatrix.valid())
	  m_chairShadowMatrix->setNodeMask(0);
}

void PokerSeatController::DisableArrow()
{
	SetSelectable(false);
	GetModel()->mArrowPAT->setNodeMask(0);
}

void PokerSeatController::Enable()
{
  GetModel()->GetArtefact()->setNodeMask(MAF_VISIBLE_MASK | MAF_COLLISION_MASK);
  if (m_chairShadowMatrix.valid())
  	m_chairShadowMatrix->setNodeMask( MAF_VISIBLE_MASK );
}

void PokerSeatController::EnableArrow()
{
	SetSelectable(true);
	GetModel()->mArrowPAT->setNodeMask(MAF_VISIBLE_MASK | MAF_COLLISION_MASK);
}

bool PokerSeatController::Update(MAFApplication *game)
{
  NPROFILE_SAMPLE("PokerSeatController::Update");
  PokerSelectableController::Update(game);
  //UGAMEArtefactController::Update(game);
  
  if (game->HasEvent())
    return true;

  bool focused = (game->GetFocus() == this);
  float delta = GetDeltaFrame()/1000.f;
  delta = (focused ? delta : -delta);
  GetModel()->mTimer.AddTime(delta);
  osg::Vec3 scale;
  GetModel()->mTimer.Get(scale, GetModel()->mScaleInterpolator);
  GetModel()->mArrowPAT->setScale(scale);


  if (mSelected)
      {
	mSelected = false;
	GetModel()->SetSelected(false);
	GetModel()->mFree = !GetModel()->mFree;
	return false;
      }

//   if (GetSelected()) {
//     GetModel()->SetSelected(false);
//     GetModel()->mFree = !GetModel()->mFree;
//     return false;
//   }

  return true;
}

// manager

PokerSeatManager::PokerSeatManager(unsigned int id) : MAFController(id) , mMainPlayerStatus(MAINPLAYER_OUT), mSeatsCount(0), mCurrentTableSeats(0), mSeats(0), mMainPlayerSeat(-1)
{
}

PokerSeatManager::~PokerSeatManager()
{
  g_debug("PokerSeatManager::~PokerSeatManager");
  for (unsigned int i = 0; i < mSeats.size(); i++)
  {
    PokerSeatController &seat = *(mSeats[i]);
    RecursiveClearUserData(seat.GetModel()->GetNode());
    mSeats[i] = 0;
  }
  //RecursiveClearUserData(mDoor->GetModel()->mDoorCollNode.get());
  return;
}

void PokerSeatManager::Init(PokerApplication *game)
{
  MAFController::Init();
  const int defaultSeatCount = 10;
  mSeatsCount = defaultSeatCount;
  mCurrentTableSeats.resize(defaultSeatCount);
  mSeats.resize(defaultSeatCount);
  for (int seatId = 0; seatId < defaultSeatCount; seatId++)
    {
      mCurrentTableSeats[seatId] = false;
      PokerSeatController *seat = new PokerSeatController(GetID());
      seat->Init(seatId, game);
      mSeats[seatId] = seat;
    }
}

void PokerSeatManager::SetSeats(const std::vector<int> &currentTableSeats)
{
	mMainPlayerStatus = MAINPLAYER_OUT;
	for (unsigned int i = 0; i < mCurrentTableSeats.size(); i++)
	{
		if (mCurrentTableSeats[i])
			mSeats[i]->Disable();
		mCurrentTableSeats[i] = false;
	}
	for (unsigned int i = 0; i < currentTableSeats.size(); i++)
	{
		mCurrentTableSeats[currentTableSeats[i]] = true;
	}
	for (unsigned int seatId = 0; seatId < mSeatsCount; seatId++)
	{
		if (mCurrentTableSeats[seatId])
		{
			PokerSeatController &seat = *(mSeats[seatId]);
			seat.Enable();
			seat.EnableArrow();
		}
	}
}

void PokerSeatManager::DisableAllSeats()
{
	for (unsigned int i = 0; i < mSeatsCount; i++)
	{
		if (mCurrentTableSeats[i])
		{
			mSeats[i]->Disable();
			mSeats[i]->DisableArrow();
		}
	}
}

void PokerSeatManager::MainPlayerArrive(const std::vector<guint> &seat2serial)
{
	g_assert(mSeatsCount <= seat2serial.size()); 

	mMainPlayerStatus = PokerSeatManager::MAINPLAYER_SEAT_IN;
	for (unsigned int i = 0; i < mSeatsCount; i++)
	{
		if (!seat2serial[i])
			if (mCurrentTableSeats[i])
			{
				mSeats[i]->DisableArrow();
			}
	}
}

void PokerSeatManager::MainPlayerLeave(const std::vector<guint> &seat2serial)
{
	g_assert(mSeatsCount <= seat2serial.size()); 

	if (mMainPlayerStatus == PokerSeatManager::MAINPLAYER_OUT)
		return;

	mMainPlayerStatus = PokerSeatManager::MAINPLAYER_OUT;

	for (unsigned int i = 0; i < mSeatsCount; i++)
	{
		if (!seat2serial[i])
			if (mCurrentTableSeats[i])
			{
				mSeats[i]->EnableArrow();
				mSeats[i]->m_chairGroup->setNodeMask(MAF_VISIBLE_MASK);
			}
	}
}

void PokerSeatManager::PlayerLeave(unsigned int seat)
{
  if (mMainPlayerStatus == 0)
    mSeats[seat]->EnableArrow();
  if (mCurrentTableSeats[seat])
    mSeats[seat]->Enable();
}

void PokerSeatManager::MainPlayerSitOut()
{
	if (mMainPlayerSeat != -1) {
		PokerSeatController *seat = mSeats[mMainPlayerSeat].get();
		seat->Enable();
		seat->EnableArrow();
		seat->m_chairGroup->setNodeMask(0);
		seat->GetModel()->mTimer.mCurrent = 0;
		seat->GetModel()->mArrowPAT->setScale( osg::Vec3f(1, 1, 1) );
	}
	mMainPlayerStatus = PokerSeatManager::MAINPLAYER_SEAT_OUT;
}

void PokerSeatManager::MainPlayerSit()
{
	mSeats[mMainPlayerSeat]->DisableArrow();
	mMainPlayerStatus = PokerSeatManager::MAINPLAYER_SEAT_IN;
}

void PokerSeatManager::PlayerSeated(unsigned int seat)
{
  if (mMainPlayerStatus == 0)
		mSeats[seat]->DisableArrow();
  if (mCurrentTableSeats[seat])
		mSeats[seat]->Disable();
}

bool PokerSeatManager::Update(MAFApplication *game)
{
  unsigned int seatsCount = mSeatsCount;
  if (mMainPlayerStatus == 0 || mMainPlayerStatus == 2)
    {
      for (unsigned int seatId = 0; seatId < seatsCount; seatId++)
        {
          if (mCurrentTableSeats[seatId])
            {
              PokerSeatController &seat = *(mSeats[seatId]);
              if (!seat.DoUpdate(game))
                {
									if (mMainPlayerStatus == 0) {
										PokerModel *poker = static_cast<PokerApplication *>(game)->GetPoker()->GetModel();
										osg::ref_ptr<MAFPacket> packet;
										packet = game->GetPacketsModule()->Create("PacketPokerSeat");
										packet->SetMember("serial", poker->mMe);
										packet->SetMember("game_id", poker->mGameSerial);	  
										packet->SetMember("seat", seat.GetModel()->mId);
										game->PythonCall("getSeat", packet.get());
									}
									else {
							      game->PythonCall("clickSitOut");
									}
                }
            }
        }
    }
  return true;
}
