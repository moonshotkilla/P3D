/*
 *
 * Copyright (C) 2007 Loic Dachary <loic@dachary.org>
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Henry Pr�cheur <henry@precheur.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 *  Igor Kravtchenko <igor@obraz.net>
 *
 */

#ifndef poker_board_h
#define poker_board_h

#ifndef POKER_USE_VS_PCH
#include <map>
#include <vector>

#include <maf/model.h>
#include <maf/view.h>
#include <maf/controller.h>

#include <PokerSceneView.h>

#include <osg/Version>
#include <osg/Transform>
#include <osg/Timer>
#include <osg/AutoTransform>
#include <osg/ShapeDrawable>
#include <osg/TexMat>
#include <osg/TexEnvCombine>
#endif

class PokerApplication;

#include <PokerCard.h>

namespace osg { class Material; }

#define BOARD_BUFFER_ANGLE 50

template <class T> class PokerSampleValue
{
  T* mSamples;
  int mPreviousSample;
  float mDelay,mSampleRate;
  float mInternalTimer;
  int mSize;

 public:

  PokerSampleValue() : mSamples(0) , mPreviousSample(0), mDelay(0), mSampleRate(0) , mInternalTimer(0), mSize(0) {}
  ~PokerSampleValue() {
    delete [] mSamples;
  }

  void Init(int nbValue,const T& init) {
    mSize=nbValue;
    if (mSamples)
      delete [] mSamples;
    mSamples=new T[mSize];
    for (int i=0;i<mSize;i++)
      mSamples[i]=init;
  }

  void SetDelay(float t) { mDelay=t;}
  void SetSampleRate(float t) { mSampleRate=t;}
  float GetInternalTimer() const { return mInternalTimer;}
  void GetSample(T& result) const { GetSample(result,mDelay);}

  void GetSample(T& result,float delay) const {
    float v=mInternalTimer-delay;
    if (v<0)
      v=0;

    int res=(int)floor(v/mSampleRate);
    float frac=v/mSampleRate-res;
    res=res%BOARD_BUFFER_ANGLE;
    result=mSamples[res];
    result+=(mSamples[(res+1)%BOARD_BUFFER_ANGLE]-result)*frac;
  }

  void SetSample(T& sample) {
    int res=(int)floorf(mInternalTimer/mSampleRate);
//     printf("mInternalTimer %f - mSampleRate %f\n",mInternalTimer,mSampleRate);
    int start=(int)ceilf(mPreviousSample);
    if (start>res)
      res=start;
    for (int i=start;i<=res;i++)
      mSamples[i%BOARD_BUFFER_ANGLE]=sample;
    mPreviousSample=res;
  }

  void GetAverage(T& result) const {
    for (int i=0;i<mSize;i++)
      result+=mSamples[i];
    result/=(float)mSize;
  }
  void Update(float dt) { mInternalTimer+=dt;}
};

template <> class PokerSampleValue<osg::Quat>
{
  osg::Quat mSamples[BOARD_BUFFER_ANGLE];
  int mPreviousSample;
  float mDelay,mSampleRate;
  float mInternalTimer;

public:
  PokerSampleValue() : mPreviousSample(0), mDelay(0), mSampleRate(0) , mInternalTimer(0) {}

  void SetDelay(float t) { mDelay=t;}
  void SetSampleRate(float t) { mSampleRate=t;}

  void GetSample(osg::Quat& result) const {
    float v=mInternalTimer-mDelay;
    if (v<0)
      v=0;

    int res=(int)floor(v/mSampleRate);
    float frac=v/mSampleRate-res;
    res=res%BOARD_BUFFER_ANGLE;
//     result=mSamples[res];
//     result+=(mSamples[(res+1)%BOARD_BUFFER_ANGLE]-result)*frac;
    g_debug("get %d",res);
    result.slerp(frac,mSamples[res],mSamples[(res+1)%BOARD_BUFFER_ANGLE]);
  }
  void SetSample(osg::Quat& sample) {
    int res=(int)floorf(mInternalTimer/mSampleRate);
    int start=(int)ceilf(mPreviousSample);
    if (start>res)
      res=start;
    g_debug("set start %d end %d",start,res);
    for (int i=start;i<=res;i++)
      mSamples[i%BOARD_BUFFER_ANGLE]=sample;
    mPreviousSample=res;
  }

  void Update(float dt) { mInternalTimer+=dt;}
  
};


class PokerBoardController : public MAFController
{
	osg::ref_ptr<osg::MatrixTransform> mTransformProjector;
	osg::ref_ptr<osg::MatrixTransform> mCpath04_transform;
	osg::ref_ptr<osg::MatrixTransform> mCpath05_transform;

  osg::ref_ptr<osg::MatrixTransform> mBoardCenter;
  osg::ref_ptr<MAFBillBoard> mTextBillboard;
  osg::ref_ptr<osg::MatrixTransform> mTextAnchor;
  osg::Matrix mInitialMatrix;
  std::vector<osg::ref_ptr<osg::MatrixTransform> > mTransformCards;
  std::vector<osg::Matrix> mMatrixOriginal;
  std::vector<osg::ref_ptr<osg::MatrixTransform> > mTransformTransitions;
  std::vector<osg::ref_ptr<osg::MatrixTransform> > mTransformTransitionTranslations;
  std::vector<osg::ref_ptr<osg::MatrixTransform> > mTransformTransitionCards;

  PokerSampleValue<osg::Vec3> mSamples;

  float mParamAnimationDuration;
  float mTransitionTime;
  osg::Vec3 mTargetPos[5];

  bool mStartToDisplayHandValue;
  float mOffsetCard;
  float mParamYoffsetForText;
  float mScale;
  //float mParamYoffsetForCards;
  float mParamTextYTranslate;

  osg::Vec4 mParamShadeColorForCardUsed;

//   BezierInterpolator<float> mInterpolator;
//   void LoadKeys(std::vector<osg::Vec2> &keys, MAFXmlData *data, const std::string &name);
//   template<typename T> void LoadSpline(T &interpolator, MAFXmlData *data, const std::string &name) {
//     std::vector<osg::Vec2> keys;
//     LoadKeys(keys, data, name);
//     interpolator.InitKeys(keys);
//   }

	osg::ref_ptr<UGAMEShadowedText> mLabel;

  osg::ref_ptr<MAFAudioController> mSoundCard;
  osg::ref_ptr<MAFAudioController> mSoundCardEffect;

  bool mSoundStarted;
  float mSoundAngleThreshold;

  osg::ref_ptr<MAFAudioController> mSoundOpen;
  osg::ref_ptr<MAFAudioController> mSoundClose;
  
  std::vector<int> mCardsValue;
  bool mCallAgainSetCards;


 public:

  PokerCardControllerVector mCards;
  PokerApplication* mGame;

  osg::AutoTransform* mRoot;

  PokerBoardController(PokerApplication* game,unsigned int controllerID);
  virtual ~PokerBoardController();

	const char* GetControllerName() const { return "PokerBoardController";}

  void SetHandValue(const std::string& str) { if(str != "") mLabel->setText(str);}
//  void SetTextPosition(const osg::Vec3& pos) { mLabel->GetView()->SetCenter(pos); }
  void SetTextColor(const osg::Vec4& a) { mLabel->setColor(a);}

  //bool StopToDisplayShowDown();
  void SetCards(const std::vector<int>& cards);
  void FoldCards(void);
  bool StartToDisplayShowDown(PokerPlayer *);
  bool StopToDisplayShowDown();
  virtual bool Update(MAFApplication* application);

	void SetWinningCards(std::vector<int> &cards) { mWinningCards = cards; }

	osg::ref_ptr<osg::MatrixTransform> mCardsMatrix[5];

	osg::ref_ptr<MAFBillBoard> mBillBoard;

	bool mShowDownTime;
	float mLabelAlpha;
  float mParamFadeInDuration;

  bool mChangeSpace;
  bool mChangeSpaceFinal;
  bool mActivateFadein;
  float mTransitionTranslationTime;
  float mParamTransitionTranslationDuration;
  float mFadeInTime;

  osg::Vec3 mTargetPositionInHandSpace[5];
  osg::Vec3 mSourcePositionInHandSpace[5];

	osg::ref_ptr<osg::MatrixTransform> mCardsNode[5];
	osg::Vec3f mOrgCardsTranslation[5];

	osg::Vec3f mSourceTranslation;
	osg::Vec3f mDestinationTranslation;
	float mCurrentTranslationFactor;

public:

	class Slot {
	public:
		Slot()
		  : iCard(-1), textureAngle(0), cpath_texmat(NULL), matrix_factor(0),
		  cpath_currentPos(0), alphaRay(0),
		  state(-1), rayState(0), geode_cpath(NULL) { };

		int iCard; // -1 means no card for this slot
		osg::TexMat *texMat;
		float textureAngle;

		osg::TexMat *cpath_texmat;
		osg::MatrixTransform *cpath;
		float matrix_factor;
		float cpath_currentPos;
		float alphaRay;
		float scale;

		int state;

		int rayState; // 0 = disappear, 1 = appear
		osg::Geode *geode_cpath;

	};

  Slot mSlots[5];
  bool mAllCardsGo;
  float mCounterAllCardsGo;

  float mConeMatrixCounter;
  float mConeFactor;
  int mConeStatus;

  osg::Matrix mRayBaseInv;
  osg::Vec3 mRayBase;

  int mPreviousCardsSize;
  int mPreviousCardsValue[5];

  MAFESCNData *mSetData;

  osg::Node *mLightRay[5];
  osg::TexMat *mLightRayProjMat[5][2];
  osg::Material *mLightRayMaterial[5];

  osg::Group *mLightCone;
  osg::TexMat *mLightConeTexMat[2];
  osg::Material *mLightConeMaterial;

	osg::Group *mCPath[2];

	osg::Vec3f *mLightconeVertex;
	osg::Vec3f *mLightconeVertexTop_bak;
	osg::Vec3f *mLightconeVertexBottom_bak;

	osg::Vec3f mLightRayColor;

	std::vector<int> mWinningCards;
	float mParamWinningCardsTranslation;

  float _lerp(float from, float to, float factor) { return from + (to - from) * factor; }

  void MakeCardArrive(int slot, int iCard);
  void makeCardGo(int slot);
  void MakeAllCardsGo();

  void MakeConeArrive();
  void MakeConeGo();

  void MakeCardNikel(int);
  void makeAllCardsNikel();

  void EnableSound();
  void DisableSound();

  class LightRayGeometry : public osg::Geometry {
  public:

		LightRayGeometry(const osg::Geometry &_geom, int _index, PokerBoardController *projo, const osg::CopyOp &_copyop = osg::CopyOp::SHALLOW_COPY)
		  : osg::Geometry(_geom, _copyop)
	  {
		  mRayIndex = _index;
		  mProjectorCard = projo;
	  }

	  int mRayIndex;
	  PokerBoardController *mProjectorCard;

#if OSG_VERSION_MAJOR != 2
	  virtual void drawImplementation(osg::State &) const;
#else // OSG_VERSION_MAJOR != 2
	  virtual void drawImplementation(osg::RenderInfo &) const;
#endif  // OSG_VERSION_MAJOR != 2
		virtual osg::BoundingBox computeBound();
  };

};


#endif // _poker_h

