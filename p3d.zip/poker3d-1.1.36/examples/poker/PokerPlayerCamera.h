/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Igor Kravtchenko <igor@obraz.net>
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#ifndef _pokerplayercamera_h
#define _pokerplayercamera_h

#ifndef POKER_USE_VS_PCH
#include <map>
#include <string>

#include <PokerCamera.h>

#include <maf/clock.h>
#include <ugame/text.h>
#endif

class PokerCameraController;
class PokerPlayer;

class PokerPlayerCamera {
 public:
  PokerPlayerCamera();
  PokerPlayerCamera(PokerCameraController* camera, std::map<std::string,std::string>& params);
  void Init(PokerCameraController* camera, std::map<std::string,std::string>& params);
  ~PokerPlayerCamera();

  enum UpdateResult {
    NONE = 0,
    START_LOOK_CARDS = 1,
    END_LOOK_CARDS = 2,
  };
	enum CameraState {
    NONE_STATE = 0,
		START_FIRST_PERSON = 1,
		END_FIRST_PERSON = 2,
		IN_FIRST_PERSON = 3
	};

  UpdateResult Update(SDL_Event* event, float delta, bool focused, bool ignoreEvent, bool wantToForceFreeMode = false);

  void SetCameraModel(const std::string& name, const MAFCameraModel& model) { mCameras[name] = model; }
  void SetPlayerPosition(const osg::Vec3& position) { mPositionOfPlayerInWorldspace = position; }
  void SetPlayerDirection(const osg::Vec3& direction) { mDirectionOfPlayerInWorldspace = direction; }
  void SetLookingCardAnimationTimeout(double timeout) { mLookingCardAnimationTimeout = timeout; }
  void SetInteractorSelected(bool selected) { mInteractorSelected = selected; }
  PokerCameraController *GetCameraController() { return mCamera.get(); }

	CameraState GetCameraState() const;

 private:
  std::map<std::string,MAFCameraModel> mCameras;
  bool mInteractorSelected;

  double mTimePlaying;
  double mTimeWaiting;
  double mTimeNoise;
  double mInternalTime; // time since the player is here

  double mCameraTimeout;
  double mCameraTotalTimeout;

  int mCameraElapsed;
  float mCameraTimeToReach;
  float mCameraTimeToRewind;
  float mCameraTimeToRelease;
  float mCameraFactorToReach;
  float mCameraFactorToRewind;
  float mCameraTimeShoulder;

  float mCameraTimeToReachLook;
  float mCameraTimeToRewindLook;

  osg::Vec3 mDirectionOfPlayerInWorldspace;
  osg::Vec3 mPositionOfPlayerInWorldspace;
 protected:
  osg::ref_ptr<PokerCameraController> mCamera;
 public:
  void MoveCameraToModel(const std::string& model);
 private:
  void MoveCameraToCamLookModel();
  void MoveCameraToPreviousModel();
  void MoveCamera(const osg::Vec3 &position, const osg::Vec3 &target, float fov);
  bool CameraEvaluateModeTransition();
 protected:
  void BeginFreeMode();
  void ExecuteFreeMode();
  void EndFreeMode();
  void BeginEnterMode();
  void ExecuteEnterMode();
  void EndEnterMode();
  void BeginGameMode();
  void ExecuteGameMode();
  void EndGameMode();
  void BeginDirectMode();
  void ExecuteDirectMode();
  void EndDirectMode();
  void BeginLeaveMode();
  void ExecuteLeaveMode();
  void EndLeaveMode();
  void BeginFixMode();
  void ExecuteFixMode();
  void EndFixMode();
 public:
  int fixmode;
 private:

	void Cal3DInFPV();
	void Cal3DInTPV();

	bool IsCal3DMeshNeedToBeRemoved(const std::string &meshName);

  double mCameraLookCardTimeout;
  int mCameraLookCardState;
  double mCameraMinTimeToLookCards;
  double mCameraVelocityToLookCards;
  double mLookingCardAnimationTimeout;

  float mCameraButtonDelayToActivateDirectMode;
  float mCameraGameModeDelay;
  float mCameraGameModeMouseThreshold;
  float mCameraGameModeDelayLookCards;

  double mDeltaS;
  float mMouseDelta[2];
  float mMouseDeltaOverall[2];
  float mMouseDeltaRel[2];
  bool mCameraMouseMotion;
  bool mDisplayedAndFocused;
  bool mCameraButtonPressed;
  bool mCameraButtonClickUp;
  bool mCameraButtonClickDown;
  bool mCameraButtonClickFocused;
  double mCameraButtonPressedDuration;
  std::vector<osg::Vec2> mCameraKeys;

  osg::Vec3Array *array_;
  osg::Vec2f hudPos_[9];
  float factor_[9];
  int sens_;
  float timeSinceFirstPersonView_;
	std::string dataPath_;

  osg::ref_ptr<osg::MatrixTransform> mt_[9];
  osg::ref_ptr<osg::MatrixTransform> mtrot_[9];
  osg::ref_ptr<osg::MatrixTransform> mticon_[9];
  osg::ref_ptr<osg::MatrixTransform> mticonrot_[9];
  osg::ref_ptr<osg::MatrixTransform> mtdealerButton_[9];
  osg::ref_ptr<osg::MatrixTransform> mtpanel_[9];
	osg::ref_ptr<osg::MatrixTransform> mtchat_[9];

	osg::ref_ptr<osg::Group> actionGroup_[9];
	osg::ref_ptr<osg::Group> dealerGroup_[9];

  osg::ref_ptr<UGAMEBasicText> textName_[9];
  osg::ref_ptr<UGAMEBasicText> textLastAction_[9];
  osg::ref_ptr<UGAMEBasicText> textLastActionIt_[9];
	osg::ref_ptr<UGAMEBasicText> textChat_[9];
  PokerPlayer *players_[9];

  std::string strLastAction_[9];

	std::vector<std::string> cal3dMeshesToKeepInFPV_;

	std::set<osg::Drawable*> removedCal3DMeshes_;

  void updatePos(float dt);
/* 	void StartWaitIdleAnimation(); */
/* 	void StopWaitIdleAnimation(); */

	bool mCameraGoViewFirstPerson;
	bool mCameraLeaveViewFirstPerson;
 public:
	osg::MatrixTransform* GetHUDMatrixTransform(int index, int me_index)
		{
			int r_index;
			if (index > me_index)
				r_index = index - me_index;
			else
				r_index = 10 + index - me_index;
			r_index--;
			return mt_[r_index].get();
		}
};

#endif // _pokerplayercamera_h
