/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Igor Kravtchenko <igor@ozos.net>
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include "pokerStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */
#ifdef WIN32
#include <cstdio>
# define snprintf _snprintf
#endif

#ifndef POKER_USE_VS_PCH
#include <osg/BlendFunc>
#include <osg/Stencil>

#include <maf/window.h>
#include <maf/shadow.h>
#include <maf/timer.h>
#include <maf/assert.h>
#include <maf/renderbin.h>

#include <varseditor/varseditor.h>

#include <PokerApplication.h>
#include <PokerOutfit.h>
#include <PokerSceneView.h>
#endif

#include <osg/LightModel>
#include <maf/alpha_fx.h>

static int viewport_x;
static int viewport_y;
static int viewport_w;
static int viewport_h;

static int viewport_y0;
static int viewport_middle;

const osg::Vec3f g_farPos(0, 95, 350);
const osg::Vec3f g_nearPos(0, 170, -80);

const osg::Vec3f g_farPos_pv(0, 95, -250);
const osg::Vec3f g_nearPos_pv(0, 170, -250);

static void Plop()
{
  ;
}

// struct AlphaFXCallback : osg::NodeCallback
// {
//   MAFAlphaFX* _fx;
//   AlphaFXCallback(MAFAlphaFX* fx) : _fx(fx)
//   {
//   }
//   void operator()(osg::Node* node, osg::NodeVisitor* nv)
//   {
//     if (_fx->mTimer.Finished())
//       _fx->Init(0.0, 1.0, 2.0);
//     _fx->Update(0.1);
    
//   }
// };

class PokerOutfitModel::EyeBlinkAnimation : public CalScheduler::StopCallback
{

 protected:
  osg::ref_ptr<UGAMEAnimatedController>  mAnimated;

	bool mStopped;
	float mMinRandom,mMaxRandom;

 public:
  EyeBlinkAnimation(UGAMEAnimatedController* animated, float minrand, float maxrand):mAnimated(animated), mStopped(false), mMinRandom(minrand) , mMaxRandom(maxrand) {}

	void Stop() 
	{
		int coreAnimation = mAnimated->GetCoreAnimationId("blink");
		CalAnimationAlt* anim=mAnimated->GetScheduler()->getAnimation(coreAnimation);
		if (anim) {
			anim->setStopCallback(0);
			mAnimated->GetScheduler()->stop(coreAnimation);
		}
	}

	void Run() { process(0,0);}

  void process(CalModel* model, CalAnimationAlt* animation) 
	{
		if (mAnimated.get()) {
			float delay=mMinRandom+(mMaxRandom*rand()/(RAND_MAX+1.0));
			int coreAnimation = mAnimated->GetCoreAnimationId("blink");
			CalAnimationAlt* anim = mAnimated->GetScheduler()->run(CalScheduler::FOREGROUND,
																														 coreAnimation,
																														 CalScheduler::ONCE,
																														 1.0,
																														 0, // no weight function
																														 delay);
			anim->setStopCallback(this);
		}
	}
	
};



PokerOutfitModel::PokerOutfitModel(MAFApplication* _application) :
  mApplication(dynamic_cast<PokerApplication*>(_application))
{
  float width = mApplication->GetWindow(true)->GetWidth();
  float height = mApplication->GetWindow(true)->GetHeight();

//	Sleep(10000);

	const std::string &datadir = mApplication->HeaderGet("settings", "/settings/data/@path");

	osg::Group *rootGroup = mApplication->GetScene()->GetModel()->mGroup.get();
	osg::Group *sceneGroup = new osg::Group;
	//sceneGroup->getOrCreateStateSet()->setTextureAttributeAndModes(0, mApplication->GetInterface()->GetAlphaFX());
	SetNode(sceneGroup);

  osg::ref_ptr<osg::Texture2D> texture = new osg::Texture2D;
  osg::Image* image;
  {
    const osg::Texture::Extensions* extensions = texture->getExtensions(0,true);
    std::string backgroundpath = datadir + "/" + mApplication->HeaderGet("sequence", "/sequence/outfit/@background");
    int size = extensions->maxTextureSize();
    if(size > 512) size = 1024;
    char tmp[256];
    snprintf(tmp, 256, backgroundpath.c_str(), size, size);
    image = osgDB::readImageFile(tmp);
  }

	float half_width = 1024 / 2;
	float half_height = 1024 / 2;
	float center_x = width / 2;
	float center_y = height / 2;

  if(image) {
    texture->setImage(image);

    osg::StateSet* dstate = new osg::StateSet;
    dstate->setMode(GL_CULL_FACE,osg::StateAttribute::OFF);
    dstate->setMode(GL_LIGHTING,osg::StateAttribute::OFF);
    dstate->setTextureAttributeAndModes(0, texture.get(), osg::StateAttribute::ON);
    osg::BlendFunc* tenv = new osg::BlendFunc(osg::BlendFunc::SRC_ALPHA,osg::BlendFunc::ONE_MINUS_SRC_ALPHA);
    dstate->setAttributeAndModes(tenv, osg::StateAttribute::ON);
    dstate->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);

    osg::Geometry* geom = new osg::Geometry;
    geom->setStateSet(dstate);

    osg::Vec2Array* tcoords = new osg::Vec2Array(4);
    (*tcoords)[0].set(0.0f,0.0f);
    (*tcoords)[1].set(0.0f,1.0f);
    (*tcoords)[2].set(1.0f,1.0f);
    (*tcoords)[3].set(1.0f,0.0f);
    geom->setTexCoordArray(0,tcoords);

    osg::Vec3Array* coords = new osg::Vec3Array(4);
    (*coords)[0].set(center_x - half_width, center_y - half_height, 0.f);
    (*coords)[1].set(center_x - half_width, center_y + half_height, 0.f);
    (*coords)[2].set(center_x + half_width, center_y + half_height, 0.f);
    (*coords)[3].set(center_x + half_width, center_y - half_height, 0.f);
    geom->setVertexArray(coords);

    osg::Vec4Array* colours = new osg::Vec4Array(1);
    (*colours)[0].set(1.0f,1.0f,1.0,1.0f);
    geom->setColorArray(colours);
    geom->setColorBinding(osg::Geometry::BIND_OVERALL);

    geom->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::QUADS,0,4));

    // set up the geode.
    osg::Geode* geode = new osg::Geode;
    geode->setName("OutfitBackground");
//     MAFAlphaFX* fx = new MAFAlphaFX();
//     fx->Init(0.0, 1.0f, 2.0f);
//     geode->setUpdateCallback(new AlphaFXCallback(fx));
//     geode->getOrCreateStateSet()->setTextureAttributeAndModes(0, fx);
    geode->addDrawable(geom);

		sceneGroup->addChild(geode);
  }

	sceneController_ = new MAFSceneController();
	sceneController_->Init();

	osgUtil::SceneView *sceneView = sceneController_->GetModel()->mScene.get();
	sceneView_ = sceneView;

	sceneView->setState( mApplication->GetScene()->GetModel()->mScene->getState()) ;

	osgCal::CoreModel *data;
  osgCal::Model *model;
  UGAMEAnimatedController* animated;
	osgCal::Model::Drawables *draws;
	osg::Group *group;

	osg::Group *scene = new osg::Group();
	sceneView->setSceneData(scene);

	//Sleep(5000);

	std::map<std::string,std::string> light_pos = mApplication->HeaderGetProperties("sequence", "/sequence/outfit/light_pos");
  if (light_pos.find("x") == light_pos.end() || light_pos.find("y") == light_pos.end() || light_pos.find("z") == light_pos.end())
    g_error("PokerOutfit: /sequence/outfit/light_pos incorrectly set");
	float lgt_pos_x = atof( light_pos["x"].c_str() );
	float lgt_pos_y = atof( light_pos["y"].c_str() );
	float lgt_pos_z = atof( light_pos["z"].c_str() );

	std::map<std::string,std::string> global_ambient = mApplication->HeaderGetProperties("sequence", "/sequence/outfit/global_ambient");
  if (global_ambient.find("r") == global_ambient.end() || global_ambient.find("g") == global_ambient.end() || global_ambient.find("b") == global_ambient.end())
    g_error("PokerOutfit: /sequence/outfit/global_ambient incorrectly set");
	float global_ambient_r = atof( global_ambient["r"].c_str() );
	float global_ambient_g = atof( global_ambient["g"].c_str() );
	float global_ambient_b = atof( global_ambient["b"].c_str() );

	std::map<std::string,std::string> light_diffuse = mApplication->HeaderGetProperties("sequence", "/sequence/outfit/light_diffuse");
  if (light_diffuse.find("r") == light_diffuse.end() || light_diffuse.find("g") == light_diffuse.end() || light_diffuse.find("b") == light_diffuse.end())
    g_error("PokerOutfit: /sequence/outfit/light_diffuse incorrectly set");

	float light_diffuse_r = atof( light_diffuse["r"].c_str() );
	float light_diffuse_g = atof( light_diffuse["g"].c_str() );
	float light_diffuse_b = atof( light_diffuse["b"].c_str() );

	osg::LightSource *lgtSource = new osg::LightSource();
	osg::Light *lgt = new osg::Light();
	lgt->setLightNum(0);
	lgt->setAmbient( osg::Vec4(0.0f, 0.0f, 0.0f, 0.0f) );
	lgt->setDiffuse( osg::Vec4f(light_diffuse_r, light_diffuse_g, light_diffuse_b, 1) );
	lgt->setSpecular( osg::Vec4f(1, 1, 1, 1) );

	lgt->setPosition( osg::Vec4f(lgt_pos_x, lgt_pos_y, lgt_pos_z, 1) );
	lgtSource->setLight(lgt);
	scene->addChild(lgtSource);

	osg::LightModel *lightmodel = new osg::LightModel;
	lightmodel->setAmbientIntensity( osg::Vec4f(global_ambient_r, global_ambient_g, global_ambient_b, 0) );
	scene->getOrCreateStateSet()->setAttributeAndModes(lightmodel, osg::StateAttribute::ON);

	scene->getOrCreateStateSet()->setMode(GL_LIGHT0, osg::StateAttribute::ON);
	scene->getOrCreateStateSet()->setMode(GL_LIGHT1, osg::StateAttribute::OFF);
	scene->getOrCreateStateSet()->setMode(GL_LIGHT2, osg::StateAttribute::OFF);
	scene->getOrCreateStateSet()->setMode(GL_LIGHT3, osg::StateAttribute::OFF);
	scene->getOrCreateStateSet()->setMode(GL_LIGHTING, osg::StateAttribute::ON);

	
	// scene->getOrCreateStateSet()->setTextureAttributeAndModes(0, mApplication->GetInterface()->GetAlphaFX());
// 	osg::BlendFunc* bf = new osg::BlendFunc();
// 	bf->setFunction(osg::BlendFunc::ONE, osg::BlendFunc::ONE_MINUS_SRC_ALPHA);
// 	scene->getOrCreateStateSet()->setAttributeAndModes(bf);

  MAFWindow* window = mApplication->GetWindow(true);
  std::map<std::string,std::string> properties = mApplication->HeaderGetProperties("sequence", "/sequence/outfit/preview");
  if (properties.find("x") == properties.end() || properties.find("y") == properties.end() ||
      properties.find("width") == properties.end() || properties.find("height") == properties.end())
    g_error("PokerOutfit: /sequence/outfit/preview incorrectly set");

  int x = atoi(properties["x"].c_str());
  int y = atoi(properties["y"].c_str());

  viewport_w = atoi(properties["width"].c_str());
  viewport_h = atoi(properties["height"].c_str());

  viewport_x = (int)(window->GetWidth()/2.0f + x);
  viewport_y = (int)(window->GetHeight() - (window->GetHeight()/2.0f + y + viewport_h ) );

  viewport_y0 = (int)float(window->GetHeight()/2.0f + y);
  viewport_middle = viewport_y0 + viewport_h/2;


	sceneView->setProjectionMatrix( osg::Matrixd::perspective(20.0f, ((float)viewport_w)/viewport_h, 1.0f, 10000.f) );

	sceneController_->GetView()->setViewport( viewport_x, viewport_y, viewport_w, viewport_h );
	sceneController_->GetView()->setSetupVP(false);
	sceneController_->GetModel()->mScene->setClearColor( osg::Vec4f(56/255.0f, 62/255.0f, 69/255.0f, 0) );

	MAF_OSGQuadParams params;
	params.bInvertUV = false;
	//params.minPt = osg::Vec2f(viewport_x, viewport_y + viewport_h);
	//params.maxPt = osg::Vec2f(viewport_x+64, viewport_y + viewport_h + 64);

	MAF_OSGQuad *quad;
	{
		float x0 = window->GetWidth()/2.0f - 512 + 219;
		float y0 = window->GetHeight() - (window->GetHeight()/2.0f - (512-(758+64)) );

		params.minPt = osg::Vec2f(x0, y0);
		params.maxPt = osg::Vec2f(x0 + 64, y0 + 64);
		params.minUV = osg::Vec2f(0, 0);
		params.maxUV = osg::Vec2f(1, 1);
		params.textureName = datadir + "/fleche_gauche_normal.tga";
		quad = new MAF_OSGQuad(params);

//		{
	//		int rbvalue;
		//	if (!VarsEditor::Instance().Get("RB_OutfitHUD",rbvalue))
			//	MAF_ASSERT(0 && "RB_OutfitHUD not found in client.xml");
//			quad->getGeode()->getOrCreateStateSet()->setRenderBinDetails(rbvalue, "RenderBin");
	//	}
		if (!MAFRenderBin::Instance().SetupRenderBin("OutfitHUD", quad->getGeode()->getOrCreateStateSet()))
			MAF_ASSERT(0 && "OutfitHUD not found in client.xml");

		sceneGroup->addChild(quad->getGeode());

		Button button;
		button.normalState = MAFApplication::GetTextureManager()->GetTexture2D(datadir + "/fleche_gauche_normal.tga");
		button.rollOverState = MAFApplication::GetTextureManager()->GetTexture2D(datadir + "/fleche_gauche_active.tga");
		button.pushedState = MAFApplication::GetTextureManager()->GetTexture2D(datadir + "/fleche_gauche_selected.tga");
		button.focusID = 1;
		button.x0 = (int)x0;
		button.y0 = (int)(window->GetHeight()/2.0f - 512 + 758);
		button.w = 64;
		button.h = 64;
		button.quad = quad;
		buttons_.push_back(button);
	}

	{
		float x0 = window->GetWidth()/2.0f - 512 + (219 + 64);
		float y0 = window->GetHeight() - (window->GetHeight()/2.0f - (512-(758+64)) );

		params.minPt = osg::Vec2f(x0, y0);
		params.maxPt = osg::Vec2f(x0 + 64, y0 + 64);
		params.minUV = osg::Vec2f(0, 0);
		params.maxUV = osg::Vec2f(1, 1);
		params.textureName = datadir + "/loupe_normal.tga";
		quad = new MAF_OSGQuad(params);

//		{
	//		int rbvalue;
		//	if (!VarsEditor::Instance().Get("RB_OutfitHUD",rbvalue))
			//	MAF_ASSERT(0 && "RB_OutfitHUD not found in client.xml");
			//quad->getGeode()->getOrCreateStateSet()->setRenderBinDetails(rbvalue, "RenderBin");
		//}
		if (!MAFRenderBin::Instance().SetupRenderBin("OutfitHUD", quad->getGeode()->getOrCreateStateSet()))
			MAF_ASSERT(0 && "OutfitHUD not found in client.xml");

		sceneGroup->addChild(quad->getGeode());

		Button button;
		button.normalState = MAFApplication::GetTextureManager()->GetTexture2D(datadir + "/loupe_normal.tga");
		button.rollOverState = MAFApplication::GetTextureManager()->GetTexture2D(datadir + "/loupe_active.tga");
		button.pushedState = MAFApplication::GetTextureManager()->GetTexture2D(datadir + "/loupe_selected.tga");
		button.focusID = 2;
		button.x0 = (int)(x0);
		button.y0 = (int)(window->GetHeight()/2.0f - 512 + 758);
		button.w = 64;
		button.h = 64;
		button.quad = quad;
		buttons_.push_back(button);
	}

	{
		float x0 = window->GetWidth()/2.0f - 512 + (219 + 128);
		float y0 = window->GetHeight() - (window->GetHeight()/2.0f - (512-(758+64)) );

		params.minPt = osg::Vec2f(x0, y0);
		params.maxPt = osg::Vec2f(x0 + 64, y0 + 64);
		params.minUV = osg::Vec2f(0, 0);
		params.maxUV = osg::Vec2f(1, 1);
		params.textureName = datadir + "/fleche_droite_normal.tga";
		quad = new MAF_OSGQuad(params);
//		{
	//		int rbvalue;
		//	if (!VarsEditor::Instance().Get("RB_OutfitHUD",rbvalue))
			//	MAF_ASSERT(0 && "RB_OutfitHUD not found in client.xml");
			//quad->getGeode()->getOrCreateStateSet()->setRenderBinDetails(rbvalue, "RenderBin");
		//}
		if (!MAFRenderBin::Instance().SetupRenderBin("OutfitHUD", quad->getGeode()->getOrCreateStateSet()))
			MAF_ASSERT(0 && "OutfitHUD not found in client.xml");

		sceneGroup->addChild(quad->getGeode());

		Button button;
		button.normalState = MAFApplication::GetTextureManager()->GetTexture2D(datadir + "/fleche_droite_normal.tga");
		button.rollOverState = MAFApplication::GetTextureManager()->GetTexture2D(datadir + "/fleche_droite_active.tga");
		button.pushedState = MAFApplication::GetTextureManager()->GetTexture2D(datadir + "/fleche_droite_selected.tga");
		button.focusID = 3;
		button.x0 = (int)x0;
		button.y0 = (int)(window->GetHeight()/2.0f - 512 + 758);
		button.w = 64;
		button.h = 64;
		button.quad = quad;
		buttons_.push_back(button);
	}

	mCurrentFocus = -1;

	caracMatrix_ = new osg::MatrixTransform();
	scene->addChild(caracMatrix_.get());

	{
		osg::Matrix	shadowMatrix = MAFBuildShadowMatrix(osg::Plane(0,	1, 0,	0),	osg::Vec4f(100,	500, -100,	1) );
		shadowMatrix_ = new osg::MatrixTransform();
		shadowMatrix_->setMatrix( shadowMatrix );
		caracMatrix_->addChild(shadowMatrix_.get());

		shadowMatrix_->getOrCreateStateSet()->setMode(GL_DEPTH_TEST, FALSE);

		osg::Material* material	=	new	osg::Material;
		material->setAmbient(osg::Material::FRONT_AND_BACK,	osg::Vec4(0.0f,	0.0f,	0.0f,	0.0f));
		material->setDiffuse(osg::Material::FRONT_AND_BACK,	osg::Vec4(0.0f,	0.0f,	0.0f,	0.0f));
		material->setEmission(osg::Material::FRONT_AND_BACK, osg::Vec4(0.8f, 0.8f, 0.8f, 0.0f));
		material->setShininess(osg::Material::FRONT_AND_BACK,	0.0f);
		shadowMatrix_->getOrCreateStateSet()->setAttribute(material,	osg::StateAttribute::OVERRIDE);
		shadowMatrix_->getOrCreateStateSet()->setTextureMode(0, GL_TEXTURE_2D,	osg::StateAttribute::OVERRIDE	|	osg::StateAttribute::OFF);

		if (!MAFRenderBin::Instance().SetupRenderBin("OutfitShadowPlayer", shadowMatrix_->getOrCreateStateSet()))
			MAF_ASSERT(0 && "OutfitShadowPlayer not found in client.xml");

		osg::Stencil *stenc	=	new	osg::Stencil;
		stenc->setFunction(osg::Stencil::EQUAL,	0x0, 0xffffffff);
		stenc->setOperation(osg::Stencil::KEEP,	osg::Stencil::INCR,	osg::Stencil::INCR);
		shadowMatrix_->getOrCreateStateSet()->setAttributeAndModes(stenc);
		shadowMatrix_->getOrCreateStateSet()->setMode(GL_STENCIL_TEST,	TRUE);

		osg::BlendFunc *blend	=	new	osg::BlendFunc;
		blend->setFunction(GL_DST_COLOR, GL_ZERO);
		shadowMatrix_->getOrCreateStateSet()->setAttributeAndModes(blend, osg::StateAttribute::OVERRIDE | osg::StateAttribute::ON);
		shadowMatrix_->getOrCreateStateSet()->setMode(GL_LIGHTING,	osg::StateAttribute::OVERRIDE	|	osg::StateAttribute::ON);
	}

	previewSexNode_ = NULL;

	MAFMonitor *mon = mApplication->GetLoader();

	//osg::ref_ptr<osgDB::ReaderWriter::Options> options = new osgDB::ReaderWriter::Options;
	osg::ref_ptr<osgCal::IOOptions> options = new osgCal::IOOptions;
	options->setObjectCacheHint(osgDB::ReaderWriter::Options::CACHE_ALL);
	options->setMonitor( (osgCal::Monitor*) mon );

	if (mon) {
		//mon->write("Loading Outfits And Animations...");
		//mon->setMulFactor(0.5f);
		mon->setMulAddFactor(0.3333f * 0.5f, 0.6666f);
		mon->write("Loading...");
	}

  data = (osgCal::CoreModel*) osgDB::readObjectFile("player.male.cal3d/cal3d.xfg", options.get());
  if (!data)
    g_error("PokerOutfit: Error loading \"player.male.cal3d/cal3d.xfg\"");

	model = new osgCal::Model();

	group = (osg::Group*) new osg::Group;
	group->setNodeMask(MAF_VISIBLE_MASK);
	rootGroup->addChild(group);
	//model->setFXGroup(group);
	//model->setFXState(sceneView->getState());
	model->setFXGroup( PokerSceneView::getInstance()->m_TLFGroup.get() );
	model->setFXState( PokerSceneView::getInstance()->m_TLFState.get() );

	model->setUseVertexProgram(false);
	model->setCoreModel(data);
        //	const char* outfitNameMale=data->getOutfitNameByIndex(0); // get first outfit
        //	model->loadOutfit(outfitNameMale);
	animated = new UGAMEAnimatedController(0);
	animated->SetModel(new UGAMEAnimatedModel);
	animated->GetModel()->SetOsgCalModel(model);
	animated->Init();
	model->applyParameterFromOutfitDescription();

	{
		const char *meshToRemove[] = { "chair_lv00", "chair_lv01", "bentcard0", "bentcard1", "bentcard2", "bentcard3", "bentcard4" };
		int nbMeshesToRemove = sizeof meshToRemove / sizeof(char*);
		for (int i = 0; i < nbMeshesToRemove; i++) {
			draws = model->getDrawables( meshToRemove[i] );
			if (!draws)
				continue;
			int nbDrawables = draws->size();
			for (int j = 0; j < nbDrawables; j++) {
				model->removeDrawable( (*draws)[j].get() );
			}
		}

		CalScheduler *sch = animated->GetScheduler();
		Anim anim;
		anim.id = model->getCalCoreModel()->getCoreAnimationId("upIdle01");
		maleAnims_.push_back(anim);
		anim.id = model->getCalCoreModel()->getCoreAnimationId("upIdle02");
		maleAnims_.push_back(anim);
		anim.id = model->getCalCoreModel()->getCoreAnimationId("upIdle03");
		maleAnims_.push_back(anim);
		anim.id = model->getCalCoreModel()->getCoreAnimationId("upIdle05");

		maleAnims_.push_back(anim);
		anim.id = model->getCalCoreModel()->getCoreAnimationId("clothing");
		maleAnims_.push_back(anim);

    if (!maleAnims_[0].id)
      g_error("PokerOutfit: upIdle01 animation is missing for male");

		maleStopCallback_ = new StopCallback(this, 1);
		sch->run(CalScheduler::FOREGROUND, maleAnims_[0].id, CalScheduler::ONCE)->setStopCallback(maleStopCallback_);
	}


	// get blink from configuration file
  std::map<std::string,std::string> eyes = mApplication->HeaderGetProperties("sequence", "/sequence/animation/blinkeye");
	if (eyes.find("min_random") == eyes.end())
		g_error("PokerOutfit::PokerOutfit need min_random in /sequence/animation/blinkeye");
	if (eyes.find("max_random") == eyes.end())
		g_error("PokerOutfit::PokerOutfit need max_random in /sequence/animation/blinkeye");
	float eyeRandomMin = atof(eyes["min_random"].c_str());
	float eyeRandomMax = atof(eyes["max_random"].c_str());

	mEyeAnimation["male"] = new EyeBlinkAnimation(animated,eyeRandomMin,eyeRandomMax);

	mEyeAnimation["male"]->Run();
	animated_["male"] = animated;

	if (mon) {
//		mon->setAddFactor(0.5f);
		//mon->write("Loading Outfits And Animations...");

		mon->setMulAddFactor(0.3333f * 0.5f, 0.6666f+0.3333f*0.5f);
		mon->write("Loading...");
	}

	data = (osgCal::CoreModel*) osgDB::readObjectFile("player.female.cal3d/cal3d.xfg",options.get());
  if (!data)
    g_error("Error loading \"player.female.cal3d/cal3d.xfg\"");

	if (mon) {
		mon->setMulAddFactor(1.0f, 0.0f);
	}

	model = new osgCal::Model();
	group = (osg::Group*) new osg::Group;
	group->setNodeMask(MAF_VISIBLE_MASK);
	rootGroup->addChild(group);
	//model->setFXGroup(group);
	//model->setFXState(sceneView->getState());
	model->setFXGroup( PokerSceneView::getInstance()->m_TLFGroup.get() );
	model->setFXState( PokerSceneView::getInstance()->m_TLFState.get() );

	model->setUseVertexProgram(false);
	model->setCoreModel(data);
        //	const char* outfitNameFemale=data->getOutfitNameByIndex(0); // get first outfit
        //	model->loadOutfit(outfitNameFemale);
	animated = new UGAMEAnimatedController(0);
	animated->SetModel(new UGAMEAnimatedModel);
	animated->GetModel()->SetOsgCalModel(model);
	animated->Init();
	Plop();
	model->applyParameterFromOutfitDescription();

	{
		const char *meshToRemove[] = { "chair_lv00", "chair_lv01", "bentcard0", "bentcard1", "bentcard2", "bentcard3", "bentcard4" };
		int nbMeshesToRemove = sizeof meshToRemove / sizeof(char*);
		for (int i = 0; i < nbMeshesToRemove; i++) {
			draws = model->getDrawables( meshToRemove[i] );
			if (!draws)
				continue;
			int nbDrawables = draws->size();
			for (int j = 0; j < nbDrawables; j++) {
				model->removeDrawable( (*draws)[j].get() );
			}
		}

		CalScheduler *sch = animated->GetScheduler();
		Anim anim;
		anim.id = model->getCalCoreModel()->getCoreAnimationId("upIdle05");
		femaleAnims_.push_back(anim);
		anim.id = model->getCalCoreModel()->getCoreAnimationId("upIdle02");
		femaleAnims_.push_back(anim);
		anim.id = model->getCalCoreModel()->getCoreAnimationId("upIdle03");
		femaleAnims_.push_back(anim);
		anim.id = model->getCalCoreModel()->getCoreAnimationId("upIdle01");
		femaleAnims_.push_back(anim);
		anim.id = model->getCalCoreModel()->getCoreAnimationId("clothing");
		femaleAnims_.push_back(anim);

    if (!femaleAnims_[0].id)
        g_error("PokerOutfit: upIdle01 animation is missing for female");

		femaleStopCallback_ = new StopCallback(this, 2);
		sch->run(CalScheduler::FOREGROUND, femaleAnims_[0].id, CalScheduler::ONCE)->setStopCallback(femaleStopCallback_);
	}
	mEyeAnimation["female"] = new EyeBlinkAnimation(animated,eyeRandomMin,eyeRandomMax);
	mEyeAnimation["female"]->Run();
	animated_["female"] = animated;

	mNearFarPosBlend = 0.0f;
	mSensZoom = 0;
	mbZoomInProgress = false;

	mCamPos = g_farPos;
	mCamRot = osg::Vec3f(0, 0.0f, 0);

	mCaracPos = osg::Vec3f(0, 0, 0);
	mCaracRot = osg::Vec3f(0, 0, 0);

	mbLMB = false;
	mWheel = 0;
	mAltitude = 0.0f;
	mLastMalePlayedAnimation = 0;
	mLastFemalePlayedAnimation = 0;

	mRotationPersoX = 0;
	mbClickOnIcon = false;
	mTimeSinceLastIconClick = 0;

	mbDragViewport = false;

	osg::Matrix mat = osg::Matrix::identity();
	mat.postMult( osg::Matrix::translate(mCamPos) );
	sceneView_->setViewMatrix( osg::Matrix::inverse(mat) );

	//mApplication->KillSplashScreen();
}

PokerOutfitModel::~PokerOutfitModel()
{
	if (maleStopCallback_)
		delete maleStopCallback_;

	if (femaleStopCallback_)
		delete femaleStopCallback_;

  for (std::map<std::string,EyeBlinkAnimation*>::iterator it=mEyeAnimation.begin();
       it!=mEyeAnimation.end();
       it++) {
		delete it->second;
	}
	
}

PokerOutfitController::PokerOutfitController(MAFApplication *_application)
{
  SetModel(new PokerOutfitModel(_application));
}

PokerOutfitController::~PokerOutfitController()
{
	Plop();
  g_debug("PokerOutfitController::~PokerOutfitController");
	Hide();
  PokerOutfitModel* model = GetModel();
  for (std::map<std::string,osg::ref_ptr<UGAMEAnimatedController> >::iterator it=model->animated_.begin();
       it!=model->animated_.end();
       it++) {

		model->mEyeAnimation[it->first]->Stop();
			
    it->second.get()->GetModel()->GetArtefact()->setFXGroup(0);
		it->second.get()->GetScheduler()->stop(CalScheduler::ALL);
		
	}
}

bool PokerOutfitController::Update(MAFApplication *_application)
{
	int i;
//	char str[200];
	PokerOutfitModel *model = GetModel();
	PokerApplication *app = (PokerApplication*) _application;

	if(model->GetNode()->getNodeMask() == 0x0)
	    return true;

	float dt = GetDeltaFrame() / 1000.0f;

	if (_application->HasEvent()) {
		SDL_Event *event = app->GetLastEventIgnoreLocking();

		if (event) {
			if (event->type == SDL_MOUSEBUTTONDOWN && event->button.button == SDL_BUTTON_LEFT) {
				model->mbLMB = true;
			}
			else if (event->type == SDL_MOUSEBUTTONUP && event->button.button == SDL_BUTTON_LEFT) {
				model->mbLMB = false;
			}
			else if ((event->type == SDL_MOUSEBUTTONDOWN && event->button.button == SDL_BUTTON_WHEELUP) ||
							 (event->type == SDL_KEYDOWN && event->key.keysym.sym == SDLK_UP)) {
				model->mWheel = 2;
				model->mSensZoom = 0;
			}
			else if ( (event->type == SDL_MOUSEBUTTONDOWN && event->button.button == SDL_BUTTON_WHEELDOWN) ||
								(event->type == SDL_KEYDOWN && event->key.keysym.sym == SDLK_DOWN)) {
				model->mWheel = -2;
				model->mSensZoom = 0;
			}
			//else if(event->type == SDL_MOUSEMOTION) {
				//model->mDeltaMouseX = event->motion.xrel * 0.01f;
				//model->mDeltaMouseY = event->motion.yrel * 0.01f;
        //        g_debug("PokerOutfitController::Update: %f %f", deltaMouseX_, deltaMouseY_);
			//}
		}
		return true;
	}

	int m_x = app->getMouseX();
	int m_y = app->getMouseY();
	model->mDeltaMouseX = (app->getMouseX() - model->mOldMouseX) * 0.01f;
	model->mDeltaMouseY = (app->getMouseY() - model->mOldMouseY) * 0.01f;
	model->mOldMouseX = m_x;
	model->mOldMouseY = m_y;

	float zoomFactor = model->mNearFarPosBlend;
	float zf = cos(zoomFactor * osg::PI_2);
	zf *= zf;
	model->mCamPos = g_farPos * (zf) + g_nearPos * (1 - zf);
	osg::Vec3f pv = g_farPos_pv * (zf) + g_nearPos_pv * (1 - zf);

	if (model->mbZoomInProgress == true) {
		if (model->mSensZoom == 1)
			zoomFactor += dt * 1.0f;
		else if (model->mSensZoom == 0)
			zoomFactor -= dt * 1.0f;
	}
	else {
		zoomFactor += dt * model->mWheel;
		float f = dt*10;
		if (f > 1) f = 1;
		model->mWheel *= 1 - f;
	}

	if (zoomFactor < 0) {
		zoomFactor = 0;
		model->mbZoomInProgress = false;
	}
	else if (zoomFactor > 1) {
		zoomFactor = 1;
		model->mbZoomInProgress = false;
	}

	model->mNearFarPosBlend = zoomFactor;

	if (zoomFactor > 0.6f) {

		if (model->mLastMalePlayedAnimation != 0) {
			CalScheduler *scheduler = model->animated_["male"]->GetScheduler();

			model->currentMaleAnim_->setStopCallback(0);
			scheduler->stop( model->currentMaleAnim_->getAnimationId(), new CalAnimationAlt::FadeOut(1.5f), 0.0f);

			int animID = model->maleAnims_[0].id;
			CalAnimationAlt *anim = scheduler->run(CalScheduler::FOREGROUND, animID, CalScheduler::ONCE, 1.0f, new CalAnimationAlt::FadeIn(1.5f));
			anim->setStopCallback(model->maleStopCallback_);
			model->currentMaleAnim_ = anim;
			model->mLastMalePlayedAnimation = 0;
		}

		if (model->mLastFemalePlayedAnimation != 0) {
			CalScheduler *scheduler = model->animated_["female"]->GetScheduler();

			model->currentFemaleAnim_->setStopCallback(0);
			scheduler->stop( model->currentFemaleAnim_->getAnimationId(), new CalAnimationAlt::FadeOut(1.5f), 0.0f);

			int animID = model->femaleAnims_[0].id;
			CalAnimationAlt *anim = scheduler->run(CalScheduler::FOREGROUND, animID, CalScheduler::ONCE, 1.0f, new CalAnimationAlt::FadeIn(1.5f));
			anim->setStopCallback(model->femaleStopCallback_);
			model->currentFemaleAnim_ = anim;
			model->mLastFemalePlayedAnimation = 0;
		}


	}

	int focusIWantToTake = -1;
	int nbButtons = model->buttons_.size();
	for (i = 0; i < nbButtons; i++) {
		PokerOutfitModel::Button &button = model->buttons_[i];
		osg::Geometry *geom = button.quad->getGeometry();
		osg::StateSet *ss = geom->getStateSet();

		if (m_x >= button.x0 && m_x <= button.x0 + button.w &&
				m_y >= button.y0 && m_y <= button.y0 + button.h)
		{
			ss->setTextureAttributeAndModes(0, button.rollOverState.get(), osg::StateAttribute::ON);
			focusIWantToTake = i;
		}
		else {
			ss->setTextureAttributeAndModes(0, button.normalState.get(), osg::StateAttribute::ON);
		}
	}

	if (focusIWantToTake != model->mCurrentFocus) {
		if (model->mbLMB != true)
			model->mCurrentFocus = focusIWantToTake;
	}

	if (model->mCurrentFocus != -1 && model->mbLMB) {
		if (model->mbClickOnIcon == false) {
			model->mOldRotationPersoX = model->mRotationPersoX;
			model->mTimeSinceLastIconClick = GetRealTime();
			model->mbClickOnIcon = true;
		}
		PokerOutfitModel::Button &button = model->buttons_[model->mCurrentFocus];
		osg::Geometry *geom = button.quad->getGeometry();
		osg::StateSet *ss = geom->getStateSet();
		if (m_x >= button.x0 && m_x <= button.x0 + button.w &&
			m_y >= button.y0 && m_y <= button.y0 + button.h) {
			ss->setTextureAttributeAndModes(0, button.pushedState.get(), osg::StateAttribute::ON);

			if (model->mCurrentFocus == 0) {
				if (model->mOldRotationPersoX < 0)
					model->mRotationPersoX = 0;
				else {
					if (model->mRotationPersoX < 2)
						model->mRotationPersoX = 2;
				}
			}
			else if (model->mCurrentFocus == 1) {
				model->mCurrentFocus = -1;

				model->mSensZoom ^= 1;
				model->mbZoomInProgress = true;
			}
			else if (model->mCurrentFocus == 2) {
				if (model->mOldRotationPersoX > 0)
					model->mRotationPersoX = 0;
				else {
					if (model->mRotationPersoX > -2)
						model->mRotationPersoX = -2;
				}
			}
		}
	}
	else {
		if (model->mbClickOnIcon == true) {
			float deltaTime = GetRealTime() - model->mTimeSinceLastIconClick;
			if (deltaTime > 0.2f)
				model->mRotationPersoX = 0;
			else {
//				if (model->mRotationPersoX != model->mOldRotationPersoX)
//					model->mRotationPersoX = 0;
			}
		}
		model->mbClickOnIcon = false;
	}

	model->mCaracRot._v[0] += model->mRotationPersoX * dt;

	if (m_x >= viewport_x && m_x <= viewport_x + viewport_w &&
		m_y >= viewport_y0 && m_y <= viewport_y0 + viewport_h && model->mbLMB) {

		model->mCaracRot._v[0] += model->mDeltaMouseX;

		model->mRotationPersoX = 0;

		model->mAltitude -= model->mDeltaMouseY; // * 160.0f;
		if (model->mAltitude < -osg::PI/4)
			model->mAltitude = -osg::PI/4;
		else if (model->mAltitude > osg::PI/8)
			model->mAltitude = osg::PI/8;

		if (model->mbDragViewport == false) {
			model->mbDragViewport = true;
		}
	}
	else {
		if (model->mbDragViewport == true) {
			model->mbDragViewport = false;
			model->mRotationPersoX = model->mDeltaMouseX * 50;
			if (model->mRotationPersoX > 5)
				model->mRotationPersoX = 5;
			else if (model->mRotationPersoX < -5)
				model->mRotationPersoX = -5;
		}
	}

//	osgUtil::SceneView *scene = (osgUtil::SceneView*) app->GetScene()->GetModel()->mScene.get();
	//osg::Matrix currentViewMatrix = scene->getViewMatrix();

	osg::Matrix mat;

	// update camera matrix (!in world space!)

//	osg::Vec3f vec = osg::Vec3f(0,  model->mCamPos._v[1] + model->mAltitude, model->mCamPos._v[2]) - osg::Vec3f(0, model->mCamPos._v[1], -220);
	//vec.normalize();
	//model->mCamRot._v[1] = -asin(vec._v[1]);

//	mat = osg::Matrix::translate( -osg::Vec3f(0, 100, -250) );
	//mat.postMult( osg::Matrix::rotate( model->mAltitude, osg::Vec3f(1, 0, 0) ) );
	//mat.postMult( osg::Matrix::translate( osg::Vec3f(0, 100, -250) ) );

	mat = osg::Matrix::identity();
	mat.postMult( osg::Matrix::translate(model->mCamPos) );
	mat.postMult( osg::Matrix::translate(-pv) );
	mat.postMult( osg::Matrix::rotate( model->mAltitude, osg::Vec3f(1, 0, 0) ) );
	mat.postMult( osg::Matrix::translate(pv) );

	osg::Vec3f trans = mat.getTrans();
	if (trans._v[1] < 0)
		model->shadowMatrix_->setNodeMask(0);
	else
		model->shadowMatrix_->setNodeMask(MAF_VISIBLE_MASK);

	/*
	mat = osg::Matrix::rotate(	model->mCamRot.z(), osg::Vec3f(0, 0, 1),
															model->mCamRot.y(), osg::Vec3f(1, 0, 0),
															model->mCamRot.x(), osg::Vec3f(0, 1, 0));
	mat.postMult( osg::Matrix::translate(0, 0, -30) );
	mat.postMult( osg::Matrix::rotate( model->mAltitude, osg::Vec3f(1, 0, 0) ) );
	mat.postMult( osg::Matrix::translate(0, 0, 30) );
	mat.postMult( osg::Matrix::translate(model->mCamPos) );
	*/
	model->sceneView_->setViewMatrix( osg::Matrix::inverse(mat) );

	// update caracter matrix (in world space)
	osg::Vec3f pivotPt(0, 0, -232); // BAD! but Cal3D fuck me out

	mat = osg::Matrix::translate( -pivotPt ) *
				osg::Matrix::rotate(	model->mCaracRot.z(), osg::Vec3f(0, 0, 1),
															model->mCaracRot.y(), osg::Vec3f(1, 0, 0),
															model->mCaracRot.x(), osg::Vec3f(0, 1, 0) ) *
				osg::Matrix::translate( pivotPt );

	//mat.setTrans( caracPos_ );
	model->caracMatrix_->setMatrix( mat );

	return true;
}

void PokerOutfitController::Show()
{
	PokerOutfitModel *model = GetModel();

	model->mCaracRot = osg::Vec3f(0, 0, 0);
	model->mNearFarPosBlend = 0;
	model->mSensZoom = 0;
	model->mAltitude = 0;
	model->mbZoomInProgress = false;

	model->mOldMouseX = model->mApplication->getMouseX();
	model->mOldMouseY = model->mApplication->getMouseY();

  model->GetNode()->setNodeMask(MAF_VISIBLE_MASK);
	//osg::Group *scene = (osg::Group*) GetModel()->mApplication->GetScene()->GetModel()->mScene->getSceneData();
  //scene->addChild(GetModel()->projection_.get());

	//model->mApplication->GetScene()->GetModel()->mGroup->removeChild( model->mApplication->GetPoker()->GetModel()->mSetData->GetGroup() );
	PokerModel *pokerModel = model->mApplication->GetPoker()->GetModel();
	if (pokerModel && pokerModel->mSetData)
		pokerModel->mSetData->GetGroup()->setNodeMask(0);

	model->mApplication->GetWindow(true)->AddView( model->sceneController_->GetView() );
	model->mApplication->mTransformTableName->setNodeMask(0);
}

void PokerOutfitController::Hide()
{
	PokerOutfitModel *model = GetModel();

  model->GetNode()->setNodeMask(0x0);
//	osg::Group *scene = (osg::Group*) GetModel()->mApplication->GetScene()->GetModel()->mScene->getSceneData();
  //scene->removeChild(GetModel()->projection_.get());

//	model->mApplication->GetScene()->GetModel()->mGroup->addChild( model->mApplication->GetPoker()->GetModel()->mSetData->GetGroup() );
	//MAFOSGData *setData = model->mApplication->GetPoker()->GetModel()->mSetData;
	PokerModel *pokerModel = model->mApplication->GetPoker()->GetModel();
	if (pokerModel && pokerModel->mSetData)
		pokerModel->mSetData->GetGroup()->setNodeMask(MAF_VISIBLE_MASK | MAF_COLLISION_MASK);

	model->mApplication->GetWindow(true)->DelView( model->sceneController_->GetView() );
	model->mApplication->mTransformTableName->setNodeMask(MAF_VISIBLE_MASK);
}

void PokerOutfitController::SetSex(std::string _sex)
{
  PokerOutfitModel* model = GetModel();
	osg::Node *node = model->animated_[_sex]->GetModel()->GetNode();
//	if(model->caracMatrix_->getNumChildren() > 0)
  //  model->caracMatrix_->removeChild(0, 1);

	if (model->previewSexNode_) {
		model->caracMatrix_->removeChild(model->previewSexNode_);
		model->shadowMatrix_->removeChild(model->previewSexNode_);
	}

	model->caracMatrix_->addChild(node);
	model->shadowMatrix_->addChild(node);
	//model->shadowMatrix2_->addChild(node);
  model->sex_ = _sex;

	model->previewSexNode_ = node;
}

void PokerOutfitController::SetSlot(std::string _slotType, std::string _slotName, int _slotIndex)
{
	PokerOutfitModel *model = (PokerOutfitModel *) GetModel();
	osgCal::Model *m = model->animated_[model->sex_]->GetModel()->GetArtefact();

	g_debug("SetSlot %s %s %d",_slotType.c_str(),_slotName.c_str(),_slotIndex);
	m->applySlot(_slotType, _slotName, _slotIndex);
  m->setupLayers(_slotType, _slotName, _slotIndex);
  m->setupTLF(_slotType, _slotIndex);
}

void PokerOutfitController::UnSetSlot(std::string _slotType, int _slotIndex)
{
	PokerOutfitModel *model = (PokerOutfitModel *) GetModel();
	osgCal::Model *m = model->animated_[model->sex_]->GetModel()->GetArtefact();
	m->unapplySlot(_slotType, _slotIndex);
}


void PokerOutfitController::SetParam(std::string _parameter, std::string _name, int _value)
{
	PokerOutfitModel *model = (PokerOutfitModel *) GetModel();
	osgCal::Model *m = model->animated_[model->sex_]->GetModel()->GetArtefact();
	//g_debug("send to osgcal %s - %s - %d",_parameter.c_str(),_name.c_str(),_value);
	m->setParam(_parameter, _name, _value);
}

void PokerOutfitModel::StopCallback::process(CalModel *_model, CalAnimationAlt *_animation)
{
	CalScheduler *scheduler = (CalScheduler*)(_model->getAbstractMixer());
	CalAnimationAlt *anim;

	// choose an animation from a list that doesn't contain the old animation
	// that's merely allow to cannot have an animation played twice
	int animCandidate[50];
	int j = 0;
	int nbAnims;
	int iAnim = 0;
	int animID;

	if (maleOrFemale_ == 1) {
		nbAnims = model_->maleAnims_.size();

		for (int i = 0; i < nbAnims; i++) {
			if (i == model_->mLastMalePlayedAnimation)
				continue;
			animCandidate[j++] = i;
		}

		if (model_->mNearFarPosBlend < 0.6f) {
			iAnim = (rand() * j) / (RAND_MAX+1);
			iAnim = animCandidate[iAnim];
		}

		model_->mLastMalePlayedAnimation = iAnim;
		animID = model_->maleAnims_[iAnim].id;

		anim = scheduler->run(CalScheduler::FOREGROUND, animID, CalScheduler::ONCE);
		model_->currentMaleAnim_ = anim;
	}
	else {
		nbAnims = model_->femaleAnims_.size();

		for (int i = 0; i < nbAnims; i++) {
			if (i == model_->mLastFemalePlayedAnimation)
				continue;
			animCandidate[j++] = i;
		}

		if (model_->mNearFarPosBlend < 0.6f) {
			iAnim = (rand() * j) / (RAND_MAX+1);
			iAnim = animCandidate[iAnim];
		}

		model_->mLastFemalePlayedAnimation = iAnim;
		animID = model_->femaleAnims_[iAnim].id;

		anim = scheduler->run(CalScheduler::FOREGROUND, animID, CalScheduler::ONCE);
		model_->currentFemaleAnim_ = anim;
	}

  if (anim)
	  anim->setStopCallback(this);
}
