/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Johan Euphrosine <johan@mekensleep.com>
 *  Cedric Pinson <cpinson@freesheep.org>
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include "pokerStdAfx.h"

#ifdef HAVE_CONFIG_H


#include "config.h"
#endif /* HAVE_CONFIG_H */
#ifdef WIN32
#include <cstdio>
# define snprintf _snprintf
#endif

#ifndef POKER_USE_VS_PCH

#ifdef USE_NPROFILE
#include <nprofile/profile.h>
#else  //USE_NPROFILE
#define NPROFILE_SAMPLE(a)
#endif //USE_NPROFILE

#include <algorithm>

#include <osg/MatrixTransform>
#include <osg/Matrix>
#include <osg/TexGen>
#include <osg/Material>
#include <osg/AutoTransform>
#include <osg/Node>
#include <osg/Geode>
#include <osg/Geometry>
#include <osg/Array>
#include <osg/AnimationPath>
#include <osg/BlendFunc>
#include <osg/Stencil>
#include <osg/Depth>

#include <osgDB/ReaderWriter>
#include <osgDB/FileNameUtils>
#include <osgDB/FileUtils>
#include <osgDB/ReadFile>

#include <osgCal/SubMeshHardware>
#include <osgCal/SubMeshSoftware>

#include <maf/maferror.h>
#include <maf/autoscale.h>
#include <maf/osghelper.h>
#include <maf/scene.h>
#include <maf/split.h>
#include <maf/renderbin.h>
#include <maf/scene.h>
#include <maf/packets.h>
#include <maf/shadow.h>
#include <maf/utils.h>
#include <maf/window.h>
#include <maf/depthmask.h>
#include <maf/glow_fx.h>
#include <maf/MultipleAnimationPathCallback.h>
#include <maf/assert.h>
#include <maf/shader.h>
#include <maf/assert.h>

#include <varseditor/varseditor.h>

#include <ugame/animated.h>
#include <ugame/debug.h>
#include <ugame/timeout.h>
#include "PokerMoveChips.h"
#include "PokerSound.h"

#	include "PokerPlayerCamera.h"
#	include "PokerApplication.h"
#	include "PokerChipsStack.h"
#	include "PokerCard.h"
#	include "PokerChipsStack.h"
#	include "PokerPlayer.h"
#	include "PokerBubble.h"
#	include "PokerBody.h"
# include "PokerCursor.h"
# include "PokerSceneView.h"
# include "PokerPlayerTimeout.h"
# include "PokerMultiTable.h"

#include <osgAL/SoundManager>

#endif


// this flag should be remove later
#define NB_SOUND_PER_PLAYER 10
#define MAX_ANIMATION_CARD_TO_PLAY 4


//#define TUNE_SOUND_PLAYER // uncomment this line to control sound in game for your main player

#if 1
static void Plop()
{
  ;
}
#endif

class CallbackTimeoutSound : public UGAMETimeOut::Callback
{
	typedef std::map<int,osg::ref_ptr<MAFAudioController> > SoundContainer;
	SoundContainer mSounds;
protected:
	virtual ~CallbackTimeoutSound() {}

public:

	bool Init(PokerApplication* game) {

		const std::list<std::string> &sounds_names = game->HeaderGetList("sequence", "/sequence/player_timeout/sound/sound_time/@name");
 		const std::list<std::string> &sounds_volumes = game->HeaderGetList("sequence", "/sequence/player_timeout/sound/sound_time/@volume");
 		const std::list<std::string> &sounds_times = game->HeaderGetList("sequence", "/sequence/player_timeout/sound/sound_time/@time");
		if (sounds_times.size() != sounds_volumes.size() && sounds_times.size() != sounds_names.size()) {
			g_error("CallbackTimeoutSound::Init error size of parameters list (name, volume, time) have not the same size, check player_timeout/sound/sound_time in client.xml");
		}

		std::list<std::string>::const_iterator sounds_time_it = sounds_times.begin();
		std::list<std::string>::const_iterator sounds_name_it = sounds_names.begin();
		std::list<std::string>::const_iterator sounds_volume_it = sounds_volumes.begin();
		for(;sounds_name_it != sounds_names.end();) {
			
			const std::string &name = *sounds_name_it;
			const std::string &volume = *sounds_volume_it;
			const std::string &time = *sounds_time_it;
			
			if (time.empty())
 				g_error("CallbackTimeoutSound::Init can't use an empty sound time check player_timeout/sound/sound_time in client.xml !!!");
			int key = atoi(time.c_str());

			if (name.empty())
 				g_error("CallbackTimeoutSound::Init can't use an empty sound name check player_timeout/sound/sound_time in client.xml !!!");

			MAFAudioData *data = game->mDatas->GetAudio(name);
			if (data) {
				float v = atof(volume.c_str());

				MAFAudioModel* audio_model = new MAFAudioModel;
				audio_model->SetName(name);
				audio_model->SetData(data);
				audio_model->SetAmbient(true);
				audio_model->SetSoundEvent(true);
				audio_model->SetGain(v);
				MAFAudioController* audio_controller = new MAFAudioController;
				audio_controller->SetModel(audio_model);
				audio_controller->Init();
				mSounds[key] = audio_controller;
			}
		}
		return true;
	}

	virtual void operator()(int second)
	{
		SoundContainer::iterator it = mSounds.find(second);
		if ( it != mSounds.end())
			it->second->Play();
		else
			g_warning("CallbackTimeoutSound::operator() sound with key %d not found",second);
	}

};


void PokerPlayer::GetExcludeMesh(const std::string& skinUrl, std::vector<std::string>& mesh)
{
  //	const std::string& dataPath = mGame->HeaderGet("settings", "/settings/data/@path");
	MAFXmlData *data = 0;
	data = mGame->mDatas->GetXml(skinUrl + "/cal3d.xfg");

	// get all meshs that have the attribute specificto != the current level
	const std::string& currentLevel = mGame->mDatas->GetLevel();
	const std::string& base = "//library/mesh[@specificto!=\"";
	const std::string& base2 =  base + currentLevel + "\"]/@name";
	mesh.clear();

	std::list<std::string> result = data->GetList(base2);
	for (std::list<std::string>::iterator it = result.begin(); it != result.end(); it++)
		mesh.push_back(*it);
}


void PokerPlayer::HasRunAnimationBet(bool flag) { mHasRunAnimationBet = flag;}
bool PokerPlayer::HasRunAnimationBet() const { return mHasRunAnimationBet;}

PokerPlayer::PokerPlayer(PokerApplication *game,
												 unsigned int controllerID,
												 bool me,
												 const std::string &skinUrl,
												 const std::string& skinOutfitXML) :
MAFController(controllerID), mGame(game), mSeatId(POKER_PLAYER_NO_SEAT), mInGame(false), mSit(false), mCamera(0),
mMe(me), mStandUpAnimationId(-1), mMoveTimeout(0.0), mSitInTimeout(0.0), mClickOnChair(false),mTimerInFirstPerson(false),mShadowFlag(false), mHasRunAnimationBet(false)
{
#ifdef USE_NPROFILE
		double st1 = nprf::GetRealTime();
#endif

  const std::string& dataPath = mGame->HeaderGet("settings", "/settings/data/@path");

	bSentRaisePacket = false;
	bSentCheckPacket = false;
	bSentCallPacket = false;
	bSentFoldPacket = false;
  mHasReceivedABetStackOnTable=false;
  mAnimationPlayerBet=mAnimationPlayerGetPot=false;

  mSyncBetStackWithPacket=true;
  mLastPot2Player=0;

	// create objects, in

  //
  // Create objects
  //
  const std::string &shadow = game->HeaderGet("settings", "/settings/shadow");
  if (shadow == "on" || shadow == "yes")
    mShadowFlag=true;

  //
  // Interaction objects
  //
	{
 		const std::list<std::string> &interactors = game->HeaderGetList("sequence", "/sequence/interactor/@name");
		for(std::list<std::string>::const_iterator i = interactors.begin();
			i != interactors.end();
			i++) {

			const std::string &name = *i;
			const std::string &url = game->HeaderGet("sequence", "/sequence/" + name + "/@url");
			MAFOSGData* data = dynamic_cast<MAFOSGData*>(game->mDatas->GetVision(url));

			data = (MAFOSGData*)data->Clone(LEVEL_CLONE_SETTING);

			osg::Geode *pos_mark = OSGHelper_getGeodeByName(*data->GetGroup(), "mesh_posMark");
			if (!pos_mark)
				g_error("PokerPlayer: \"mesh_posMark\" is missing from the scene");

			osg::StateSet *pos_state = pos_mark->getDrawable(0)->getOrCreateStateSet();

			if (!MAFRenderBin::Instance().SetupRenderBin("ButtonPosition", pos_mark->getOrCreateStateSet()))
				MAF_ASSERT(0 && "ButtonPosition not found in client.xml");

			osg::TexGen *texgen = new osg::TexGen;
			texgen->setMode(osg::TexGen::NORMAL_MAP);
			pos_state->setTextureAttributeAndModes(0, texgen, osg::StateAttribute::ON);

			osg::TexMat *texmat = new osg::TexMat;
			osg::Matrix mat = osg::Matrix::scale(0.5f, 0.5f, 0);
			mat(3, 0) = 0.5f;
			mat(3, 1) = 0.5f;
			texmat->setMatrix(mat);
			pos_state->setTextureAttributeAndModes(0, texmat, osg::StateAttribute::ON);

			std::string texName = dataPath + "/level00/position/refarrow.jpg";
			osg::Texture2D *envTex = MAFApplication::GetTextureManager()->GetTexture2D(texName, NULL);
			pos_state->setTextureAttributeAndModes(0, envTex);

			osg::TexEnvCombine *envCombine;
			envCombine = new osg::TexEnvCombine;
			envCombine->setCombine_RGB(GL_ADD);
			envCombine->setCombine_Alpha(GL_REPLACE);

			envCombine->setSource0_RGB(GL_PREVIOUS_ARB);
			envCombine->setSource0_Alpha(GL_PREVIOUS_ARB);
			envCombine->setOperand0_RGB(GL_SRC_COLOR);
			envCombine->setOperand0_Alpha(GL_SRC_ALPHA);

			envCombine->setSource1_RGB(GL_TEXTURE);
			envCombine->setSource1_Alpha(GL_TEXTURE);
			envCombine->setOperand1_RGB(GL_SRC_COLOR);
			envCombine->setOperand1_Alpha(GL_SRC_ALPHA);
			pos_state->setTextureAttributeAndModes(0, envCombine, osg::StateAttribute::ON);

			mGlowLightMap = OSGHelper_getGeodeByName(*data->GetGroup(), "mesh_posGlow");

			if (!mGlowLightMap)
				g_error("PokerPlayer: \"mesh_posGlow\" is missing from the scene");

			mInteractors[name] = new UGAMEArtefactController();
			mInteractors[name]->Init();
			mInteractors[name]->Displayed(false);
			mInteractors[name]->GetModel()->SetData(data);
			mInteractors[name]->GetModel()->SetArtefact(data->GetGroup());
		}
	}

  unsigned int copyop=osg::CopyOp::DEEP_COPY_OBJECTS | osg::CopyOp::DEEP_COPY_NODES | osg::CopyOp::DEEP_COPY_DRAWABLES | osg::CopyOp::DEEP_COPY_STATESETS; //| osg::CopyOp::DEEP_COPY_STATEATTRIBUTES;

  //
  // Seat
  //

  {
    std::string seat_name = game->HeaderGet("sequence", "/sequence/seat/@url");
    mSeatData = dynamic_cast<MAFOSGData*>(game->mDatas->GetVision(seat_name)->Clone(copyop));

    UGAMEArtefactModel* vision_model = new UGAMEArtefactModel;
    vision_model->SetData(mSeatData);
    mSeat = new UGAMEArtefactController;
    mSeat->SetModel(vision_model);
    mSeat->Init();
    vision_model->SetArtefact(mSeatData->GetGroup());
  }

  //
  // Cards
  //
  {
    std::string hand_url = game->HeaderGet("sequence", "/sequence/hand/@url");
    std::string hand_count = game->HeaderGet("sequence", "/sequence/hand/@count");
    int count = atoi(hand_count.c_str());
    for(int i = 0; i < count; i++) {
      mHole.push_back(new PokerCardController(game, hand_url,controllerID));
    }
    mShowdown = new PokerShowdownController(game, mSeatData,controllerID);
    game->AddController(mShowdown.get());
  }

	Plop();

  std::string skinUrlUsed=skinUrl;
  {
    //		const std::string &player = game->HeaderGet("sequence", "/sequence/player/@url");

    std::string skinUrlDefault = game->HeaderGet("sequence", "/sequence/skin/default/@url");
    if(skinUrlDefault.empty())
      g_error("PokerPlayer::PokerPlayer: /sequence/skin/default/@url does not define a default url");

    if (skinUrlUsed=="default")
      skinUrlUsed=skinUrlDefault;

    osg::ref_ptr<osgDB::ReaderWriter::Options> options = new osgDB::ReaderWriter::Options;
    options->setObjectCacheHint(osgDB::ReaderWriter::Options::CACHE_ALL);

    osgCal::CoreModel* data=0;
    data=dynamic_cast<osgCal::CoreModel*>(osgDB::readObjectFile(skinUrlUsed + "/cal3d.xfg",options.get()));
    g_debug("Cache %p for url %s", data, skinUrlUsed.c_str());
    if (!data) {
      if (skinUrlUsed==skinUrlDefault)
        g_error("PokerPlayer::PokerPlayer: skin url %s not found",skinUrlUsed.c_str());
      else {
        g_warning("PokerPlayer::PokerPlayer: skin url %s not found use default %s instead",
                  skinUrlUsed.c_str(),
                  skinUrlDefault.c_str());

        skinUrlUsed=skinUrlDefault;
        data=dynamic_cast<osgCal::CoreModel*>(osgDB::readObjectFile(skinUrlUsed + "/cal3d.xfg",options.get()));
        if (!data) {

          g_critical("PokerPlayer::PokerPlayer: default skin url %s not found",skinUrlDefault.c_str());
          // last solution is to use an entry in local url

          std::list<std::string> skinUrlRescueList = game->HeaderGetList("sequence", "/sequence/skin/path/@url");
          if (skinUrlRescueList.empty())
            g_error("PokerPlayer::PokerPlayer: no url specified for skin ???");

          skinUrlUsed=skinUrlRescueList.front();

          data=dynamic_cast<osgCal::CoreModel*>(osgDB::readObjectFile(skinUrlUsed + "/cal3d.xfg",options.get()));
          if (!data)
            g_error("PokerPlayer::PokerPlayer: your configuration is broken post to underware-devel@gna.org or update your client");
        }
      }
    }

		bool bUseVertexProgram = MAFShader::getTechnicAuthorisation() & MAFShader::TECHNIC_AUTHORISATION_VERTEX_PROGRAM;

    osgCal::Model* model = new osgCal::Model;

    {
			osgUtil::SceneView *sceneView = game->GetScene()->GetModel()->mScene.get();
      osg::Group* scene = (osg::Group*) sceneView->getSceneData();
      osg::Group* group = (osg::Group*) new osg::Group;
      group->setNodeMask(MAF_VISIBLE_MASK);
      scene->addChild(group);

			model->setFXGroup( PokerSceneView::getInstance()->m_TLFGroup.get() );
			model->setFXState( PokerSceneView::getInstance()->m_TLFState.get() );
    }


		std::vector<std::string> excludeMesh;
		GetExcludeMesh(skinUrlUsed,excludeMesh);
		
    model->setCoreModel(data);
    model->setUseVertexProgram(bUseVertexProgram);

#ifdef USE_NPROFILE
		double st2 = nprf::GetRealTime() - st1;
		osg::notify(osg::WARN) << "OSGCAL: interaction objects, seat, cards: " << int(st2*1000) << "ms" << std::endl;
#endif

#ifdef USE_NPROFILE
		double time = nprf::GetRealTime();
#endif

    if (!model->initOutfitFromXMLString(skinOutfitXML,&excludeMesh)) {
			g_debug("PokerPlayer::PokerPlayer can't load outfit");
			assert(0);
		}

    mBody = new PokerBodyController(game,mSeatData,controllerID,mMe);

		//model = new osgCal::Model(*model);
    mBody->GetModel()->SetOsgCalModel(model);

    const std::string &dataPath = game->HeaderGet("settings", "/settings/data/@path");
    mBody->SetDataPath(dataPath+G_DIR_SEPARATOR_S+skinUrlUsed);
    mBody->SetDeck(game->mDeck);

    if(game->HeaderGet("sequence", "/sequence/player/@animated") == "no")
      mBody->GetModel()->DisableAnimations();

#ifdef USE_NPROFILE
		double time2 = nprf::GetRealTime();
#endif

		mBody->Init();

#ifdef USE_NPROFILE
		time2 = nprf::GetRealTime() - time2;
		osg::notify(osg::WARN) << "OSGCAL: INIT of BODY took " << int(time2*1000) << "ms" << std::endl;
#endif

    model->applyParameterFromOutfitDescription();

#ifdef USE_NPROFILE
		time = nprf::GetRealTime() - time;
		osg::notify(osg::WARN) << "OSGCAL: Creation of BODY took " << int(time*1000) << "ms" << std::endl;
#endif

    game->AddController(mBody.get());
  }

#ifdef USE_NPROFILE
	double tt1 = nprf::GetRealTime();

	double ta, tb;
#endif

  //
  // Money & bet stack of the player
  //
#ifdef USE_NPROFILE
	ta = nprf::GetRealTime();
#endif // USE_NPROFILE
  {
    mMoneyStack = new PokerChipsStackController(game,controllerID);
    const std::string& name = game->HeaderGet("sequence", "/sequence/money/@anchor");
    MAFAnchor* anchor = mSeatData->GetAnchor(name);
    if(anchor == 0)
      g_error("PokerPlayer::PokerPlayer: anchor %s not found", name.c_str());
    else
      mMoneyStack->Anchor(anchor);
    mMoneyStack->SetSelectable(true);
    game->AddController(mMoneyStack.get());

		// add collision from root to transform
		osg::NodePath pathToAddCollisionMask;
		MAFCreateNodePath(anchor, pathToAddCollisionMask);
		for (osg::NodePath::iterator it = pathToAddCollisionMask.begin(); it != pathToAddCollisionMask.end(); it++) {
			unsigned int mask = (*it)->getNodeMask();
			mask =  mask | MAF_COLLISION_MASK;
			(*it)->setNodeMask(mask);
		}
  }
#ifdef USE_NPROFILE
	tb = nprf::GetRealTime() - ta;

	ta = nprf::GetRealTime();
#endif // USE_NPROFILE
  {
    mBetStack = new PokerChipsStackController(game,controllerID);
    const std::string& name = game->HeaderGet("sequence", "/sequence/bet/@anchor");
    MAFAnchor* anchor = mSeatData->GetAnchor(name);
    if(anchor == 0)
      g_error("PokerPlayer::PokerPlayer: anchor %s not found", name.c_str());
    else
      mBetStack->Anchor(anchor);

		// add collision from root to transform
		osg::NodePath pathToAddCollisionMask;
		MAFCreateNodePath(anchor, pathToAddCollisionMask);
		for (osg::NodePath::iterator it = pathToAddCollisionMask.begin(); it != pathToAddCollisionMask.end(); it++) {
			unsigned int mask = (*it)->getNodeMask();
			mask =  mask | MAF_COLLISION_MASK;
			(*it)->setNodeMask(mask);
		}

    mBetStack->SetSelectable(true);
    if(mMe) {
      mBetStack->CreateShadowStacks(game);
      mBetStack->CreateSlider(game);
    }
    game->AddController(mBetStack.get());
  }
#ifdef USE_NPROFILE
	tb = nprf::GetRealTime() - ta;
#endif // USE_NPROFILE

  mInPosition = false;

  char tmp[128];

  //
  // Move interaction objects
  //
#ifdef USE_NPROFILE
	ta = nprf::GetRealTime();
#endif // USE_NPROFILE
  {
    std::list<std::string> interactors = game->HeaderGetList("sequence", "/sequence/interactor/@name");
    for(std::list<std::string>::iterator i = interactors.begin();
        i != interactors.end();
        i++) {
      std::string name = *i;

      std::string anchor_name = mGame->HeaderGet("sequence", "/sequence/" + name + "/@anchor");
      MAFAnchor* anchor = mSeatData->GetAnchor(anchor_name);
      g_assert(anchor != 0);
      mInteractors[name]->Anchor(anchor);

    }
  }
#ifdef USE_NPROFILE
	tb = nprf::GetRealTime() - ta;
#endif // USE_NPROFILE

  //
  // Move Cards
  //
#ifdef USE_NPROFILE
	ta = nprf::GetRealTime();
#endif // USE_NPROFILE
  {
    std::string anchor_card = mGame->HeaderGet("sequence", "/sequence/hand/@anchor");
    std::string hand_count = mGame->HeaderGet("sequence", "/sequence/hand/@count");

    mHole.resize(atoi(hand_count.c_str()));
    for(unsigned int i = 0; i < mHole.size(); i++) {
      snprintf(tmp, sizeof(tmp), anchor_card.c_str(), ('A' + i));
      mHole[i]->Anchor(mSeatData->GetAnchor(tmp));
    }
  }
#ifdef USE_NPROFILE
	tb = nprf::GetRealTime() - ta;
#endif // USE_NPROFILE

  //
  // Move body
  //
#ifdef USE_NPROFILE
	ta = nprf::GetRealTime();
#endif // USE_NPROFILE
  {
    std::string anchor_player = mGame->HeaderGet("sequence", "/sequence/player/@anchor");
		MAFAnchor * panchor = mSeatData->GetAnchor(anchor_player);
    mBody->Anchor(panchor);
		mBody->SetSelectable(true);

		// add collision from root to transform
		osg::NodePath pathToAddCollisionMask;
		MAFCreateNodePath(panchor, pathToAddCollisionMask);
		for (osg::NodePath::iterator it = pathToAddCollisionMask.begin(); it != pathToAddCollisionMask.end(); it++) {
			unsigned int mask = (*it)->getNodeMask();
			mask =  mask | MAF_COLLISION_MASK;
			(*it)->setNodeMask(mask);
		}
  }
#ifdef USE_NPROFILE
	tb = nprf::GetRealTime() - ta;
#endif // USE_NPROFILE

  // Bubble 
  std::string displayBubble = mGame->HeaderGet("sequence", "/sequence/bubble/@enable");
  mDisplayBubble = (displayBubble == "yes");
//   if (mDisplayBubble)
//     {
//       //if (mMe)
//       {
//         const std::string &anchor = mGame->HeaderGet("sequence", "/sequence/bubble/@anchor");
//         mBubble = new PokerBubbleController(mGame, mSeatData->GetAnchor(anchor));
//         mBubble->Anchor(game->GetScene()->GetModel()->mGroup.get());
//         game->AddController(mBubble.get());
//       }
//     }

  // init time waiting
  mTimePlaying=0;
  mTimeWaiting=0;
  mTimeNoise=0;
  mInternalTime=0;

	mTimeout = new UGAMETimeOut();

  if(mMe) {
		// Camera parameters
    PokerCameraController* camera = dynamic_cast<PokerCameraController*>(mGame->GetScene()->GetModel()->mCamera.get());
    std::map<std::string, std::string> params = game->HeaderGetProperties("sequence", "/sequence/cameras");
    mCamera = new PokerPlayerCamera(camera, params);


		mPPTimeout = new PokerPlayerTimeout(game, mSeatData, mTimeout.get());
		game->AddController(mPPTimeout.get());

#if 0
		// not tested yet i need to finish sound tuning before using that
		if (mGame->GetScene()->GetModel()->GetAudio())
			mTimeout->SetCallback(new CallbackTimeoutSound(game));
#endif
  }


  // SitIn/Out Timeout
  if (mMe) {
    int sitInId = GetBody()->GetCoreAnimationId("seatDown");
    mSitInTimeout = GetBody()->GetDuration(sitInId);
  }

  /// chips animations
#ifdef USE_NPROFILE
	ta = nprf::GetRealTime();
#endif // USE_NPROFILE
  {
    std::string playerChipsAnchor = mGame->HeaderGet("sequence", "/sequence/player/@betzone");
    osg::Node* playerChipsAnchorNode=mSeatData->GetAnchor(playerChipsAnchor);
    assert(playerChipsAnchorNode);

    std::string playerBetZone = mGame->HeaderGet("sequence", "/sequence/player/@betzone");
    osg::Node* playerBetZoneNode=mSeatData->GetAnchor(playerBetZone);
    assert(playerBetZoneNode);


    /// from player to bet
    const std::string basePath="/sequence/seat/animationBetPlayer";
    const std::string skinBase="[@skinUrl=\""+skinUrlUsed+"\"]/";
    const std::string anchorAnimationName=game->HeaderGet("sequence",basePath+skinBase+ "@anchor");
    if (anchorAnimationName.empty())
      g_error("PokerPlayer::PokerPlayer bet animation anchor not found for skin url %s in client.xml",skinUrlUsed.c_str());
    MAFAnchor* anchorAnimationBet=mSeatData->GetAnchor(anchorAnimationName.c_str());
    if (!anchorAnimationBet)
      g_error("PokerPlayer::PokerPlayer bet animation anchor %s not found",anchorAnimationName.c_str());

    osg::MatrixTransform* atr=anchorAnimationBet->asGroup()->asTransform()->asMatrixTransform();
    if (!atr->getUpdateCallback())
      g_error("PokerPlayer::PokerPlayer no animation found in node %s",anchorAnimationName.c_str());

    osg::MultipleAnimationPathCallback* cb=dynamic_cast<osg::MultipleAnimationPathCallback*>(atr->getUpdateCallback());
    if (!cb)
      g_error("PokerPlayer::PokerPlayer update call back not found in node %s",anchorAnimationName.c_str());

    atr->setNodeMask(0);
    unsigned int copyop2=osg::CopyOp::DEEP_COPY_OBJECTS | osg::CopyOp::DEEP_COPY_NODES;
    mAnimationBet=(osg::MatrixTransform*)atr->clone(copyop2);
    mAnimationBet->setNodeMask(MAF_VISIBLE_MASK);
    mAnimationBetCallback = new osg::MultipleAnimationPathCallback(*cb);
    mAnimationBet->setUpdateCallback(mAnimationBetCallback);
    
    std::list<std::string> mapNameList;
    std::list<std::string> mapAnimationNameList;
    std::list<std::string> mapAnimationScaleList;

    mapNameList=game->HeaderGetList("sequence",basePath+skinBase+"animation/@map");
    mapAnimationNameList=game->HeaderGetList("sequence",basePath+skinBase+"animation/@name");
    mapAnimationScaleList=game->HeaderGetList("sequence",basePath+skinBase+"animation/@timeScale");
    
    if (mapAnimationScaleList.empty() || !(mapAnimationScaleList.size() == mapAnimationNameList.size() && mapAnimationNameList.size()== mapNameList.size()))
      g_error("PokerPlayer::PokerPlayer onfiguration error in <animation ...> entry for bet player %s",skinUrlUsed.c_str());
    int end=(int)mapNameList.size();
    std::list<std::string>::iterator itName=mapNameList.begin();
    std::list<std::string>::iterator itAnimationName=mapAnimationNameList.begin();
    std::list<std::string>::iterator itAnimationScale=mapAnimationScaleList.begin();
    for (int i=0;i<end;i++) {

      mMapAnimationBet[*itName]=*itAnimationName;
      mMapAnimationBetTimeScale[*itName]=atof((*itAnimationScale).c_str());

      osg::AnimationPath* pt=mAnimationBetCallback->getAnimationPath(*itAnimationName);
      if (!pt)
        g_error("PokerPlayer::PokerPlayer animation %s not found in scene",(*itAnimationName).c_str());

      pt->setLoopMode(osg::AnimationPath::NO_LOOPING);
      
      itName++;
      itAnimationScale++;
      itAnimationName++;
    }
    atr->getParent(0)->addChild(mAnimationBet.get());
    mAnimationBetChipStack=new PokerChipsStackController(game,controllerID);
    mAnimationBetChipStack->Anchor(mAnimationBet.get());
		mAnimationBetChipStack->GetModel()->GetNode()->setNodeMask(0);
		mAnimationBetChipStack->SetSelectable(true);
		//mAnimationBet->setName("AnimationBetNode");
    game->AddController( mAnimationBetChipStack.get());

		// add collision from root to transform
		osg::NodePath pathToAddCollisionMask;
		MAFCreateNodePath(mAnimationBet.get(), pathToAddCollisionMask);
		for (osg::NodePath::iterator it = pathToAddCollisionMask.begin(); it != pathToAddCollisionMask.end(); it++) {
			unsigned int mask = (*it)->getNodeMask();
			mask =  mask | MAF_COLLISION_MASK;
			(*it)->setNodeMask(mask);
		}

		// here it's a chipsstack to manage the pot2player result
    osg::Group* playerBetZoneNodeGroup=dynamic_cast<osg::Group*>(playerBetZoneNode);
		mPot2PlayerChipStack=new PokerChipsStackController(game,controllerID);
		g_assert(playerBetZoneNodeGroup);
		mPot2PlayerChipStack->Anchor(playerBetZoneNodeGroup);
		mPot2PlayerChipStack->GetModel()->GetNode()->setNodeMask(0);
		mPot2PlayerChipStack->SetSelectable(true);
		game->AddController(mPot2PlayerChipStack.get());

  }
#ifdef USE_NPROFILE
	tb = nprf::GetRealTime() - ta;
#endif // USE_NPROFILE


	// get blink eye from configuration file
  std::map<std::string,std::string> eyes = game->HeaderGetProperties("sequence", "/sequence/animation/blinkeye");
	if (eyes.find("min_random") == eyes.end())
		g_error("PokerOutfit::PokerOutfit need min_random in /sequence/animation/blinkeye");
	if (eyes.find("max_random") == eyes.end())
		g_error("PokerOutfit::PokerOutfit need max_random in /sequence/animation/blinkeye");
	mEyeRandomMin = atof(eyes["min_random"].c_str());
	mEyeRandomMax = atof(eyes["max_random"].c_str());

  if (mMe) {	
    mFoldInteractor = new PokerInteractorFold(controllerID);
    mFoldInteractor->Init(game, mSeatData, "/sequence/interactors3d/fold/");

    mCheckInteractor = new PokerInteractorCheck(controllerID);
    mCheckInteractor->Init(game, mSeatData, "/sequence/interactors3d/check/");

    mCallInteractor = new PokerInteractorCall(controllerID);
    mCallInteractor->Init(game, mSeatData, "/sequence/interactors3d/call/");
		mCallInteractor->GetModel()->GetPAT()->setPosition( mCallInteractor->GetModel()->GetPAT()->getPosition());

    mRaiseInteractor = new PokerInteractorRaise(controllerID);
    mRaiseInteractor->Init(game, mSeatData, "/sequence/interactors3d/raise/");
		mRaiseInteractor->GetModel()->GetPAT()->setPosition( mRaiseInteractor->GetModel()->GetPAT()->getPosition());
		mRaiseInteractor->mbRaise = true;
  }


  mBeginPos = osg::Vec3(0.0f, 0.0f, 0.0f);
  mCurrentPos = osg::Vec3(0.0f, 0.0f, 0.0f);
  mDeltaPos = osg::Vec3(0.0f, 0.0f, 0.0f);
  mDeltaSet = false;
  mDiffPosLengthLimit = atof(game->HeaderGet("sequence", "/sequence/seat/sitout/@lengthToChooseDir").c_str());
  mDeltaIncrement = atof(game->HeaderGet("sequence", "/sequence/seat/sitout/@step").c_str());


  // card animation
  {
    const std::string& animate = game->HeaderGet("sequence", "/sequence/seat/@animation1card").c_str();
    if (animate.empty())
      g_error("PokerPlayer::PokerPlayer /sequence/seat/@animation1card not found");
    MAFAnchor* aa=mSeatData->GetAnchor(animate.c_str());
    if (!aa)
      g_error("PokerPlayer::PokerPlayer /sequence/seat/@animation1card not found");
    osg::MatrixTransform* atr=aa->asGroup()->asTransform()->asMatrixTransform();
    if (!atr->getUpdateCallback())
      g_error("PokerPlayer::PokerPlayer no animation found in node %s",animate.c_str());
    osg::MultipleAnimationPathCallback* cb=dynamic_cast<osg::MultipleAnimationPathCallback*>(atr->getUpdateCallback());
    if (!cb)
      g_error("PokerPlayer::PokerPlayer update call back not found");


    const std::string& paramMultiplier = game->HeaderGet("sequence", "/sequence/seat/@timeScale").c_str();
    if (paramMultiplier.empty())
      g_error("PokerPlayer::PokerPlayer /sequence/seat/@timeScale not found");
    float mParamMultiplier=atof(paramMultiplier.c_str());

    atr->setNodeMask(0);
    //		unsigned int copyop=osg::CopyOp::DEEP_COPY_ALL;
    unsigned int copyop2=osg::CopyOp::DEEP_COPY_OBJECTS | osg::CopyOp::DEEP_COPY_NODES;// | osg::CopyOp::DEEP_COPY_DRAWABLES | osg::CopyOp::DEEP_COPY_STATESETS;// | osg::CopyOp::DEEP_COPY_STATEATTRIBUTES;
    for (int i=0;i<MAX_ANIMATION_CARD_TO_PLAY;i++) {
      osg::MatrixTransform* natr=(osg::MatrixTransform*)atr->clone(copyop2);
      mAnimate1Card.push_back(natr);
      natr->setNodeMask(~(MAF_VISIBLE_MASK | MAF_COLLISION_MASK));
      osg::MultipleAnimationPathCallback* ncb=new osg::MultipleAnimationPathCallback(*cb);
      ncb->setTimeMultiplier(mParamMultiplier);
      natr->setUpdateCallback(ncb);
      osg::AnimationPath* pt=ncb->getAnimationPath();
      assert(pt);
      pt->setLoopMode(osg::AnimationPath::NO_LOOPING);
      atr->getParent(0)->addChild(natr);
      mAnimate1CardAnchor = atr->getParent(0);  
    }
    mCurrent1Card=0;
  }

  FoldHoleCards();

	mSoundSource=new MAFAudioSourceController();
	//    const std::string& anchor_player = mGame->HeaderGet("sequence", "/sequence/player/@anchor");
	std::string soundDirectoryForPlayer=skinUrlUsed+"/sounds/sounds.xml";

	MAFXmlData *data=0;
	try {
		data = game->mDatas->GetXml(soundDirectoryForPlayer);
	} catch (...) {
		g_warning("Disable sound for player. %s not found",soundDirectoryForPlayer.c_str());
		data = 0;
	}

#ifdef USE_NPROFILE
	ta = nprf::GetRealTime();
#endif // USE_NPROFILE

	if (data) {
		std::vector<SoundInit> params;
		LoadSoundSettings(params,data);

		for (unsigned int i=0;i<params.size();i++) {
			const std::string& n=params[i].mName;
			GetSound(params[i],skinUrlUsed+"/sounds");
			mSoundSource->GetModel()->mSounds[n]=params[i].mParam;
		}

		if (mMe) {
			const std::string& sound_url = mGame->HeaderGet("sequence","/sequence/player/@soundInPosition");
			if (sound_url.empty())
				g_debug("PokerPlayer::PokerPlayer %s not found", sound_url.c_str());
			else {
				MAFAudioData *data = mGame->mDatas->GetAudio(sound_url);
				if (data) {
					MAFAudioModel::MAFAudioParameter param;
					param.mAmbient = true;
					param.mName = "MeInPosition";
					param.mData = data;
					param.mPriority = 2;
					mSoundSource->GetModel()->mSounds["MeInPosition"] = param;
				}
			}
		}

		{
			const std::string& sound_url = mGame->HeaderGet("sequence","/sequence/player/@soundPlayerArrive");
			if (sound_url.empty())
				g_debug("PokerPlayer::PokerPlayer %s not found", sound_url.c_str());
			else {
				MAFAudioData *data = mGame->mDatas->GetAudio(sound_url);
				if (data) {
					MAFAudioModel::MAFAudioParameter param;
					param.mAmbient = true;
					param.mName = "PlayerArrive";
					param.mData = data;
					param.mPriority = 2;
					mSoundSource->GetModel()->mSounds["PlayerArrive"] = param;
				}
			}
		}

		mSoundSource->Init();

		// init with a sound to avoid warning message
		mSoundSource->Play(params[0].mName);
		mSoundSource->Stop();

	} else
		g_critical("PokerPlayer::PokerPlayer config file %s not found",soundDirectoryForPlayer.c_str());
	std::string anchorSound="transform_btok";
	mSoundSource->AttachTo(mSeatData->GetAnchor(anchorSound));
	mBody->GetModel()->BuildAnimationSoundMap(mSoundSource.get());

#ifdef USE_NPROFILE
	tb = nprf::GetRealTime() - ta;
	ta = nprf::GetRealTime();
#endif // USE_NPROFILE
  {
  const std::string& dataPath=mGame->HeaderGet("sequence", "/sequence/player/@dealer_button");
  if (dataPath.empty())
    g_error("PokerPlayer::PokerPlayer /sequence/player/@dealer_button not found in client.xml");
  MAFAnchor* ac=mSeatData->GetAnchor(dataPath);
  if (!ac)
    g_error("PokerPlayer::PokerPlayer %s not found in seat",dataPath.c_str());
  mAnimationDealer=ac->asGroup()->asTransform()->asMatrixTransform();
  mAnimationDealer->setNodeMask(0);

	osg::MultipleAnimationPathCallback* dealerUpdateCallback = dynamic_cast<osg::MultipleAnimationPathCallback*>(mAnimationDealer->getUpdateCallback());
	if (!dealerUpdateCallback)
		g_error("PokerPlayer::PokerPlayer dealer button does not contain a osg::MultipleAnimationPathCallback");
	
	mAnimationDealer->setUpdateCallback(new osg::MultipleAnimationPathCallback(*dealerUpdateCallback));

  }

  // init mousestate with the PokerCursor
  // A refactory is needed about mouse/cursor system !!!
  mMouseState.Init(game->mCursor);

  bPlayed_ = false;
  lastActionRot_ = 0;

#ifdef USE_NPROFILE
	tb = nprf::GetRealTime() - ta;
	ta = nprf::GetRealTime();
#endif // USE_NPROFILE
	{
		const std::string &dataPath = game->HeaderGet("settings", "/settings/data/@path");

		std::string anchor_player = mGame->HeaderGet("sequence", "/sequence/bet/@anchor");
		mTextAutoTransform = new MAFAutoScale(); //new osg::AutoTransform;
		//mTextAutoTransform->setAutoRotateMode(osg::AutoTransform::ROTATE_TO_SCREEN);
		mTextAutoTransform->setNodeMask( MAF_VISIBLE_MASK );
		mTextAutoTransform->getOrCreateStateSet()->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
		mTextMatrixOffset = new osg::MatrixTransform;

		// text display value of bet
		mText = new UGAMEShadowedText("ABC", MAFLoadFont(dataPath + "/FreeSansBold.ttf"));
		mText->setAlignment(osgText::Text::CENTER_CENTER);
		mText->setColor(osg::Vec4(1, 1, 1, 0));
		mText->setCharacterSize(12);

		osg::MatrixTransform *mat = new osg::MatrixTransform;
		mat->getOrCreateStateSet()->setMode(GL_DEPTH_TEST, 0);
		mat->setMatrix(osg::Matrix::translate(0, 15, 0));
		mat->addChild(mTextAutoTransform.get());
		mTextAutoTransform->addChild(mTextMatrixOffset.get());

		mTextMatrixOffset->addChild(mText.get());
		mSeatData->GetAnchor(anchor_player)->addChild(mat);

		mTextTime = 10.0f;
	}
#ifdef USE_NPROFILE
	tb = nprf::GetRealTime() - ta;

	ta = nprf::GetRealTime();
#endif // USE_NPROFILE
	{

		osg::AutoTransform *aut = new osg::AutoTransform;
		//osg::MatrixTransform *aut = new osg::MatrixTransform;
		aut->setAutoRotateMode(osg::AutoTransform::ROTATE_TO_SCREEN);

		mTooltipPlayerName = new UGAMEShadowedText("Tooltip", MAFLoadFont("data/FreeSansBold.ttf"));
		mTooltipPlayerName->setCharacterSize(8);
		mTooltipPlayerName->setCharacterSizeMode(osgText::Text::OBJECT_COORDS);
		mTooltipPlayerName->setPosition(osg::Vec3(0,0,0));
		mTooltipPlayerName->setColor( osg::Vec4f(1, 1, 1, 1.0f) );
		mTooltipPlayerName->setAlignment( osgText::Text::CENTER_CENTER);
		aut->addChild(mTooltipPlayerName.get());
		mTooltipAlpha = 0;
		mTooltipFadeOutDelay = 0;
		mTooltipFadeIn = false;

		mTooltipPlayerNameMatrix = new osg::MatrixTransform;
		mTooltipPlayerNameMatrix->setMatrix( osg::Matrix::translate(0, 160, -150) );
		mTooltipPlayerNameMatrix->addChild(aut);

		mSeatData->GetGroup()->addChild( mTooltipPlayerNameMatrix.get() );

		mToolTipPlayerNameSitInPos = osg::Vec3f(0, 160, -150);
		mToolTipPlayerNameSitOutPos = osg::Vec3f(0, 200, -230);
	}
#ifdef USE_NPROFILE
	tb = nprf::GetRealTime() - ta;

	ta = nprf::GetRealTime();
#endif // USE_NPROFILE
	if (mMe)
	{
		osg::MatrixTransform* nodeFrom = dynamic_cast<osg::MatrixTransform*>(OSGHelper_getNodeByName(*mSeatData->GetGroup(), "transform_interactorPivot3"));
		if (nodeFrom == NULL)
			g_error("PokerPlayer::PokerPlayer: missing \"transform_interactorPivot3\"");
		mSlidingInteractorPos[0] = nodeFrom->getMatrix().getTrans();
		osg::MatrixTransform* nodeTo = dynamic_cast<osg::MatrixTransform*>(OSGHelper_getNodeByName(*mSeatData->GetGroup(), "transform_interactorLPivot3"));
		if (nodeTo == NULL)
			g_error("PokerPlayer::PokerPlayer: missing \"transform_interactorLPivot3\"");

		mSlidingInteractorPos[1] = nodeTo->getMatrix().getTrans();
		const std::string& slidingInteractorDelay =  game->HeaderGet("sequence", "/sequence/seat/@slidingInteractorDelay");
		if (slidingInteractorDelay.size() == 0)
			g_error("PokerPlayer::PokerPlayer: missing \"/sequence/seat/@slidingInteractorDelay\" from configuration file");
		mSlidingInteractorDelay = atof(slidingInteractorDelay.c_str());
	}
#ifdef USE_NPROFILE
	tb = nprf::GetRealTime() - ta;

	double tt2 = nprf::GetRealTime() - tt1;
	osg::notify(osg::WARN) << "OSGCAL: Money & bet stack, bubble, chips and cards animations: " << int(tt2*1000) << "ms" << std::endl;
#endif
}



bool PokerPlayer::GetSound(SoundInit& sound,const std::string& basepath)
{
  MAFAudioData* data = mGame->mDatas->GetAudio(basepath+G_DIR_SEPARATOR_S+sound.mSoundName);
  if (!data) {
    g_debug("PokerPlayer::GetSound Unable to load soundtrack %s",sound.mSoundName.c_str());
    return 0;
  }

  sound.mParam.mData=data;
  return true;
}

bool PokerPlayer::HasAnimationBet2PotRunning()
{
  /// from bet to pot
  int size=(int)mMoveChipsFromBetToPot.size();
  for (int i=0;i<size;i++) {
    if (!mMoveChipsFromBetToPot[i]->IsFinished())
      return true;
  }
  return false;
}

void PokerPlayer::SetStartLookingCards()
{
  mStartLookingCards = true; 
  mLookingCards = false; 
  GetBody()->GetModel()->SetupTextureCardsForLookingCards(); 
}


void PokerPlayer::GetTypeAndNameFromOutfit(const std::string& outfit,std::string& name,std::string& type)
{
  name.clear();
  type.clear();
  if (outfit=="none") {
    name="default";
    type="male";
    return;
  }

  if (outfit=="default") {
    name=outfit;
    type="male";
    return;
  } 


  //extract type of outfit
  std::string separator=" - ";
  std::string::size_type pos=outfit.find(separator);
  if (pos != std::string::npos) {
    type=outfit.substr(0,pos);
    name=outfit.substr(pos+separator.size());
  } else {
    // to work with current server
    type="male";
    name=outfit;
  }
}



// only to track the ref count
void PokerPlayer::GetCount()
{
  std::string anchor_player = mGame->HeaderGet("sequence", "/sequence/player/@anchor");
  osg::Node* node=mSeatData->GetAnchor(anchor_player);
  g_debug("PokerPlayer %s count %d",anchor_player.c_str(),node->referenceCount());
}

void PokerPlayer::SetPlayerCameraToFreeMode()
{
	if (mCamera) {
		mCamera->Update(0, 4, false, true, true);
	}
}

PokerPlayer::~PokerPlayer()
{

	Plop();

  g_debug("PokerPlayer::~PokerPlayer");

	if (mPPTimeout.get()) {
		mGame->RemoveController(mPPTimeout.get());
		mPPTimeout = NULL;
	}
	mTimeout = NULL;

  for (std::map<std::string,osg::ref_ptr<UGAMEArtefactController> >::iterator it=mInteractors.begin();it!=mInteractors.end();it++)
    delete it->second.get()->GetModel()->GetData();


  RecursiveClearUserData(mSeat->GetModel()->GetNode());

	// do not remove these child from parent because parent is invalid
  int e=(int)mMoveChipsFromBetToPot.size();
  for (int i=0;i<e;i++) {
    mGame->RemoveController(mMoveChipsFromBetToPot[i].get());
	}
  mMoveChipsFromBetToPot.clear();

	// do not remove these child from parent because parent is invalid
  e=(int)mMoveChipsFromPotToPlayer.size();
  for (int i=0;i<e;i++) {
    mGame->RemoveController(mMoveChipsFromPotToPlayer[i].get());
  }
  mMoveChipsFromPotToPlayer.clear();


  if (mMe)
    {
      mFoldInteractor->Finit(mGame);
      mCheckInteractor->Finit(mGame);
			mCallInteractor->Finit(mGame);
			mRaiseInteractor->Finit(mGame);
      mFoldInteractor = NULL;
      mCheckInteractor = NULL;
			mCallInteractor = NULL;
			mRaiseInteractor = NULL;
    }

  mGame->RemoveController(mShowdown.get());
  mGame->RemoveController(mMoneyStack.get());
  RecursiveClearUserData(mMoneyStack->GetModel()->GetNode());

  g_assert(mMoneyStack->referenceCount()==1);
  mMoneyStack = 0;
  mGame->RemoveController(mBetStack.get());

  mGame->RemoveController(mBody.get());
  RecursiveClearUserData(mBody->GetModel()->GetNode());

  if(mCamera) 
		delete mCamera;

  mSeat = 0;
  mBetStack = 0;
  mHole.clear();
  mInteractors.clear();
  mShowdown = 0;


	mAnimationBetChipStack = 0;
	mAnimationBet->getParent(0)->removeChild(0,mAnimationBet->getParent(0)->getNumChildren());
  //
  // Do *NOT* delete this assert. Having more than one reference count
  // at this point is the best way to produce huge memory leaks. If you
  // remove the assert, the program will run just fine but may eat
  // tons of memory when switching tables, for instance.
  // Check pokeranimation.py and c_animated.cpp as they can be the one
  // holding an additional reference.
  //
  //  if(mBody->referenceCount() != 1)
  //    g_critical("mBody->referenceCount() != 1");
 
	mGame->GetScene()->GetModel()->RemoveControllerFromCache(mBody.get());
 	g_debug("body reference count %d",mBody->referenceCount());
	assert(mBody->referenceCount() == 1);
  mBody = 0;

	mGame->RemoveController( mPot2PlayerChipStack.get() );
	mGame->RemoveController( mAnimationBetChipStack.get() );

  //   mMoveChipsFromPlayerToBet = 0;

  //  mSoundBet = 0;
  //  mSoundStartLookCard = 0;
  //  mTestSounds.clear();

  // Animate1Card Clean
  {
    for (unsigned int i = 0; i < mAnimate1Card.size(); i++)
      {
        mAnimate1CardAnchor->removeChild(mAnimate1Card[i].get());
        mAnimate1Card[i] = 0;
      }
    mAnimate1CardAnchor = 0;
    mAnimate1Card.clear();
  }

  osg::NodeVisitor* leakNodes = RecursiveLeakCollect(mSeatData->GetGroup());

  delete mSeatData;

  RecursiveLeakCheck(leakNodes);
}

void PokerPlayer::SetInGame(bool inGame)
{
  if(inGame != mInGame) {
    mInGame = inGame;
  }
}

void PokerPlayer::NoCards(void) {
  mShowdown->TurnProjectorOff();
  //mShowdown->Reset();
  FoldHoleCards();
  FoldPocketCards();
}

void PokerPlayer::FoldHoleCards(void) {
  PokerCardControllerVector& cards = mHole;
  for(unsigned int i = 0; i < cards.size(); i++)
    cards[i]->Fold();
  
  mBody->GetModel()->mNumberOfCardsReady=0;
  mBody->SetNbCards(0);
  mBody->DettachCardsDrawableToPlayer();
  
  // if only two player the position is not lost when folding, so
  //DisableWarningTimer();
}

void PokerPlayer::SetHoleCards(const std::vector<int>& cards) 
{
  PokerCardControllerVector& card_controllers = mHole;

  for(unsigned int i = 0; i < card_controllers.size(); i++)
  {
    if (i < cards.size())
    {
      card_controllers[i]->Receive();
      if(cards[i] != 255)
      {
        card_controllers[i]->SetValue(cards[i]);
	//FIXME: HACK
        //card_controllers[i]->Visible(true);
      }
      else
      {
        card_controllers[i]->Visible(false);
      }
    }
    else
    {
      card_controllers[i]->Visible(false);
      card_controllers[i]->Fold();
    }
  }
}

bool PokerPlayer::HasEmptyHoleCards()
{
	int size = mHole.size();
  for(int i = 0; i < size; i++)
	{
		if (mHole[i]->IsDisplayed() == true)
			return false;
	}
	return true;
}

void PokerPlayer::FoldPocketCards(void) {
  FoldHoleCards();
  return ;
  //   if (mDisplayBubble) // why ???
  {
    mBody->SetNbCards(0);
    mBody->DettachCardsDrawableToPlayer();
  }
}

void PokerPlayer::SetPocketCards(const std::vector<int>& cards) 
{
  mBody->SetNbCards(cards.size());
	mBody->UpdateCardsOfPlayer(cards);
}

void PokerPlayer::SetMoney(const std::vector<int>& amount) {
  mMoneyStack->SetChips(amount);
}

void PokerPlayer::SetBet(const std::vector<int>& amount) {

  g_debug("PokerPlayer::SetBet %i",(int)amount.size());
  if (mSyncBetStackWithPacket)
    mBetStack->SetChips(amount);
}

void PokerPlayer::DisplayShadowStacks(const std::string& style) {
	return;
  std::map<unsigned int,unsigned int> chipsMap;
  if(style != "") {
    chipsMap = mMoneyStack->GetChips();
    mBetStack->SetShadowChips(chipsMap, style);
  } else {
    mBetStack->ClearShadowChips(mGame);
  }
}

void PokerPlayer::SyncBetStackWithPacket(bool state)
{
  mSyncBetStackWithPacket=state;
}

void PokerPlayer::DisplayBetStack(bool state)
{
  if (state)
    mBetStack->GetModel()->GetNode()->setNodeMask(MAF_COLLISION_MASK | MAF_VISIBLE_MASK);
  else
    mBetStack->GetModel()->GetNode()->setNodeMask(~(MAF_VISIBLE_MASK|MAF_COLLISION_MASK) );
}

void PokerPlayer::BetLimits(int min_bet, int max_bet, int step, int call, int allin, int pot) {
	mAllInLimit = allin;
  mBetStack->SetBetLimits(min_bet, max_bet, step, call, allin, pot);
}

unsigned PokerPlayer::GetBetValue(bool& isCall)
{
  return mBetStack->GetBetValue(isCall);
}

void PokerPlayer::ResetBetValue()
{
  mBetStack->ResetBetValue();
}

void PokerPlayer::SetName(const std::string& name)
{
  mTooltipPlayerName->setText(name);

  mName = name;
  if(name == "")
    mBody->Displayed(false);
  else {
    mBody->Displayed(true);
  }
}


//#define NEW_VERTEX_PROGRAM_FOR_SHADOW

#ifdef NEW_VERTEX_PROGRAM_FOR_SHADOW
#include "shadow_vertex_program"
#endif

void PokerPlayer::SetSeatId(int seat_id) {
  if(seat_id != mSeatId) {
    if(seat_id == POKER_PLAYER_NO_SEAT) {
      if (mShadowFlag && mShadowItems.size()) {

        osg::Group *pokerBody = (osg::Group*) mBody->GetModel()->GetNode();
        //osgCal::Model *model = (osgCal::Model*) pokerBody->getChild(0);
        osg::Group *transformPlayer = (osg::Group*) pokerBody->getParent(0);
        osg::Group *player = (osg::Group*) transformPlayer->getParent(0);
        osg::Group *uk = (osg::Group*) player->getParent(0);
        osg::Group *transformseat = (osg::Group*) uk->getParent(0);
        osg::Group *set = (osg::Group*) transformseat->getParent(0);

				set->removeChild( mShadowItems[0] );
				set->removeChild( mShadowItems[1] );

        mShadowItems.clear();
      }
      mSeat->Anchor(0);
      mBody->StopAll();
    } else {
      char tmp[128];
      std::string anchor_seat = mGame->HeaderGet("sequence", "/sequence/seat/@anchor");
      snprintf(tmp, sizeof(tmp), anchor_seat.c_str(), seat_id + 1);
      g_debug("PokerPlayer::SetSeatId: sitting at %s", tmp);
      MAFAnchor* anchor = mGame->mSetData->GetAnchor(tmp);

			// add collision from root to transform
			osg::NodePath pathToAddCollisionMask;
			MAFCreateNodePath(anchor, pathToAddCollisionMask);
			for (osg::NodePath::iterator it = pathToAddCollisionMask.begin(); it != pathToAddCollisionMask.end(); it++) {
				unsigned int mask = (*it)->getNodeMask();
				mask =  mask | MAF_COLLISION_MASK;
				(*it)->setNodeMask(mask);
			}
			
      mSeat->Anchor(anchor);
      mSeat->GetModel()->GetArtefact()->setName(mMe ? "self" : "player");

      {
        osg::NodePath path;
        osg::Node* node = mSeat->GetModel()->GetArtefact();
        while(node) {
          path.push_back(node);
          if(node->getNumParents() >= 1) {
            if(node->getNumParents() > 1)
              g_critical("PokerPlayer::SetSeatId: seat has more than one parent");
            node = node->getParent(0);
          } else {
            node = 0;
          }
        }
        std::reverse(path.begin(), path.end());

        /*
          toworld get the orientation of seat
          and toworld2 get a position to compute direction between players
        */
        osg::Matrix toworld = MAFComputeLocalToWorld(mSeat->GetModel()->GetArtefact());
        std::string anchor_seatpos = mGame->HeaderGet("sequence", "/sequence/player/@anchorlookat");
        if (anchor_seatpos.empty())
          g_error("anchor %s not found in /sequence/player/@anchorlookat",anchor_seatpos.c_str());

        osg::Node* nodelookat=mSeatData->GetAnchor(anchor_seatpos.c_str());
        osg::Matrix toworld2=MAFComputeLocalToWorld(nodelookat);
        mDirectionOfPlayerInWorldspace = toworld2.getTrans();
        mDirectionOfPlayerInWorldspace.normalize();
        mPositionOfPlayerInWorldspace = toworld2.getTrans();

        if (mShadowFlag) {
          mShadowItems.clear();

          osg::Vec3f to = osg::Vec3f(0, 400, 0);
          to -= mPositionOfPlayerInWorldspace;
          to.normalize();

          osg::Group *pokerBody = (osg::Group*) mBody->GetModel()->GetNode();
          osgCal::Model *model = (osgCal::Model*) pokerBody->getChild(0);
          osg::Group *transformPlayer = (osg::Group*) pokerBody->getParent(0);
          osg::Group *player = (osg::Group*) transformPlayer->getParent(0);
          osg::Group *uk = (osg::Group*) player->getParent(0);
          osg::Group *transformseat = (osg::Group*) uk->getParent(0);
          osg::Group *set = (osg::Group*) transformseat->getParent(0);

					// define this to test a vertex program specifi for shadow
#ifdef NEW_VERTEX_PROGRAM_FOR_SHADOW
					// test to use a spific vertex program fro shadow. With current data there is no gain
					osg::VertexProgram* shadowVertexProgram = 0;
					if (model->getUseVertexProgram()) {
						shadowVertexProgram = new osg::VertexProgram;
						shadowVertexProgram->setVertexProgram(SHADOW_VERTEX_PROGRAM_STR);
					}
#endif

          {
            osg::Matrix mat = MAFComputeLocalToWorld(pokerBody);
            osg::Matrix shadowMatrix = MAFBuildShadowMatrix(osg::Plane(0, 1, 0, -80), osg::Vec4f(to.x(), to.y(), to.z(), 0) );
            mat *= shadowMatrix;

						osgCal::Model *nm = new osgCal::Model(*model);

            osg::MatrixTransform *mt = new osg::MatrixTransform();
            mShadowItems.push_back(mt);

#ifdef NEW_VERTEX_PROGRAM_FOR_SHADOW
					// test to use a spific vertex program fro shadow. With current data there is no gain
						if (model->getUseVertexProgram()) {
							mt->getOrCreateStateSet()->setAttributeAndModes(shadowVertexProgram, osg::StateAttribute::OVERRIDE | osg::StateAttribute::ON);
						}
#endif
            mt->setMatrix(mat);
            mt->setNodeMask(MAF_VISIBLE_MASK);
            mt->addChild(nm);
            set->addChild(mt);

						std::string seatName = std::string(tmp);
						std::string nameNode = "ShadowForTable";
						mt->setName(nameNode+seatName);

            osg::Depth *dp = new osg::Depth();
            dp->setWriteMask(FALSE);
            mt->getOrCreateStateSet()->setAttributeAndModes(dp, osg::StateAttribute::OVERRIDE);

						if (!MAFRenderBin::Instance().SetupRenderBin("PlayerShadowOnTable", mt->getOrCreateStateSet()))
							MAF_ASSERT(0 && "PlayerShadowOnTable not found in client.xml");

						float shadowFactor = mGame->GetPoker()->GetModel()->mTableShadowFactor;

            osg::Material* material = new osg::Material;
            material->setAmbient(osg::Material::FRONT_AND_BACK, osg::Vec4(0.0f, 0.0f, 0.0f, 0.0f));
            material->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4(0.0f, 0.0f, 0.0f, 0.0f));
						material->setEmission(osg::Material::FRONT_AND_BACK, osg::Vec4(shadowFactor, shadowFactor, shadowFactor, 0.0f));
            material->setShininess(osg::Material::FRONT_AND_BACK, 0.0f);
            mt->getOrCreateStateSet()->setAttribute(material,osg::StateAttribute::OVERRIDE);

            mt->getOrCreateStateSet()->setTextureMode(0, GL_TEXTURE_2D, osg::StateAttribute::OVERRIDE | osg::StateAttribute::OFF);
            mt->getOrCreateStateSet()->setTextureMode(1, GL_TEXTURE_2D, osg::StateAttribute::OVERRIDE | osg::StateAttribute::OFF);
            osg::BlendFunc *blend = new osg::BlendFunc;
            blend->setFunction(GL_DST_COLOR, GL_ZERO);
            mt->getOrCreateStateSet()->setAttributeAndModes(blend, osg::StateAttribute::OVERRIDE | osg::StateAttribute::ON);
            mt->getOrCreateStateSet()->setMode(GL_LIGHT0, osg::StateAttribute::OVERRIDE | osg::StateAttribute::ON);
            mt->getOrCreateStateSet()->setMode(GL_LIGHTING, osg::StateAttribute::OVERRIDE | osg::StateAttribute::ON);
            mt->getOrCreateStateSet()->setMode(GL_ALPHA_TEST, osg::StateAttribute::OVERRIDE | osg::StateAttribute::OFF);

            osg::Stencil *stencil = new osg::Stencil;
            stencil->setFunction(osg::Stencil::EQUAL, 0x1, 0xffffffff);
            stencil->setOperation(osg::Stencil::KEEP, osg::Stencil::ZERO, osg::Stencil::ZERO);
            mt->getOrCreateStateSet()->setAttributeAndModes(stencil);
		        mt->getOrCreateStateSet()->setMode(GL_STENCIL_TEST, TRUE);
            mBody->GetModel()->newModelForTableShadow_ = nm;

            int nb = nm->getNumDrawables();
            std::list<std::string> urls = mGame->HeaderGetList("sequence", "/sequence/excludeFromShadow[@shadowed=\"table\"]/mesh/@name");

						// hardware mesh so remove all software mesh for shadow
						if (nm->getUseVertexProgram()) {
							for (int i = nb-1; i >=0 ; i--) {
								osg::Drawable *drawable = nm->getDrawable(i);
								const std::string &className = drawable->className();
								if (className == "SubMeshSoftware") {
#if OSG_VERSION_MAJOR > 1 || ( OSG_VERSION_MAJOR == 1 && OSG_VERSION_MINOR >= 1 )
									nm->removeDrawables(i);
#else // OSG_VERSION_MAJOR > 1 || ( OSG_VERSION_MAJOR == 1 && OSG_VERSION_MINOR >= 1 )
									nm->removeDrawable(i);
#endif // OSG_VERSION_MAJOR > 1 || ( OSG_VERSION_MAJOR == 1 && OSG_VERSION_MINOR >= 1 )
                }
							}
						}

            nb = nm->getNumDrawables();
            for (int i = 0; i < nb; i++) {
              osg::Drawable *drawable = nm->getDrawable(i);
              const std::string &className = drawable->className();
              std::string name;
              if (className == "SubMeshSoftware")
                name = ((osgCal::SubMeshSoftware*)drawable)->getName();
              else
                name = ((osgCal::SubMeshHardware*)drawable)->getName();

              std::list<std::string>::const_iterator it = urls.begin();
              while (it != urls.end() ) {
                const std::string &str = (*it);
                if (name.find(str) != std::string::npos) {
#if OSG_VERSION_MAJOR > 1 || ( OSG_VERSION_MAJOR == 1 && OSG_VERSION_MINOR >= 1 )
                  nm->removeDrawables(i);
#else // OSG_VERSION_MAJOR > 1 || ( OSG_VERSION_MAJOR == 1 && OSG_VERSION_MINOR >= 1 )
                  nm->removeDrawable(i);
#endif // OSG_VERSION_MAJOR > 1 || ( OSG_VERSION_MAJOR == 1 && OSG_VERSION_MINOR >= 1 )
                  i--;
                  nb--;
                  break;
                }
                it++;
              }
            }

						// check drawable used for shadow
						for (unsigned int i=0; i<nm->getNumDrawables(); i++) {
              osg::Drawable *drawable = nm->getDrawable(i);
              const std::string &className = drawable->className();
              std::string name;
              if (className == "SubMeshSoftware") {
                name = ((osgCal::SubMeshSoftware*)drawable)->getName();
								g_debug("soft table shadow drawable - %s",name.c_str());
              } else {
                name = ((osgCal::SubMeshHardware*)drawable)->getName();
								g_debug("hard table shadow drawable - %s",name.c_str());
							}
						}


					}

          {
            osg::Matrix mat = MAFComputeLocalToWorld(pokerBody);
            osg::Matrix shadowMatrix = MAFBuildShadowMatrix(osg::Plane(0, 1, 0, 0), osg::Vec4f(to.x(), to.y(), to.z(), 0) );
            mat *= shadowMatrix;
            //mat *= osg::Matrix::translate(0, 100, 0);

            osgCal::Model *nm = new osgCal::Model(*model);

            osg::MatrixTransform *mt = new osg::MatrixTransform();
            mShadowItems.push_back(mt);

#ifdef NEW_VERTEX_PROGRAM_FOR_SHADOW
					// test to use a spific vertex program fro shadow. With current data there is no gain
						if (model->getUseVertexProgram()) {
							mt->getOrCreateStateSet()->setAttributeAndModes(shadowVertexProgram, osg::StateAttribute::OVERRIDE | osg::StateAttribute::ON);
						}
#endif
            mt->setMatrix(mat);
            mt->setNodeMask(MAF_VISIBLE_MASK);
            mt->addChild(nm);
            set->addChild(mt);

						std::string seatName = std::string(tmp);
						std::string nameNode = "ShadowForGround";
						mt->setName(nameNode+seatName);

            osg::Depth *dp = new osg::Depth();
            dp->setWriteMask(FALSE);
            mt->getOrCreateStateSet()->setAttributeAndModes(dp, osg::StateAttribute::OVERRIDE);
//						{
	//						int rbvalue;
		//					if (!VarsEditor::Instance().Get("RB_PlayerShadowOnGround",rbvalue))
			//					MAF_ASSERT(0 && "RB_PlayerShadowOnGround not found in client.xml");
				//			mt->getOrCreateStateSet()->setRenderBinDetails(rbvalue, "RenderBin");
						//}
						if (!MAFRenderBin::Instance().SetupRenderBin("PlayerShadowOnGround" ,mt->getOrCreateStateSet()))
							MAF_ASSERT(0 && "PlayerShadowOnGround not found in client.xml");

            mt->setNodeMask(MAF_VISIBLE_MASK);

						float shadowFactor = mGame->GetPoker()->GetModel()->mGroundShadowFactor;

            osg::Material* material = new osg::Material;
            material->setAmbient(osg::Material::FRONT_AND_BACK, osg::Vec4(0.0f, 0.0f, 0.0f, 0.0f));
            material->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4(0.0f, 0.0f, 0.0f, 0.0f));
						material->setEmission(osg::Material::FRONT_AND_BACK, osg::Vec4(shadowFactor, shadowFactor, shadowFactor, 0.0f));
            material->setShininess(osg::Material::FRONT_AND_BACK, 0.0f);
            mt->getOrCreateStateSet()->setAttribute(material, osg::StateAttribute::OVERRIDE);

						mt->getOrCreateStateSet()->setTextureMode(0, GL_TEXTURE_2D, osg::StateAttribute::OVERRIDE | osg::StateAttribute::OFF);

            osg::BlendFunc *blend = new osg::BlendFunc;
            blend->setFunction(GL_DST_COLOR, GL_ZERO);
            mt->getOrCreateStateSet()->setAttributeAndModes(blend, osg::StateAttribute::OVERRIDE | osg::StateAttribute::ON);
            mt->getOrCreateStateSet()->setMode(GL_LIGHTING, osg::StateAttribute::OVERRIDE | osg::StateAttribute::ON);

            osg::Stencil *stencil = new osg::Stencil;
            stencil->setFunction(osg::Stencil::EQUAL, 0x2, 0xffffffff);
            stencil->setOperation(osg::Stencil::KEEP, osg::Stencil::ZERO, osg::Stencil::ZERO);
            mt->getOrCreateStateSet()->setAttributeAndModes(stencil);
            mt->getOrCreateStateSet()->setMode(GL_STENCIL_TEST, TRUE);

            int nb = nm->getNumDrawables();
            std::list<std::string> urls = mGame->HeaderGetList("sequence", "/sequence/excludeFromShadow[@shadowed=\"ground\"]/mesh/@name");

						// hardware mesh so remove all software mesh for shadow
						if (nm->getUseVertexProgram()) {
							for (int i = nb-1; i >=0 ; i--) {
								osg::Drawable *drawable = nm->getDrawable(i);
								const std::string &className = drawable->className();
								if (className == "SubMeshSoftware") {
#if OSG_VERSION_MAJOR > 1 || ( OSG_VERSION_MAJOR == 1 && OSG_VERSION_MINOR >= 1 )
									nm->removeDrawables(i);
#else // OSG_VERSION_MAJOR > 1 || ( OSG_VERSION_MAJOR == 1 && OSG_VERSION_MINOR >= 1 )
									nm->removeDrawable(i);
#endif // OSG_VERSION_MAJOR > 1 || ( OSG_VERSION_MAJOR == 1 && OSG_VERSION_MINOR >= 1 )
                }
							}
						}

            nb = nm->getNumDrawables();
            for (int i = 0; i < nb; i++) {
              osg::Drawable *drawable = nm->getDrawable(i);
              const std::string &className = drawable->className();
              std::string name;
              if (className == "SubMeshSoftware")
                name = ((osgCal::SubMeshSoftware*)drawable)->getName();
              else
                name = ((osgCal::SubMeshHardware*)drawable)->getName();

              std::list<std::string>::const_iterator it = urls.begin();
              while (it != urls.end() ) {
                const std::string &str = (*it);
                if (name.find(str) != std::string::npos) {
#if OSG_VERSION_MAJOR > 1 || ( OSG_VERSION_MAJOR == 1 && OSG_VERSION_MINOR >= 1 )
                  nm->removeDrawables(i);
#else // OSG_VERSION_MAJOR > 1 || ( OSG_VERSION_MAJOR == 1 && OSG_VERSION_MINOR >= 1 )
                  nm->removeDrawable(i);
#endif // OSG_VERSION_MAJOR > 1 || ( OSG_VERSION_MAJOR == 1 && OSG_VERSION_MINOR >= 1 )
                  i--;
                  nb--;
                  break;
                }
                it++;
              }
            }
						// check drawable used for shadow
						for (unsigned int i=0; i<nm->getNumDrawables(); i++) {
              osg::Drawable *drawable = nm->getDrawable(i);
              const std::string &className = drawable->className();
              std::string name;
              if (className == "SubMeshSoftware") {
                name = ((osgCal::SubMeshSoftware*)drawable)->getName();
								g_debug("soft ground shadow drawable - %s",name.c_str());
              } else {
                name = ((osgCal::SubMeshHardware*)drawable)->getName();
								g_debug("hard ground shadow drawable - %s",name.c_str());
							}
						}
          }
        }

        if(mCamera) {
          mCamera->SetPlayerDirection(mDirectionOfPlayerInWorldspace);
          mCamera->SetPlayerPosition(mPositionOfPlayerInWorldspace);

          std::string cameras_string = mGame->HeaderGet("sequence", "/sequence/cameras/@names");
          std::vector<std::string> cameras = std::split(cameras_string, " ", 0);
          for(std::vector<std::string>::iterator i = cameras.begin();
              i != cameras.end();
              i++) {
            MAFCameraController* camera = mSeatData->GetCamera(*i);
            g_assert(camera != 0);
            MAFCameraModel model = *camera->GetModel();
            model.SetPosition(model.GetPosition() * toworld);
            model.SetTarget(model.GetTarget() * toworld);
            mCamera->SetCameraModel(*i, model);
          }
        }
      }
    }
  }
  mSeatId = seat_id;
}

void PokerPlayer::SetSit(bool sit) {
  if(mSit != sit) {
    mSit = sit;
  }
}

void PokerPlayer::InPosition()
{
  if (!mInPosition) {
    mInPosition=true;
    mInteractors["position"]->Displayed(true);
    MarkLastAction();

		PokerSceneView *instance = PokerSceneView::getInstance();
		if (instance)
			instance->resetGlowCounter();
	}
}


void PokerPlayer::DisableWarningTimer()
{
	mTimeout->SetEnable(false);

  // init counter for the timeout warning
	if (mMe)
		mPPTimeout->Disable();
}

void PokerPlayer::LostPosition()
{
  if(mInPosition) {
    mInPosition = false;
    mInteractors["position"]->Displayed(false);
    MarkLastAction();

    DisableWarningTimer();
    g_debug("lost position");
  }
}


void PokerPlayer::LookAt(PokerPlayer* player)
{
  mBody->PlayLookAt(GetDirectionOfPlayer(), GetPositionOfPlayer(), player->GetPositionOfPlayer());
}

void PokerPlayer::MarkLastAction()
{
  mTimeWaiting=0;
  mTimePlaying=0;
}

void PokerPlayer::SetTextMessage(const std::string &messageStr)
{
 //	std::string message = messageStr;
 //	std::string newMessage;
 //	EDITABLE(int, lineLen, 20);
	//std::vector<std::string>& lines = std::split(message, "\n", 0);
	//for (int i = 0; i < lines.size(); i++)
	//{
	//	if (lines[i].size() > lineLen)
	//	{
	//		newMessage += lines[i].substr(0, 20) + "-\n";
	//		newMessage += lines[i].substr(20) + "\n";
	//	}
	//	else
	//	{
	//		newMessage += lines[i] + "\n";
	//	}
	//}

 	//		//if (pos == message.size())
 	//		//	{
 	//		//		newMessage += message;
 	//		//		break;
 	//		//	}
		//	if (message.size() <= lineLen)
		//	{
		//		newMessage += message;
		//		break;
		//	}
		//	int pos = (lineLen);
 	//		newMessage += message.substr(0, pos) + "-\n";
 	//		message = message.substr(pos + 1);
 	//	}
	PushTextMessage(messageStr);
//   if (mDisplayBubble)
//     mBubble->SetTextMessage(message);
}

void PokerPlayer::PushTextMessage(const std::string &message)
{
	//std::cout << "push message:" << message << std::endl;
	mMessages.push_back(message);
}

bool PokerPlayer::PopTextMessage(std::string &message)
{
	if (mMessages.size() == 0)
		return false;
 	message = mMessages.front();
	//std::cout << "pop message:" << message << std::endl;
	mMessages.erase(mMessages.begin());
	return true;
}

void PokerPlayer::DisplayChipsOfBetAnimation(bool state)
{
  if (state) {
		mAnimationBetChipStack->GetModel()->GetNode()->setNodeMask(MAF_VISIBLE_MASK | MAF_COLLISION_MASK);
		//		mAnimationBet->setNodeMask(MAF_VISIBLE_MASK);
// 		osg::Material* mat = new osg::Material;
// 		mat->setDiffuse(osg::Material::FRONT_AND_BACK,osg::Vec4(0,1,0,1));
// 		mAnimationBet->getOrCreateStateSet()->setAttributeAndModes(mat,osg::StateAttribute::OVERRIDE);
// 		std::cout << this << " Display TRUE\n";
  } else {
		mAnimationBetChipStack->GetModel()->GetNode()->setNodeMask(0);
		//    mAnimationBet->setNodeMask(0);
// 		osg::Material* mat = new osg::Material;
// 		mat->setDiffuse(osg::Material::FRONT_AND_BACK,osg::Vec4(0,1,1,1));
// 		mAnimationBet->getOrCreateStateSet()->setAttributeAndModes(mat,osg::StateAttribute::OVERRIDE);
// 		std::cout << this << " Display FALSE\n";
	}
}

void PokerPlayer::SetValueChipsOfBetAnimation(const std::vector<int>& chips)
{
  mAnimationBetChipStack->SetChips(chips);
}

void PokerPlayer::StartBetZoneAnimation(const std::string& animationName,const std::vector<int>& amounts)
{
  std::map<std::string,std::string>::const_iterator it=mMapAnimationBet.find(animationName);
  if ( it == mMapAnimationBet.end()) {
    g_critical("PokerPlayer::::StartBetAnimation animation %s not found in exg animation",animationName.c_str());
    return;
  }

  const std::string& name=it->second;
  float timeScale=mMapAnimationBetTimeScale[animationName];
  if (!mAnimationBetCallback) {
    g_critical("PokerPlayer::StartBetAnimation node transform has no callback MultipleAnimationPathCallback");
    return;
  }
  
  mAnimationBetChipStack->SetChips(amounts);
  mAnimationBetCallback->setCurrentAnimationPath(name);
  mAnimationBet->setNodeMask(MAF_VISIBLE_MASK);
  mAnimationBetCallback->setPause(false);
  mAnimationBetCallback->setTimeMultiplier(timeScale);
  mAnimationBetCallback->reset();
}


bool PokerPlayer::IsAnimationBetFinished()
{
	double duration = mAnimationBetCallback->getAnimationDuration();
	const std::string& animationName = mAnimationBetCallback->getCurrentAnimationString();
	if (animationName.find("bet") == std::string::npos) {
		g_debug("PokerPlayer::IsAnimationBetFinished animation set to %s",animationName.c_str());
		g_error("PokerPlayer::IsAnimationBetFinished animation");
	}

	if (duration < 0)
		g_error("PokerPlayer::IsAnimationBetFinished");
  if (mAnimationBetCallback->getAnimationTime() >= duration-1e-4)
    return true;
  return false;
}

void PokerPlayer::StartGetPotAnimation(const std::vector<int>& chips) // tranfert bet stack to money stack
{
  if (mAnimationPlayerBet || mAnimationPlayerGetPot)
    g_critical("PokerPlayer::StartBetAnimation called with an existing animation");
  StartBetZoneAnimation("getPot",chips);
  mAnimationPlayerGetPot=true;
}



bool PokerPlayer::Update(MAFApplication* application)
{	

	NPROFILE_SAMPLE("PokerPlayer::Update");

	//SDL_Event* event = mGame->GetLastEvent(this);
	PokerCameraModel* camera=(dynamic_cast<PokerCameraController*>(mGame->GetScene()->GetModel()->mCamera.get()))->GetModel();

  if (mMe && camera->GetMode() == PokerCameraModel::CAMERA_FREE_MODE)
	{		
		osg::Vec3 player = mPositionOfPlayerInWorldspace;
		osg::Vec3 center = osg::Vec3(0.0f, mPositionOfPlayerInWorldspace.y(), 0.0f);
		osg::Vec3 at = (player - center);
		at.normalize();
		osg::Vec3 up = osg::Vec3(0.0f, 1.0f, 0.0f);
		osg::Vec3 right = (player - center) ^ up;
		right.normalize();
		osg::Vec3 eye = mCamera->GetCameraController()->GetModel()->GetPosition();
		osg::Vec3 eyeAt = eye - center;
		eyeAt.normalize();
		static float lastDot = 0.0f;
		float dot = eyeAt * right;
		bool doit = false;
		if ((lastDot >= 0.0f && dot < 0.0f) || (lastDot < 0.0f && dot >= 0.0f))
		{
			doit = true;
		}
		lastDot = dot;

		//if (event)
		if (doit)
		{
			//if (event->type == SDL_KEYDOWN)
			//{
			//	if (event->key.keysym.sym == SDLK_t)
			//	{
					static int current = 0;
					osg::Vec3 posFrom = mSlidingInteractorPos[current];	
					osg::Vec3 posTo = mSlidingInteractorPos[!current];
					mSlidingInteractorInterpolator.Init(posFrom, posTo);
					mSlidingInteractorTimer.Init(mSlidingInteractorDelay);
					current = !current;
			//	}
			//}
		}
		else
		{
			if (mSlidingInteractorTimer.Finished() == false)
			{
				osg::Vec3 current;
				mSlidingInteractorTimer.AddTime(GetDeltaFrame());
				mSlidingInteractorTimer.Get(current, mSlidingInteractorInterpolator);
				mFoldInteractor->mPosRoot_3 = current;
				mCheckInteractor->mPosRoot_3 = current;
				mCallInteractor->mPosRoot_3 = current;
				mRaiseInteractor->mPosRoot_3 = current;
				//mFoldInteractor->mPosRoot_3 = current;
				//osg::MatrixTransform* nodeFrom = dynamic_cast<osg::MatrixTransform*>(OSGHelper_getNodeByName(*mSeatData->GetGroup(), "transform_interactorPivot3"));
				//assert(nodeFrom != NULL);
				//osg::Matrix trans = nodeFrom->getMatrix();
				//trans.setTrans(current);
				//nodeFrom->setMatrix(trans);
			}
		}
	}

	if (!mGame->HasEvent()) {

		const double MaxTimeToWait=10;
		const double MaxTimeToPlay=7;

		double deltaS=GetDeltaFrame()/1000.0;
		mInternalTime+=deltaS;

		{
			osg::Drawable *draw = mGlowLightMap->getDrawable(0);
			osg::Material *mat = (osg::Material*) draw->getOrCreateStateSet()->getAttribute(osg::StateAttribute::MATERIAL);
			float alpha = MAFGlowFX::getGlowTextureOpacity();
			mat->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(1, 1, 1, alpha) );
		}

		bool playerHasCards = GetBody()->GetNbCards() != 0;
		bool cardsOnTableFocused = GetBody()->GetFocus().rfind("__cardzone") != std::string::npos; 
		bool bodyFocused = mGame->GetFocus() == GetBody();

		if (cardsOnTableFocused && !playerHasCards) // exclude card zone if no cards
			cardsOnTableFocused = bodyFocused = false;

		if (!bodyFocused && mGame->GetFocus() != GetMoneyStack()) {

			if (!mTooltipFadeIn) {
				mTooltipAlpha -= deltaS * 2;
				if (mTooltipAlpha < 0) {
					mTooltipAlpha = 0;
					mTooltipPlayerName->setNodeMask(0);
				}
			}

			GetMoneyStack()->ForceToDisplayTooltip(false);
			// merge focus with chipstack
      GetShowdown()->SetFocus(false);
    }
		else {
			mTooltipFadeIn = true;
			mTooltipFadeOutDelay = 0.25f;

			GetMoneyStack()->ForceToDisplayTooltip(true);
      GetShowdown()->SetFocus(true);
    }

		if (mTooltipFadeIn) {
			mTooltipPlayerName->setNodeMask( MAF_VISIBLE_MASK );
			mTooltipAlpha += deltaS * 4;
			if (mTooltipAlpha > 1.0f) {
				mTooltipAlpha = 1.0f;
				mTooltipFadeOutDelay -= deltaS;
				if (mTooltipFadeOutDelay < 0)
					mTooltipFadeIn = false;
			}
		}

		mTooltipPlayerName->setColor( osg::Vec4f(1, 1, 1, mTooltipAlpha ) );

		if (mSit == true)
			mTooltipPlayerNameMatrix->setMatrix( osg::Matrix::translate(mToolTipPlayerNameSitInPos) );
		else
			mTooltipPlayerNameMatrix->setMatrix( osg::Matrix::translate(mToolTipPlayerNameSitOutPos) );

		if (mTimeout->IsEnable())
			mTimeout->Update(deltaS);

		mTextTime += deltaS;
		float alpha = 1;
		float text_offset = 0;
		osg::Vec4f textColor = mText->getColor();

		if (mTextTime < 0.25f) {
			alpha = mTextTime / 0.25f;
		}

		if (mTextTime > 1) {
			alpha = (mTextTime-1) / 1.0f;
			if (alpha > 1)
				alpha = 1;
			alpha = 1 - alpha;
			text_offset = (mTextTime-1) / 1.0f * 15;
		}

		mBetStack->GetModel()->mbCanBeDisplay = true;
		if (alpha != 0)
			mBetStack->GetModel()->mbCanBeDisplay = false;

		textColor._v[3] = alpha;
		mText->setColor(textColor);
		mTextMatrixOffset->setMatrix( osg::Matrix::translate(0, text_offset, 0) );

		if (mInPosition)
			mTimePlaying += deltaS;
		else
			mTimeWaiting += deltaS;
		mTimeNoise -= deltaS;

		// the player is too slow when playing
		if (! (mMe && camera->GetMode()!=PokerCameraModel::CAMERA_FREE_MODE))
			if(mInPosition && mTimePlaying>MaxTimeToPlay) {
				mTimePlaying=0;
			}

			if (mTimeNoise < 0) {
				if (mSit)
					mBody->PlayBlink();
				mTimeNoise = mEyeRandomMin+(mEyeRandomMax*rand()/(RAND_MAX+1.0));
			}

			// the player wait to play too long
			if (! (mMe && camera->GetMode()!=PokerCameraModel::CAMERA_FREE_MODE))
				if(mSit && !mInPosition && mTimeWaiting>MaxTimeToWait) {
					mTimeWaiting=0;
				}

				if (mMe && !mInPosition) {
					mPPTimeout->Disable();
					mTimeout->SetEnable(false);
				}

				if (mCamera) {
					PokerCameraModel::Mode pmode = mCamera->GetCameraController()->GetModel()->GetMode();
					if (pmode == PokerCameraModel::CAMERA_ENTER_MODE || pmode == PokerCameraModel::CAMERA_DIRECT_MODE || pmode == PokerCameraModel::CAMERA_GAME_MODE) {
						if (mFoldInteractor.valid()) {
							//mFoldInteractor->mCanZoom = false;
							mFoldInteractor->mMorph += deltaS * 4;
							if (mFoldInteractor->mMorph > 1)
								mFoldInteractor->mMorph = 1;
						}
						if (mCheckInteractor.valid()) {
							//mCheckInteractor->mCanZoom = false;
							mCheckInteractor->mMorph += deltaS * 4;
							if (mCheckInteractor->mMorph > 1)
								mCheckInteractor->mMorph = 1;
						}
						if (mCallInteractor.valid()) {
							//mCallInteractor->mCanZoom = false;
							mCallInteractor->mMorph += deltaS * 4;
							if (mCallInteractor->mMorph > 1)
								mCallInteractor->mMorph = 1;
						}
						if (mRaiseInteractor.valid()) {
							//mRaiseInteractor->mCanZoom = false;
							mRaiseInteractor->mMorph += deltaS * 4;
							if (mRaiseInteractor->mMorph > 1)
								mRaiseInteractor->mMorph = 1;
						}
					}
					else {
						if (mFoldInteractor.valid()) {
							//mFoldInteractor->mCanZoom = true;
							mFoldInteractor->mMorph -= deltaS * 4;
							if (mFoldInteractor->mMorph < 0)
								mFoldInteractor->mMorph = 0;
						}
						if (mCheckInteractor.valid()) {
							//mCheckInteractor->mCanZoom = true;
							mCheckInteractor->mMorph -= deltaS * 4;
							if (mCheckInteractor->mMorph < 0)
								mCheckInteractor->mMorph = 0;
						}
						if (mCallInteractor.valid()) {
							//mCallInteractor->mCanZoom = true;
							mCallInteractor->mMorph -= deltaS * 4;
							if (mCallInteractor->mMorph < 0)
								mCallInteractor->mMorph = 0;
						}
						if (mRaiseInteractor.valid()) {
							//mRaiseInteractor->mCanZoom = true;
							mRaiseInteractor->mMorph -= deltaS * 4;
							if (mRaiseInteractor->mMorph < 0)
								mRaiseInteractor->mMorph = 0;
						}
					}
				}
	}


	if (mFoldInteractor.get())
		mFoldInteractor->Update(application);
	if (mCheckInteractor.get())
		mCheckInteractor->Update(application);
	if (mCallInteractor.get())
		mCallInteractor->Update(application);
	if (mRaiseInteractor.get())
		mRaiseInteractor->Update(application);

	if(mCamera && mSeatId != POKER_PLAYER_NO_SEAT) {

		if (mLastFocusedController != application->GetFocus()) 
			mLastFocusedController = application->GetFocus();

		SDL_Event* event = mGame->GetLastEvent(this);

		if (event)
			if ((event->type == SDL_MOUSEBUTTONDOWN) && (event->button.button == SDL_BUTTON_LEFT))
				mLastClickedController = application->GetFocus();

		bool interactorSelected =   (mLastClickedController == mBetStack.get()) ||
			(mLastClickedController == mFoldInteractor.get()) ||
			(mLastClickedController == mCheckInteractor.get()) ||
			(mLastClickedController == mCallInteractor.get()) ||
			(mLastClickedController == mRaiseInteractor.get()) ||
			(mLastClickedController == PokerSceneView::getInstance()->getMouseController());
		{
			mCamera->SetInteractorSelected(interactorSelected);
		}

		bool playerHasCards = GetBody()->GetNbCards() != 0;
		//bool chairNotFocused = GetBody()->GetFocus().rfind("__chair") == std::string::npos;
		//bool playFoldAnim = GetBody()->GetModel()->mbPlayFoldAnimation;
		bool bodyFocusable = mSit;///*playerHasCards &&*/ chairNotFocused && !playFoldAnim;
		bool bodyFocused = (mGame->GetFocus() == GetBody()) && bodyFocusable;
		bool cardsOnTableFocused = GetBody()->GetFocus().rfind("__cardzone") != std::string::npos; 

		if (cardsOnTableFocused && !playerHasCards) // exclude card zone if no cards
			cardsOnTableFocused = bodyFocused = false;
			

		bool elementsFocusedThatShouldBeIgnoredByCamera = (mGame->GetFocus() == (MAFController*)mGame->mPokerMultiTable.get());

		PokerCameraModel::Mode pmode = mCamera->GetCameraController()->GetModel()->GetMode();
		if (pmode == PokerCameraModel::CAMERA_GAME_MODE || pmode == PokerCameraModel::CAMERA_DIRECT_MODE)
			mPPTimeout->SetFirstPerson(true);
		else
			mPPTimeout->SetFirstPerson(false);

		bool executeUpdate=true;//playerHasCards || (pmode!=PokerCameraModel::CAMERA_FREE_MODE);
		if ( executeUpdate) {
			switch(mCamera->Update(event, GetDelta(), bodyFocused, elementsFocusedThatShouldBeIgnoredByCamera)) {
			case PokerPlayerCamera::NONE:
				break;
			default:
				break;
			}

			switch(mCamera->GetCameraState()) {
			case PokerPlayerCamera::START_FIRST_PERSON:
				{
					{
						g_debug("PokerPlayerCamera::START_FIRST_PERSON");
						osg::ref_ptr<MAFPacket> packet = mGame->GetPacketsModule()->Create("PacketPokerPythonAnimation");
						std::string str="stopWaitIdle";
						packet->SetMember("animation", str);
						packet->SetMember("serial", mGame->GetPoker()->GetModel()->mMe);
						packet->SetMember("game_id", mGame->GetPoker()->GetModel()->mGameSerial);
						mGame->PythonCall("schedulePacket", packet.get());
						if (playerHasCards)
							if (!IsStartLookingCards() && !IsLookingCards()) {
								if (mInPosition && mRaiseInteractor->GetNodeDisplayed("clicked") ) { // we need to schedule lookcards
									mGame->PythonCall("scheduleLookCardsAfterInteractionAnimation");
									g_debug("scheduleLookCardsAfterInteractionAnimation");
								} else {
									mGame->PythonCall("maybeStartLookCards");
									g_debug("maybeStartLookCards");
								}
							}
					}
				}
				break;
			case PokerPlayerCamera::END_FIRST_PERSON:
				{
					g_debug("PokerPlayerCamera::END_FIRST_PERSON");
					std::string str="startWaitIdle";
					osg::ref_ptr<MAFPacket> packet = mGame->GetPacketsModule()->Create("PacketPokerPythonAnimation");
					packet->SetMember("animation", str);
					packet->SetMember("serial", mGame->GetPoker()->GetModel()->mMe);
					packet->SetMember("game_id", mGame->GetPoker()->GetModel()->mGameSerial);
					mGame->PythonCall("schedulePacket", packet.get());
					if (playerHasCards)
					  mGame->PythonCall("maybeStopLookCards");
				}
				break;
			default:
				break;
			}
			// manage cards state
			if (mMe && event)
				switch(event->type) {
				case SDL_MOUSEBUTTONUP:
					{
						if  (event->button.button != SDL_BUTTON_LEFT)
							break;

						if (pmode == PokerCameraModel::CAMERA_GAME_MODE) {
							if (bodyFocused) {
								if (!IsStartLookingCards() && !IsLookingCards()) {
								  if (playerHasCards) {
										if (mRaiseInteractor->mWaitingForValid) { // we need to schedule lookcards
											mGame->PythonCall("scheduleLookCardsAfterInteractionAnimation");
											g_debug("scheduleLookCardsAfterInteractionAnimation");
										} else {
											mGame->PythonCall("maybeStartLookCards");
											g_debug("maybeStartLookCards");
										}
								  }
								} else if (IsLookingCards()) {
									mGame->PythonCall("maybeStopLookCards");
									g_debug("maybeStopLookCards");
								}
							}
						}
					}
					break;
				}

		}
	}

#ifdef TUNE_SOUND_PLAYER
	if (mMe && event && event->type == SDL_KEYUP) {
		static unsigned int soundToTest = 0;
		switch(event->key.keysym.sym) {
		case SDLK_e:
			{
				mSoundSource->Play("bet");
			}
			break;
		case SDLK_q:
			{
				soundToTest = (soundToTest+2*mSoundSource->GetModel()->mSounds.size() - 1) % mSoundSource->GetModel()->mSounds.size();
				g_debug("Sound %i", soundToTest);
			}
			break;
		case SDLK_w:
			{
				soundToTest = (soundToTest+1) % mSoundSource->GetModel()->mSounds.size();
				g_debug("Sound %i", soundToTest);
			}
			break;

		case SDLK_a:
			{
				std::string sname = "none";
				int i = 0;
				for (MAFAudioSourceModel::SoundMap::iterator it = mSoundSource->GetModel()->mSounds.begin(); it != mSoundSource->GetModel()->mSounds.end(); it++) {
					if (soundToTest == i) {
						sname = it->first;
						float gain = it->second.mGain + 0.1;
						if (gain>1.0)
							gain = 1.0;
						it->second.mGain = gain;
						g_debug("Sound %s gain changed to %f", sname.c_str(), gain);
						break;
					}
					i++;
				}
			}
			break;
		case SDLK_z:
			{
				std::string sname = "none";
				int i = 0;
				for (MAFAudioSourceModel::SoundMap::iterator it = mSoundSource->GetModel()->mSounds.begin(); it != mSoundSource->GetModel()->mSounds.end(); it++) {
					if (soundToTest == i) {
						sname = it->first;
						float gain = it->second.mGain - .1;
						if (gain < 0)
							gain = 0;
						it->second.mGain = gain;
						g_debug("Sound %s gain changed to %f", sname.c_str(), gain);
						break;
					}
					i++;
				}
			}
			break;

		case SDLK_d:
			{
				std::string sname = "none";
				int i = 0;
				for (MAFAudioSourceModel::SoundMap::iterator it = mSoundSource->GetModel()->mSounds.begin(); it != mSoundSource->GetModel()->mSounds.end(); it++) {
					if (soundToTest == i) {
						sname = it->first;
						float v = it->second.mRolloff + 0.5;
						it->second.mRolloff = v;
						g_debug("Sound %s rollof changed to %f", sname.c_str(), v);
						break;
					}
					i++;
				}
			}
			break;
		case SDLK_c:
			{
				std::string sname = "none";
				int i = 0;
				for (MAFAudioSourceModel::SoundMap::iterator it = mSoundSource->GetModel()->mSounds.begin(); it != mSoundSource->GetModel()->mSounds.end(); it++) {
					if (soundToTest == i) {
						sname = it->first;
						float v = it->second.mRolloff - 0.5;
						if (v < 0)
							v = 0;
						it->second.mRolloff = v;
						g_debug("Sound %s rollof changed to %f", sname.c_str(), v);
						break;
					}
					i++;
				}
			}
			break;

		case SDLK_s:
			{
				std::string sname = "none";
				int i = 0;
				for (MAFAudioSourceModel::SoundMap::iterator it = mSoundSource->GetModel()->mSounds.begin(); it != mSoundSource->GetModel()->mSounds.end(); it++) {
					if (soundToTest == i) {
						sname = it->first;
						float v = it->second.mReferenceDistance + 5;
						it->second.mReferenceDistance = v;
						g_debug("Sound %s refdist changed to %f", sname.c_str(), v);
						break;
					}
					i++;
				}
			}
			break;
		case SDLK_x:
			{
				std::string sname = "none";
				int i = 0;
				for (MAFAudioSourceModel::SoundMap::iterator it = mSoundSource->GetModel()->mSounds.begin(); it != mSoundSource->GetModel()->mSounds.end(); it++) {
					if (soundToTest == i) {
						sname = it->first;
						float v = it->second.mReferenceDistance - 5;
						if (v < 1)
							v = 1;
						it->second.mReferenceDistance = v;
						g_debug("Sound %s refdist changed to %f", sname.c_str(), v);
						break;
					}
					i++;
				}
			}
			break;

		case SDLK_SPACE:
			{
				std::string sname = "none";
				int i = 0;
				for (MAFAudioSourceModel::SoundMap::iterator it = mSoundSource->GetModel()->mSounds.begin(); it != mSoundSource->GetModel()->mSounds.end(); it++) {
					if (soundToTest == i) {
						sname = it->first;
						break;
					}
					i++;
				}
				mSoundSource->Play(sname);
				g_debug("SoundTest For MainPlayer %s", sname);
			}
			break;
		default:
			break;
		}
	}
#endif


		return true;
}

void PokerPlayer::DisableSound()
{
  if (mSoundSource.get())
    mSoundSource->Disable();
}

void PokerPlayer::EnableSound()
{
  if (mSoundSource.get())
    mSoundSource->Enable();
}


void PokerPlayer::TimeoutAdvise(float timeToPlay)
{
	mTimeout->SetCounter(timeToPlay);
	mTimeout->SetEnable(true);
	if (mMe)
		mPPTimeout->Start();
}


void PokerPlayer::MouseState::WarpMouse(bool state)
{
  mWarp = state; 
  mCursor->ShowCursor(!state);
}

void PokerPlayer::MouseState::Update(SDL_Event *event)
{
  if (mStateChanged)
    mStateChanged = false;

  mRX = 0;
  mRY = 0;
  if (event)
    switch(event->type)
      {
      case SDL_MOUSEBUTTONDOWN:
        if  (event->button.button == SDL_BUTTON_LEFT)	
          LeftClick(true);
        break;
      case SDL_MOUSEBUTTONUP:
        if  (event->button.button == SDL_BUTTON_LEFT)
          LeftClick(false);
        break;
      case SDL_MOUSEMOTION:
        {
          mRX = event->motion.xrel;
          mRY = event->motion.yrel;

          if (mWarp)
            {
              if (event->motion.x != mX || event->motion.y != mY)	      
                mCursor->WarpMouse(mX,mY);
              // 		  SDL_WarpMouse(mX, mY);
              else
                {
                  mRX = 0;
                  mRY = 0;
                }
            }
          else
            {
              mX = event->motion.x;
              mY = event->motion.y;
            }
        }
        break;
      default:
        break;
      }
}


struct PokerPlayerUtil
{
  static void ScreenPosNormalize(osg::Vec3 &out, const osg::Vec3 &in, PokerApplication *application)
  {
    float x = in.x();
    float y = in.y();
    float width = application->GetWindow(true)->GetWidth();
    float height = application->GetWindow(true)->GetHeight();
    float widthOver2 = width / 2.0f;
    float heightOver2 = height / 2.0f;
    out = osg::Vec3((x - widthOver2)/widthOver2, -((y - heightOver2)/heightOver2), 0.0f);
  }
  static void ScreenDirNormalize(osg::Vec3 &out, const osg::Vec3 &in, PokerApplication *application)
  {
    float x = in.x();
    float y = in.y();
    float width = application->GetWindow(true)->GetWidth();
    float height = application->GetWindow(true)->GetHeight();
    float widthOver2 = width / 2.0f;
    float heightOver2 = height / 2.0f;
    out = osg::Vec3(x/widthOver2, -(y/heightOver2), 0.0f);
  }
};


PokerMoveChipsBet2PotController* PokerPlayer::GetFreeAnimationBet2Pot()
{
  int e=(int)mMoveChipsFromBetToPot.size();
  for (int i=0;i<e;i++)
    if (mMoveChipsFromBetToPot[i]->IsFinished())
      return mMoveChipsFromBetToPot[i].get();

  // no free so alloc a new one
  /// from bet to pot
  std::string playerBetZone = mGame->HeaderGet("sequence", "/sequence/player/@betzone");
  osg::Node* playerBetZoneNode=mSeatData->GetAnchor(playerBetZone);
  assert(playerBetZoneNode);

  PokerMoveChipsBet2PotController* a=new PokerMoveChipsBet2PotController(mGame,playerBetZoneNode,GetID());
  mMoveChipsFromBetToPot.push_back(a);
  mGame->mSetData->GetGroup()->addChild(a->mTransform.get());
  mGame->AddController(a);
  return a;

}


PokerMoveChipsPot2PlayerController* PokerPlayer::GetFreeAnimationPot2Player()
{
  int e=(int)mMoveChipsFromPotToPlayer.size();
  for (int i=0;i<e;i++)
    if (mMoveChipsFromPotToPlayer[i]->IsFinished())
      return mMoveChipsFromPotToPlayer[i].get();

  // no free so alloc a new one
  /// from pot to bet
  std::string playerChipsAnchor = mGame->HeaderGet("sequence", "/sequence/player/@betzone");
  osg::Node* playerChipsAnchorNode=mSeatData->GetAnchor(playerChipsAnchor);
  assert(playerChipsAnchorNode);

  PokerMoveChipsPot2PlayerController* a=new PokerMoveChipsPot2PlayerController(mGame,playerChipsAnchorNode,GetID());
  mMoveChipsFromPotToPlayer.push_back(a);
  mGame->mSetData->GetGroup()->addChild(a->mTransform.get());
  mGame->AddController(a);
  return a;
}


int PokerPlayer::GetMaxCardsAnimation() { return MAX_ANIMATION_CARD_TO_PLAY;}

void PokerPlayer::AnimateCard(int i)
{
  mAnimate1Card[i]->setNodeMask(MAF_VISIBLE_MASK | MAF_COLLISION_MASK);
  osg::MultipleAnimationPathCallback* cb=dynamic_cast<osg::MultipleAnimationPathCallback*>(mAnimate1Card[i]->getUpdateCallback());
  cb->setPause(false);
  cb->reset();
}


osg::MatrixTransform* PokerPlayer::GetAnimationCard(int i) 
{
  return mAnimate1Card[i].get();
}



void PokerPlayer::HideAnimateCard(int i)
{
  mAnimate1Card[i]->setNodeMask(~(MAF_VISIBLE_MASK|MAF_COLLISION_MASK));
  osg::MultipleAnimationPathCallback* cb=dynamic_cast<osg::MultipleAnimationPathCallback*>(mAnimate1Card[i]->getUpdateCallback());
  cb->reset();
  cb->setPause(true);
}

int PokerPlayer::GetNbCardsDisplayed()
{
  return mBody->GetModel()->GetNbCardsDisplayed();
}

void PokerPlayer::ShowCard(int i)
{
  mBody->GetModel()->ShowCard(i);
}

void PokerPlayer::HideCard(int i)
{
  mBody->GetModel()->HideCard(i);
}

void PokerPlayer::WriteFadeText(const std::string &_txt)
{
	if (mTextTime < 1)
		return; // tmp hack since this method can be called too many times atm

	mText->setStringUTF8(_txt);
	mTextTime = 0;
}

MAFAudioSourceController* PokerPlayer::GetSoundSource()
{
  return mSoundSource.get();
}
