/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *  Loic Dachary <loic@gnu.org>
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#include "pokerStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */

#ifndef POKER_USE_VS_PCH

#ifdef USE_NPROFILE
#include <nprofile/profile.h>
#else  //USE_NPROFILE
#define NPROFILE_SAMPLE(a)
#endif //USE_NPROFILE

#include <maf/window.h>
#include <maf/animate2d.h>

#include <osg/Matrix>
#include <osg/Quat>

#include <ugame/debug.h>

# include "PokerPlayer.h"
# include "PokerBody.h"
#	include "PokerApplication.h"
#	include "PokerCamera.h"
#	include "PokerError.h"
# include <varseditor/varseditor.h>

#include "maf/audio.h"
#include <CustomAssert/CustomAssert.h>

//#include "PokerDebug2D.h"

#endif

#define NbKeyFrames 16

#define POKER_CAMERA_POSITION 0
#define POKER_CAMERA_TARGET 1

#define POKER_CAMERA_ANIMATION_COUNT 2

#ifndef MAX
#define MAX(a,b)    (((a) > (b)) ? (a) : (b))
#endif
#ifndef MIN
#define MIN(a,b)    (((a) < (b)) ? (a) : (b))
#endif

// TODO: clean readjust routine

struct CamHelper
{
  static inline osg::Vec3 QuatGetUp(const osg::Quat &quat)
  {
    osg::Matrix mat;
    quat.get(mat);
    return osg::Vec3(MatrixGetUp(mat));
  }
  static inline osg::Vec3 QuatGetAt(const osg::Quat &quat)
  {
    osg::Matrix mat;
    quat.get(mat);
    return osg::Vec3(MatrixGetAt(mat));
  }
  static inline osg::Vec3 QuatGetRight(const osg::Quat &quat)
  {
    osg::Matrix mat;
    quat.get(mat);
    return osg::Vec3(MatrixGetRight(mat));
  }  
  static inline osg::Vec3 MatrixGetUp(const osg::Matrix &mat)
  {
    return osg::Vec3(mat(0, 1), mat(1, 1), mat(2, 1));
  }
  static inline osg::Vec3 MatrixGetAt(const osg::Matrix &mat)
  {
    return osg::Vec3(mat(0, 2), mat(1, 2), mat(2, 2));
  }
  static inline osg::Vec3 MatrixGetRight(const osg::Matrix &mat)
  {
    return osg::Vec3(mat(0, 0), mat(1, 0), mat(2, 0));
  } 
  static inline osg::Vec3 QuatRotate(const osg::Vec3 &in, const osg::Quat &quat)
  {
    osg::Quat V(osg::Vec4(in, 1.0f));
    osg::Quat rotatedPos;
    rotatedPos *= quat.conj();
    rotatedPos *= V;
    rotatedPos *= quat;
    return osg::Vec3(rotatedPos.asVec3());
  }
  static inline void QuatNormalize(osg::Quat &quat)
  {
    osg::Vec4 N = quat.asVec4();
    N.normalize();
    quat.set(N);
  }

  static inline osg::Quat QuatLookAt(const osg::Vec3 &position, const osg::Vec3 &target, const osg::Vec3 &up)
  {
    osg::Quat quat;
    quat.set(osg::Matrix::lookAt(position, target, up));
    return quat;
  }

  static inline osg::Quat QuatSlerp(double t, const osg::Quat& from, const osg::Quat& to, double scale = 1.0)
  {
    //    const double epsilon = 0.00001;
    double omega, cosomega, sinomega, scale_from, scale_to ;
    
    osg::Quat quatTo(to);
    // this is a dot product
    
    cosomega = from.asVec4() * to.asVec4();
    
    double phase = (scale - 1.0)*t;


    if ( cosomega <0.0 )
    { 
        cosomega = -cosomega; 
        quatTo = -to;
    }

    //    if( (1.0 - cosomega) > epsilon )
    //{
        omega= acos(cosomega) ;  // 0 <= omega <= Pi (see man acos)
        sinomega = sin(omega) ;  // this sinomega should always be +ve so
        // could try sinomega=sqrt(1-cosomega*cosomega) to avoid a sin()?
        scale_from = sin((1.0-t)*omega-phase)/sinomega ;
        scale_to = sin(t*omega+phase)/sinomega ;
	//}
  //else
  // {
        /* --------------------------------------------------
           The ends of the vectors are very close
           we can use simple linear interpolation - no need
           to worry about the "spherical" interpolation
           -------------------------------------------------- */
  //scale_from = 1.0 - t ;
  //     scale_to = t ;
  //  }
	
	return osg::Quat((from*scale_from) + (quatTo*scale_to));
	
	// so that we get a Vec4
  }
};


PokerCameraModel::PokerCameraModel() :
  mKeys(POKER_CAMERA_ANIMATION_COUNT),
  mSpline(POKER_CAMERA_ANIMATION_COUNT),
  mIsMoving(POKER_CAMERA_ANIMATION_COUNT),
  mRotateX(0.f),
  mRotateY(0.f),
  mNeedReadjust(false),
  mReadjusting(false),
  mReadjustTimeout(0.0f),
  mReadjustScale(1.0f),
	mFirstPersonReadjusting(false),
  mMode(CAMERA_FREE_MODE),
  mModeChanged(false),
  mAnglePixelRatio(20.f)
{
  for(int i = 0; i < POKER_CAMERA_ANIMATION_COUNT; i++) {
    mKeys[i] = new KeyFrame[2*NbKeyFrames];
    mIsMoving[i] = false;
  }
	mWasClickedWithNoFocus = false;
}

PokerCameraModel::~PokerCameraModel()
{
  for(int i = 0; i < POKER_CAMERA_ANIMATION_COUNT; i++)
    delete [] mKeys[i];
}

void PokerCameraModel::StartInterpolation(float timeout)
{
  mTimer.Init(timeout);
  SetIsMoving(true);
}

void PokerCameraModel::SetupTargetInterpolator(const osg::Vec3 &target)
{  
  const osg::Vec3 &targetFrom = GetTarget();
  const osg::Vec3 &targetTo = target;
  mTargetBInterpolator.Init(targetFrom, targetTo);
}

void PokerCameraModel::SetupLengthInterpolator(const osg::Vec3 &position, const osg::Vec3 &target)
{
  const osg::Vec3 &positionFrom = GetPosition();
  const osg::Vec3 &positionTo = position;
  const osg::Vec3 &targetFrom = GetTarget();
  const osg::Vec3 &targetTo = target;
  float lengthFrom = (targetFrom - positionFrom).length();
  float lengthTo = (targetTo - positionTo).length();

  mLengthBInterpolator.Init(lengthFrom, lengthTo);
  mCamNextPosition = positionTo;
  mCamPrevPosition = positionFrom;
  mCamNextTarget = targetTo;
  mCamPrevTarget = targetFrom;
}

void PokerCameraModel::SetupFovInterpolator(float fov)
{
  mFovBInterpolator.Init(GetFov(), fov);
  mCamNextFov = fov;
  mCamPrevFov = GetFov();
}

void PokerCameraModel::SetupRotationInterpolator(const osg::Quat &attitude)
{
  const osg::Quat &attitudeFrom = mCamAttitude;
  const osg::Quat &attitudeTo = attitude;

  mRotationBInterpolator.Init(attitudeFrom, attitudeTo);

  mCamNextAttitude = attitudeTo;
  if (mReadjusting)
    {
      mReadjusting = false;
      mReadjustBInterpolator.Get(mCamPrevAttitude, 1.0f, 1.0f);
    }
  else    
    {
      mCamPrevAttitude = attitudeFrom;
    }
}


void PokerCameraModel::SetupReadjustInterpolator(const osg::Quat &attitude)
{
  const osg::Quat &attitudeFrom = mCamAttitude;
  const osg::Quat &attitudeTo = attitude;
  mReadjustBInterpolator.Init(attitudeFrom, attitudeTo);
}


void PokerCameraModel::SetupInterpolators(const osg::Vec3 &position, const osg::Vec3 &target, const osg::Vec3 &up, float fovTo, float timeout)
{
  osg::Quat attitude;
  attitude.set(osg::Matrix::lookAt(position, target, up));
  SetupInterpolators(position, target, attitude, fovTo, timeout);
}

void PokerCameraModel::SetupInterpolators(const osg::Vec3 &position, const osg::Vec3 &target, const osg::Quat& attitude, float fovTo, float timeout)
{
  const osg::Vec3 &positionFrom = GetPosition();
  const osg::Vec3 &positionTo = position;
  const osg::Vec3 &targetFrom = GetTarget();
  const osg::Vec3 &targetTo = target;
  float lengthFrom = (targetFrom - positionFrom).length();
  float lengthTo = (targetTo - positionTo).length();

  const osg::Quat &attitudeFrom = mCamAttitude;
  const osg::Quat &attitudeTo = attitude;

  mTargetBInterpolator.Init(targetFrom, targetTo);
  mLengthBInterpolator.Init(lengthFrom, lengthTo);
  if (mReadjusting)
    mReadjustBInterpolator.Init(attitudeFrom, attitudeTo);
  else
    mRotationBInterpolator.Init(attitudeFrom, attitudeTo);
  mFovBInterpolator.Init(GetFov(), fovTo);
  
  
  mCamPrevAttitude = attitudeFrom;
  if (mReadjusting)
    mRotationBInterpolator.Get(mCamPrevAttitude, 1.0f);
  mCamPrevPosition = positionFrom;
  mCamPrevTarget = targetFrom;  
  mCamPrevFov = GetFov();

  mTimer.Init(timeout);
  SetIsMoving(true);
}

void PokerCameraModel::Readjust()
{
  osg::Matrix mat;
  mCamAttitude.get(mat);
  osg::Vec3 eye, target, up;
  mat.getLookAt(eye, target, up);
  float angle = osg::PI * 1.0f;
  osg::Quat q(angle, GetTarget()-GetPosition());
  //up = CamHelper::QuatRotate(up, q);
  mReadjusting = true;
  //mReadjustScale = 1.5f;

  SetupReadjustInterpolator(CamHelper::QuatLookAt(GetPosition(), GetTarget(), -up));
  float timeout = 1250.0f;
  StartInterpolation(timeout);
}

bool PokerCameraModel::GetIsMoving(void) {
  for(int i = 0; i < POKER_CAMERA_ANIMATION_COUNT; i++) {
    if(mIsMoving[i] == true)
      return true;
  }
  return false;
}

void PokerCameraModel::SetIsMoving(bool isMoving) {
  for(int i = 0; i < POKER_CAMERA_ANIMATION_COUNT; i++)
    mIsMoving[i] = isMoving;
}

void PokerCameraModel::Update(float delta) {

  if (mTimer.Finished())
    {
      SetIsMoving(false);
      if (mReadjusting)
	  mReadjusting = false;
			if (mFirstPersonReadjusting)
				mFirstPersonReadjusting = false;
      return;
    }

  //else
  mTimer.AddTime(delta);
  
  osg::Quat current;

  if (mReadjusting)
    {
      mTimer.Get(current, mReadjustBInterpolator, mReadjustScale);
      osg::Matrix mat;
      current.get(mat);
      osg::Vec3 eye, center, up;
      mat.getLookAt(eye, center, up);
			SetUp(up);
      mCamAttitude = current;
      return;
    }
  if (mFirstPersonReadjusting)
	{
      mTimer.Get(current, mFirstPersonBInterpolator, mReadjustScale);
      osg::Matrix mat;
      current.get(mat);
      osg::Vec3 eye, center, up;
      mat.getLookAt(eye, center, up);
			SetPosition(GetPosition() + eye);
			SetTarget(GetPosition() + center);
			SetUp(up);
      mCamAttitude = current;
      return;
	}

  mTimer.Get(current, mRotationBInterpolator);

  osg::Vec3 target;  
  mTimer.Get(target, mTargetBInterpolator);
  float length;
  mTimer.Get(length, mLengthBInterpolator);
  float fov;
  mTimer.Get(fov, mFovBInterpolator);

  osg::Matrix mat;
  current.get(mat);
  osg::Vec3 eye, center, up;
  mat.getLookAt(eye, center, up);
  osg::Vec3 at;
  at = (center - eye);
  at.normalize();

  // set LookAt
  SetPosition(target - at * length);
  SetTarget(target);	
  SetUp(up);
//	fov = 30;
  SetFov(fov);

  mCamAttitude = current;
  return;
}

void PokerCameraModel::LoadKeys(std::vector<osg::Vec2> &keys, MAFXmlData *data, const std::string &name)
{
  if (data != NULL)
  {
    const std::list<std::string> &xResultList = data->GetList("/splines/" + name + "/list/entry/@xvalue");
    const std::list<std::string> &yResultList = data->GetList("/splines/" + name + "/list/entry/@yvalue");
    
    g_assert(xResultList.size() == yResultList.size());
    typedef std::list<std::string>::const_iterator It;
    It xbegin = xResultList.begin();
    It xend = xResultList.end();
    
    It ybegin = yResultList.begin();
    It yend = yResultList.end();
    
    while(xbegin != xend) {
      keys.push_back(osg::Vec2(atof((*xbegin).c_str()), atof((*ybegin).c_str())));
      xbegin++;
      ybegin++;
   	}
  }
}

// controller

PokerCameraController::PokerCameraController(PokerApplication* game,unsigned int controllerID) : MAFCameraController(controllerID), mGame(game), mRespondToEvents(true), mCurrent(1) {
  SetModel(new PokerCameraModel());
	//  Init();
}

PokerCameraController::~PokerCameraController()
{
}

void PokerCameraController::Init(void) {
  MAFCameraController::Init();

  GetModel()->mCamAttitude.set(osg::Matrix::lookAt(GetModel()->GetPosition(), GetModel()->GetTarget(), GetModel()->GetUp()));
  GetModel()->mCamPosition = GetModel()->GetPosition();
  GetModel()->mFirstTime = true; // HACK

  const std::string &url = mGame->HeaderGet("sequence", "/sequence/cameras/cameraspline/@url");
  const std::string &rotate = mGame->HeaderGet("sequence", "/sequence/cameras/cameraspline/@rotate");
  const std::string &target = mGame->HeaderGet("sequence", "/sequence/cameras/cameraspline/@target");
  const std::string &length = mGame->HeaderGet("sequence", "/sequence/cameras/cameraspline/@length");
  const std::string &readjust = mGame->HeaderGet("sequence", "/sequence/cameras/cameraspline/@readjust");
	const std::string &firstPerson = mGame->HeaderGet("sequence", "/sequence/cameras/cameraspline/@firstPerson");

  MAFXmlData *data = mGame->mDatas->GetXml(url);
  GetModel()->LoadSpline(GetModel()->mRotationBInterpolator, data, rotate);
  GetModel()->LoadSpline(GetModel()->mReadjustBInterpolator, data, readjust);
  GetModel()->LoadSpline(GetModel()->mFirstPersonBInterpolator, data, firstPerson);
  float value = GetModel()->mReadjustBInterpolator.GetT(1.0f);
  GetModel()->mReadjustScale = 1.0f / value;

  GetModel()->LoadSpline(GetModel()->mTargetBInterpolator, data, target);
  GetModel()->LoadSpline(GetModel()->mLengthBInterpolator, data, length);
  GetModel()->LoadSpline(GetModel()->mFovBInterpolator, data, length);

  const std::string &anglePixelRatio = mGame->HeaderGet("sequence", "/sequence/cameras/@anglePixelRatio");
  if(anglePixelRatio != "")
    GetModel()->SetAnglePixelRatio(atof(anglePixelRatio.c_str()));

	const std::string &soundName = mGame->HeaderGet("sequence", "/sequence/cameras/cameraspline/@sound");
	if (!soundName.empty()) {
		MAFAudioData* soundData = mGame->mDatas->GetAudio(soundName);
		MAFAudioModel* audio_model = new MAFAudioModel;
		audio_model->SetName(soundName);
		audio_model->SetData(soundData);
		MAFAudioController* audio_controller = new MAFAudioController;
		audio_controller->SetModel(audio_model);
		audio_controller->Init();
		audio_model->SetAmbient(true);
		audio_model->SetSoundEvent(true);
		mSound = audio_controller;
	} else
		g_critical("PokerCameraController::Init /sequence/cameras/cameraspline/@sound not found in configuration file");

	GetModel()->mMinTargetHeight = atof(mGame->HeaderGet("sequence", "/sequence/cameras/@minTargetHeight").c_str());
	GetModel()->mMaxTargetHeight = atof(mGame->HeaderGet("sequence", "/sequence/cameras/@maxTargetHeight").c_str());	
	GetModel()->mMinTargetDistance = atof(mGame->HeaderGet("sequence", "/sequence/cameras/@minTargetDistance").c_str());
	GetModel()->mMaxTargetDistance = atof(mGame->HeaderGet("sequence", "/sequence/cameras/@maxTargetDistance").c_str());	
}

void PokerCameraController::Rotate(float dx, float dy, float dz)
{
  switch(GetMode())
    {
    case PokerCameraModel::CAMERA_FREE_MODE:
      RotateFreeMode(dx, dy, dz);
      break;
    case PokerCameraModel::CAMERA_GAME_MODE:
			RotateGameMode(dx, dy, dz);
      break;
    default:
      break;
    }
}

void PokerCameraController::RotateFreeMode(float dx, float dy, float dz)
{
	//g_debug2d.Init(mGame);
  const osg::Vec3 &positionFrom = GetModel()->GetPosition();
  const osg::Vec3 &targetFrom = GetModel()->GetTarget();

  osg::Vec3 atFrom = positionFrom - targetFrom;
  atFrom.normalize();

  osg::Vec3 up = osg::Vec3(0.0f, 1.0f, 0.0f);

  float lengthFrom = (positionFrom - targetFrom).length();
  float factor = 1.0f;
  float angleFrom = acosf(atFrom * up);

  const osg::Quat &attitudeFrom = GetModel()->mCamAttitude;
  osg::Matrix matAttitudeFrom;
  attitudeFrom.get(matAttitudeFrom);
  osg::Vec3 eyeFrom, centerFrom, upFrom;
  matAttitudeFrom.getLookAt(eyeFrom, centerFrom, upFrom);
  

  float signFrom = (upFrom * up >= 0 ? 1.0f : -1.0f);
  angleFrom = angleFrom * signFrom;

  float anglePixelRatio = GetModel()->GetAnglePixelRatio();
  float ratioX = mGame->GetWindow(true)->GetWidth() / anglePixelRatio;
  float ratioY = mGame->GetWindow(true)->GetHeight() / anglePixelRatio;
  float drotateX = (osg::PI_4 * dx) / ratioX;
  float drotateY = (osg::PI_4 * dy * factor) / ratioY;


  float newAngle = angleFrom - drotateY;
  // drotateY is inverted
  if (newAngle > osg::PI_2)
    newAngle = osg::PI_2;
  else if (newAngle < -osg::PI_2)
    newAngle = -osg::PI_2;
  drotateY = angleFrom - newAngle;
  
  osg::Quat attitudeTo = attitudeFrom;

  osg::Quat qX(drotateX, up);
  attitudeTo = qX * attitudeTo;

  osg::Vec3 right = CamHelper::QuatGetRight(attitudeTo);
  osg::Quat qY(drotateY, right);
  attitudeTo = qY * attitudeTo;
  
  CamHelper::QuatNormalize(attitudeTo);
 
  osg::Matrix matAttitudeTo;
  attitudeTo.get(matAttitudeTo);
  osg::Vec3 eyeTo, centerTo, upTo;
  matAttitudeTo.getLookAt(eyeTo, centerTo, upTo);
  osg::Vec3 atTo = eyeTo - centerTo;
  atTo.normalize();

	
	//float newLength = ((GetModel()->GetPosition() + offset)).length();
// 				if (newLength < GetModel()->mMinTargetDistance)
// 					{
// 						osg::Vec3 N = GetModel()->GetPosition();
// 						N.normalize();
// 						N *= GetModel()->mMinTargetDistance;
// 						GetModel()->SetPosition(N);
// 					}
// 				else if (newLength > GetModel()->mMaxTargetDistance)
// 					{
// 						osg::Vec3 N = GetModel()->GetPosition();
// 						N.normalize();
// 						N *= GetModel()->mMaxTargetDistance;
// 						GetModel()->SetPosition(N);
// 					}
// 				else
// 					GetModel()->SetPosition(GetModel()->GetPosition() + offset);
// 			}

	float minLength = GetModel()->mMinTargetDistance;
	float maxLength = GetModel()->mMaxTargetDistance;
	VarsEditor::Instance().Get("PC_MinTargetDistance",minLength);
	VarsEditor::Instance().Get("PC_MaxTargetDistance",maxLength);


  float lengthTo = lengthFrom + dz * anglePixelRatio;
	{
		if (lengthTo < minLength)
			lengthTo = minLength;
		else if (lengthTo > maxLength)
			lengthTo = maxLength;
	}
	osg::Vec3 targetTo;
	{
		osg::Vec3 tableTargetMin = osg::Vec3(0.0f, GetModel()->mMinTargetHeight, 0.0f);
		osg::Vec3 tableTargetMax = osg::Vec3(0.0f, GetModel()->mMaxTargetHeight, 0.0f);
		float length = lengthTo;
		float currentLength = length - minLength;
		float t;
		t = currentLength / (maxLength*2 - minLength);
		t = MAX(t, 0.0f);
		t = MIN(t, 1.0f);
		targetTo = (tableTargetMin * (1.0f - t) + tableTargetMax * t);
	}

	

  osg::Vec3 positionTo =  targetTo + atTo * lengthTo;


  float angleTo = acosf(atTo * up);
  float signTo = (upTo * up >= 0 ? 1.0f : -1.0f);
  angleTo = angleTo * signTo;
  if (angleTo < -osg::PI_2/4.0f)
    {
			if ( GetModel()->mNeedReadjust == false )
				{
					GetModel()->mNeedReadjust = true;
					GetModel()->mReadjustTimeout = 200.0f;
				}
    }
  else
    GetModel()->mNeedReadjust = false;

  GetModel()->mCamAttitude = attitudeTo;
  GetModel()->SetPosition(positionTo);
  GetModel()->SetUp(upTo);
	GetModel()->SetTarget(targetTo);
}

void PokerCameraController::RotateGameMode(float dx, float dy, float dz)
{
  float anglePixelRatio = GetModel()->GetAnglePixelRatio();
  float ratioX = mGame->GetWindow(true)->GetWidth() / anglePixelRatio;
  float ratioY = mGame->GetWindow(true)->GetHeight() / anglePixelRatio;
  float drotateX = (osg::PI_4 * dx) / ratioX;
	float drotateY = (osg::PI_4 * dy) / ratioY;
	const osg::Vec3& cameraPos = GetModel()->GetPosition();
	const osg::Vec3& cameraTarget = GetModel()->GetTarget();

	const osg::Quat& cameraAttitudeFrom = GetModel()->mCamAttitude;

	osg::Vec3 cameraPos2Target = cameraTarget - cameraPos;
	// at seems inversed
	osg::Vec3 cameraAt = -CamHelper::QuatGetAt(cameraAttitudeFrom);
	cameraAt.normalize();
	osg::Vec3 cameraRight = CamHelper::QuatGetRight(cameraAttitudeFrom);
	cameraRight.normalize();
	osg::Vec3 cameraUp = CamHelper::QuatGetUp(cameraAttitudeFrom);
	cameraUp.normalize();

	const osg::Vec3& playerPos = cameraPos;
	osg::Vec3 playerAt = osg::Vec3(0.0f, playerPos.y(), 0.0f) - playerPos;
	playerAt.normalize();
	osg::Vec3 playerUp = osg::Vec3(0.0f, 1.0f, 0.0f);
	osg::Vec3 playerRight = playerAt ^ playerUp;

	osg::Vec3 cameraInPlayerSpace;
	cameraInPlayerSpace.z() = cameraRight * playerAt;
	cameraInPlayerSpace.y() = cameraRight * playerUp;
	cameraInPlayerSpace.x() = cameraRight * playerRight; 	


	float angleXFrom = atan2(cameraInPlayerSpace.x(), cameraInPlayerSpace.z());
	angleXFrom -= osg::PI_2;
	if (angleXFrom < -osg::PI)
		angleXFrom += 2 * osg::PI;
	float angleXTo = angleXFrom + drotateX;

	float angleXMin = -0.70;
	float angleXMax = 0.70;
	VarsEditor::Instance().Get("PC_AngleXMin",angleXMin);
	VarsEditor::Instance().Get("PC_AngleXMax",angleXMax);

	//std::cout << "angleXFrom:" << angleXFrom << std::endl;
	//std::cout << "angleXTo:" << angleXTo << std::endl;
	angleXTo = std::min(std::max(angleXTo, angleXMin), angleXMax);
	drotateX = angleXTo - angleXFrom;
	if (drotateX > 0.0f)
	{
		float angleXMaxFactor = 1.0;
		VarsEditor::Instance().Get("PC_AngleXMaxFactor",angleXMaxFactor);
		drotateX *= ((angleXMax - angleXFrom)/angleXMax)*angleXMaxFactor;
	}
	else
	{
		float angleXMinFactor = 1.0;
		VarsEditor::Instance().Get("PC_AngleXMinFactor",angleXMinFactor);
		drotateX *= ((angleXMin - angleXFrom)/angleXMin)*angleXMinFactor;
	}

	osg::Vec3 cameraInPlayerSpace2;
	cameraInPlayerSpace2.z() = cameraUp * playerAt;
	cameraInPlayerSpace2.y() = cameraUp * playerUp;
	cameraInPlayerSpace2.x() = cameraUp * playerRight;

	float angleYFrom = atan2(cameraInPlayerSpace2.y(), cameraInPlayerSpace2.z());
	angleYFrom -= osg::PI_2;
	if (angleYFrom < -osg::PI)
		angleYFrom += 2 * osg::PI;
	float angleYTo = angleYFrom - drotateY;

	float angleYMin = -0.8;
	float angleYMax = 0.5;
	VarsEditor::Instance().Get("PC_AngleYMin",angleYMin);
	VarsEditor::Instance().Get("PC_AngleYMax",angleYMax);
	angleYTo = std::min(std::max(angleYTo, angleYMin), angleYMax);
	drotateY = angleYFrom - angleYTo;

	if (drotateY < 0.0f)
	{
		float angleYMaxFactor = 1.0;
		VarsEditor::Instance().Get("PC_AngleYMaxFactor",angleYMaxFactor);
		drotateY *= ((angleYMax - angleYFrom)/angleYMax)*angleYMaxFactor;
	}
	else
	{
		float angleYMinFactor = 1.0;
		VarsEditor::Instance().Get("PC_AngleYMinFactor",angleYMinFactor);
		drotateY *= ((angleYMin - angleYFrom)/angleYMin)*angleYMinFactor;
	}


	CUSTOM_ASSERT(!osg::isNaN(angleYFrom));
	CUSTOM_ASSERT(!osg::isNaN(drotateY));
	CUSTOM_ASSERT(!osg::isNaN(angleYTo));
#if 0
	std::cout << "angleYFrom(" << angleYFrom;
	std::cout << ") - drotateY(" << drotateY;
	std::cout << ") = angleYTo(" << angleYTo << ")" << std::endl;
#endif
//	EDITABLE(float, angleYMin, -0.80);
//	EDITABLE(float, angleYMax, 0.80);
//	angleYTo = std::min(std::max(angleYTo, angleYMin), angleYMax);
//	std::cout << "angleYFrom:" << angleYFrom << std::endl;
//	std::cout << "angleYTo:" << angleYTo << std::endl;
//	std::cout << "drotateY:" << drotateY << std::endl;

	//angleXFrom = atan2(cameraInPlayerSpace2.y(), cameraInPlayerSpace2.x())
	//EDITABLE(float, angleYMin, -0.80);
	//EDITABLE(float, angleYMax, 0.80);
	//drotateY is inverted
	//if (angleTo > angleYMax)
	//{
	//		angleTo = angleYMax;
	//}
	//else if (angleTo < angleYMin)
	//{
	//		angleTo = angleYMin;
	//}
	//drotateY = angleFrom - angleTo;
	//}
	//std::cout << angleFrom << std::endl;


	osg::Quat cameraAttitudeTo = GetModel()->mCamAttitude;
	osg::Quat rotationX = osg::Quat(drotateX, osg::Vec3(0.0f, 1.0f, 0.0f));
	cameraAttitudeTo = rotationX * cameraAttitudeTo;
	osg::Quat rotationY = osg::Quat(drotateY, CamHelper::QuatGetRight(cameraAttitudeTo));
	cameraAttitudeTo = rotationY * cameraAttitudeTo;

	osg::Vec3 cameraUpTo = CamHelper::QuatGetUp(cameraAttitudeTo);
	osg::Vec3 cameraAtTo = CamHelper::QuatGetAt(cameraAttitudeTo);
	cameraUpTo.normalize();
	cameraAtTo.normalize();

	osg::Vec3 cameraTargetTo =  cameraPos - (cameraAtTo * cameraPos2Target.length());

	GetModel()->SetTarget(cameraTargetTo);
	GetModel()->SetUp(cameraUpTo);
	GetModel()->mCamAttitude = cameraAttitudeTo;

	return;
}

bool PokerCameraController::Update(MAFApplication* application) 
{  
  NPROFILE_SAMPLE("PokerCameraController::Update");

  SDL_Event*	event = application->GetLastEvent(this);

	float dt = application->GetDeltaFrame() / 1000.0f;

	static float dx = 0.0f;
	static float dy = 0.0f;
	static float dz = 0.0f;


  //init
  if (GetModel()->mFirstTime)
    {
      const osg::Vec3 &eye = GetModel()->GetPosition();
      const osg::Vec3 &center = GetModel()->GetTarget();
      osg::Vec3 up(0.0f,1.0f,0.0f);
      osg::Matrix mat;
      mat.makeLookAt(eye, center, up);
      GetModel()->mCamAttitude.set(mat);
      GetModel()->mFirstTime = false;
    }


  bool noFocusOrFocusLocked = (application->GetFocus() == NULL);
	if (!noFocusOrFocusLocked) {
		PokerApplication* pa = static_cast<PokerApplication*>(application);
		PokerBodyController* focusPlayerBody = dynamic_cast<PokerBodyController*>(pa->GetFocus());

		if (focusPlayerBody) {
			PokerModel::Serial2Player& s2p = pa->GetPoker()->GetModel()->mSerial2Player;

			PokerPlayer* player = pa->GetPoker()->GetModel()->GetLocalPlayer();
			if (player) {
				PokerBodyController* bodyMe = player->GetBody();
				if (bodyMe != focusPlayerBody)
					for (PokerModel::Serial2Player::iterator it = s2p.begin(); it != s2p.end(); it++) {
						if (it->second.get()) {
							PokerBodyController* bodyToTest = it->second->GetBody();
							if (bodyToTest == focusPlayerBody) {
								noFocusOrFocusLocked = true;
								break;
							}
						}
					}
			} else  {
			  noFocusOrFocusLocked = true;
			}
		}
	}

	//  static bool wasClickedWithNoFocus = false;

  if (event)
    {
      if (event->type == SDL_MOUSEBUTTONDOWN) 
				{
					if (event->button.button == SDL_BUTTON_LEFT)
						{
							//std::cout << "wasClickedWithNoFocus:" << noFocusOrFocusLocked << std::endl;
							GetModel()->mWasClickedWithNoFocus = noFocusOrFocusLocked;
						}
				}
      else if (event->type == SDL_MOUSEBUTTONUP) 
				{
				}
    }

  if(GetModel()->GetIsMoving())
    {
      //std::cout << "GetIsMoving == true" << std::endl;
      GetModel()->Update(GetDelta());
    } 
  else if(GetRespondToEvents() && event)
    {
      //std::cout << "GetRespondToEvents == true" << std::endl;
      if (GetMode() == PokerCameraModel::CAMERA_FREE_MODE)
				{
					if (GetModel()->mWasClickedWithNoFocus)
						{
							if(event->type == SDL_MOUSEMOTION && (SDL_GetMouseState(NULL, NULL) & SDL_BUTTON(1)))
								{			
									dx = event->motion.xrel * mCurrent;
									dy = event->motion.yrel;
									application->LockFocus();
								}
							else if ((SDL_GetMouseState(NULL, NULL) & SDL_BUTTON(1)) == 0)
								{
									application->UnlockFocus();
								}
						}
					if(event->type == SDL_MOUSEBUTTONDOWN) 
						{
							mCurrent = (event->motion.y < (application->GetWindow(true)->GetHeight()/2)) ? -1 : 1;
							switch (event->button.button)
								{
								case SDL_BUTTON_WHEELUP:
									dz = -1.0f * dt*70;
									break;
								case SDL_BUTTON_WHEELDOWN:
									dz = 1.0f * dt*70;
									break;
								case SDL_BUTTON_LEFT:				  
								default:
									break;
								}
						} 
					else if (event->type == SDL_KEYDOWN) 
						{
							switch(event->key.keysym.sym) 
								{
								case SDLK_UP:
									dz = -1.0f * dt*70;
									break;
								case SDLK_DOWN:
									dz = 1.0f * dt*70;
									break;
								default:
									break;
								}
						}
				}
      else if (GetMode() == PokerCameraModel::CAMERA_GAME_MODE)
				{
					if (GetModel()->mWasClickedWithNoFocus) 
						{
							//TODO: Move in PokerPlayerCamera ?
							if(event->type == SDL_MOUSEMOTION && (SDL_GetMouseState(NULL, NULL) & SDL_BUTTON(1)))
								{
									dx = event->motion.xrel;
									dy = event->motion.yrel;
									application->LockFocus();
								}
							else if ((SDL_GetMouseState(NULL, NULL) & SDL_BUTTON(1)) == 0)
								{
									application->UnlockFocus();
								}
						}
				}
    }
  else if (GetModel()->mNeedReadjust)
    {
      // camera idle
      float timeout = GetModel()->mReadjustTimeout;
      //std::cout << timeout << std::endl;
      if (timeout > 0.0f)
				timeout -= GetDeltaFrame();
      //std::cout << timeout << std::endl;
      if (timeout <= 0.0f)
				{
					timeout = 0.0f;
					if (GetMode() == PokerCameraModel::CAMERA_FREE_MODE)
						{
							mSound->Play();

							GetModel()->Readjust();
							GetModel()->mNeedReadjust = false;
						}
				}
      GetModel()->mReadjustTimeout = timeout;
    } 
  
  if (!event && GetModel()->mWasClickedWithNoFocus) // we take only the last event
    {
      Rotate(dx, dy, dz);
      dx = 0;
      dy = 0;
      float f = dt*6;
      if (f > 1) f = 1;
      dz *= 1 - f;
      //	dz = 0;
    }
  
  return true;
}

void PokerCameraController::MoveTo(const osg::Vec3 &position, const osg::Vec3 &target, float fov, float timeout)
{
  GetModel()->SetupTargetInterpolator(target);

  GetModel()->SetupLengthInterpolator(position, target);

  GetModel()->SetupFovInterpolator(fov);

  osg::Vec3 up = osg::Vec3(0.0f, 1.0f, 0.0f);
  GetModel()->SetupRotationInterpolator(CamHelper::QuatLookAt(position, target, up));

  GetModel()->StartInterpolation(timeout);
}

void PokerCameraController::MoveToPrevious(float timeout)
{
  const osg::Vec3 &target = GetModel()->mCamPrevTarget;
  const osg::Vec3 &position = GetModel()->mCamPrevPosition;
  float fov = GetModel()->mCamPrevFov;
  const osg::Quat &attitude = GetModel()->mCamPrevAttitude;

  GetModel()->SetupTargetInterpolator(target);

  GetModel()->SetupLengthInterpolator(position, target);

  GetModel()->SetupFovInterpolator(fov);

  GetModel()->SetupRotationInterpolator(attitude);

  GetModel()->StartInterpolation(timeout);
}

void PokerCameraController::SetMode(PokerCameraModel::Mode mode)
{
  GetModel()->SetMode(mode);
}
PokerCameraModel::Mode PokerCameraController::GetMode() const
{
  return GetModel()->GetMode();
}
void PokerCameraController::ConsumeMode()
{
  GetModel()->SetModeChanged(false);
}
bool PokerCameraController::ModeChanged() const
{
  return GetModel()->GetModeChanged();
}

void PokerCameraController::SetRespondToEvents(bool respondToEvents)
{
  if (respondToEvents == false)
    mGame->UnlockFocus();
  mRespondToEvents = respondToEvents;
}
