/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Cedric Pinson <cpinson@freesheep.org>
*
*/

#include "pokerStdAfx.h"

#ifndef POKER_USE_VS_PCH
#include <PokerMultiTable.h>
#include <PokerApplication.h>
#include <Poker.h>
#include "maf/window.h"
#include "maf/utils.h"

#include <osg/BlendFunc>
#include <osg/Geode>
#include <osg/Material>
#include <osg/Texture2D>

#endif


static void Plop()
{
	;
}

PokerMultiTable::PokerMultiTable(PokerApplication *game)
{
  // UGAMEArtefact Init
  UGAMEArtefactModel*	model = new UGAMEArtefactModel;
	model->Init();
  SetModel(model);
  Init();

	Plop();

	std::map<std::string,std::string> properties = game->HeaderGetProperties("sequence", "/sequence/multitable/button_switch");
	if (properties.empty())
		g_assert(0 && "/sequence/multitable/button_switch is missed in client.xml");

	mButtonSwithTable = new osg::Geometry;

	const std::string&	path = game->HeaderGet("settings", "/settings/data/@path");
	const std::string& textureName = game->HeaderGet("sequence", "/sequence/multitable/@button_switch_file");
	if (textureName.empty())
		g_assert(0 && "/sequence/multitable/button_switch_file is empty");

	osg::Texture2D *textureSwitch = MAFApplication::GetTextureManager()->GetTexture2D(path+"/"+textureName);
	g_assert(textureSwitch);

	osg::ref_ptr<osg::Vec3Array> vertexes = new osg::Vec3Array;
	osg::ref_ptr<osg::Vec2Array> uvs = new osg::Vec2Array;
	
	int delta_x = atoi(properties["x"].c_str());
	int delta_y = atoi(properties["y"].c_str());
	int width = atoi(properties["width"].c_str());
	int height = atoi(properties["height"].c_str());

	int screenW = game->GetWindow(true)->GetWidth();

	vertexes->push_back(osg::Vec3(screenW - width + delta_x, 0 + delta_y, 0));
	vertexes->push_back(osg::Vec3(screenW + delta_x, 0 + delta_y, 0));
	vertexes->push_back(osg::Vec3(screenW + delta_x, height + delta_y, 0));
	vertexes->push_back(osg::Vec3(screenW - width + delta_x, height + delta_y, 0));
	

	int s = 0;
	int t = 0;
	if (textureSwitch->getUserData()) {
		TextureInformation* info = dynamic_cast<TextureInformation*>(textureSwitch->getUserData());
		if (info) {
			s = info->getWidth();
			t = info->getHeight();
		} else {
			g_assert(0 && "can't deduce texture size");
		}
	} else {
		s=textureSwitch->getTextureWidth();
		t=textureSwitch->getTextureHeight();
	}



	float su = width * 1.0 / s;
	float sv = height * 1.0 / t;

	uvs->push_back(osg::Vec2(0,0));
	uvs->push_back(osg::Vec2(su,0));
	uvs->push_back(osg::Vec2(su,sv));
	uvs->push_back(osg::Vec2(0,sv));

	mButtonSwithTable->setVertexArray(vertexes.get());
	mButtonSwithTable->setTexCoordArray(0,uvs.get());

	mButtonSwithTable->addPrimitiveSet(new osg::DrawArrays(GL_QUADS,0,4));

	mGeode = new osg::Geode;
	mGeode->getOrCreateStateSet()->setTextureAttributeAndModes(0,textureSwitch);
	mGeode->getOrCreateStateSet()->setMode(GL_CULL_FACE, osg::StateAttribute::OFF);
	osg::Material* mat = new osg::Material;
	mat->setDiffuse(osg::Material::FRONT_AND_BACK,osg::Vec4(1,1,1,1));
	mGeode->getOrCreateStateSet()->setAttributeAndModes(mat,osg::StateAttribute::ON);
 	mGeode->getOrCreateStateSet()->setAttributeAndModes(new osg::BlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA), osg::StateAttribute::ON);

	mGeode->addDrawable(mButtonSwithTable.get());

	mGroup = new osg::Group;
	mGroup->setName("PokerMultiTable");
	mGroup->addChild(mGeode.get());
	
	GetModel()->SetArtefact(mGroup.get());
	osg::Group *HUDgroup = game->GetScene()->GetModel()->mHUDGroup.get();
	Anchor(HUDgroup);

	SetSelectable(true);
	ShowButton(false);
}

PokerMultiTable::~PokerMultiTable()
{
	Anchor(0);
  RecursiveClearUserData(GetModel()->GetNode());
	mGroup = 0;
}

void PokerMultiTable::ShowButton(bool show)
{
	if (show)
		mGroup->setNodeMask(MAF_VISIBLE_MASK | MAF_COLLISION_MASK);
	else
		mGroup->setNodeMask(0);
}

bool PokerMultiTable::Update(MAFApplication* application)
{
	SDL_Event *event = application->GetLastEventIgnoreLocking();
	if (!event)
		return true;

	switch (event->type) {

	case SDL_MOUSEBUTTONUP:
		if(application->GetFocus() == this) {
			if (mButtonClicked) {
				PokerApplication* app=(PokerApplication*)application;
				app->PythonCall("rotateTable");
				mButtonClicked = false;
			}
		} else {
			mButtonClicked = false;
		}
		break;
	
	case SDL_MOUSEBUTTONDOWN:
		if(application->GetFocus() == this) {
			mButtonClicked = true;
		} else {
			mButtonClicked = false;
		}
	
	break;
	}
	return true;
}


#if 0
int PokerMultiTable::FindTable(int table)
{
	for (int i = 0; i<mTables.size(); i++) // if found do nothing
		if (mTables[i] == table)
			return i;
	return -1;
}

void PokerMultiTable::LeaveTable(int table)
{
	int i = FindTable(table);
	g_assert(i != -1);
	mTables.erase(mTables.begin()+i);
	UpdateTableState();
	mCurrentTable = -1;
}

void PokerMultiTable::JoinTable(int table)
{
	mCurrentTable = table;
	if (FindTable(table) != -1 )
		return;
	
	mTables.push_back(table);
	mCurrentTable = table;

	UpdateTableState();
}

void PokerMultiTable::UpdateTableState()
{
	if (mTables.size()>1)
		mGroup->setNodeMask(MAF_VISIBLE_MASK | MAF_COLLISION_MASK);
	else
		mGroup->setNodeMask(0);
}
#endif
