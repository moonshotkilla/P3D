/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#ifndef _pokerbubblemanager_h
#define _pokerbubblemanager_h

#ifndef POKER_USE_VS_PCH
#include <vector>
#include <osg/Vec3>
#include <osg/Referenced>
#include <maf/controller.h>
#include "PokerBubble.h"
//#include "PokerEditor.h"
#endif

class MAFApplication;

struct PokerBubble
{
	PokerBubble();
	osg::Vec2 GetCenterPos();
	osg::Vec2 mInPos;
	osg::Vec2 mInPrevPos;
	osg::Vec2 mOutPos;
	osg::Vec2 mOutPrevPos;	
	osg::Vec2 mSize;
	bool mCollide;
        void InitInOut(const osg::Vec2& in, const osg::Vec2& out);
	void Init(const osg::Vec2& pos, const osg::Vec2& size);
	void Update(float delta);
	void Verlet(float delta);
	void SizeContraint();
	void CenterPosConstraint(const osg::Vec2& centerWantedPos);
	void ScreenConstraint();
	void CollisionConstraint(PokerBubble& left, float ratioA = 1.0f, float ratioB = 1.0f);
	bool mActive;
};

struct PokerBubbleManager : MAFController
{
  PokerBubbleManager(unsigned int controllerID) : MAFController(controllerID) {};
  void Init(PokerApplication *game);
  void Finit();// should take PokerApplication* arg
  
  const char* GetControllerName() const { return "PokerBubbleManager";}
  
  bool Update(MAFApplication *application);
  void _Update(PokerApplication* game);
  void SetVisible(bool value);
  void LoadColorSet();
  void SwitchColorSet();
  template <typename T>
    void GameAccept(const T&);
  bool mVisible;
  std::vector<osg::Vec3> mBubbleAnchorWorldPos;
  std::vector<osg::ref_ptr<PokerBubbleController> > mControllers;
  std::vector<PokerBubble> mBubbles;
  std::vector<PokerBubble> mCollisions;
  std::vector<osg::Node*> mAnchors;
  osg::ref_ptr<osg::Group> mGroup;
  PokerApplication* mGame;
  std::vector<std::vector<osg::Vec4> > mColorSet;
};

#endif
