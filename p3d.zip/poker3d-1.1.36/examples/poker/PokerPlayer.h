/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef _pokerplayer_h
#define _pokerplayer_h

#ifndef POKER_USE_VS_PCH
#include <map>
#include <vector>
#include <string>

#include <osg/Array>
#include <osg/Vec2>
#include <osg/ShapeDrawable>
#include <osgText/Text>

#include <maf/audio.h>

#include <maf/MultipleAnimationPathCallback.h>
#include <maf/scene.h>

#include <ugame/artefact.h>
#include <ugame/timeout.h>

#include <PokerCard.h>
#include <PokerInteractor.h>
#include <PokerMoveChips.h>
#include <PokerShowdown.h>
#include <pokerexport.h>

#include <ugame/Bubble>

#endif

class PokerPlayerCamera;
class PokerApplication;
class UGAMEAnimatedController;
class PlayerAnimation;
class PokerChipsStackController;
class PokerBubbleController;
class PokerBodyController;
class PokerMoveChipsController;
class PokerMoveChipsBet2PotController;
class SoundInit;
class PokerCursor;
class PokerSplashScreenModel;
class PokerShowdownController;
class PokerMoveChipsPot2PlayerController;
class PokerPlayerTimeout;

#define POKER_PLAYER_NO_SEAT 255

class PokerPlayer : public MAFController {

  void GetTypeAndNameFromOutfit(const std::string& outfit,std::string& name,std::string& type);
	void GetExcludeMesh(const std::string& skinUrl, std::vector<std::string>& mesh);

  osg::ref_ptr<PokerChipsStackController>	mMoneyStack;
  bool mHasReceivedABetStackOnTable;

  osg::ref_ptr<MAFAudioSourceController> mSoundSource;
  osg::ref_ptr<MAFAudioSourceController> mSoundSourceTest;

  bool mSyncBetStackWithPacket;

  PokerMoveChipsBase* mLastPot2Player;

	osg::ref_ptr<PokerChipsStackController> mPot2PlayerChipStack;

	osg::ref_ptr<PokerPlayerTimeout> mPPTimeout;
	osg::ref_ptr<UGAMETimeOut> mTimeout;

	float mEyeRandomMin,mEyeRandomMax;

	// reserved to be updated by python
	bool mStartLookingCards;
	bool mLookingCards;

protected:
  virtual ~PokerPlayer();

public:

  POKER_EXPORT PokerPlayer(PokerApplication *game,
														unsigned int tableId,
														bool me,
														const std::string &skinUrl,
														const std::string &skinOutfit);

  bool Update(MAFApplication* application);

  MAFAudioSourceController* GetSoundSource();

	// do not use that
	// only python should control that
	POKER_EXPORT void SetStartLookingCards();
	void SetLookingCards() { mStartLookingCards = false; mLookingCards = true;}
	void UnsetLookingCards() { mStartLookingCards = false; mLookingCards = false;}
	bool IsStartLookingCards() { return mStartLookingCards;}
	bool IsLookingCards() { return mLookingCards;}

	void SetPlayerCameraToFreeMode();
	
  UGAMEArtefactController* GetSeat(void) { return mSeat.get(); }

	const char* GetControllerName() const { return "PokerPlayer"; }

  void BodyCollideAll(void);
  void BodyCollideCards(void);
  void VisibleCards(bool visible);
  void NoCards(void);
  void FoldHoleCards(void);
  void SetHoleCards(const std::vector<int>& cards);
	bool HasEmptyHoleCards();
  PokerShowdownController* GetShowdown(void) { return mShowdown.get(); }
  void SetPocketCards(const std::vector<int>& cards);
  void FoldPocketCards(void);

	// write a text in top of the player that moves and fades
	void WriteFadeText(const std::string &);

  void DisableSound();
  void EnableSound();

  void SetMoney(const std::vector<int>& amount);
  void SetBet(const std::vector<int>& amount);  
  void DisplayShadowStacks(const std::string& style);
  void DisplayBetStack(bool state);
  void BetLimits(int min_bet, int max_bet, int step, int call, int allin, int pot);

  unsigned int GetBetValue(bool& isCall);
  void	ResetBetValue();

  const std::string& GetLastActionString() const { return m_strLastAction; }
  void SetLastActionString(const std::string &str) { m_strLastAction = str; if (lastActionRot_ > osg::PI*0.5) lastActionRot_ = 0; }
  int GetLastBet() const { return m_lastBet; }
  void SetLastBet(int bet) { m_lastBet = bet; }

  void SetInGame(bool inGame);
  bool GetInGame(void) { return mInGame; }

  void SetName(const std::string& name);
  const std::string& GetName(void) const { return mName; }

  PokerBodyController* GetBody(void) { return mBody.get(); }

  void SetSeatId(int seat);
  int GetSeatId(void) const { return mSeatId; }

  void SetSit(bool sit);
  bool GetSit(void) { return mSit; }

  void InPosition();
  void LostPosition();
  bool HasPosition() const { return mInPosition; }

  void LookAt(PokerPlayer* player);

  void DisableWarningTimer();

  double PlayStartLookCards();
  double PlayEndLookCards();

  void SetTextMessage(const std::string &message);


  const osg::Vec3& GetPositionOfPlayer() const { return mPositionOfPlayerInWorldspace;}
  const osg::Vec3& GetDirectionOfPlayer() const { return mDirectionOfPlayerInWorldspace;}

	UGAMETimeOut* GetTimeOut() { return mTimeout.get(); }

  // advise player that he has to play else he will fold
  void TimeoutAdvise(float timeToPlay);

	// contains shadowitems to clear when removing player (see seatid)
	std::vector<osg::MatrixTransform*> mShadowItems;


  // common function for bet animation and get pot
  void StartBetZoneAnimation(const std::string& animationName,const std::vector<int>& amounts);

  // setup the chips stack for animation player 2 bet
  bool IsAnimationBetFinished();

  bool HasNeverReceivedABetStackOnTable() const { return mHasReceivedABetStackOnTable;}
  void SetHasNeverReceivedABetStackOnTable(bool state) { mHasReceivedABetStackOnTable=state;}

  // get pot functions
  void StartGetPotAnimation(const std::vector<int>& chips); // tranfert bet stack to money stack

  void DisplayChipsOfBetAnimation(bool state);
  void SetValueChipsOfBetAnimation(const std::vector<int>& chips);
  void SyncBetStackWithPacket(bool state);

	PokerChipsStackController* GetPot2PlayerChipStack() { return mPot2PlayerChipStack.get();}
	void DisplayPot2PlayerChipStack(bool state) {
		if (state)
			mPot2PlayerChipStack->GetModel()->GetNode()->setNodeMask(MAF_VISIBLE_MASK | MAF_COLLISION_MASK);
		else
			mPot2PlayerChipStack->GetModel()->GetNode()->setNodeMask(0);
	}

 public:

  void GetCount();

  PokerApplication* mGame;
  osg::ref_ptr<PokerChipsStackController>	mBetStack;
  
  PokerCardControllerVector mHole;

  bool bPlayed_;
  float lastActionRot_;
  std::string strLastAction_;
  std::string fullLastAction_;
	float mTextTime;
	bool bSentCallPacket;
	bool bSentCheckPacket;
	bool bSentRaisePacket;
	bool bSentFoldPacket;

  std::map<std::string,osg::ref_ptr<UGAMEArtefactController> > mInteractors;

  osg::Geode *mGlowLightMap;

  bool GetMe(void) { return mMe; }
  void SetMe(bool s) { mMe=s;}

  bool GetSound( SoundInit& sound,const std::string& base);

  std::vector<osg::ref_ptr<PokerMoveChipsBet2PotController> > mMoveChipsFromBetToPot;
  std::vector<osg::ref_ptr<PokerMoveChipsPot2PlayerController> > mMoveChipsFromPotToPlayer;

  PokerMoveChipsBet2PotController* GetFreeAnimationBet2Pot();
  PokerMoveChipsPot2PlayerController* GetFreeAnimationPot2Player();

  bool HasAnimationBet2PotRunning();

	bool mHasRunAnimationBet;

  void HasRunAnimationBet(bool flag);
  bool HasRunAnimationBet() const;

	PokerChipsStackController* GetAnimationBetChipStack() { return mAnimationBetChipStack.get(); }
  PokerChipsStackController* GetMoneyStack() { return mMoneyStack.get() ;}
  PokerChipsStackController* GetBetStack() { return mBetStack.get() ;}

  int GetNbCardsDisplayed();

	std::vector<std::string> mMessages;
	void PushTextMessage(const std::string &message);
	bool PopTextMessage(std::string &message);

  osg::ref_ptr<osg::MatrixTransform> mAnimationDealer;
private:

  osg::ref_ptr<UGAMEArtefactController> mSeat;
  MAFOSGData* mSeatData;

  osg::ref_ptr<PokerChipsStackController> mAnimationBetChipStack;
  osg::ref_ptr<osg::MatrixTransform> mAnimationBet;
  osg::MultipleAnimationPathCallback* mAnimationBetCallback;
  std::map<std::string,std::string> mMapAnimationBet;
  std::map<std::string,float> mMapAnimationBetTimeScale;
  std::vector<int> mBetChipStackDelayed;

  bool mAnimationPlayerBet,mAnimationPlayerGetPot;

  void MarkLastAction();

  std::string mName;
  int mSeatId;
  bool mInPosition;
  bool mInGame;
  bool mSit;

  float mPositionGlowCounter;
  osg::Material *mGlowMaterial;

  bool mDisplayBubble;
  osg::ref_ptr<PokerBubbleController> mBubble;
  PokerPlayerCamera* mCamera;
 public:
  PokerPlayerCamera* GetCamera() { return mCamera; }
 private:
  osg::ref_ptr<PokerShowdownController> mShowdown;

  double mTimePlaying;
  double mTimeWaiting;
  double mTimeNoise;
  double mInternalTime; // time since the player is here

  osg::Vec3 mPositionOfPlayerInWorldspace; 
  osg::Vec3 mDirectionOfPlayerInWorldspace;

  bool mMe; // true if it's me
  struct MouseState
  {
    MouseState() :  mRightButtonClicked(false), mLeftButtonClicked(false), mStateChanged(false), mWarp(false), mX(0), mY(0), mRX(0), mRY(0) {}
    void LeftClick(bool state) {mLeftButtonClicked = state; mStateChanged = true;}
    void Update(SDL_Event *event);
    void WarpMouse(bool state);
    void Init(PokerCursor* cursor) { mCursor=cursor;}

    PokerCursor* mCursor;
    bool mRightButtonClicked;
    bool mLeftButtonClicked;
    bool mStateChanged;
    bool mWarp;
    int  mX;
    int  mY;
    int  mRX;
    int  mRY;
  };
  MouseState mMouseState;
  int mStandUpAnimationId;
  double mMoveTimeout;
  double mSitInTimeout;
  bool mClickOnChair;
  void UpdateSitIn();
  void UpdateSittingOut();
  void UpdateSitOut();

  void SendPacketSitOut();
  void SendPacketSit();

  osg::ref_ptr<PokerBodyController> mBody;

	bool mTimerInFirstPerson;
  
  osg::Vec3 mBeginPos;
  osg::Vec3 mCurrentPos;
  osg::Vec3 mDeltaPos;
  bool mDeltaSet;
  float mDiffPosLengthLimit;
  float mDeltaIncrement;

  bool mShadowFlag;

 public:
  osg::ref_ptr<PokerInteractorFold> mFoldInteractor;
  osg::ref_ptr<PokerInteractorCheck> mCheckInteractor;
  osg::ref_ptr<PokerInteractorCall> mCallInteractor;
  osg::ref_ptr<PokerInteractorRaise> mRaiseInteractor;

  std::string m_strLastAction;
  int m_lastBet;

  osg::ref_ptr<osg::Group> mAnimate1CardAnchor;
  std::vector<osg::ref_ptr<osg::MatrixTransform> > mAnimate1Card;
  int mCurrent1Card;

  void ShowCard(int i);
  void HideCard(int i);

  int GetMaxCardsAnimation();
  void AnimateCard(int i);
  osg::MatrixTransform* GetAnimationCard(int i);
  void HideAnimateCard(int i);

	MAFController* mLastFocusedController;
	MAFController* mLastClickedController;

	int mAllInLimit;

	osg::ref_ptr<osg::Transform> mTextAutoTransform;
	osg::ref_ptr<osg::MatrixTransform> mTextMatrixOffset;
	osg::ref_ptr<UGAMEShadowedText> mText; // text display value of bet

	osg::ref_ptr<UGAMEShadowedText> mTooltipPlayerName;
	osg::ref_ptr<osg::MatrixTransform> mTooltipPlayerNameMatrix;
	osg::Vec3f mToolTipPlayerNameSitOutPos;
	osg::Vec3f mToolTipPlayerNameSitInPos;
	float mTooltipAlpha;
	float mTooltipFadeOutDelay;
	bool mTooltipFadeIn;

	MAFLinearInterpolator<osg::Vec3> mSlidingInteractorInterpolator;	
	MAFInterpolatorTimer<> mSlidingInteractorTimer;
	osg::Vec3 mSlidingInteractorPos[2];
	float mSlidingInteractorDelay;
};

#endif // _pokerplayer_h
