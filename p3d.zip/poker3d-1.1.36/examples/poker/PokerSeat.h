/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#ifndef __pokerseat_h__
#define __pokerseat_h__

#ifndef POKER_USE_VS_PCH
#include <osg/Vec3>

#include <maf/controller.h>
#include <maf/interpolator.h>
#include <ugame/artefact.h>

#include "PokerApplication.h"
#include "PokerSelectable.h"
#endif

namespace osg { class PositionAttitudeTransform; }

class PokerApplication;
class PokerPlayer;

class PokerSeatModel : public UGAMEArtefactModel
{
 public:
  PokerSeatModel();
  ~PokerSeatModel();
  void Init();
  int mId;
  bool mFree;

  osg::ref_ptr<osg::PositionAttitudeTransform> mArrowPAT;

  MAFLinearInterpolator<osg::Vec3> mScaleInterpolator;
  MAFInterpolatorTimer<> mTimer;
  osg::ref_ptr<osg::Geode> mSeatGeode;
  float mMinAlpha;
  float mAngleAlpha;
};

class PokerSeatController : public PokerSelectableController
{
 public:
  PokerSeatController(unsigned int tableId);
  ~PokerSeatController();
  void Init(int id, PokerApplication *game);
  void Enable();
  void Disable();
	void EnableArrow();
	void DisableArrow();
  bool Update(MAFApplication *game);
  PokerSeatModel *GetModel() { return static_cast<PokerSeatModel *>(UGAMEArtefactController::GetModel()); }

	virtual const char* GetControllerName() const { return "PokerSeatController"; }

	osg::ref_ptr<osg::Group> m_chairGroup;
	osg::ref_ptr<osg::MatrixTransform> m_chairShadowMatrix;
};

class PokerSeatManager  : public MAFController
{
public:

	 enum MAINPLAYERSTATUS {
		 MAINPLAYER_OUT,
		 MAINPLAYER_SEAT_IN,
		 MAINPLAYER_SEAT_OUT
	 };

  PokerSeatManager(unsigned int tableId);
  ~PokerSeatManager();

	virtual const char* GetControllerName() const { return "PokerSeatManager"; }

  void Init(PokerApplication *game);
  void SetSeats(const std::vector<int> &currentTableSeats);
  void DisableAllSeats();
  bool Update(MAFApplication *game);
  unsigned int GetSeatsCount() { return mSeats.size(); }
  void MainPlayerArrive(const std::vector<guint> &seats);
  void MainPlayerLeave(const std::vector<guint> &seats);
  void PlayerSeated(unsigned int seat);
  void PlayerLeave(unsigned int seat);
	MAINPLAYERSTATUS GetMainPlayerStatus() const { return mMainPlayerStatus; }

	void MainPlayerSitOut();
	void MainPlayerSit();

	int GetMainPlayerSeat() const { return mMainPlayerSeat; }
	void SetMainPlayerSeat(int seat) { mMainPlayerSeat = seat; }

private:

  MAINPLAYERSTATUS mMainPlayerStatus;
  unsigned int  mSeatsCount;
  std::vector<int> mCurrentTableSeats;
  std::vector< osg::ref_ptr<PokerSeatController> > mSeats;
  PokerApplication* mGame;
	int mMainPlayerSeat;
};

#endif // __pokerseat_h__
