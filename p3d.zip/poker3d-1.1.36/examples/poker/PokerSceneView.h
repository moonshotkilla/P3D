/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#ifndef _pokersceneview_h_
#define _pokersceneview_h_

#ifndef POKER_USE_VS_PCH
#include "maf/scene.h"
#include "ugame/artefact.h"
#endif

#include "pokerexport.h"

namespace osgText { class Font; }
namespace osg { class ColorMask; class DrawCallback; }
namespace osgUtil { class SceneView; }

class MAFWindow;
class MAFPBuffer;
class MAF_OSGQuad;
class PokerApplication;
class PokerUIMouseController;
class PokerUIDummyDrawCallback;

struct UGAMEBasicText;

class POKER_EXPORT PokerSceneView : public MAFSceneView {
public:

	typedef MAFSceneView Parent;
	typedef std::map<std::string, std::vector<std::string > > Description;

	class DrawableThatStayInColor {
	public:

		DrawableThatStayInColor() {
			for (int i = 0; i < 4; i++)
				orgTexture[i] = NULL;
		};
		~DrawableThatStayInColor() { };

		osg::Drawable *drawable;
		int flags;

	protected:

		std::string orgTextureName[4];
		osg::Texture2D *orgTexture[4];
		osg::Vec4f orgColor;

		osg::ref_ptr<osg::ColorMask> colorMask;
		std::string orgRenderBinName;
		int orgRenderBinNum;
		int renderBinToUse;
		osg::Drawable::DrawCallback *oldDrawCallback;

		friend class PokerSceneView;
	};

	// this is a simple helper (considering we can have only one instance of PokerSceneView)
	static PokerSceneView *getInstance();

	PokerSceneView(PokerApplication *, int grayTextureSize);
	virtual ~PokerSceneView();

	// overloaded from MAFSceneView
	virtual void Init();
	virtual void Update(MAFWindow*);

	// setup the instance to be used, this has to be called once the level has been loaded
	virtual void setup();
	virtual void uninit();

	// add a Drawable that stays in color
	void addDrawableThatStayInColor(osg::Drawable *, int orgRenderBin, int renderBinToUse, const std::string &renderName, int flags);
	void removeDrawableThatStayInColor(osg::Drawable *);
	void removeAllDrawablesThatStayInColor() { m_stayInColor.clear(); }

	//
	void setCurrentSelectionedItem(const std::string &selected, bool bLock, void* itemID);

	// the texture used for the B&W effect
	osg::Texture2D *getGrayTexture() { return m_grayTexture.get(); }

	inline bool isActivated() const { return m_bActivated; }
	void setActivated(bool b) { m_bActivated = b; if (!b) changeDrawableRender(true); }

	inline bool isActivateButtonShown() const { return m_bButtonAvailable; }
	void showActivateButton(bool bShow);

	PokerUIMouseController* getMouseController() { return m_mouseController.get(); }	

	void resetGlowCounter() { m_glowCounter = 0; }

//protected:

	void changeDrawableRender(bool bOrgRender);
	void renameTextureName(std::string &name);

	osg::ref_ptr<osg::ColorMask> m_colorMask;
	bool											m_bActivated;
	osg::ref_ptr<osg::Texture2D> m_grayTexture;
	osg::ref_ptr<osg::Texture2D> m_gtex;
	std::vector<DrawableThatStayInColor>	m_stayInColor;
	int												m_grayTextureWidth;
	int												m_grayTextureHeight;
	osg::ref_ptr<MAFPBuffer> m_pbuffer;

	osg::ref_ptr<osg::Group>	m_TLFGroup;
	osg::ref_ptr<osg::State>	m_TLFState;
	
	osg::ref_ptr<osg::Projection> m_panelProjo;

	osg::ref_ptr<osg::MatrixTransform> m_panelMatrix;

	osg::ref_ptr<MAF_OSGQuad> m_topQuad;
	osg::ref_ptr<MAF_OSGQuad> m_middleQuad;
	osg::ref_ptr<MAF_OSGQuad> m_lowQuad;

	osg::ref_ptr<osg::MatrixTransform> m_fontMatrix;
	osg::ref_ptr<osgText::Font> m_font;
	osg::ref_ptr<UGAMEBasicText> m_text;

	osg::ref_ptr<MAF_OSGQuad> m_button;
	bool											m_bButtonAvailable;

	osg::ref_ptr<osg::MatrixTransform> m_grayQuad;

	PokerApplication					*m_game;
	Description								m_desc;
	bool											m_bSetuped;

	bool											m_bDescriptionLocked;
	//std::string								m_prevStrDesc;
	void*												m_currentDescID;
	float											m_alphaPanel;

	int												m_currentFocus;

	float											m_glowCounter;

	std::string								m_dataPath;

	osg::ref_ptr<PokerUIMouseController> m_mouseController;

	osg::ref_ptr<PokerUIDummyDrawCallback> m_dummyDrawCallback;

	friend class PokerUIMouseController;

	int mDelta_x;
	int mDelta_y;
	int mWidth;
	int mHeight;

};

class PokerUIMouseController : public UGAMEArtefactController {
public:

	PokerUIMouseController(PokerSceneView *parent);
	virtual ~PokerUIMouseController();

	bool Update(MAFApplication *);

protected:
	PokerSceneView *parent_;
	bool bLMB_;

	osg::ref_ptr<osg::Group> group_;

	friend class PokerSceneView;
};

class PokerUIDummyDrawCallback : public osg::Drawable::DrawCallback {
public:

	PokerUIDummyDrawCallback() { };
	virtual ~PokerUIDummyDrawCallback() { };

	void drawImplementation(osg::State &_state, const osg::Drawable *_drawable)
	{
		return; // just draw nothing!
	}
};

#endif
