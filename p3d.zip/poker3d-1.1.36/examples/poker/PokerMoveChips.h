/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#ifndef _poker_move_chips_h
#define _poker_move_chips_h

#ifndef POKER_USE_VS_PCH
#include <maf/controller.h>
#include <osg/Vec3>
#include <osg/ref_ptr>
#include <osg/MatrixTransform>
#include <maf/interpolator.h>
#include <maf/data.h>
#include <PokerChipsStack.h>
#include <osg/Vec3>
#endif

class PokerApplication;
class PokerPlayer;
class PokerPotController;



class PokerMoveChipsBase : public MAFController
{
  osg::ref_ptr<PokerChipsStackController> mTargetChips;

protected:

  std::vector<int> mAmount;
  osg::Vec3 mDestination;


public:  
  PokerMoveChipsBase(PokerApplication* game,unsigned int controllerID);
  virtual ~PokerMoveChipsBase();

	const char* GetControllerName() const { return "PokerMoveChipsBase";}

  osg::ref_ptr<PokerChipsStackController> mChips;
  osg::ref_ptr<osg::MatrixTransform> mTransform;
  float mTimeDuration;

  void SetTargetChipsStack(PokerChipsStackController* chipstack) { mTargetChips=chipstack;}
  void SetAmount(const std::vector<int>& amount) { mAmount=amount;}
  void UpdateTarget();
  void Display(bool state);
  bool IsFinished();
  bool mFinished;
  void SetDestination(const osg::Vec3& dest) { mDestination=dest;}
  float GetDuration() { return mTimeDuration;}
  virtual void ExecuteAtEnd(PokerPlayer* player) {}
};




class PokerMoveChipsBet2PotController : public PokerMoveChipsBase
{
 public:
  PokerMoveChipsBet2PotController(PokerApplication* game,osg::Node* source,unsigned int controllerID);
  ~PokerMoveChipsBet2PotController();

	const char* GetControllerName() const { return "PokerMoveChipsBet2PotController";}

  float mAngleToInterpolate;
  osg::Matrix mBaseMatrix;
  float mDistanceFromCenter;
  float mDistanceToInterpolate;
  float mTimeToOffset;

  void StartAnimation();
  void InitAnimation();

  void ExecuteAtEnd(PokerPlayer* player);

  /// general data
  bool Update(MAFApplication* application);

  float mInternalTimer;
  osg::ref_ptr<osg::Node> mNode;
  /// end general

};

class PokerMoveChipsPot2PlayerController : public PokerMoveChipsBet2PotController
{
 public:
  PokerMoveChipsPot2PlayerController(PokerApplication* game,osg::Node* source,unsigned int controllerID):PokerMoveChipsBet2PotController(game,source,controllerID){}
  ~PokerMoveChipsPot2PlayerController();

	const char* GetControllerName() const { return "PokerMoveChipsPot2PlayerController";}

  bool Update(MAFApplication* application);
  void InitAnimation();
  void ExecuteAtEnd(PokerPlayer* player);
};


class PokerMoveChips : public osg::Referenced
{
public:
  
  virtual ~PokerMoveChips() {}
  
  struct PokerMoveChipsCommand
  {
    int mSerial;
    std::vector<int> mChips;
    int mIndex;
    PokerMoveChipsCommand(int serial,const std::vector<int>& chips,int index):mSerial(serial),mChips(chips),mIndex(index){}
    int IsEmpty() {
      int res=0;
      for (std::vector<int>::iterator i=mChips.begin();i!=mChips.end();i++)
        res+=(*i);
      return res == 0;
    }
  };


  class PokerTrackActiveMoveChips : public osg::Referenced
  {
  protected:
    ~PokerTrackActiveMoveChips()
		{
		}
  public:
    
    struct EntryElement
    {
      guint mSerial;
      osg::ref_ptr<PokerMoveChipsBase> mAnimation;
      EntryElement(guint serial,PokerMoveChipsBase* animation):mSerial(serial),mAnimation(animation){}
    };

    PokerTrackActiveMoveChips(std::map<guint,osg::ref_ptr<PokerPlayer> >& serial):mSerial2Player(serial){}
    
    bool HasAnimation();
    void RemoveFinishedEntry();
    void AddEntry(const EntryElement& entry) {
      mActives.push_back(entry);
    }

		void ClearEntries(guint serial);
		void ClearAllEntries();

    std::vector<EntryElement> mActives;
    std::map<guint,osg::ref_ptr<PokerPlayer> >& mSerial2Player;    
  };

  PokerMoveChips(std::map<guint,osg::ref_ptr<PokerPlayer> >& serial);

  void SwitchToExistingLevel();
  void PlayerFold(int serial);
  void GameStart();
  void EndRound();
  void PlayerLeave(int serial);
  void PokerPotChips(int index, const std::vector<int>& amounts);
  void PokerChipsBet2Pot(int index, int pos, const std::vector<int>& amounts);

  void Update(PokerApplication* game, PokerPotController* potcenter);
  template<typename T>
  void GameAccept(const T& event);
  //  void GameAccept(const std::string& message);

  std::map<guint,osg::ref_ptr<PokerPlayer> >& mSerial2Player;
  bool mEventRunAnimationProcess;
  std::vector<PokerMoveChipsCommand> mBet2PotCommand;
  std::vector<PokerMoveChipsCommand> mPot2PlayerCommand;
  void SortStack(std::vector<PokerMoveChipsCommand>& stackToSort,bool toPlayer);
  bool mBatchMode;
	std::map<int,std::vector<int> > mLastPacketPotChip;
  bool mPacketPot2PlayerReceived;

  osg::ref_ptr<PokerTrackActiveMoveChips> mActiveBet2Pot;
  osg::ref_ptr<PokerTrackActiveMoveChips> mActivePot2Player;

  bool IsAnyChipsToMoveToPot();
  bool IsAnyChipsToMoveToPlayer();
  bool IsAnyChipsToMoveToPotFromPlayer(int serial);

  float RunChipsAnimationBet2Pot(PokerPotController* potcenter);
  float RunChipsAnimationPot2Player(PokerPotController* potcenter);

  bool IsValidToRunAnimationBet2Pot();
  bool IsAnimationsBet2PotFinished(bool potCenterIsFrozen, bool potCenterIsStoped);
  void RunAnimationsBet2PotForPlayerFinishToBet(PokerPotController* potcenter);
  void ReportPlayersHaveBet2PotAndHaveNotFinishToBet();
  void RunAnimationsPot2Players(PokerPotController* potcenter);
};


#endif

