/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Igor Kravtchenko <igor@tarevitch.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 */

#include "pokerStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */

#ifdef WIN32
# define snprintf _snprintf
#endif

#ifndef POKER_USE_VS_PCH

#include <cstdio>
#include <osgDB/ReadFile>

#include <osg/BlendFunc>
#include <osg/GLExtensions>
#include <osg/Geometry>
#include <osg/MatrixTransform>
#include <osg/PositionAttitudeTransform>

#include <osgText/Text>

#include <maf/application.h>
#include <maf/split.h>
#include <maf/window.h>
#include <maf/assert.h>
#include <maf/renderbin.h>
#include <maf/timer.h>

#include <varseditor/varseditor.h>
#include <PokerApplication.h>
#include <PokerSplashScreen.h>
#include <PokerError.h>
#endif

PokerSplashScreenModel::PokerSplashScreenModel(PokerApplication *_application)
{
	application_ = _application;

  float width = _application->GetWindow(true)->GetWidth();
  float height = _application->GetWindow(true)->GetHeight();

	MAF_OSGQuad::setScreenResolution((int)width, (int)height);

	const std::string &datadir = _application->HeaderGet("settings", "/settings/data/@path"); 
//	Sleep(8000);

	screenGroup_ = new osg::Group();
	SetNode(screenGroup_.get());

	MAF_OSGQuadParams params;
	params.minPt = osg::Vec2f(0, 0);
	params.maxPt = osg::Vec2f(width, height);
	params.minUV = osg::Vec2f(0, 256/1024.0f);
	params.maxUV = osg::Vec2f(1, 1024/1024.0f);
	params.bInvertUV = false;

	params.textureName = datadir + "/splash_fond.tga";
	backGround_ = new MAF_OSGQuad(params);

//	params.textureName = datadir + "/splash_cards.tga";
	//progressBar_ = new MAF_OSGQuad(params);

//	{
	//	int rbvalue;
		//if (!VarsEditor::Instance().Get("RB_SplashScreen",rbvalue))
			//MAF_ASSERT(0 && "RB_SplashScreen not found in client.xml");
		//screenGroup_->getOrCreateStateSet()->setRenderBinDetails(rbvalue, "RenderBin");
	//}
	if (!MAFRenderBin::Instance().SetupRenderBin("SplashScreen", screenGroup_->getOrCreateStateSet()))
		MAF_ASSERT(0 && "SplashScreen not found in client.xml");

	screenGroup_->addChild(backGround_->getGeode());
	//screenGroup_->addChild(progressBar_->getGeode());

	fontMatrix_ = new osg::MatrixTransform;
	osg::Matrix mat = osg::Matrix::scale( width * 0.0005f, height * 0.0005f , 1.0f) * osg::Matrix::translate((65/1024.0f)*width, (285/768.0f)*height, 0);
	fontMatrix_->setMatrix(mat);

	font_ = MAFLoadFont(datadir + "/FreeSans.ttf");
	text_ = new UGAMEBasicText("", font_.get());
	text_->getText()->setFontResolution(36, 36);
	text_->getText()->setCharacterSize(36);
	text_->getText()->setAlignment( osgText::Text::LEFT_BOTTOM );
	text_->getOrCreateStateSet()->setAttributeAndModes(new osg::BlendFunc(osg::BlendFunc::SRC_ALPHA, osg::BlendFunc::ONE_MINUS_SRC_ALPHA), osg::StateAttribute::ON);

	fontMatrix_->addChild(text_.get());
	screenGroup_->addChild(fontMatrix_.get());

	params.textureName = datadir + "/barre_O.tga";

	int x = 65;
	int y = 768-(492+64);

	params.minUV = osg::Vec2f(0, 0);
	params.maxUV = osg::Vec2f(1, 1);

	params.minPt = osg::Vec2f( (x/1024.0f) * width, (y/768.0f) * height);
	params.maxPt = osg::Vec2f( ((x+64)/1024.0f) * width, ((y+64)/768.0f) * height);

	progressBk_ = new MAF_OSGQuad(params);
	screenGroup_->addChild( progressBk_->getGeode() );

	pos_ = 0;
	addFactor_ = 0.0f;
	mulFactor_ = 1.0f;
	len_ = 100;
}

PokerSplashScreenModel::~PokerSplashScreenModel()
{
}

void PokerSplashScreenModel::write(const char *_msg)
{
	text_->getText()->setText(_msg);
	pos_ = 0;
	updateProgressBar();
}

void PokerSplashScreenModel::setProgressLength(int _len)
{
	len_ = _len;
}

void PokerSplashScreenModel::progress()
{
	pos_ += 1.0f;
	updateProgressBar();
}

void PokerSplashScreenModel::updateProgressBar()
{
	float width = application_->GetWindow(true)->GetWidth();

	float step = ((pos_ / len_) * mulFactor_ + addFactor_) * 14;
	float x_vert = (ceil(65+64*step)/1024.0f) * width;

	osg::Vec3Array *vertices = progressBk_->getVerticesArray();
	(*vertices)[1][0] = x_vert;
	(*vertices)[2][0] = x_vert;

	double time = GetRealTime();
	if (time - lastTime_ > 0.05f || pos_ == len_) { // limit update to 20hz
		application_->GetWindow(true)->Render();
		lastTime_ = time;
	}

	// it's a good thing to treat incoming event even if we ignore them
	// that's allow to purge the messages queue
	SDL_Event event;
	while (SDL_PollEvent(&event)) {
	};
}

PokerSplashScreenController::PokerSplashScreenController(PokerApplication *application)
{
  SetModel(new PokerSplashScreenModel(application));
}

PokerSplashScreenController::~PokerSplashScreenController() {
}

bool PokerSplashScreenController::Update(PokerApplication *application)
{
  return true;
}
