/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Johan Euphrosine <johan@mekensleep.com>
 *  Igor Kravtchenko <igor@ozos.net>
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include "pokerStdAfx.h"

#include <PokerEvent.h>
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */

#ifndef POKER_USE_VS_PCH

#include "Poker.h"
#include "PokerApplication.h"
#include "PokerPlayerCamera.h"
#include "PokerPlayer.h"
#include "PokerBubbleManager.h"
#include "PokerBody.h"
//#include "PokerEditor.h"

#include <maf/assert.h>
#include <maf/window.h>
#include <maf/renderbin.h>
#include <varseditor/varseditor.h>

#include <osg/ref_ptr>
#include <osgCal/SubMeshSoftware>
#include <osgCal/SubMeshHardware>
#endif

#include <osg/Material>
#include <osg/BlendFunc>
#include <osg/PositionAttitudeTransform>

#define CONVX(a) a
#define CONVY(a) a

float g_fontSize = 1.0f;

static osg::Vec2f g_HUDPos_Dst[] = {
  osg::Vec2f( CONVX(0),		CONVY(283) ),
  osg::Vec2f( CONVX(0),		CONVY(218) ),
  osg::Vec2f( CONVX(0),		CONVY(155) ),

  osg::Vec2f( CONVX(124 + 65),		CONVY(40) ),
  osg::Vec2f( CONVX(324 + 65),		CONVY(40) ) ,
  osg::Vec2f( CONVX(524 + 65),		CONVY(40) ),

  osg::Vec2f( CONVX(800),		CONVY(155) ),
  osg::Vec2f( CONVX(800),		CONVY(218) ),
  osg::Vec2f( CONVX(800),		CONVY(283) ) };

static osg::Vec2f g_HUDPos_Src[] = {
  osg::Vec2f( CONVX(-130-20),	CONVY(283) ),
  osg::Vec2f( CONVX(-130-20),	CONVY(218) ),
  osg::Vec2f( CONVX(-130-20),	CONVY(155) ),

  osg::Vec2f( CONVX(124 + 65),		CONVY(-65) ),
  osg::Vec2f( CONVX(324 + 65),		CONVY(-65) ),
  osg::Vec2f( CONVX(524 + 65),		CONVY(-65) ),

  osg::Vec2f( CONVX(800+130 + 20),	CONVY(155) ),
  osg::Vec2f( CONVX(800+130 + 20),	CONVY(218) ),
  osg::Vec2f( CONVX(800+130 + 20),	CONVY(283) ) };


PokerPlayerCamera::~PokerPlayerCamera()
{

}

static void setupGeom(osg::Geometry *_geom,
		      const std::string &_textureName,
		      float _x, float _y,
		      float _ox, float _oy,
		      float _umin, float _umax,
		      float _vmin, float _vmax)
{
  osg::StateSet *state = _geom->getOrCreateStateSet();
  osg::ref_ptr<osg::Material> material = new osg::Material;
  state->setAttributeAndModes(material.get(), osg::StateAttribute::ON);
  state->setMode(GL_LIGHTING, osg::StateAttribute::OFF);
  state->setMode(GL_CULL_FACE, osg::StateAttribute::OFF);
  material->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(1, 1, 1, 1) );

  osg::Vec3Array *array = new osg::Vec3Array();
  array->resize(4);
  _geom->setVertexArray(array);

  array[0][0] = osg::Vec3f(_ox, _oy, 0);
  array[0][1] = osg::Vec3f(_x + _ox, _oy, 0);
  array[0][2] = osg::Vec3f(_x + _ox, _y + _oy, 0);
  array[0][3] = osg::Vec3f(_ox, _y + _oy, 0);
  float umin = _umin;
  float umax = _umax;
  float vmin = _vmin;
  float vmax = _vmax;

  osg::Vec2Array *uv = new osg::Vec2Array();
  uv->push_back( osg::Vec2f(umin, vmax) );
  uv->push_back( osg::Vec2f(umax, vmax) );
  uv->push_back( osg::Vec2f(umax, vmin) );
  uv->push_back( osg::Vec2f(umin, vmin) );
  _geom->setTexCoordArray(0, uv);

  GLushort *index = new GLushort[6];
  index[0] = 0;
  index[1] = 1;
  index[2] = 2;
  index[3] = 0;
  index[4] = 2;
  index[5] = 3;

  _geom->addPrimitiveSet(new osg::DrawElementsUShort(osg::PrimitiveSet::TRIANGLES, 6, index));
  _geom->setUseDisplayList(false);
  _geom->setUseVertexBufferObjects(false);

  if (_textureName != "") {
    osg::Texture2D *texture = MAFApplication::GetTextureManager()->GetTexture2D(_textureName);
    state->setTextureAttributeAndModes(0, texture, osg::StateAttribute::ON);
  }

  osg::BlendFunc *bf = new osg::BlendFunc;
  bf->setFunction(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  state->setAttributeAndModes(bf, osg::StateAttribute::ON);
  state->setMode(GL_ALPHA_TEST, FALSE);
}

PokerPlayerCamera::PokerPlayerCamera()
{
}

PokerPlayerCamera::PokerPlayerCamera(PokerCameraController* camera, std::map<std::string,std::string>& params)
{
  Init(camera, params);
}

void PokerPlayerCamera::Init(PokerCameraController* camera, std::map<std::string,std::string>& params)
{
  int i;

  // Camera parameters
  std::string param = params["timeToReach"];
  mCameraTimeToReach = atof(param.c_str());
  param = params["timeToRewind"];
  mCameraTimeToRewind = atof(param.c_str());
  param = params["timeToRelease"];
  mCameraTimeToRelease = atof(param.c_str());
  param = params["timeShoulder"];
  mCameraTimeShoulder = atof(param.c_str());
  param = params["factorToReach"];
  mCameraFactorToReach = atof(param.c_str());
  param = params["factorToRewind"];
  mCameraFactorToRewind = atof(param.c_str());

  param = params["minTimeToLookCards"];
  mCameraMinTimeToLookCards = atof(param.c_str()) * 1.0f;
  param = params["velocityToLookCards"];
  mCameraVelocityToLookCards = atof(param.c_str());

  mCameraButtonDelayToActivateDirectMode = atof(params["buttonDelayToActivateDirectMode"].c_str());
  mCameraGameModeDelay = atof(params["gameModeDelay"].c_str());
  mCameraGameModeMouseThreshold = atof(params["gameModeMouseThreshold"].c_str());
  mCameraGameModeDelayLookCards = atof(params["gameModeDelayLookCards"].c_str());

  mCamera = camera;
  mCamera->SetMode(PokerCameraModel::CAMERA_FREE_MODE);
  mCameraTimeout = 0;
      
  mCameraLookCardTimeout = 0;
  mCameraLookCardState = 0;
  mLookingCardAnimationTimeout = 0;
  mCameraButtonPressedDuration = 0;
  mCameraMouseMotion = false;
  mDisplayedAndFocused = false;
  mCameraButtonPressed = false;
  mCameraButtonClickUp = false;
  mCameraButtonClickDown = false;
  mCameraButtonClickFocused = false;
  mInteractorSelected = false;

  mMouseDelta[0] = 0.0f;
  mMouseDelta[1] = 0.0f;
  timeSinceFirstPersonView_ = 0;

  PokerApplication *app = camera->mGame;
  std::string	path = app->HeaderGet("settings", "/settings/data/@path");
	dataPath_ = path;

  std::string normalFont = app->HeaderGet("sequence", "/sequence/FirstPersonHUD/font/@normal");
  std::string pastFont = app->HeaderGet("sequence", "/sequence/FirstPersonHUD/font/@past");
  std::string sizeFont = app->HeaderGet("sequence", "/sequence/FirstPersonHUD/font/@size");
  osgText::Font *font = MAFLoadFont(path + "/" + normalFont);
  //osgText::Font *font = MAFLoadFont("U:/working/release/example/poker/data/FreeSans.ttf");
  osgText::Font *fontIt = MAFLoadFont(path + "/" + pastFont);
  //g_fontSize = atof(sizeFont.c_str());

  font->setMinFilterHint(osg::Texture::NEAREST);
  font->setMagFilterHint(osg::Texture::NEAREST);
  fontIt->setMinFilterHint(osg::Texture::NEAREST);
  fontIt->setMagFilterHint(osg::Texture::NEAREST);

  osg::Group *set_root = app->mSetData->GetGroup();
  (void)set_root;

  sens_ = 1;

  {
    osg::Group *root = new osg::Group();
    root->setNodeMask( MAF_VISIBLE_MASK );

    osg::StateSet *ss = root->getOrCreateStateSet();
    if (!MAFRenderBin::Instance().SetupRenderBin("InteractorInHelpMode", ss))
      MAF_ASSERT(0 && "InteractorInHelpMode not found in client.xml");

    //ss->setMode(GL_DEPTH_WRITEMASK, osg::StateAttribute::OFF);
    ss->setMode(GL_DEPTH_TEST, osg::StateAttribute::OFF);
    ss->setMode(GL_LIGHTING, osg::StateAttribute::OFF);

    osg::MatrixTransform* modelview_abs = new osg::MatrixTransform;
    modelview_abs->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
    modelview_abs->setMatrix(osg::Matrix::identity());
    //		modelview_abs->getOrCreateStateSet()->setMode(GL_DEPTH_TEST, FALSE);
    root->addChild(modelview_abs);

    osg::Projection *projection = new osg::Projection;
    osg::Matrix projMat = osg::Matrix::identity();
    projMat(2, 2) = 0.00000f; // z is always 0
    projection->setMatrix( projMat );
    modelview_abs->addChild(projection);

    osg::Geode *geode_left = new osg::Geode();
    osg::Geode *geode_right = new osg::Geode();
    osg::Geode *geode_middle = new osg::Geode();
    osg::Geode *geode_action = new osg::Geode();
    osg::Geode *geode_dealer = new osg::Geode();

    osg::Geometry *geom_left = new osg::Geometry();
    osg::Geometry *geom_right = new osg::Geometry();
    osg::Geometry *geom_middle = new osg::Geometry();
    osg::Geometry *geom_action = new osg::Geometry();
    osg::Geometry *geom_dealer = new osg::Geometry();

    geode_left->addDrawable(geom_left);
    geode_right->addDrawable(geom_right);
    geode_middle->addDrawable(geom_middle);
    geode_action->addDrawable(geom_action);
    geode_dealer->addDrawable(geom_dealer);

    geode_left->setCullingActive(false);
    geode_right->setCullingActive(false);
    geode_middle->setCullingActive(false);
    geode_action->setCullingActive(false);
    geode_dealer->setCullingActive(false);

    for (i = 0; i < 9; i++) {

      factor_[i] = 0.0f;

      osg::MatrixTransform *mt = new osg::MatrixTransform;
      mt_[i] = mt;
      mt->setNodeMask(0);
      projection->addChild(mt);

      osg::MatrixTransform *matpanel = new osg::MatrixTransform();
      mt->addChild(matpanel);

      mtpanel_[i] = matpanel;

      if (i < 3)
	matpanel->addChild(geode_left);
      else if (i < 6)
	matpanel->addChild(geode_middle);
      else
	matpanel->addChild(geode_right);

      osg::MatrixTransform *icon_matrix = new osg::MatrixTransform();
      osg::MatrixTransform *icon_rotmatrix = new osg::MatrixTransform();
      //			if (i < 3)
      //			icon_matrix->setMatrix(osg::Matrix::translate((152-14-10)/400.0f, -22/300.0f, 0) );
      //	else
      //	icon_matrix->setMatrix(osg::Matrix::translate(10/400.0f, -22/300.0f, 0) );
      if (i < 3)
	icon_matrix->setMatrix(osg::Matrix::translate(0, 21, 0) );
      else if (i < 6)
	icon_matrix->setMatrix(osg::Matrix::translate(-65, 21, 0) );
      else
	icon_matrix->setMatrix(osg::Matrix::translate(-130, 21, 0) );

      mt->addChild(icon_matrix);
      icon_matrix->addChild(icon_rotmatrix);
      mticon_[i] = icon_matrix;
      mticonrot_[i] = icon_rotmatrix;

      actionGroup_[i] = new osg::Group;
      actionGroup_[i]->addChild(geode_action);
      icon_rotmatrix->addChild( actionGroup_[i].get() );

      dealerGroup_[i] = new osg::Group;
      dealerGroup_[i]->addChild(geode_dealer);
      dealerGroup_[i]->setNodeMask(0);
      icon_matrix->addChild( dealerGroup_[i].get() );

      osg::MatrixTransform *font_matrix;
      osg::MatrixTransform *font_rotmatrix;
      UGAMEBasicText *text;

      font_matrix = new osg::MatrixTransform();
      mt->addChild(font_matrix);
      if (i < 3)
	font_matrix->setMatrix( osg::Matrix::scale(g_fontSize, -g_fontSize, g_fontSize) * osg::Matrix::translate(3, 7, 0) );
      //				font_matrix->setMatrix( osg::Matrix::scale(g_fontSize, -g_fontSize, 1) * osg::Matrix::translate(0, 0, 0) );
      //font_matrix->setMatrix( osg::Matrix::scale(2/1280.0f, 2/1024.0f, 1) * osg::Matrix::translate(3/400.0f, -7/300.0f, 0) );
      else if (i < 6)
	font_matrix->setMatrix( osg::Matrix::scale(g_fontSize, -g_fontSize, 1) * osg::Matrix::translate(0, 7, 0) );
      //font_matrix->setMatrix( osg::Matrix::scale(2/1280.0f, 2/1024.0f, 1) * osg::Matrix::translate((130/2)/400.0f, -7/300.0f, 0) );
      else
	font_matrix->setMatrix( osg::Matrix::scale(g_fontSize, -g_fontSize, 1) * osg::Matrix::translate(-3, 7, 0) );
      //font_matrix->setMatrix( osg::Matrix::scale(2/1280.0f, 2/1024.0f, 1) * osg::Matrix::translate((130-3)/400.0f, -7/300.0f, 0) );

      text = new UGAMEBasicText("", font);
      text->getText()->setFontResolution(14, 14);
      text->getText()->setCharacterSize(14);
      text->getOrCreateStateSet()->setAttributeAndModes(new osg::BlendFunc(osg::BlendFunc::SRC_ALPHA, osg::BlendFunc::ONE_MINUS_SRC_ALPHA), osg::StateAttribute::ON);

      if (i < 3)
	text->getText()->setAlignment( osgText::Text::LEFT_TOP );
      else if (i < 6)
	text->getText()->setAlignment( osgText::Text::CENTER_TOP );
      else
	text->getText()->setAlignment( osgText::Text::RIGHT_TOP );
      textName_[i] = text;
      font_matrix->addChild(text);



      font_matrix = new osg::MatrixTransform();
      font_rotmatrix = new osg::MatrixTransform();
      mt->addChild(font_matrix);
      font_matrix->addChild(font_rotmatrix);
      mtrot_[i] = font_rotmatrix;

      if (i < 3)
	font_matrix->setMatrix( osg::Matrix::scale(g_fontSize, -g_fontSize, 0) * osg::Matrix::translate(65, 25, 0) );
      else if (i < 6)
	font_matrix->setMatrix( osg::Matrix::scale(g_fontSize, -g_fontSize, 0) * osg::Matrix::translate(0, 25, 0) );
      else
	font_matrix->setMatrix( osg::Matrix::scale(g_fontSize, -g_fontSize, 0) * osg::Matrix::translate(-65, 25, 0) );

      {
	text = new UGAMEBasicText("", font);
	text->getOrCreateStateSet()->setAttributeAndModes(new osg::BlendFunc(osg::BlendFunc::SRC_ALPHA, osg::BlendFunc::ONE_MINUS_SRC_ALPHA), osg::StateAttribute::ON);
	text->getOrCreateStateSet()->setMode(GL_CULL_FACE, FALSE);
	text->getText()->setFontResolution(14, 14);
	text->getText()->setCharacterSize(14);
	text->getText()->setColor( osg::Vec4f(0, 0, 0, 1) );

	text->getText()->setAlignment( osgText::Text::CENTER_TOP );
	textLastAction_[i] = text;
	font_rotmatrix->addChild(text);
      }

      {
	text = new UGAMEBasicText("", fontIt);
	text->getOrCreateStateSet()->setAttributeAndModes(new osg::BlendFunc(osg::BlendFunc::SRC_ALPHA, osg::BlendFunc::ONE_MINUS_SRC_ALPHA), osg::StateAttribute::ON);
	text->getOrCreateStateSet()->setMode(GL_CULL_FACE, FALSE);
	text->getText()->setFontResolution(14, 14);
	text->getText()->setCharacterSize(14);
	text->getText()->setColor( osg::Vec4f(0, 0, 0, 1) );

	text->getText()->setAlignment( osgText::Text::CENTER_TOP );
	textLastActionIt_[i] = text;
	font_rotmatrix->addChild(text);
      }

      if (1)
	{
	  osg::MatrixTransform* chat_matrix = new osg::MatrixTransform();
	  chat_matrix->setMatrix(osg::Matrix::scale(g_fontSize, g_fontSize, 0) * osg::Matrix::translate(0, 48, 0));
	  UGAMEBasicText* text = new UGAMEBasicText("", font);
	  text->getOrCreateStateSet()->setMode(GL_CULL_FACE, FALSE);
	  text->getText()->setFontResolution(11, 11);
	  text->getText()->setCharacterSize(11);
	  text->getText()->setColor( osg::Vec4f(1, 1, 1, 1) );
	  //text->getText()->setAlignment( osgText::Text::CENTER_TOP );
	  text->getText()->setText(osgText::String("", osgText::String::ENCODING_UTF8));
	  chat_matrix->addChild(text);
	  mt->addChild(chat_matrix);
	  mtchat_[i] = chat_matrix;
	  textChat_[i]  = text;
	}
			
    }

    {
      std::list<std::string> urls = app->HeaderGetList("sequence", "/sequence/FPCal3DMeshes//mesh/@name");

      for (std::list<std::string>::iterator it = urls.begin(); it != urls.end(); ++it) {
	std::string &mesh = *it;
	cal3dMeshesToKeepInFPV_.push_back(mesh);
      }

    }

    float fw = 1; //1 / 400.0f; //app->GetWindow(true)->GetWidth() / 800.0f;
    float fh = 1; //1 / 300.0f; //app->GetWindow(true)->GetHeight() / 600.0f;

    float su, sv;

    su = 0.5f / 256;
    sv = 0.5f / 32;

    setupGeom(geom_left, "", 256, 32, 0, 0, su, 1-su, sv, 1-sv);
    setupGeom(geom_right, "", 256, 32, -130, 0, 130/256.0f-su, -126/256.0f+su, sv, 1-sv);
    setupGeom(geom_middle, "", 256, 32, -65, 0, su, 1-su, sv, 1-sv);

    setupGeom(geom_action, "", 130*fw, 16*fh, 0, 0, su, 1-su, sv, 1-sv);
    setupGeom(geom_dealer, "", 15*fw, 16*fh, 0, 0, su, 1-su, sv, 1-sv);
  }
}

PokerPlayerCamera::UpdateResult PokerPlayerCamera::Update(SDL_Event* event, float delta, bool focused,bool ignoreEvent,bool wantToForceFreeMode)
{
  int i;
  mCameraLeaveViewFirstPerson = false;
  mCameraGoViewFirstPerson = false;

  mDeltaS = delta/1000.0;

  {
    PokerApplication *app = GetCameraController()->mGame;
    PokerModel *pokerModel = app->GetPoker()->GetModel();

    guint me_id = pokerModel->mMe;
    PokerPlayer *me = pokerModel->mSerial2Player[me_id].get();
    int me_index = me->GetSeatId();

    int nb = pokerModel->mSeat2Serial.size();

    for (i = 0; i < 9; i++) {
      mt_[i]->setNodeMask(0);
      players_[i] = NULL;
    }

    for (i = 0; i < nb; i++) {
      unsigned int serial = pokerModel->mSeat2Serial[i];
      if (serial && serial != me_id) {
				PokerPlayer *player = pokerModel->mSerial2Player[serial].get();
				int index = player->GetSeatId();
				int r_index;
				if (index > me_index)
					r_index = index - me_index;
				else
					r_index = 10 + index - me_index;
				r_index--;

				mt_[r_index]->setNodeMask(MAF_VISIBLE_MASK);
				textName_[r_index]->getText()->setText(osgText::String(player->GetName(), osgText::String::ENCODING_UTF8));
				players_[r_index] = player;

				const std::string &lastAction = player->GetLastActionString();
				int lastBet = player->GetLastBet();

				std::string str;

				if ((lastAction == "Blind" || lastAction == "Raise" || lastAction == "Bet" || lastAction == "Call") && lastBet != 0)
					str = lastAction + " " + MAFformat_amount(lastBet);
				else
					str = lastAction;

				std::string textureName;

				if (r_index < 3)
					textureName = dataPath_ + "/hudcards_leftright";
				else if (r_index < 6)
					textureName = dataPath_ + "/hudcards_middle";
				else
					textureName = dataPath_ + "/hudcards_leftright";

				if (player->HasPosition())
					textureName += "_highlight";
				else if (!player->bPlayed_)
					textureName += "_lowlight";

				textureName += ".tga";

				osg::Texture2D *texpanel = MAFApplication::GetTextureManager()->GetTexture2D(textureName);
				mtpanel_[r_index]->getOrCreateStateSet()->setTextureAttributeAndModes(0, texpanel, osg::StateAttribute::ON);

				player->fullLastAction_ = str;

				{
					const std::string& msg = app->GetPoker()->GetModel()->mBubbleManager->mControllers[i]->mDisplayedText;
					{
						textChat_[r_index]->getText()->setText(osgText::String(msg, osgText::String::ENCODING_UTF8));
						const osg::BoundingBox& bbox = textChat_[r_index]->getText()->getBound();
						float	x_len = (bbox.xMax() - bbox.xMin()) * 800.0f;
						//float	y_len = (bbox.yMax() - bbox.yMin()) * 600.0f;
						float x_scale = std::min(256.0f/x_len, g_fontSize);
						float y_scale = x_scale;
						mtchat_[r_index]->setMatrix(osg::Matrix::scale(x_scale, y_scale, 0) * osg::Matrix::translate(0/400.0f, -48/300.0f, 0));
						//						std::cout << x_len << ":" << y_len << std::endl;
					}
				}
      }
    }
  }

  updatePos(mDeltaS * 5);

  int lookCardState = mCameraLookCardState;

  mCameraButtonClickUp = false;
  mCameraButtonClickDown = false;
  mCameraMouseMotion = false;

  mDisplayedAndFocused = focused;

  if (mCameraButtonPressed)
    mCameraButtonPressedDuration+=mDeltaS;

  if (event && !ignoreEvent)
    {
      if (mCamera->GetRespondToEvents())
				switch(event->type)
					{
					case SDL_MOUSEBUTTONDOWN:
						{
							if  (event->button.button != SDL_BUTTON_LEFT)
								break;
							mMouseDelta[0] = 0;
							mMouseDelta[1] = 0;
							mMouseDeltaOverall[0] = 0;
							mMouseDeltaOverall[1] = 0;
	      
							mCameraButtonPressed = true;
							mCameraButtonPressedDuration = 0;
							mCameraButtonClickDown = true;
							mCameraButtonClickFocused = mDisplayedAndFocused;
						}
						break;
					case SDL_MOUSEBUTTONUP:
						{
							if  (event->button.button != SDL_BUTTON_LEFT)
								break;
							mMouseDeltaRel[0] = 0;
							mMouseDeltaRel[1] = 0;
							mCameraButtonPressed = false;
							mCameraButtonClickUp = true;
						}
						break;
					case SDL_MOUSEMOTION:
						{
							mCameraMouseMotion = true;
							mMouseDelta[0] += event->motion.xrel;
							mMouseDelta[1] += event->motion.yrel;
							mMouseDeltaOverall[0] += std::abs(event->motion.xrel);
							mMouseDeltaOverall[1] += std::abs(event->motion.yrel);
							mMouseDeltaRel[0] = event->motion.xrel;	      
							mMouseDeltaRel[1] = event->motion.yrel;
						}
						break;
					default:
						break;
					}
    }

  if (wantToForceFreeMode) {
    // simulate a pressed and release button to go to leave mode
    mMouseDelta[0] = 0;
    mMouseDelta[1] = 0;
    mMouseDeltaOverall[0] = 0;
    mMouseDeltaOverall[1] = 0;

    mCameraButtonPressed = true;
    mCameraButtonPressedDuration = 0;
    mCameraButtonClickDown = true;
    mCameraButtonClickFocused = false;
    mDisplayedAndFocused = false;
    mInteractorSelected = false;

    mMouseDeltaRel[0] = 0;
    mMouseDeltaRel[1] = 0;
    mCameraButtonPressed = false;
    mCameraButtonClickUp = true;
    //		mCamera->SetMode(PokerCameraModel::CAMERA_LEAVE_MODE);
  }

  switch(mCamera->GetMode())
    {
    case PokerCameraModel::CAMERA_FREE_MODE:
      timeSinceFirstPersonView_ = 0;
      ExecuteFreeMode();
      break;
    case PokerCameraModel::CAMERA_ENTER_MODE:
      timeSinceFirstPersonView_ = 0;
      ExecuteEnterMode();
      break;
    case PokerCameraModel::CAMERA_GAME_MODE: // player has clicked once
      timeSinceFirstPersonView_ += mDeltaS;
      if ( timeSinceFirstPersonView_ > 2)
	sens_ = 0;
      ExecuteGameMode();
      break;
    case PokerCameraModel::CAMERA_DIRECT_MODE: // player has clicked and stay clicked
      timeSinceFirstPersonView_ += mDeltaS;
      if ( timeSinceFirstPersonView_ > 2)
	sens_ = 0;
      ExecuteDirectMode();
      break;
    case PokerCameraModel::CAMERA_LEAVE_MODE:
      timeSinceFirstPersonView_ = 0;
      sens_ = 1;
      ExecuteLeaveMode();
      break;
    case PokerCameraModel::CAMERA_FIX_MODE:
      ExecuteFixMode();
      break;
    }

  if(mCameraLookCardState != lookCardState) {
    if(lookCardState == 0) {
      return START_LOOK_CARDS;    
    } else {
      return END_LOOK_CARDS;
    }
  } else {
    return NONE;
  }
}


void PokerPlayerCamera::MoveCameraToModel(const std::string& model)
{
  std::map<std::string,MAFCameraModel>::iterator it=mCameras.find(model);
  MAF_ASSERT(it!=mCameras.end());
  MAFCameraModel& camera=(*it).second;
  const osg::Vec3 &position = camera.GetPosition();
  const osg::Vec3 &target = camera.GetTarget();
  float fov = camera.GetFov();
  MoveCamera(position, target, fov);
}

void PokerPlayerCamera::MoveCameraToCamLookModel()
{  
  std::map<std::string,MAFCameraModel>::iterator it=mCameras.find("CamLook");
  g_assert(it!=mCameras.end());

  MAFCameraModel& camera=(*it).second;
  const osg::Vec3 &position = camera.GetPosition();
  const osg::Vec3 &target = camera.GetTarget();
  float fov = camera.GetFov();

  MoveCamera(position, target, fov);

  if (!mCameraLookCardState)
    {
      mCameraLookCardState=1;
    }
  else
    {
      g_error("PokerPlayerCamera::MoveCameraToCamLookModel: unexpected mCameraLookCardState == 1");
    }
}

void PokerPlayerCamera::MoveCamera(const osg::Vec3 &position, const osg::Vec3 &target, float fov)
{
  float timeout;
  float length = (position - mCamera->GetModel()->GetPosition()).length();
  
  if (mCameraTimeout > 0)
    {
      timeout = mCameraTotalTimeout*1000.f - mCameraTimeout*1000.f;
    }
  else
    {
      timeout = (length) / mCameraVelocityToLookCards;
    }
  
  if (timeout < mCameraMinTimeToLookCards)
    {
      timeout = mCameraMinTimeToLookCards;
    }
  
  g_assert(timeout >= 0);

  mCameraTotalTimeout = mCameraTimeout = timeout/1000.f;
  //  const float fovTo = 84.5f;
  mCamera->MoveTo(position, target, fov, timeout);
}


void PokerPlayerCamera::MoveCameraToPreviousModel()
{
  float timeout;
  float length = (mCamera->GetModel()->GetPosition() - mCamera->GetModel()->mCamPrevPosition).length();
  
  if (mCameraTimeout > 0)
    timeout = mCameraTotalTimeout*1000.f - mCameraTimeout*1000.f;
  else
    timeout = (length) / mCameraVelocityToLookCards;
  
  if (timeout < mCameraMinTimeToLookCards)
    timeout = mCameraMinTimeToLookCards;
  
  g_assert(timeout >= 0);
   
  mCameraTotalTimeout = mCameraTimeout = timeout/1000.f;
  
  mCamera->MoveToPrevious(timeout);
  
  mCameraLookCardState = 0;
}

bool PokerPlayerCamera::CameraEvaluateModeTransition()
{
  const float mCameraButtonDelayToActivateDirectMode=0.2;

  bool canActivateDirectMode = (mCameraButtonPressedDuration>mCameraButtonDelayToActivateDirectMode) && mCameraButtonPressed && mCameraButtonClickFocused;
  bool canActivateGameMode = mCameraButtonClickUp && mCameraButtonClickFocused;
  
  if (canActivateDirectMode)
    mCamera->SetMode(PokerCameraModel::CAMERA_DIRECT_MODE);
  else if (canActivateGameMode)
    mCamera->SetMode(PokerCameraModel::CAMERA_ENTER_MODE);
  return (mCamera->ModeChanged());
}

void PokerPlayerCamera::BeginFreeMode()
{
  mCamera->ConsumeMode();
  mCameraTimeout = 0.0f;
  mCameraTotalTimeout = 0.0f;
  mCameraLookCardState = 0;
  mLookingCardAnimationTimeout = 0.0f;
  mMouseDelta[0] = 0.0f;
  mMouseDelta[1] = 0.0f;
  //mCamera->SetRespondToEvents(true);
}

void PokerPlayerCamera::ExecuteFreeMode()
{
  if (mCamera->ModeChanged())
    BeginFreeMode();
  
  if (CameraEvaluateModeTransition())
    MoveCameraToCamLookModel();
  
  if (mCamera->ModeChanged())
    EndFreeMode();
}

void PokerPlayerCamera::EndFreeMode()
{
  //mGame->mPreviousCamera=*(mCamera->GetModel());
}

void PokerPlayerCamera::BeginEnterMode()
{
  mCamera->ConsumeMode();
  mCameraGoViewFirstPerson = true;
  GetCameraController()->mGame->GetPoker()->GameAccept(PokerEventStartFirstPerson());
}

void PokerPlayerCamera::ExecuteEnterMode()
{
  if (mCamera->ModeChanged())
    BeginEnterMode();

  if (mCameraTimeout > 0)
    mCameraTimeout-=mDeltaS;

  if (mLookingCardAnimationTimeout > 0)
    mLookingCardAnimationTimeout-=mDeltaS;

  if (mCameraTimeout<=0 && mLookingCardAnimationTimeout <= 0)
    mCamera->SetMode(PokerCameraModel::CAMERA_GAME_MODE);

  if (!mDisplayedAndFocused && mCameraButtonClickUp)
    mCamera->SetMode(PokerCameraModel::CAMERA_LEAVE_MODE);

  float cameraTimeoutToHideDisplayCal3dMesh = 0.5;
  VarsEditor::Instance().Get("PPC_timeToHideCal3dMeshes",cameraTimeoutToHideDisplayCal3dMesh);
	
  if (mCameraTotalTimeout-mCameraTimeout > cameraTimeoutToHideDisplayCal3dMesh)
    Cal3DInFPV();

  if (mCamera->ModeChanged())
    EndEnterMode();
}

void PokerPlayerCamera::EndEnterMode()
{

}

void PokerPlayerCamera::BeginGameMode()
{
  mCamera->ConsumeMode();

  mMouseDeltaOverall[0] = 0.0f;
  mMouseDeltaOverall[1] = 0.0f;

  mCameraTimeout=mCameraGameModeDelay;

  mLookingCardAnimationTimeout = 0;
  mCamera->GetModel()->mCamGameAttitude = mCamera->GetModel()->mCamAttitude;
  // std::map<std::string,MAFCameraModel>::iterator it=mCameras.find("CamLook");
  // MAFCameraModel& camera=(*it).second;
  // const osg::Vec3 &target = camera.GetTarget();
  //mCamera->GetModel()->mCamPrevTarget = target;
  // 	StopWaitIdleAnimation();
}

void PokerPlayerCamera::ExecuteGameMode()
{
  if (mCamera->ModeChanged())
    BeginGameMode();
  
  if (mCameraTimeout > 0)
    mCameraTimeout-=mDeltaS;

  if (mLookingCardAnimationTimeout > 0)
    mLookingCardAnimationTimeout-=mDeltaS;

  bool clickOnCard = mDisplayedAndFocused && mCameraButtonClickUp && mLookingCardAnimationTimeout <= 0;
  if (clickOnCard) {
		if (!mCameraLookCardState) {
			mCameraLookCardState = 1;
			mCameraTimeout=mCameraGameModeDelay;
		} else {
			mCameraLookCardState=0;
			mCameraTimeout = mCameraGameModeDelay-mCameraGameModeDelayLookCards;
		}
	}


  if (mCameraMouseMotion || mCameraButtonPressed) {
    mCameraTimeout=mCameraGameModeDelay;
  }
  
  bool lookCardTimeouted = mCameraLookCardState && (mCameraTimeout<(mCameraGameModeDelay-mCameraGameModeDelayLookCards));
  if (lookCardTimeouted) {
    mCameraLookCardState=0;
  }

  float mouseDeltaMAX = 10.0;
  VarsEditor::Instance().Get("PPC_mouseDeltaMax",mouseDeltaMAX);
  float timeToReadjust = 500.0;
  VarsEditor::Instance().Get("PPC_timeToReadjust",timeToReadjust);

  bool readjust = mCamera->GetModel()->mWasClickedWithNoFocus && !mInteractorSelected &&  mCameraButtonClickUp && ((mMouseDeltaOverall[0] >= mouseDeltaMAX) || (mMouseDeltaOverall[1] >= mouseDeltaMAX));
  if (readjust) {
    std::map<std::string,MAFCameraModel>::iterator it=mCameras.find("CamLook");
    g_assert(it!=mCameras.end());

    MAFCameraModel& camera=(*it).second;
    const osg::Vec3 &position = camera.GetPosition();
    const osg::Vec3 &target = camera.GetTarget();
    const osg::Vec3 &up = camera.GetUp();
    //float fov = camera.GetFov();
    osg::Quat quat;
    quat.set(osg::Matrix::lookAt(position, target, up));
    const osg::Quat &attitudeFrom = mCamera->GetModel()->mCamAttitude;
    const osg::Quat &attitudeTo = quat;
    mCamera->GetModel()->mFirstPersonBInterpolator.Init(attitudeFrom, attitudeTo);
    mCamera->GetModel()->mFirstPersonReadjusting = true;
    mCamera->GetModel()->StartInterpolation(timeToReadjust);
  }

  bool leaveMode = (!mDisplayedAndFocused && !mInteractorSelected &&  mCameraButtonClickUp && ((mMouseDeltaOverall[0] < mouseDeltaMAX) && (mMouseDeltaOverall[1] < mouseDeltaMAX)));
  if (leaveMode && (mCamera->GetModel()->mFirstPersonReadjusting == false)) {
    mCamera->SetMode(PokerCameraModel::CAMERA_LEAVE_MODE);
  }

  if (mCamera->ModeChanged())
    EndGameMode();
}

void PokerPlayerCamera::EndGameMode()
{
  mCameraTimeout = 0.0f;
	// cpinson it is already done in BeginLeaveMode
	//  mCameraLeaveViewFirstPerson = true;
}

void PokerPlayerCamera::BeginDirectMode()
{
  mCamera->ConsumeMode();
  //mCamera->SetRespondToEvents(false);
  mCameraGoViewFirstPerson = true;
  GetCameraController()->mGame->GetPoker()->GameAccept(PokerEventStartFirstPerson());
}


void PokerPlayerCamera::ExecuteDirectMode()
{
  if (mCamera->ModeChanged())
    BeginDirectMode();
  if (mCameraTimeout > 0)
    mCameraTimeout-=mDeltaS;

  if (!mCameraButtonPressed)
    mCamera->SetMode(PokerCameraModel::CAMERA_LEAVE_MODE);

  float cameraTimeoutToHideDisplayCal3dMesh = 0.5;
  VarsEditor::Instance().Get("PPC_timeToHideCal3dMeshes",cameraTimeoutToHideDisplayCal3dMesh);
  if (mCameraTotalTimeout-mCameraTimeout > cameraTimeoutToHideDisplayCal3dMesh)
    Cal3DInFPV();
 
  if (mCamera->ModeChanged())
    EndDirectMode();
}

void PokerPlayerCamera::EndDirectMode()
{
  //mCamera->SetRespondToEvents(true);
}

void PokerPlayerCamera::BeginLeaveMode()
{
  mCamera->ConsumeMode();
  MoveCameraToPreviousModel();
  mCameraLeaveViewFirstPerson = true;
  GetCameraController()->mGame->GetPoker()->GameAccept(PokerEventEndFirstPerson());
}

void PokerPlayerCamera::ExecuteLeaveMode()
{
  if (mCamera->ModeChanged())
    BeginLeaveMode();

  if (mCameraTimeout)
    mCameraTimeout-=mDeltaS;

  if (mLookingCardAnimationTimeout > 0)
    mLookingCardAnimationTimeout-=mDeltaS;

  float cameraTimeoutToShowDisplayCal3dMesh = 0.5;
  VarsEditor::Instance().Get("PPC_timeToShowCal3dMeshes",cameraTimeoutToShowDisplayCal3dMesh);
  if (mCameraTotalTimeout - mCameraTimeout > cameraTimeoutToShowDisplayCal3dMesh)
    Cal3DInTPV();
    
  //bool canMoveToLookModel = (mLookingCardAnimationTimeout <= 0) && (CameraEvaluateModeTransition());
  //if (canMoveToLookModel)
  //  MoveCameraToCamLookModel();
  
  if (mCameraTimeout<=0 && mLookingCardAnimationTimeout <= 0)
    mCamera->SetMode(PokerCameraModel::CAMERA_FREE_MODE);

  if (mCamera->ModeChanged())
    EndLeaveMode();
}

void PokerPlayerCamera::EndLeaveMode()
{
  GetCameraController()->mGame->GetPoker()->GameAccept(PokerEventEndLeaveFirstPerson());
}

void PokerPlayerCamera::BeginFixMode()
{
  mCamera->ConsumeMode();
}

void PokerPlayerCamera::ExecuteFixMode()
{
  if (fixmode == 1)
    if (GetCameraController()->GetModel()->GetIsMoving() == false)
      GetCameraController()->SetMode(PokerCameraModel::CAMERA_FREE_MODE);
}

void PokerPlayerCamera::EndFixMode()
{
}

void PokerPlayerCamera::updatePos(float _elapsed)
{
  int i;

  PokerApplication *app = GetCameraController()->mGame;
  PokerModel *pokerModel = app->GetPoker()->GetModel();

  for (i = 0; i < 9; i++) {
    float srcX, srcY, destX, destY;
    srcX = g_HUDPos_Src[i].x();
    srcY = g_HUDPos_Src[i].y();
    destX = g_HUDPos_Dst[i].x();
    destY = g_HUDPos_Dst[i].y();

    float fac = factor_[i];
    hudPos_[i].x() = srcX + (destX - srcX) * fac;
    hudPos_[i].y() = srcY + (destY - srcY) * fac;

    if (sens_ == 0)
      fac += (1 - fac) * _elapsed;
    else
      fac -= fac * _elapsed;

    if (fac < 0) fac = 0;
    else if (fac > 1) fac = 1;

    factor_[i] = fac;
  }

  for (i = 0; i < 9; i++) {
    PokerPlayer *player = players_[i];

    if (!player)
      continue;

    if (player->GetSeatId() == pokerModel->mDealerButtonSeatIndex) {
      std::string imgName = "dealer";

      if (!player->bPlayed_)
				imgName += "_G";

      osg::Texture2D *texture = MAFApplication::GetTextureManager()->GetTexture2D(dataPath_ + G_DIR_SEPARATOR_S + imgName + ".tga");
      dealerGroup_[i]->getOrCreateStateSet()->setTextureAttributeAndModes(0, texture, osg::StateAttribute::ON);
      dealerGroup_[i]->setNodeMask(MAF_VISIBLE_MASK);
    }
    else {
      dealerGroup_[i]->setNodeMask(0);
    }

    float x0 = hudPos_[i].x();
    float y0 = hudPos_[i].y();

    float rX0 = (x0 / 800) * 2 - 1;
    float rY0 = (y0 / 600) * 2 - 1;

    int sw = app->GetWindow(true)->GetWidth();
    int sh = app->GetWindow(true)->GetHeight();

    rX0 = floor(rX0 * sw) / float(sw);
    rY0 = floor(rY0 * sh) / float(sh);

    rX0 += 0.5f / sw;
    rY0 += 0.5f / sh;

    osg::Matrix mat = osg::Matrix::scale(2.0f/sw, -2.0f/sh, 1.0f) * osg::Matrix::translate(rX0, -rY0, 0);
    //		osg::Matrix mat = osg::Matrix::scale(0.003f, 0.003f, 1) * osg::Matrix::translate(rX0, -rY0, 0);
    mt_[i]->setMatrix(mat);

    if (factor_[i] == 0)
      mt_[i]->setNodeMask(0);
    else
      mt_[i]->setNodeMask(MAF_VISIBLE_MASK);

    osg::MatrixTransform *mtrot = mtrot_[i].get();
    osg::MatrixTransform *mticonrot = mticonrot_[i].get();

    float rot = player->lastActionRot_;
    rot += _elapsed * 0.75f;
    if (rot > osg::PI*2)
      rot = osg::PI*2;

    if (!player->bPlayed_) {
      rot = osg::PI*2;
    }

    if (rot > osg::PI*0.5) {

      if (rot < (osg::PI * 3) / 4 )
	rot += osg::PI; // after the text is on the slice, go straight to the last quarter

      std::string action = player->fullLastAction_;

      bool bTimeOut = false;
      if (action == "TimeOut") {
	int time = (int) player->GetTimeOut()->GetCounter();
	std::ostringstream oss;
	oss << time;
	action = oss.str();
	bTimeOut = true;
      }

      textLastAction_[i]->getText()->setText(osgText::String(action, osgText::String::ENCODING_UTF8));
      textLastActionIt_[i]->getText()->setText(osgText::String(action, osgText::String::ENCODING_UTF8));

      if (player->bPlayed_) {
	mtrot->getChild(0)->setNodeMask(MAF_VISIBLE_MASK);
	mtrot->getChild(1)->setNodeMask(0);
      }
      else {
	mtrot->getChild(0)->setNodeMask(0);
	mtrot->getChild(1)->setNodeMask(MAF_VISIBLE_MASK);
      }

      if (action == "") {
	actionGroup_[i]->setNodeMask(0);
      }
      else {
	std::string imgName = "check";

	if (bTimeOut == true)
	  imgName = "timeout_hud";
	else if (action.find("Bet") != std::string::npos)
	  imgName = "bet";
	else if (action.find("Blind") != std::string::npos)
	  imgName = "bet";
	else if (action.find("Fold") != std::string::npos)
	  imgName  = "fold";
	else if (action.find("Call") != std::string::npos)
	  imgName = "call";

	if (!player->bPlayed_ && imgName != "timeout_hud")
	  imgName += "_G";

	osg::Texture2D *texture = MAFApplication::GetTextureManager()->GetTexture2D(dataPath_ + "/" + imgName + ".tga");
	actionGroup_[i]->getOrCreateStateSet()->setTextureAttributeAndModes(0, texture, osg::StateAttribute::ON);
	actionGroup_[i]->setNodeMask(MAF_VISIBLE_MASK);
      }
    }

    mtrot->setMatrix( osg::Matrix::translate(0, 6, 0) * osg::Matrix::rotate(rot, osg::Vec3f(1, 0, 0)) * osg::Matrix::translate(0, -6, 0) );
    mticonrot->setMatrix( osg::Matrix::translate(0, -8.0f, 0) * osg::Matrix::rotate(rot, osg::Vec3f(1, 0, 0)) * osg::Matrix::translate(0, 8.0f, 0) );

    player->lastActionRot_ = rot;
  }
}

PokerPlayerCamera::CameraState PokerPlayerCamera::GetCameraState() const
{
  if (mCameraGoViewFirstPerson)
    return START_FIRST_PERSON;
  else if (mCameraLeaveViewFirstPerson)
    return END_FIRST_PERSON;
  return NONE_STATE;
}

void PokerPlayerCamera::Cal3DInFPV()
{
  int i;

  PokerApplication *app = mCamera->mGame;
  int me = app->GetPoker()->GetModel()->mMe;
  PokerPlayer *p = app->GetPoker()->GetModel()->mSerial2Player[me].get();
  PokerBodyModel *mod = p->GetBody()->GetModel();
  osgCal::Model *model = mod->GetOsgCalModel();

  /*
  //	mod->SetForceTransparencyRenderBin(true);
  //	mod->SetAlpha(1.0f);
	
  const std::string &fname = model->getCoreModel()->getFilename();
  float znear = 0, zfar = 0;
  std::map<std::string,std::string> url;
  url = app->HeaderGetProperties("sequence", "/sequence/FPCal3DMeshes");

  if (fname.rfind("player.male") != std::string::npos) {
  znear = atof( url["neardist_male"].c_str() );
  zfar = atof( url["fardist_male"].c_str() );
  }
  else if (fname.rfind("player.female") != std::string::npos) {
  znear = atof( url["neardist_female"].c_str() );
  zfar = atof( url["fardist_female"].c_str() );
  }
  //	model->setNearDistanceAlphaFog(znear);
  //model->setFarDistanceAlphaFog(zfar);
  //model->setUseAlphaFog(true);
  */
  std::vector<osg::Drawable*> toBeRemoved;

  int nbDrawables = model->getNumDrawables();
  for (i = 0; i < nbDrawables; i++) {
    osg::Drawable *drawable = model->getDrawable(i);

    osgCal::SubMeshSoftware *submesh = dynamic_cast<osgCal::SubMeshSoftware*>(drawable);
    if (!submesh) {
      osgCal::SubMeshHardware *submesh = dynamic_cast<osgCal::SubMeshHardware*>(drawable);
      const std::string &name = submesh->getName();

      bool res = IsCal3DMeshNeedToBeRemoved(name);
      if (res)
	toBeRemoved.push_back(submesh);

    }
    else {
      const std::string &name = submesh->getName();

      bool res = IsCal3DMeshNeedToBeRemoved(name);
      if (res)
	toBeRemoved.push_back(submesh);
    }
  }

  int nbToBeRemoved = toBeRemoved.size();
  for (i = 0; i < nbToBeRemoved; i++) {
    osg::Drawable *rem = toBeRemoved[i];
    model->removeDrawable(rem);
    removedCal3DMeshes_.insert(rem);
  }

  {
    PokerApplication *game = mCamera->mGame;
    osgUtil::SceneView *sceneView = game->GetScene()->GetView()->GetModel()->mScene.get();
    osg::Matrix camMat = sceneView->getViewMatrix();
    osg::Matrix invCamMat = osg::Matrix::inverse( camMat );

    osg::Vec3f camPos = invCamMat.getTrans();

    int me = game->GetPoker()->GetModel()->mMe;
    PokerPlayer *p = game->GetPoker()->GetModel()->mSerial2Player[me].get();
    osg::Node *seat = p->GetSeat()->GetModel()->GetArtefact();

    MAFBillBoard *n = (MAFBillBoard*) GetNode(seat, "autotransform_interactorPivot1");
    n->setActive(false);

    //		osg::AutoTransform *n = (osg::AutoTransform*) GetNode(seat, "autotransform_interactorPivot1");
    //	n->setAutoRotateMode( osg::AutoTransform::NO_ROTATION );

    /*
      osg::MatrixTransform *n = (osg::MatrixTransform*) GetNode(seat, "transform_interactorPivot3");
      osg::MatrixTransform *nn = (osg::MatrixTransform*) n->getParent(0);
      osg::Matrix mm = MAFComputeLocalToWorld(nn);
      mm = osg::Matrix::inverse(mm);

      osg::Vec3f vec;
      float dist;
      {
      osg::MatrixTransform *n = (osg::MatrixTransform*) GetNode(seat, "transform_interactorPivot1");
      osg::Matrix fmat = MAFComputeLocalToWorld(n);
      vec = fmat.getTrans() - camPos;
      dist = vec.length();
      }

      //		osg::Vec3f zaxis( -invCamMat(2, 0), -invCamMat(2, 1), -invCamMat(2, 2) );
      //	osg::Vec3f rpos = zaxis * 253 + camPos;
      osg::Vec3f rpos = vec * invCamMat;
      rpos = rpos * mm;
      osg::Matrix mat = n->getMatrix();
      mat.setTrans(rpos);
      //n->setMatrix(mat);
      */
  }
}

void PokerPlayerCamera::Cal3DInTPV()
{
  if (removedCal3DMeshes_.empty())
    return;
  int me = mCamera->mGame->GetPoker()->GetModel()->mMe;
  PokerPlayer *p = mCamera->mGame->GetPoker()->GetModel()->mSerial2Player[me].get();
  PokerBodyModel *mod = p->GetBody()->GetModel();
  osgCal::Model *model = mod->GetOsgCalModel();

  //	model->setUseAlphaFog(false);
  //mod->SetForceTransparencyRenderBin(false);

  for (std::set<osg::Drawable*>::iterator it = removedCal3DMeshes_.begin(); it != removedCal3DMeshes_.end(); ++it) {
    osg::Drawable *draw = *it;
    model->addDrawable(draw);
  }

  removedCal3DMeshes_.clear();

  {
    PokerApplication *game = mCamera->mGame;
    //osgUtil::SceneView *sceneView = game->GetScene()->GetView()->GetModel()->mScene.get();

    int me = game->GetPoker()->GetModel()->mMe;
    PokerPlayer *p = game->GetPoker()->GetModel()->mSerial2Player[me].get();
    osg::Node *seat = p->GetSeat()->GetModel()->GetArtefact();

    MAFBillBoard *n = (MAFBillBoard*) GetNode(seat, "autotransform_interactorPivot1");
    n->setActive(true);
    //n->setActive(false);
  }
}


bool PokerPlayerCamera::IsCal3DMeshNeedToBeRemoved(const std::string &_meshName)
{
  int size = cal3dMeshesToKeepInFPV_.size();
  for (int i = 0; i < size; i++) {
    const std::string &name = cal3dMeshesToKeepInFPV_[i];
    if (name == _meshName)
      return false;
  }
  return true;
}
