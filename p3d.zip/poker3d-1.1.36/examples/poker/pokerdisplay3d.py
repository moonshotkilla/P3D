#
# Copyright (C) 2004-2006 Mekensleep
#
# Mekensleep
# 24 rue vieille du temple
# 75004 Paris
#       licensing@mekensleep.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
# Authors:
#  Loic Dachary <loic@gnu.org>
#

from twisted.internet import reactor
from twisted.python import log

from underware.mafapplication import MAFApplication

from pokerui.pokerdisplay import PokerDisplay

import poker.pokeranimation3d
import platform
import os

if platform.system() == "Windows":
    from win32com.shell import shell, shellcon

class ReactorWrapper:
    def __init__(self, reactor):
        self.reactor = reactor

    def iterate(self):
        self.reactor.iterate()
        return log.error_occurred == False

class PokerDisplay3D(PokerDisplay):
    def __init__(self, *args, **kwargs):
        PokerDisplay.__init__(self, *args, **kwargs)

    def init(self):
        settings = self.settings
        config = self.config

        self.underware = MAFApplication()
        self.underware.SetHeaders(settings.doc._o, config.doc._o)
        applicationTag = self.underware.SetLogPolicy()
        self.underware.SetReactor(ReactorWrapper(reactor))
        self.underware.Init()
        self.showProgressBar()
        self.tickProgressBar(0.0, "Initializing")
        self.animations = poker.pokeranimation3d.create(self.underware, config, settings)

    def interfaceReady(self):
        self.underware.InterfaceReady()
        
    def setRenderer(self, renderer):
        PokerDisplay.setRenderer(self, renderer)
        self.underware.SetClient(renderer)

    def load(self):
        self.underware.Load()
        
    def finish(self):
        if PokerDisplay.finish(self):
            self.underware.Stop()
            self.underware = None

    def run(self):
        return self.underware.Run()

    def render(self, packet):
	if self.underware:
	    self.underware.PythonAccept(packet)
	else:
	    print "*CRITICAL* PokerDisplay3D.render called with None display"

    def showProgressBar(self):
        self.underware.ShowSplashScreen()
    
    def hideProgressBar(self):
        self.underware.HideSplashScreen()

    def tickProgressBar(self, ratio, message):
        self.underware.UpdateSplashScreen(ratio, message or "")

    def isSoundEnabled(self):
        return self.underware.IsSoundEnabled()

    def setSoundEnabled(self,state):
        return self.underware.SetSoundEnabled(state)

