/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Henry Pr�cheur <henry@precheur.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include "pokerStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */
#ifdef WIN32
#include <cstdio>
# define snprintf _snprintf
#endif

#include <osgDB/FileUtils>
#include <CustomAssert/CustomAssert.h>
#ifndef POKER_USE_VS_PCH
#include <osgDB/ReadFile>
#include <osgDB/WriteFile>
#include <osgDB/Registry>

#include <osg/BlendFunc>
#include <osg/Depth>
#include <osg/LightSource>
#include <osg/VertexProgram>
#include <osg/FragmentProgram>
#include <osg/Stencil>
#include <osg/Material>

#include <osgAL/SoundNode>
#include <osgAL/SoundRoot>
#include <osgAL/SoundManager>
#include <osgAL/SoundState>

#include <SDL/SDL.h>

#include <maf/data.h>
#include <maf/split.h>
#include <maf/maferror.h>
#include <maf/packets.h>
#include <maf/application2d.h>
#include <maf/animate2d.h>
#include <maf/wnc_source.h>
#include <maf/wnc_desktop.h>
#include <maf/window.h>
#include <maf/shadow.h>
#include <maf/shader.h>
#include <maf/assert.h>
#include <maf/glow_fx.h>
#include <maf/renderbin.h>

#include <varseditor/varseditor.h>
#endif

#include <libintl.h>
#define _(String) gettext (String)

#ifndef POKER_USE_VS_PCH
#include <ugame/ugameerror.h>
#include <ugame/text.h>
#include <ugame/artefact.h>
#include <ugame/animated.h>
#include <ugame/debug.h>

#include <osgchips/Stacks>

#	include <PokerApplication2d.h>
#	include <Poker.h>
#	include <PokerCard.h>
#	include <PokerPlayer.h>
#	include <PokerBody.h>
#	include <PokerApplication.h>
#	include <PokerCamera.h>
#	include <PokerSplashScreen.h>
#	include <PokerToolTip.h>
# include <PokerCursor.h>
# include <PokerSound.h>
#include "PokerSceneView.h"
#include <PokerMultiTable.h>

#include <sstream>
#endif

#include <osgDB/Archive>

#include <osgCal/ImageCache>

#include "osgSprite/osgSprite.h"

#include <SDL.h>

struct PokerFps: public MAFVisionController
{
  PokerFps()
    : MAFVisionController()
  {
    mText = new UGAMEBasicText("none\nnone", 0);
  }

  void	Init()
  {
    MAFVisionController::Init();
    MAFVisionModel*	model = new MAFVisionModel;
    SetModel(model);
    model->SetNode(mText.get());
  }

  bool Update(MAFApplication* application)
  {
    if (application->HasEvent())
      return true;
    else
      {
	char	tmp[256];
	snprintf(tmp, sizeof (tmp), "%.1f fps\n%.4f spf",
		 static_cast<double>(application->GetFPS()),
		 static_cast<double>(GetDeltaFrame()/1000.0));
 	mText->setStringUTF8(std::string(tmp));
//  	UGAMEPlaceTextInHud(mText->getText(), osgText::Text::LEFT_BOTTOM,
//  			  application->GetWindow(true)->GetWidth(),
//  			  application->GetWindow(true)->GetHeight());
	return true;
      }
  }

  osgText::Text*	GetText()
  {
    return mText->getText();
  }

protected:
  osg::ref_ptr<UGAMEBasicText>	mText;
};

PokerApplication::PokerApplication() :
  mSetData(0),
  mDeck(0),
  mCursor(0),
  mPyScheduler(0)
{
}

PokerApplication::~PokerApplication()
{
}

bool PokerApplication::SetSoundEnabled(bool state)
{
	return MAFAudioDevice::GetInstance()->SetSoundEnabled(state);
}

bool PokerApplication::IsSoundEnabled()
{
	return MAFAudioDevice::GetInstance()->IsSoundEnabled();
}

void PokerApplication::PythonAccept(PyObject* pypacket) {
  if(IsRunning()) {
    osg::ref_ptr<MAFPacket> packet = new MAFPacket(GetPacketsModule(), pypacket);
    if(mPoker.valid())
      mPoker->PythonAccept(packet.get());
    else if(packet->IsType("QUIT"))
      Quit();
  }
}

void PokerApplication::SendPacket(const std::string &packetName)
{
  if(IsRunning()) {
    osg::ref_ptr<MAFPacket> packet = GetPacketsModule()->Create(packetName);
    packet->SetMember("serial", mPoker->GetModel()->mMe);
    packet->SetMember("game_id", mPoker->GetModel()->mGameSerial);
    PythonCall("sendPacket", packet.get());
  }
}

void PokerApplication::Load(void)
{
  //
  // Load chips bank
  //
  osgDB::Registry::instance()->getDataFilePathList().push_back(HeaderGet("settings", "/settings/data/@path"));
  {
		osgchips::ChipBank *instance = osgchips::ChipBank::instance();
    instance->unserialize(GetHeaders()["sequence"], "/sequence/osgchips", osgDB::Registry::instance());
  }

  mDatas->SetBaseDirectory(HeaderGet("settings", "/settings/data/@path"));

  std::list<std::string> levels=HeaderGetList("sequence", "/sequence/levels/level/@url");
  if (levels.empty())
    g_error("PokerApplication::Load levels/level/@url not found, you need at least one entry");
  mDatas->SetLevel(levels.front());

  std::string sound = HeaderGet("settings", "/settings/sound");

  UGAMEDebugSingleton::Init(GetScene()->GetModel()->mGroup.get());

  mDeck = new PokerDeck(this);

	mSplashScreen->GetModel()->write("Loading...");
	mSplashScreen->GetModel()->setMulAddFactor(0.3333f, 0);
	std::list<std::string> urls = HeaderGetList("sequence", "/sequence/texture_precache/texture/@name");

	mSplashScreen->GetModel()->setProgressLength( urls.size() );

	for (std::list<std::string>::iterator it = urls.begin(); it != urls.end(); ++it) {
		std::string tex = *it;
    std::string data = HeaderGet("settings", "/settings/data/@path");

		std::string path = data + "/" + tex;
		osgCal::ImageCache::getOrLoadBinary(path);

		mSplashScreen->GetModel()->progress();
	}

	mPoker = new PokerController(this, 1, mSplashScreen->GetModel() );
  AddController(mPoker.get());
#ifdef TEST_PERFORMANCE
  std::string count_duplicate_string = HeaderGet("sequence", "/sequence/test/@count");
#endif

#ifdef TEST_PERFORMANCE
  int duplicates = atoi(count_duplicate_string.c_str());
  if(duplicates > 0) {
    std::string what_dup = HeaderGet("sequence", "/sequence/test/@what");
    std::string step_dup_string = HeaderGet("sequence", "/sequence/test/@step");
    int step_dup = atoi(step_dup_string.c_str());
    MAFVisionData* data = mDatas->GetVision(what_dup);
    for(int i = 0; i < duplicates; i++) {
      UGAMEArtefactModel* artefact_model;
      if(what_dup.find("cal3d") == std::string::npos)
	artefact_model = new UGAMEArtefactModel;
      else
	artefact_model = new UGAMEAnimatedModel;
      artefact_model->SetData(data);
      UGAMEArtefactController* controller;
      if(what_dup.find("cal3d") == std::string::npos)
	controller = new UGAMEArtefactController(0);
      else
	controller = new UGAMEAnimatedController(0);
	
      controller->SetModel(artefact_model);
      controller->Init();
      if(what_dup.find("cal3d") == std::string::npos)
	artefact_model->SetArtefact(((MAFOSGData*)data)->GetGroup());
      artefact_model->GetPAT()->setPosition(osg::Vec3(step_dup*i, 0.f, 0.f));
      GetScene()->Insert(controller);
    }
  }
#endif

  {
    mCursor=new PokerCursor(this);
    mCursor->Init();
  }

   {
		 std::string fps=HeaderGet("settings", "/settings/@fps");
		 if (fps == "on" || fps == "yes")
		 {
			 PokerFps*	fps_counter = new PokerFps();

			 fps_counter->Init();
			 GetScene()->HUDInsert(fps_counter);
			 AddController(fps_counter);
		 }
	 }


  {
    PokerToolTipController*	pttc = new PokerToolTipController(this);
    GetScene()->HUDInsert(pttc);
    AddController(pttc);
  }

  const std::string &shadow = HeaderGet("settings", "/settings/shadow");
  if (shadow == "on" || shadow == "yes")
    mShadowFlag=true;

  const std::string &trilinear = HeaderGet("settings", "/settings/trilinear");
	if (trilinear == "on" || trilinear == "yes")
		GetTextureManager()->SetUseTrilinear(true);

	PokerSceneView *instance = PokerSceneView::getInstance();
	if (instance) {
		instance->setup();
	}

	osg::Group *HUD = GetScene()->GetView()->GetModel()->mHUDProjection.get();
  HUD->getOrCreateStateSet()->setAttributeAndModes( new osg::ColorMask() );

	{
		MAFWindow *window = GetWindow(true);
		// insert name of table in hud
		const std::string &dataPath = HeaderGet("settings", "/settings/data/@path");
		
		const std::string &offsetX = HeaderGet("sequence", "/sequence/tableNameDisplay/@offsetX");
		const std::string &offsetY = HeaderGet("sequence", "/sequence/tableNameDisplay/@offsetY");
		if (offsetX.empty())
			g_error("PokerApplication::Load xml /sequence/tableNameDisplay/@offsetX not found");
		if (offsetY.empty())
			g_error("PokerApplication::Load xml /sequence/tableNameDisplay/@offsetY not found");
		float ox,oy;
		ox = atof(offsetX.c_str());
		oy = atof(offsetY.c_str());
		mTransformTableName = new osg::MatrixTransform;
		osgText::Font* font = MAFLoadFont(dataPath + "/FreeSansBold.ttf");
		mTableName = new UGAMEBasicText("", font);
		mTableName->getText()->setAlignment(osgText::Text::RIGHT_TOP);
		mTransformTableName->addChild(mTableName.get());
		mTransformTableName->setMatrix(osg::Matrix::translate(window->GetWidth()-ox,window->GetHeight()-oy,0));
		GetScene()->GetModel()->mHUDBackground->addChild(mTransformTableName.get());
	}

	mSplashScreen->GetModel()->setMulAddFactor(0.3333f, 0.3333f);
	mSplashScreen->GetModel()->write("Loading...");
	{
    std::string maleSounds = "player.male.cal3d/sounds/sounds.xml";
    MAFXmlData *maleData = mDatas->GetXml(maleSounds);

    std::string femaleSounds = "player.female.cal3d/sounds/sounds.xml";
    MAFXmlData *femaleData = mDatas->GetXml(femaleSounds);

    std::vector<SoundInit> maleParams;
    std::vector<SoundInit> femaleParams;
		LoadSoundSettings(maleParams, maleData);
		LoadSoundSettings(femaleParams, femaleData);

		int nbMaleSounds = maleParams.size();
		int nbFemaleSounds = femaleParams.size();

		mSplashScreen->GetModel()->setProgressLength(nbMaleSounds + nbFemaleSounds);

		for (int i = 0; i < nbMaleSounds; i++) {
			mDatas->GetAudio("player.male.cal3d/sounds/" + maleParams[i].mSoundName);
			mSplashScreen->GetModel()->progress();
		}

		for (int i = 0; i < nbFemaleSounds; i++) {
			mDatas->GetAudio("player.female.cal3d/sounds/" + femaleParams[i].mSoundName);
			mSplashScreen->GetModel()->progress();
		}
	}
	mSplashScreen->GetModel()->setMulAddFactor(0.333f, 0.666f);
	mSplashScreen->GetModel()->write("Loading...");

}

void PokerApplication::ShowSplashScreen(void)
{
  if(!mSplashScreen.valid()) {
    mSplashScreen = new PokerSplashScreenController(this);
    GetScene()->HUDInsert(mSplashScreen.get());
  }
}

MAFApplication2DController* PokerApplication::GetInterface()
{
  if (mPokerApplication2D.valid())
    return mPokerApplication2D->GetApplication2D();
  return 0; 
}


void PokerApplication::InterfaceReady(void)
{  
  {
    std::string display = HeaderGet("settings", "/settings/metisse/@display");
    mDatas->XwncConnect("vnc://127.0.0.1:" + display + "/?password=spe");
  }
  mPokerApplication2D = new PokerApplication2D;
  mPokerApplication2D->CreateDesktop(this,mDatas->GetDesktop());
  mPokerApplication2D->InitStackPriorityDesktop(this,mDatas->GetDesktop()->GetStackPriority());

  CUSTOM_ASSERT(GetInterface());
  GetScene()->HUDInsert(GetInterface());
  if (!MAFRenderBin::Instance().SetupRenderBin("Interface2D", GetInterface()->GetModel()->GetNode()->getOrCreateStateSet()))
    MAF_ASSERT(0 && "Interface2D not found in client.xml");
  AddController(GetInterface());
}

void PokerApplication::HideSplashScreen()
{
  if(mSplashScreen.valid()) {
    GetScene()->HUDRemove( mSplashScreen.get());
    mSplashScreen = NULL;
	//_asm { int 3 };
    //*((char*)0) = 0;
    //mSetData = 4;
    if(mSetData != NULL)
      GetScene()->GetModel()->mGroup->addChild(mSetData->GetGroup());
  }
	//*((char*)0) = 0;
}

void PokerApplication::UpdateSplashScreen(float ratio, char* message)
{
  PokerSplashScreenModel* model = mSplashScreen->GetModel();

  if(strlen(message) > 0) {
    model->write(message);
  }

  model->setProgressLength(100);
  model->pos_ = 100 * ratio;
  model->updateProgressBar();
}

#ifdef WIN32
static BOOL CALLBACK enumWindowsProc(HWND hwnd, LPARAM lParam)
{
	hwnd = hwnd;
	char str[500];
	GetWindowText(hwnd, str, sizeof(str));
	if (!strcmp(str, "poker3d - splashscreen")) {
		DestroyWindow(hwnd);
		return FALSE;
	}
	return TRUE;
}
#endif

void PokerApplication::Init(void)
{
#ifdef WIN32
#define LC_ALL 0
  //#undef PACKAGE
#define PACKAGE "underware"
#define LOCALEDIR "."
	EnumWindows(enumWindowsProc, 0);
#endif

  Create();

  // FIXME, this line cause a bug card/interactor load.
  // very strange, maybe my version of gettext/libc has a bug ?
  // setlocale (LC_ALL, "");
  bindtextdomain (PACKAGE, LOCALEDIR);
  textdomain (PACKAGE);

	VarsEditor::Instance().Read(GetHeaders()["sequence"],"/sequence/varseditor");
	MAFRenderBin::Instance().Read(GetHeaders()["sequence"],"/sequence/renderbin/*/entity");

  std::string sound = HeaderGet("settings", "/settings/sound");
  bool has_sound = sound == "yes" || sound == "on" || sound == "";

//	osg::setGLExtensionDisableString(std::string) 

  SetScene(new MAFSceneController);
  {
    MAFSceneModel* model = new MAFSceneModel;
    GetScene()->SetModel(model);
  }

	const std::string &useVertexProgram = HeaderGet("settings", "/settings/vprogram");
	const std::string &useFragmentProgram = HeaderGet("settings", "/settings/fprogram");

	bool bVP = (useVertexProgram == "yes") || (useVertexProgram == "on");
	bool bFP = (useFragmentProgram == "yes") || (useFragmentProgram == "on");

	MAFShader::setTechnicAuthorisation( MAFShader::TECHNIC_AUTHORISATION_NONE );

	if (bVP && !bFP)
		MAFShader::setTechnicAuthorisation( MAFShader::TECHNIC_AUTHORISATION_VERTEX_PROGRAM );
	else if (!bVP && bFP)
		MAFShader::setTechnicAuthorisation( MAFShader::TECHNIC_AUTHORISATION_FRAGMENT_PROGRAM );
	else if (bVP && bFP)
		MAFShader::setTechnicAuthorisation( MAFShader::TECHNIC_AUTHORISATION_VERTEXFRAGMENT_PROGRAM );

	const std::string &dataDir = HeaderGet("settings", "/settings/data/@path");
	osg::ref_ptr<osg::Image> img = osgDB::readImageFile( std::string(dataDir + "/poked_icon.tga").c_str() );
	if (img.valid()) {
		img->flipVertical();
		void *pixs = (void*) img->data();
		if (pixs)
			mWindowIcon = SDL_CreateRGBSurfaceFrom(pixs, 32, 32, 32, 32*4, 0x000000ff, 0x0000ff00, 0x00ff0000, 0xff000000);
	}

	MAFWindow *window = GetWindow(true);

	if (mWindowIcon) {
		SDL_FreeSurface(mWindowIcon);
		mWindowIcon = NULL;
	}

  PokerSceneView *uihelp = new PokerSceneView(this, 1024);
  std::string hasGlow = HeaderGet("settings", "/settings/glow");
	mGlowFlag = hasGlow == "yes" || hasGlow == "on";
	uihelp->setUseGlow(false);
  GetScene()->SetView(uihelp);
  GetScene()->Init();

  std::ostringstream oss;
  oss << "poker3d";
#ifdef _DEBUG
  oss << " (Build: " << __DATE__ << " " << __TIME__ << ")";
  oss << " DEBUG";
#endif

  MAFSceneView *sceneView = GetScene()->GetView();
  sceneView->setViewport(0, 0, window->GetWidth(), window->GetHeight());
  window->AddView(sceneView);

	int screenAlphaSize;
 	SDL_GL_GetAttribute(SDL_GL_ALPHA_SIZE, &screenAlphaSize);
	if (screenAlphaSize == 0)
		mGlowFlag = false;

  std::string title(oss.str());
  SDL_WM_SetCaption(title.c_str(), 0);
  AddController(GetScene());

  mPokerMultiTable = new PokerMultiTable(this);
  AddController(mPokerMultiTable.get());


	MAFAudioDevice::GetInstance()->SetSoundEnabled(has_sound);

	// Create ONE (only one, otherwise the transformation of the listener and update for SoundManager will be
	// called several times, which is not catastrophic, but unnecessary) 
	// SoundRoot that will make sure the listener is updated and
	// to keep the internal state of the SoundManager updated
	// This could also be done manually, this is just a handy way of doing it.
	osgAL::SoundRoot* sound_root = new osgAL::SoundRoot;
	GetScene()->GetModel()->mGroup->addChild(sound_root);

  SetPacketsModule("pokernetwork.pokerclientpackets");
}

void PokerApplication::OnExit(int code)
{
	MAFAudioDevice::GetInstance()->DeInitializeDevice();
  g_debug("PokerApplication is leaving with exit code %d.\n", code);

  if (mCursor) {
    delete mCursor;
    mCursor=0;
  }

  if (mPokerMultiTable.valid()) {
    RemoveController(mPokerMultiTable.get());
    mPokerMultiTable = 0;
  }

  UGAMEDebugSingleton::Uninit();
  if (mPoker.valid()) {
    g_assert(mPoker->referenceCount() == 1);
    mPoker = 0;
  }

  if (GetInterface()) {
	  RecursiveClearUserData(GetInterface()->GetModel()->GetNode());
	  MAFName2Animate& name2animate = GetInterface()->GetName2Animate();
		for(MAFName2Animate::iterator i = name2animate.begin(); 
				i != name2animate.end();
				i++)
			delete i->second;
  }

  GetWindow(true)->DelView(GetScene()->GetView());
  if(mDeck) {
    delete mDeck;
    mDeck = 0;
  }
  if(mDatas) {
    delete mDatas;
    mDatas = 0;
  }
  g_assert(GetScene()->referenceCount() == 1);

  PokerSceneView *sceneview = PokerSceneView::getInstance();
  if (sceneview)
	  sceneview->uninit();

  SetScene(0);

  if (GetInterface()) {
		int ref=GetInterface()->referenceCount();
		g_assert(ref == 1);
		mPokerApplication2D = 0;
  }
}

const std::string& PokerApplication::SetLogPolicy()
{
	MAFError::SetVerbose(HeaderGet("settings", "/settings/@verbose"));
	static std::string application_tag = "pok3d";
	return application_tag;
}

void PokerApplication::Crash()
{
#ifdef WIN32
	//MAFErrorHandler::GetInstance().CrashReport();
#endif
}

class AnimatedVisitor : public osg::NodeVisitor {
public:
  AnimatedVisitor(const std::string& name) : osg::NodeVisitor(osg::NodeVisitor::TRAVERSE_ALL_CHILDREN), mNode(0), mName(name) {
    setNodeMaskOverride(MAF_VISIBLE_MASK | MAF_COLLISION_MASK);
  }

  virtual void apply(osg::Node& node) {
    if(node.getName().find(mName) != std::string::npos) {
      mNode = &node;
      if(node.getName() != mName)
	g_critical("animated searched %s but found %s (AMBIGUOUS MUST BE FIXED)", mName.c_str(), node.getName().c_str());
    } else
      traverse(node);
  }

  osg::Node* mNode;
  const std::string& mName;
};

//
// serial           : 234234 -> PokerBodyController
// serial/nodename  : 234/transform_foo -> osg::Node
// nodename         : transform_foo -> osg::Node
//
osg::Referenced* PokerApplication::SearchAnimated(const std::string& name) {
	std::vector<std::string> names = std::split(name, "/", 0);
  
  std::string nodename;
  osg::Node* node;

  if(isdigit(name[0])) {
    guint serial = atoi(name.c_str());
    std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = mPoker->GetModel()->mSerial2Player;
    if(serial2player.find(serial) == serial2player.end())
      return 0;
    PokerPlayer* player = serial2player[serial].get();
    if(names.size() == 1)
      return player->GetBody();

    node = player->GetSeat()->GetModel()->GetArtefact();
    nodename = names[1];
  } else {
    node = GetScene()->GetModel()->mGroup.get();
    nodename = name;
  }

  AnimatedVisitor visitor(nodename);
  node->accept(visitor);
  return visitor.mNode;
}


//
// serial           : 234234 -> PokerBodyController
//
osg::Referenced* PokerApplication::SearchPlayer(const std::string& name) {
	PokerPlayer* pl = 0;

  if(isdigit(name.c_str()[0])) {
    guint serial = atoi(name.c_str());
    std::map<guint,osg::ref_ptr<PokerPlayer> >& serial2player = mPoker->GetModel()->mSerial2Player;
    if(serial2player.find(serial) == serial2player.end())
      return 0;
    PokerPlayer* player = serial2player[serial].get();
		pl = player;
  }
	return pl;
}
