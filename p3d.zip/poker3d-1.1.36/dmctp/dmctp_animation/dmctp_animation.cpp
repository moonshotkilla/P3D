/*
 *
 * Copyright (C) 2005, 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include <string>
#include <iostream>
#include <vector>
#include <cal3d/coreanimation.h>
#include <cal3d/corekeyframe.h>
#include <cal3d/coretrack.h>
#include <cal3d/loader.h>

#include <libxml/xmlreader.h>
#include <libxml/tree.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <libxml/xinclude.h>
#include <libxml/xpathInternals.h>

#include <osg/AnimationPath>

#if CAL3D_VERSION >= 11
using namespace cal3d;
#else
typedef CalCoreAnimation* CalCoreAnimationPtr;
#endif


int LoadCal3d(const std::string& file)
{
	CalCoreAnimationPtr coreanimation = CalLoader::loadCoreAnimation(file);
	if (!coreanimation)
		return -1;
	int size = 0;

	std::list<CalCoreTrack *>& listtrack = coreanimation->getListCoreTrack();
	for (std::list<CalCoreTrack *>::iterator it = listtrack.begin(); it != listtrack.end(); it++) {
		CalCoreTrack* track = *it;
		int nbKeys = track->getCoreKeyframeCount();
		size += nbKeys*(sizeof(CalCoreKeyframe) + sizeof(CalCoreKeyframe*)); // because a vector store pointer to CalCoreKeyframe
	}
	return size;
}

int LoadEscn(const std::string& file)
{
  int size = 0;
  xmlDocPtr document = xmlParseFile(file.c_str());
  xmlXPathContextPtr xpathContext = xmlXPathNewContext(document);
  if (!xpathContext) {
    //    std::cerr << "unable to create new XPath context " << std::endl;
    return -1;
  }

  int maxKey = 0;
  {
    char* xpath = "//animation/track_position/key";
    xmlXPathObjectPtr xpathObj = xmlXPathEvalExpression((xmlChar*)xpath, xpathContext);
    if (xpathObj) {
      xmlNodeSetPtr nodes = xpathObj->nodesetval;
      if(nodes && nodes->nodeNr > maxKey)
        maxKey = nodes->nodeNr;
    }
    xmlXPathFreeObject(xpathObj);
  }

  {
    char* xpath = "//animation/track_rotation/key";
    xmlXPathObjectPtr xpathObj = xmlXPathEvalExpression((xmlChar*)xpath, xpathContext);
    if (xpathObj) {
      xmlNodeSetPtr nodes = xpathObj->nodesetval;
      if(nodes && nodes->nodeNr > maxKey)
        maxKey = nodes->nodeNr;
    }
    xmlXPathFreeObject(xpathObj);
  }

  {
    char* xpath = "//animation/track_scale/key";
    xmlXPathObjectPtr xpathObj = xmlXPathEvalExpression((xmlChar*)xpath, xpathContext);
    if (xpathObj) {
      xmlNodeSetPtr nodes = xpathObj->nodesetval;
      if(nodes && nodes->nodeNr > maxKey)
        maxKey = nodes->nodeNr;
    }
    xmlXPathFreeObject(xpathObj);
  }

  xmlXPathFreeContext(xpathContext);
  xmlFreeDoc(document);

  size = maxKey * sizeof(osg::AnimationPath::ControlPoint);
	return size;
}


int main(int argc, char** argv)
{
	if (argc != 2) {
		std::cout << "usage " << argv[0] << " file\n";
		exit(1);
	}

	std::string filename = std::string(argv[1]);
  std::string ext = filename;
  for (int i = 0; i < (int)filename.size() ; i++ ) {
    ext[i] = (char) tolower(filename[i]);
  }
	
	int size =  0;
	if (ext.find(".escn") != std::string::npos) {
		size = LoadEscn(filename);
	} else if (ext.find(".caf") != std::string::npos) {
		size = LoadCal3d(filename);
	}

	if (size == -1)
		return 1;
	
	std::cout << size << std::endl;
	return 0;
}
