/*
 *
 * Copyright (C) 2005, 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include <string>
#include <iostream>
#include <osgDB/ReadFile>


static void usage()
{
	std::cout << "usage dmctp_image file\n";
	exit(1);
}

int main(int argc, char** argv)
{
	if (argc != 2)
		usage();

	std::string filename = std::string(argv[1]);
	osg::ref_ptr<osg::Image> image;
	image = osgDB::readImageFile(filename);
	if (image.valid()) {
		int size = image->getTotalSizeInBytes()*2; // to include mipmap
		std::cout << size << std::endl;
		return 0;
	}
	return 1;
}
