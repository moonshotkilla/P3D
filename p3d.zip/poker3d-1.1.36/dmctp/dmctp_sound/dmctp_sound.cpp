/*
 *
 * Copyright (C) 2005, 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include <string>
#include <iostream>
#include <vector>
#include <ogg/ogg.h>
#include <vorbis/vorbisfile.h>


#define BUFFER_OGG 32768

int LoadOgg(const std::string& path){
  int endian = 0;                         // 0 for Little-Endian, 1 for Big-Endian
  int bitStream;
  long bytes;
  char array[BUFFER_OGG];                // Local fixed size array
  std::vector<char> buffer;
  int freq;

  FILE *file = fopen(path.c_str(), "rb");
  if(file == NULL) {
    return -1;
  }

  vorbis_info *pInfo;
  OggVorbis_File oggFile;

  if(ov_open(file, &oggFile, NULL, 0) != 0) {
    fclose(file);
    return -1;
  }

  pInfo = ov_info(&oggFile, -1);

	// if format == 1 it's 16 bits mono else 16 bits stereo
	// pInfo->channels

  freq = pInfo->rate;

  do {
    bytes = ov_read(&oggFile, array, BUFFER_OGG, endian, 2, 1, &bitStream);

    if (bytes < 0) {
      ov_clear(&oggFile);
      return -1;
    }
    buffer.insert(buffer.end(), array, array + bytes);
  } while(bytes > 0);

  ov_clear(&oggFile);

  void* vb=&buffer.front();
  (void)vb;
  int sz=buffer.size();
	return sz;
}


int LoadWav(const std::string& path)
{
  FILE *file = fopen(path.c_str(), "rb");
  if(file == NULL) {
    return -1;
  }
	int size = 0;
	fseek(file,SEEK_END,0);
	size = ftell(file);
	fclose(file);
	return size;
}


int main(int argc, char** argv)
{
	if (argc != 2) {
		std::cout << "usage " << argv[0] << " file\n";
		exit(1);
	}

	std::string filename = std::string(argv[1]);
	int size =  0;
	if (filename.find(".ogg") != std::string::npos) {
		size = LoadOgg(filename);
	} else if (filename.find(".wav") != std::string::npos) {
		size = LoadWav(filename);
	}

	if (size == -1)
		return 1;
	
	std::cout << size << std::endl;
	return 0;
}
