/*
 * Copyright (C) 2002 Loic Dachary <loic@gnu.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */
#ifdef WIN32
//#include "config_win32.h"
#define _WIN32_WINNT 0x0500 //for GetCurrentDirectory
#include <windows.h>
#endif

#include <direct.h>
#include <windows.h>
#include <tlhelp32.h>
#include <cstdio>
#include <iostream>
#include <string>

#ifdef _DEBUG // for Windows python23_d.lib is not in distribution... ugly but works
 #undef _DEBUG
 #include <Python.h>
 #define _DEBUG
#else
 #include <Python.h>
#endif

//extern "C"
//DL_EXPORT(int) Py_Main( int argc, char *argvw[] );

int Py_Main( int argc, char *argv[] );

#undef WIN32

#include "shlobj.h"

#include "lmaccess.h"

BOOL CALLBACK dialogProc(HWND _hwnd, UINT _msg, WPARAM _wParam, LPARAM _lParam)
{
	static int timer_count = 0;
	char str[500];

	switch(_msg) {

		case WM_CLOSE:
			break;

		case WM_INITDIALOG:
			return FALSE;
			break;

		default:
			return FALSE;
	}
	return TRUE;
}

bool killit(const char *name)
{
  std::string exeName(name);
  HANDLE hProcessSnap;
  PROCESSENTRY32 pe32;

  hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
  if(hProcessSnap == INVALID_HANDLE_VALUE)
  {
    std::cerr << "CreateToolhelp32Snapshot (of processes)" << std::endl;
    return false;
  }

  pe32.dwSize = sizeof(PROCESSENTRY32);

  if(!Process32First(hProcessSnap, &pe32))
  {
    std::cerr << "Process32First" << std::endl;
    CloseHandle(hProcessSnap);
    return false;
  }

  do
  {
    std::string processName(pe32.szExeFile);
    if (processName == exeName)
    {
      HANDLE hProcess;
      hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pe32.th32ProcessID);
      if(hProcess == NULL)
        std::cerr << "OpenProcess" << std::endl;
      else
      {
        std::cout << "TerminateProcess " << processName << ":" << hProcess << std::endl;
        TerminateProcess(hProcess, -1);
        WaitForSingleObject(hProcess, INFINITE);
        CloseHandle(hProcess);
      }
    }
  } while(Process32Next(hProcessSnap, &pe32));

  CloseHandle(hProcessSnap);
  return true;
}


void fixSlash(char *_str)
{
	int size = strlen(_str);
	for (int i = 0; i < size; i++) {
		if (_str[i] == '/')
			_str[i] = '\\';
	}
}

int Execute(const char* commandline)
{
	STARTUPINFO si;
	PROCESS_INFORMATION pi;

	ZeroMemory( &si, sizeof(si) );
	si.cb = sizeof(si);
	ZeroMemory( &pi, sizeof(pi) );

	// Start the child process. 
	if( !CreateProcess( NULL,   // No module name (use command line). 
		(LPSTR)commandline,				// Command line. 
		NULL,											// Process handle not inheritable. 
		NULL,										  // Thread handle not inheritable. 
		TRUE,											// Set handle inheritance to FALSE. 
		0,												// No creation flags. 
		NULL,            					// Use parent's environment block. 
		NULL,            					// Use parent's starting directory. 
		&si,             					// Pointer to STARTUPINFO structure.
		&pi )            					// Pointer to PROCESS_INFORMATION structure.
		) 
	{
		printf( "CreateProcess failed (%d).\n", GetLastError() );
		return -1;
	}

	// Wait until child process exits.
	WaitForSingleObject( pi.hProcess, INFINITE );
	return 0;
}

bool getCurrentProcessName(std::string& exeName)
{
  HANDLE hProcessSnap;
  PROCESSENTRY32 pe32;

  hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
  if(hProcessSnap == INVALID_HANDLE_VALUE)
  {
    std::cerr << "CreateToolhelp32Snapshot (of processes)" << std::endl;
    return false;
  }

  pe32.dwSize = sizeof(PROCESSENTRY32);

  if(!Process32First(hProcessSnap, &pe32))
  {
    std::cerr << "Process32First" << std::endl;
    CloseHandle(hProcessSnap);
    return false;
  }

  do
  {
		if (pe32.th32ProcessID == GetCurrentProcessId())
		{
			exeName = pe32.szExeFile;
			return true;
		}
  } while(Process32Next(hProcessSnap, &pe32));

  CloseHandle(hProcessSnap);
	return false;
}

bool sameProcessExist()
{
	std::string exeName;
	getCurrentProcessName(exeName);
  HANDLE hProcessSnap;
  PROCESSENTRY32 pe32;

  hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
  if(hProcessSnap == INVALID_HANDLE_VALUE)
  {
    std::cerr << "CreateToolhelp32Snapshot (of processes)" << std::endl;
    return false;
  }

  pe32.dwSize = sizeof(PROCESSENTRY32);

  if(!Process32First(hProcessSnap, &pe32))
  {
    std::cerr << "Process32First" << std::endl;
    CloseHandle(hProcessSnap);
    return false;
  }

  do
  {
    std::string processName(pe32.szExeFile);
    if (processName == exeName)
    {
			if (pe32.th32ProcessID != GetCurrentProcessId())
				return true;
    }
  } while(Process32Next(hProcessSnap, &pe32));

  CloseHandle(hProcessSnap);
	return false;
}

int main(int argc, char **argv)
{
	bool restartPok3d = (argc == 2) &&  (strcmp(argv[1], "--restart") == 0);
  bool showConsole = (argc == 2) &&  (strcmp(argv[1], "--console") == 0);

	char pathOfExec[512];
	GetCurrentDirectory(511, pathOfExec);
#ifdef _DEBUG
  if (strstr(pathOfExec, "bin-pok3d") == NULL)
  {
    MessageBox(GetForegroundWindow(), "change working directory of pok3dwin32 to 'bin-pok3d/ConfigurationName'", "bad working directory", 0);
    return -1;
  }
#endif

	Py_Initialize();

	char py_path[4096];
	strcpy(py_path, Py_GetPath());
	strcat(py_path, "..\\..\\Python;..\\..\\Python\\Lib;..\\..\\Python\\Lib\\site-packages;..\\..\\Python\\Lib\\site-packages\\win32;..\\..\\Python\\Lib\\site-packages\\win32\\lib;..\\..\\Python\\DLLs;..\\..\\Python\\Lib\\xml;..\\..\\python\\Lib\\site-packages\\libxmlmods;..\\..\\python\\Lib\\site-packages\\twisted;..\\..\\python\\Lib\\site-packages\\underware");
	strcat(py_path, ";..\\..\\..\\underware\\Python");
	PySys_SetPath(py_path);

	SetEnvironmentVariable("CYGWIN_MISMATCH_OK", "1");

	//
	// all paths relative to the Poker's interface execution directory
	if (! SetEnvironmentVariable("PANGO_RC_FILE", "conf/pangorc")) {
		//std::cout << "SetEnvironmentVariable for PANGO_RC_FILE failed ("<< GetLastError() << ")\n"; 
		return FALSE;
	}

	if (! SetEnvironmentVariable("FONTCONFIG_PATH", "conf")) {
		//std::cout << "SetEnvironmentVariable for FONTCONFIG_PATH failed ("<< GetLastError() << ")\n"; 
		return FALSE;
	}


	if (! SetEnvironmentVariable("GTK_PATH", "./")) {
		//std::cout << "SetEnvironmentVariable for GTK_PATH failed ("<< GetLastError() << ")\n"; 
		return FALSE;
	}


	if (! SetEnvironmentVariable("GDK_PIXBUF_MODULE_FILE", "conf/gdk-pixbuf.loaders")) {
		//std::cout << "SetEnvironmentVariable for GDK_PIXBUF_MODULE_FILE failed ("<< GetLastError() << ")\n"; 
		return FALSE;
	}

	int ret = Py_Main(argc, argv);
	return ret;
}
