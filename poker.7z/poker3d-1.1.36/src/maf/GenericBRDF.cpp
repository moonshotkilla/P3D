
#include <osgFX/GenericBRDF>
#include <osgFX/Registry>

#include <osg/VertexProgram>
#include <osg/FragmentProgram>

#include <osgUtil/CubeMapGenerator>

using namespace osgFX;

#ifndef NORMALIZE
#define NORMALIZE(a) "DP3 " #a ".w, " #a ", " #a ";\nRSQ " #a ".w, " #a ".w;\nMUL " #a ".xyz, " #a ".w, " #a ";\n"
#endif

namespace
{
    // register a prototype for this effect
	Registry::Proxy proxy(new GenericBRDF);

	class CubeMapGenerator : public osgUtil::CubeMapGenerator {
	public:

		CubeMapGenerator() : osgUtil::CubeMapGenerator(256)
		{
		}

		osg::Vec4 compute_color(const osg::Vec3 &_R) const
		{
			osg::Vec3f norm = _R / _R.length();
			norm *= 0.5f;
			norm += osg::Vec3(0.5f, 0.5f, 0.5f);
			return osg::Vec4(norm._v[0], norm._v[1], norm._v[2], norm._v[3]);
		}
	};

	class DefaultTechnique : public Technique {

		void getRequiredExtensions(std::vector<std::string> &extensions) const
		{
			extensions.push_back("GL_ARB_vertex_program");
			extensions.push_back("GL_ARB_fragment_program");
		}

		void define_passes()
		{
			char vp_code[] =
			"!!ARBvp1.0\n"\
			"ATTRIB	pos = vertex.position;\n"\
			"PARAM	mv[4] = { state.matrix.modelview };\n"\
			"PARAM	mvp[4] = { state.matrix.mvp };\n"\
			"PARAM	mvinv[4] = { state.matrix.modelview.invtrans };\n"\
			"TEMP	tmp, vtx;\n"\
			"# vertex to clip space\n"\
			"DP4	result.position.x, mvp[0], vertex.position;\n"\
			"DP4	result.position.y, mvp[1], vertex.position;\n"\
			"DP4	result.position.z, mvp[2], vertex.position;\n"\
			"DP4	result.position.w, mvp[3], vertex.position;\n"\
			"# local normal to eye space\n"\
			"DP3	result.texcoord[2].x, mvinv[0], vertex.normal;\n"\
			"DP3	result.texcoord[2].y, mvinv[1], vertex.normal;\n"\
			"DP3	result.texcoord[2].z, mvinv[2], vertex.normal;\n"\
			"# vertex to eye space\n"\
			"DP4	vtx.x, mv[0], vertex.position;\n"\
			"DP4	vtx.y, mv[1], vertex.position;\n"\
			"DP4	vtx.z, mv[2], vertex.position;\n"\
			"DP4	vtx.w, mv[3], vertex.position;\n"\
			"MOV	result.texcoord[4], -vtx;\n"\
			"# light to vertex vector\n"\
			"SUB	tmp, state.light[0].position, vtx;\n"\
			"MOV	result.texcoord[3], tmp;\n"\
			"# diffuse color\n"\
			"MOV	result.color, state.lightprod[0].diffuse;\n"\
			"# tex coords 0 & 1\n"\
			"MOV	result.texcoord[0], vertex.texcoord[0];\n"\
			"MOV	result.texcoord[1], vertex.texcoord[1];\n"\
			"\n"\
			"END\n";

			// (diffuse texture * brdf texture1) + (specular texture * brdf texture2)

			char fp_code[] = 
			"!!ARBfp1.0\n"\
			"TEMP	N, L, E, H, tex1, tex2, tex3, tex4, tmp;\n"\
			"MOV	N, fragment.texcoord[2];\n"\
			"MOV	L, fragment.texcoord[3];\n"\
			"MOV	E, fragment.texcoord[4];\n"\

			"TEX	N, N, texture[3], CUBE;\n"\
			"TEX	L, L, texture[3], CUBE;\n"\
			"TEX	E, E, texture[3], CUBE;\n"\
			"MAD	N, N, 2, -1;\n"\
			"MAD	L, L, 2, -1;\n"\
			"MAD	E, E, 2, -1;\n"\

			"DP3	tmp.x, N, L;\n"\
			"DP3	tmp.y, N, E;\n"\
			"MAD	tmp, tmp, 0.49, 0.5;\n"\

			"TXP	tex1, fragment.texcoord[0], texture[0], 2D;\n"\
			"TXP	tex2, fragment.texcoord[1], texture[1], 2D;\n"\
			"TEX	tex3, tmp, texture[2], 2D;\n"\
			"MUL	tex1, tex1, tex3;\n"\
			"MUL	tex2, tex2, tex3.w;\n"\
			"ADD	tmp, tex1, tex2;\n"\
			"MOV	tmp.w, 1;\n"\
			"MOV	result.color, tmp;\n"\
			"END\n";

			osg::ref_ptr<osg::StateSet> ss = new osg::StateSet;

			osg::ref_ptr<osg::VertexProgram> vp = new osg::VertexProgram;
      vp->setVertexProgram(vp_code);
      ss->setAttributeAndModes(vp.get());

			osg::ref_ptr<osg::FragmentProgram> fp = new osg::FragmentProgram;
      fp->setFragmentProgram(fp_code);
      ss->setAttributeAndModes(fp.get());

			CubeMapGenerator *cubeMapGen = new CubeMapGenerator();

			osg::TextureCubeMap *cubeMap = new osg::TextureCubeMap();
			cubeMap->setImage(osg::TextureCubeMap::POSITIVE_X, cubeMapGen->getImage( osg::TextureCubeMap::POSITIVE_X ) );
			cubeMap->setImage(osg::TextureCubeMap::NEGATIVE_X, cubeMapGen->getImage( osg::TextureCubeMap::NEGATIVE_X ) );
			cubeMap->setImage(osg::TextureCubeMap::POSITIVE_Y, cubeMapGen->getImage( osg::TextureCubeMap::POSITIVE_Y ) );
			cubeMap->setImage(osg::TextureCubeMap::NEGATIVE_Y, cubeMapGen->getImage( osg::TextureCubeMap::NEGATIVE_Y ) );
			cubeMap->setImage(osg::TextureCubeMap::POSITIVE_Z, cubeMapGen->getImage( osg::TextureCubeMap::POSITIVE_Z ) );
			cubeMap->setImage(osg::TextureCubeMap::NEGATIVE_Z, cubeMapGen->getImage( osg::TextureCubeMap::NEGATIVE_Z ) );

			cubeMap->setWrap(osg::Texture::WRAP_S, osg::Texture::CLAMP);
			cubeMap->setWrap(osg::Texture::WRAP_T, osg::Texture::CLAMP);
			cubeMap->setWrap(osg::Texture::WRAP_R, osg::Texture::CLAMP);

			cubeMap->setFilter(osg::Texture::MIN_FILTER, osg::Texture::NEAREST);
			cubeMap->setFilter(osg::Texture::MAG_FILTER, osg::Texture::NEAREST);

			cubeMapGen->generateMap(false);

			ss->setTextureAttributeAndModes(3, cubeMap, osg::StateAttribute::ON);

			addPass(ss.get());
		}
	};
}

GenericBRDF::GenericBRDF()
{
}

GenericBRDF::GenericBRDF(const GenericBRDF &copy, const osg::CopyOp &copyop) :
Effect(copy, copyop)
{
}

bool GenericBRDF::define_techniques()
{
	osgFX::Technique *tech = new DefaultTechnique();
	addTechnique(tech);
	return true;
}
