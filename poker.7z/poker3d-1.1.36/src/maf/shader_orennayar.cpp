/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <maf/shader_orennayar.h>

#include <osg/VertexProgram>
#include <osg/FragmentProgram>
#include <osg/StateSet>
#include <osg/Texture1D>
#include <osg/Texture2D>

#include <osgDB/WriteFile>

#endif

osg::Texture2D *g_sinTanTexture = NULL;

#ifndef MAX
#define MAX(a,b)    (((a) > (b)) ? (a) : (b))
#endif
#ifndef MIN
#define MIN(a,b)    (((a) < (b)) ? (a) : (b))
#endif

float* MAFShaderOrenNayar::generateSinTanLookup()
{
	float *table = new float[512*512];

	float *ptr = table;

	for (int j = 0; j < 512; j++) {
		for (int i = 0; i < 512; i++) {
			float theta_l = i / 512.0f;
			float theta_v = j / 512.0f;

			float a = acosf(theta_l);
			float b = acosf(theta_v);

			float alpha = MAX(a, b);
			float beta = MIN(a, b);

			float res = sinf(alpha) * tanf(beta);

			*ptr++ = res;
		}
	}

	/*
	float *start = table;
	for (int j = 0; j < 512; j++) {
		for (int i = 0; i < 512; i++) {
			float theta_l = i / 512.0f;
			float theta_v = j / 512.0f;

			float alpha = MAX(theta_l, theta_v);
			float beta = MIN(theta_l, theta_v);

			float res = sinf(acosf(alpha)) * tanf(acosf(beta));

			*ptr++ = res;
		}
	}
*/
	return table;
}

osg::Texture2D* MAFShaderOrenNayar::getSinTanTexture()
{
	if (!g_sinTanTexture) {
		float *table = generateSinTanLookup();
		osg::Image *img = new osg::Image();
		img->setImage(512, 512, 1, GL_LUMINANCE16F_ARB, GL_LUMINANCE, GL_FLOAT, (unsigned char*) table, osg::Image::USE_NEW_DELETE);
		//osgDB::writeImageFile(*img, "c:/oren.tga");

		g_sinTanTexture = new osg::Texture2D();
		g_sinTanTexture->setImage(img);
		g_sinTanTexture->setWrap( osg::Texture::WRAP_R, osg::Texture::CLAMP);
		g_sinTanTexture->setWrap( osg::Texture::WRAP_S, osg::Texture::CLAMP);
		g_sinTanTexture->setFilter(osg::Texture::MIN_FILTER, osg::Texture::NEAREST);
		g_sinTanTexture->setFilter(osg::Texture::MAG_FILTER, osg::Texture::NEAREST);
	}
	return g_sinTanTexture;
}


// OREN NAYAR

/*
vector OrenNayarDiffuse(
float3 light,
float3 view,
float3 norm,
float roughness)
{
float VdotN = dot(view, norm);
float LdotN = dot(light, norm);
float cos_theta_i = LdotN;
float theta_r = acos( VdotN );
float theta_i = acos( cos_theta_i );
float cos_phi_diff = dot( normalize(view - norm*VdotN), normalize(light - norm*LdotN) );
float alpha = max(theta_i, theta_r);
float beta = min(theta_i, theta_r);
float sigma2 = roughness*roughness;
float A = 1.0 - 0.5 * sigma2/(sigma2+0.33);
float B = 0.45 * sigma2/(sigma2+0.09);

if (cos_phi_diff >= 0)
B *= sin(alpha) * tan(beta);
else
B *= 0;

return cos_theta_i * (A + B);
}

roughness defines the roughness of the surface
0 means for total diffusion of the light on the surface and so is just a simple Lambert
A and B are constant for a given roughness and so can be precalculated and passed as shader constant

*/



char MAFVP_ORENNAYAR[] =
"!!ARBvp1.0\n"\
"ATTRIB	pos = vertex.position;\n"\
"PARAM	mv[4] = { state.matrix.modelview };\n"\
"PARAM	mvp[4] = { state.matrix.mvp };\n"\
"PARAM	mvinv[4] = { state.matrix.modelview.invtrans };\n"\
"TEMP	tmp, vtx;\n"\
"# vertex to clip space\n"\
"DP4	result.position.x, mvp[0], vertex.position;\n"\
"DP4	result.position.y, mvp[1], vertex.position;\n"\
"DP4	result.position.z, mvp[2], vertex.position;\n"\
"DP4	result.position.w, mvp[3], vertex.position;\n"\
"# local normal to eye space\n"\
"DP3	result.texcoord[3].x, mvinv[0], vertex.normal;\n"\
"DP3	result.texcoord[3].y, mvinv[1], vertex.normal;\n"\
"DP3	result.texcoord[3].z, mvinv[2], vertex.normal;\n"\
"# vertex to eye space\n"\
"DP4	vtx.x, mv[0], vertex.position;\n"\
"DP4	vtx.y, mv[1], vertex.position;\n"\
"DP4	vtx.z, mv[2], vertex.position;\n"\
"DP4	vtx.w, mv[3], vertex.position;\n"\
"# light to vertex vector\n"\
"SUB	tmp, state.light[0].position, vtx;\n"\
"MOV	result.texcoord[4], tmp;\n"\
"MOV	result.texcoord[5], -vtx;\n"\
"# diffuse color\n"\
"MOV	result.color, state.lightprod[0].diffuse;\n"\
"# tex coords 0&1\n"\
"MOV	result.texcoord[0], vertex.texcoord[0];\n"\
"MOV	result.texcoord[1], vertex.texcoord[1];\n"\
"\n"\
"END\n";


char MAFFP_ORENNAYAR[] = 
"!!ARBfp1.0\n"\
"TEMP	norm, light, view, VdotN, LdotN, tmp, tmp2, theta_r, theta_i, cos_phi_diff, alpha, beta, A, B;\n"\
"PARAM	AB = program.local[0];\n"\
"MOV	norm, fragment.texcoord[3];\n"\
MAFSHADER_NORMALIZE(norm)
"MOV	light, fragment.texcoord[4];\n"\
MAFSHADER_NORMALIZE(light)
"MOV	view, fragment.texcoord[5];\n"\
MAFSHADER_NORMALIZE(view)
"DP3	VdotN.x, view, norm;\n"\
"DP3	LdotN.x, light, norm;\n"\

"MUL	tmp.xyz, norm, VdotN.x;\n"\
"SUB	tmp.xyz, view, tmp;\n"\
MAFSHADER_NORMALIZE(tmp)
"MUL	tmp2.xyz, norm, LdotN.x;\n"\
"SUB	tmp2.xyz, light, tmp2;\n"\
MAFSHADER_NORMALIZE(tmp2)
"DP3_SAT	cos_phi_diff.x, tmp, tmp2;\n"\

"MOV	tmp.x, VdotN.x;\n"\
"MAD	tmp.x, tmp.x, 0.5, 0.5;\n"\
"TEX	theta_r.x, tmp.x, texture[2], 1D;\n"\

"MOV	tmp.x, LdotN.x;\n"\
"MAD	tmp.x, tmp.x, 0.5, 0.5;\n"\
"TEX	theta_i.x, tmp.x, texture[2], 1D;\n"\

"MAX	alpha.x, theta_i.x, theta_r.x;\n"\
"MIN	beta.x, theta_i.x, theta_r.x;\n"\

"SCS	tmp, beta.x;\n"\
"RCP	tmp.x, tmp.x;\n"\
"MUL	tmp.x, tmp.x, tmp.y;\n"\
"SIN	tmp.y, alpha.x;\n"\

"MOV	A, AB.x;\n"\
"MOV	B, AB.y;\n"\
/*
"MUL	B.x, B.x, cos_phi_diff.x;\n"\
*/
"MUL	B.x, B.x, tmp.x;\n"\
"MUL	B.x, B.x, tmp.y;\n"\
/*
"ADD	B.x, B.x, A.x;\n"\
"MAX	LdotN.x, LdotN.x, 0;\n"\
"MUL	LdotN.x, LdotN.x, B.x;\n"\
*/
"MUL	result.color, B.x, 1.0;\n"\
"END\n";


char MAFFP_ORENNAYAR2[] = 
"!!ARBfp1.0\n"\
"TEMP	norm, light, view, VdotN, LdotN, tmp, tmp2, sintan, cos_phi_diff, A, B;\n"\
"PARAM	AB = program.local[0];\n"\
"MOV	norm, fragment.texcoord[3];\n"\
MAFSHADER_NORMALIZE(norm)
"MOV	light, fragment.texcoord[4];\n"\
MAFSHADER_NORMALIZE(light)
"MOV	view, fragment.texcoord[5];\n"\
MAFSHADER_NORMALIZE(view)
"DP3	VdotN.x, view, norm;\n"\
"DP3	LdotN.x, light, norm;\n"\

"MUL	tmp.xyz, norm, VdotN.x;\n"\
"SUB	tmp.xyz, view, tmp;\n"\
MAFSHADER_NORMALIZE(tmp)
"MUL	tmp2.xyz, norm, LdotN.x;\n"\
"SUB	tmp2.xyz, light, tmp2;\n"\
MAFSHADER_NORMALIZE(tmp2)
"DP3_SAT	cos_phi_diff.x, tmp, tmp2;\n"\

"MOV_SAT	tmp.x, LdotN.x;\n"\
"MOV_SAT	tmp.y, VdotN.x;\n"\
"TEX	sintan, tmp, texture[2], 2D;\n"\

"MOV	A, AB.x;\n"\
"MOV	B, AB.y;\n"\

"MUL	B.x, B.x, cos_phi_diff.x;\n"\
"MUL	B.x, B.x, sintan.x;\n"\
"ADD	B.x, B.x, A.x;\n"\

"MAX	LdotN.x, LdotN.x, 0;\n"\
"MUL	LdotN.x, LdotN.x, B.x;\n"\

/*
"TXP	tmp, fragment.texcoord[0], texture[0], 2D;\n"\
"TXP	tmp2, fragment.texcoord[1], texture[1], 2D;\n"\
"MUL	tmp2, tmp2, 2;\n"\
"MUL	tmp, tmp, tmp2;\n"\
*/
"MUL	result.color, LdotN.x, 1;\n"\
"END\n";


MAFShaderOrenNayar::MAFShaderOrenNayar()
{
	vp_->setVertexProgram(MAFVP_ORENNAYAR);
	fp_->setFragmentProgram(MAFFP_ORENNAYAR2);
	fp_->setProgramLocalParameter(0, osg::Vec4f(1, 0, 0, 0) );
}

MAFShaderOrenNayar::~MAFShaderOrenNayar()
{
}

void MAFShaderOrenNayar::setRoughness(float _roughness)
{
	float sigma2 = _roughness*_roughness;
	float A = 1.0 - 0.5 * sigma2/(sigma2+0.33);
	float B = 0.45 * sigma2/(sigma2+0.09);

	fp_->setProgramLocalParameter(0, osg::Vec4f(A, B, 0, 0) );
}

void MAFShaderOrenNayar::writeProgramToDisk(const char *_vertex_file, const char *_fragment_file)
{
	Parent::writeProgramToDisk(_vertex_file, _fragment_file, MAFVP_ORENNAYAR, MAFFP_ORENNAYAR);
}

void MAFShaderOrenNayar::configureStateSet(osg::StateSet &_ss)
{
	Parent::configureStateSet(_ss);

	osg::Texture2D *texture = getSinTanTexture();
	//osg::Texture1D *texture = MAFShader::getAcosTexture();
	_ss.setTextureAttributeAndModes(2, texture, osg::StateAttribute::ON);
}
