/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Vincent Caron <zerodeux@gnu.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif // HAVE_CONFIG_H

#ifdef USE_NPROFILE
#include <nprofile/profile.h>
#else  //USE_NPROFILE
#define NPROFILE_SAMPLE(a)
#endif //USE_NPROFILE
#include <maf/maferror.h>
#include <maf/window.h>
#include <maf/scene.h>
#include <maf/application.h>
#endif //MAF_USE_VS_PCH

#include <sstream>

MAFWindow::MAFWindow() : mSurface(0), mFullScreen(true), mWidth(1024), mHeight(768), mOpenGL(false)
{
}

MAFWindow::~MAFWindow()
{
  SDL_Quit();
}

void MAFWindow::SwapBuffers()
{
  if(mOpenGL)
    SDL_GL_SwapBuffers();
  else
    SDL_Flip(mSurface);
}

void MAFWindow::SetCaption(const std::string& Caption)
{
  SDL_WM_SetCaption(Caption.c_str(), NULL);
}


bool MAFWindow::AddView(MAFView* pView)
{
  mViews.push_back(pView);

  return true;
}

bool MAFWindow::DelView(MAFView* pView)
{
  mViews.remove(pView);

  return true;
}

void MAFWindow::Render()
{
  NPROFILE_SAMPLE("MAFWindow::Render");
  MAFApplication::mbAgain--;

  if (!MAFApplication::mbVisible || MAFApplication::mbAgain > 0)
    return;

  ViewList::iterator i;

  for (i = mViews.begin(); i != mViews.end(); ++i) {
    MAFView *view = (*i);
    view->Update(this);
  }

  {
    SwapBuffers();
  }
}

std::string getOpenGLErrorString()
{
  std::ostringstream oss;
  oss << "Your graphic card or its driver may be to old to run Pok3d." << std::endl;
  oss << "First try upgrading to the latest driver from your graphic card's manufacturer then reboot your computer." << std::endl;
  oss << "If this message persists, please report your card's name in the technical support forum for Pok3d." << std::endl;
  return oss.str();
}

#ifdef WIN32
#include <windows.h>

bool MAFWindow::Init(SDL_Surface *iconWindow)
{
	if(mSurface == 0) {
		if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_NOPARACHUTE) != 0)
			throw new MAFError(UNDERWARE_MAF_ERROR_SDLINIT, "MAFWindow::Init: SDL_Init: %s\n", SDL_GetError ());

		SDL_EnableUNICODE(1);
		SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY, SDL_DEFAULT_REPEAT_INTERVAL);
	}

	/* Let's get some video information. */
	const SDL_VideoInfo* info = SDL_GetVideoInfo( );
	if(!info)
		throw new MAFError(UNDERWARE_MAF_ERROR_SDLINIT, "MAFWindow::Init: SDL_GetVideoInfo: %s\n", SDL_GetError ());

	/* If a dimension is given a zero size, we use either the screen
	* dimension if fullscreen is required (prevent nasty frequency
	* switch on CRTs), or either use half of the dimension screen in
	* window'ed mode.
	*/

	/* We get the bpp we will request from
	* the display. On X11, VidMode can't change
	* resolution, so this is probably being overly
	* safe. Under Win32, ChangeDisplaySettings
	* can change the bpp.
	*/
	int bpp = info->vfmt->BitsPerPixel;
	if (mFullScreen) bpp = 32;

	if(mWidth == 0 || mHeight == 0) {
		g_warning("width or height equal to zero, revert to default 1024x768");
		mWidth = 1024;
		mHeight = 768;
	}

	int flags = mFullScreen ? SDL_FULLSCREEN : 0;
	if(mOpenGL) {
		flags |= SDL_OPENGL;
		SDL_GL_SetAttribute( SDL_GL_DEPTH_SIZE, 24 );
		SDL_GL_SetAttribute( SDL_GL_STENCIL_SIZE, 8 );
		SDL_GL_SetAttribute( SDL_GL_DOUBLEBUFFER, 1 );
		if (bpp == 32)
			SDL_GL_SetAttribute( SDL_GL_ALPHA_SIZE, 8 );
	}
	else {
		flags |= SDL_DOUBLEBUF;
	}

	SDL_Surface* surface;

	{
		SDL_Rect **modes;
		int i;

		/* Get available fullscreen/hardware modes */
		modes = SDL_ListModes(info->vfmt, flags);

		/*
		* Check is there are any modes available
		* and set width x height to the maximum available.
		*/
		int nearestWidth = 0;
		int nearestHeight = 0;
		bool found = mFullScreen ? false : true;
		float nearestDisplay = FLT_MAX;

		if(modes != (SDL_Rect **)0 && modes != (SDL_Rect **)-1) {
			g_debug("Available video modes (%d bpp)", info->vfmt->BitsPerPixel);
			for(i = 0; modes[i] != 0; i++) {
				int w = modes[i]->w;
				int h = modes[i]->h;
				if (mWidth == w && mHeight == h) {
					found = true;
					break;
				}
				float dist = fabs(float(mWidth * mHeight - w*h));
				if (dist < nearestDisplay) {
					nearestDisplay = dist;
					nearestWidth = w;
					nearestHeight = h;
				}

				g_debug("  %d x %d", w, h);
			}
		}

		/*
		* If there are no video modes matching the desired width /
		* height, chose the largest one.
		*/
		if(!found) {
			g_debug("desired video mode %dx%d not available, revert to %dx%d", mWidth, mHeight, nearestWidth, nearestHeight);
			mWidth = nearestWidth;
			mHeight = nearestHeight;
		}
	}

	if (iconWindow)
		SDL_WM_SetIcon(iconWindow, NULL);

	surface = SDL_SetVideoMode(mWidth, mHeight, bpp, flags);
	if(surface == 0 && bpp == 32) {
		bpp = 24;
		g_debug("Video with 32 bpp not available, revert to 24 bpp");
		surface = SDL_SetVideoMode(mWidth, mHeight, bpp, flags);
	}
	if(surface == 0 && bpp == 24) {
		g_debug("Video with 24 bpp not available, revert to 16 bpp");
		bpp = 16;
		surface = SDL_SetVideoMode(mWidth, mHeight, bpp, flags);
	}

	if(surface == 0)
		/* This could happen for a variety of reasons,
		* including DISPLAY not being set, the specified
		* resolution not being available, etc.
		*/
		throw new MAFError(UNDERWARE_MAF_ERROR_SDLINIT, "MAFWindow::Init: SDL_SetVideoMode: %s\n", SDL_GetError ());


	if (surface && mOpenGL) {
		int i[6];
		SDL_GL_GetAttribute(SDL_GL_RED_SIZE, &i[0]);
		SDL_GL_GetAttribute(SDL_GL_GREEN_SIZE, &i[1]);
		SDL_GL_GetAttribute(SDL_GL_BLUE_SIZE, &i[2]);
		SDL_GL_GetAttribute(SDL_GL_ALPHA_SIZE, &i[5]);
		SDL_GL_GetAttribute(SDL_GL_DEPTH_SIZE, &i[3]);
		SDL_GL_GetAttribute(SDL_GL_DOUBLEBUFFER, &i[4]);
		const char* version = (const char*)glGetString(GL_VERSION);

		g_debug("GL red %d green %d blue %d alpha %d",i[0],i[1],i[2],i[5]);
		g_debug("GL zbuffer %d double buffer activated %d",i[3],i[4]);
		g_debug("GL version %s",version);
		g_debug("GL extensions %s",glGetString(GL_EXTENSIONS));
		g_debug("GL renderer %s",glGetString(GL_RENDERER));
		g_debug("GL vendor %s",glGetString(GL_VENDOR));

		std::string v(version);
		std::string::size_type versionMajorDot = v.find(".");
		if (versionMajorDot == std::string::npos) {
			std::stringstream str;
			str << "Problem with your opengl version (" << v << ") be sure to have your driver up to date.";
			SDL_Quit();
			MessageBox(0, str.str().c_str() , "Pok3d - Error", MB_OK | MB_ICONINFORMATION);
			throw new MAFError(UNDERWARE_MAF_ERROR_SDLINIT, "MAFWindow::Init: Problem with the opengl version: %s\n", version);
		}

		int major = atoi(v.substr(0,versionMajorDot).c_str());
		int minor = 0;
		std::string::size_type versionMinorDot = v.find_first_of(".",versionMajorDot+1);
		if (versionMinorDot == std::string::npos) // no release number like 1.2.1
			// number like 1.2 or 2.0
			minor = atoi(v.substr(versionMajorDot).c_str());
		else
			minor = atoi(v.substr(versionMajorDot+1,versionMinorDot-versionMajorDot-1).c_str());
		if (major < 2 && minor < 3) {
			std::string str;
			str = getOpenGLErrorString();
			g_debug ("You have to upgrade your opengl driver or hardware. You need at least opengl version 1.3 and you have %s", version);
			SDL_Quit();
			MessageBox(0, str.c_str(), "Pok3d - Error", MB_OK | MB_ICONINFORMATION);
			throw new MAFError(UNDERWARE_MAF_ERROR_SDLINIT, "MAFWindow::Init: You need at least opengl version 1.3 and you have: %s\n", version);
		}
	}

	mWidth = surface->w;
	mHeight = surface->h;

	mSurface = surface;
	return true;
}

#else
bool MAFWindow::Init(SDL_Surface *iconWindow)
{
  if(mSurface == 0) {
    if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_NOPARACHUTE) != 0)
      throw new MAFError(UNDERWARE_MAF_ERROR_SDLINIT, "MAFWindow::Init: SDL_Init: %s\n", SDL_GetError ());

    SDL_EnableUNICODE(1);
    SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY, SDL_DEFAULT_REPEAT_INTERVAL);
  }

  /* Let's get some video information. */
  const SDL_VideoInfo* info = SDL_GetVideoInfo( );
  if(!info)
    throw new MAFError(UNDERWARE_MAF_ERROR_SDLINIT, "MAFWindow::Init: SDL_GetVideoInfo: %s\n", SDL_GetError ());

  /* If a dimension is given a zero size, we use either the screen
   * dimension if fullscreen is required (prevent nasty frequency
   * switch on CRTs), or either use half of the dimension screen in
   * window'ed mode.
   */

  /* We get the bpp we will request from
   * the display. On X11, VidMode can't change
   * resolution, so this is probably being overly
   * safe. Under Win32, ChangeDisplaySettings
   * can change the bpp.
   */
  int bpp = info->vfmt->BitsPerPixel > 24 ? 24 : info->vfmt->BitsPerPixel;
  if (mFullScreen) bpp = 24;
  if (bpp == 16)
	  g_error("Screen color depth must have at least 24 bits.");

  if(mWidth == 0 || mHeight == 0) {
    g_warning("width or height equal to zero, revert to default 1024x768");
    mWidth = 1024;
    mHeight = 768;
  }
  int flags = mFullScreen ? SDL_FULLSCREEN : 0; //SDL_RESIZABLE;
  if(mOpenGL) {
    flags |= SDL_OPENGL;

    /* Now, we want to setup our requested
     * window attributes for our OpenGL window.
     * We want *at least* 5 bits of red, green
     * and blue. We also want at least a 16-bit
     * depth buffer.
     *
     * The last thing we do is request a double
     * buffered window. '1' turns on double
     * buffering, '0' turns it off.
     *
     * Note that we do not use SDL_DOUBLEBUF in
     * the flags to SDL_SetVideoMode. That does
     * not affect the GL attribute state, only
     * the standard 2D blitting setup.
     */
	SDL_GL_SetAttribute( SDL_GL_RED_SIZE, 8 );
	SDL_GL_SetAttribute( SDL_GL_GREEN_SIZE, 8 );
	SDL_GL_SetAttribute( SDL_GL_BLUE_SIZE, 8 );
	SDL_GL_SetAttribute( SDL_GL_ALPHA_SIZE, 8 );
	//SDL_GL_SetAttribute( SDL_GL_BUFFER_SIZE, bpp );
	SDL_GL_SetAttribute( SDL_GL_DEPTH_SIZE, 24 );

	SDL_GL_SetAttribute( SDL_GL_STENCIL_SIZE, 8 );
	SDL_GL_SetAttribute( SDL_GL_DOUBLEBUFFER, 1 );
  } else {
    flags |= SDL_DOUBLEBUF;
  }

  SDL_Surface* surface;

  {
    SDL_Rect **modes;
    int i;

    /* Get available fullscreen/hardware modes */
    modes = SDL_ListModes(info->vfmt, flags);

    /*
     * Check is there are any modes available
     * and set width x height to the maximum available.
     */
    int maxWidth = 0;
    int maxHeight = 0;
    bool found = mFullScreen ? false : true;

		if(modes != (SDL_Rect **)0 && modes != (SDL_Rect **)-1) {
      g_debug("Available video modes (%d bpp)", info->vfmt->BitsPerPixel);
      for(i = 0; modes[i] != 0; i++) {
				if(mWidth == modes[i]->w && mHeight == modes[i]->h)
					found = true;
				g_debug("  %d x %d", modes[i]->w, modes[i]->h);
				if(maxWidth < modes[i]->w) {
					maxWidth = modes[i]->w;
					maxHeight = modes[i]->h;
				}
      }
    }

    /*
     * If there are no video modes matching the desired width /
     * height, chose the largest one.
     */
    if(!found) {
      g_debug("desired video mode %dx%d not available, revert to %dx%d", mWidth, mHeight, maxWidth, maxHeight);
      mWidth = maxWidth;
      mHeight = maxHeight;
    }
  }

	if (iconWindow)
		SDL_WM_SetIcon(iconWindow, NULL);

  surface = SDL_SetVideoMode(mWidth, mHeight, bpp, flags);
  /// this code can't be executed !!!!
  if(surface == 0 && bpp > 24 && (surface = SDL_SetVideoMode(mWidth, mHeight, bpp, flags)) == 0) {
    g_debug("Video with 32 bpp not available, revert to 24 bpp");
    SDL_GL_SetAttribute( SDL_GL_DEPTH_SIZE, 24 );
    surface = SDL_SetVideoMode(mWidth, mHeight, bpp, flags);
  }
  /// end dead code

  if(surface == 0 && bpp > 16 && (surface = SDL_SetVideoMode(mWidth, mHeight, bpp, flags)) == 0) {
    g_debug("Video with 24 bpp not available, revert to 16 bpp");
    SDL_GL_SetAttribute( SDL_GL_DEPTH_SIZE, 16 );
    surface = SDL_SetVideoMode(mWidth, mHeight, bpp, flags);
  }
  if(surface == 0)
    /* This could happen for a variety of reasons,
     * including DISPLAY not being set, the specified
     * resolution not being available, etc.
     */
    throw new MAFError(UNDERWARE_MAF_ERROR_SDLINIT, "MAFWindow::Init: SDL_SetVideoMode: %s\n", SDL_GetError ());


  if (surface && mOpenGL) {
    int i[6] ;
  	SDL_GL_GetAttribute(SDL_GL_RED_SIZE, &i[0]);
   	SDL_GL_GetAttribute(SDL_GL_GREEN_SIZE, &i[1]);
   	SDL_GL_GetAttribute(SDL_GL_BLUE_SIZE, &i[2]);
   	SDL_GL_GetAttribute(SDL_GL_ALPHA_SIZE, &i[5]);
   	SDL_GL_GetAttribute(SDL_GL_DEPTH_SIZE, &i[3]);
   	SDL_GL_GetAttribute(SDL_GL_DOUBLEBUFFER, &i[4]);
    const char* version = (const char*)glGetString(GL_VERSION);

    g_debug("GL red %d green %d blue %d alpha %d",i[0],i[1],i[2],i[5]);
    g_debug("GL zbuffer %d double buffer activated %d",i[3],i[4]);
    g_debug("GL version %s",version);
    g_debug("GL extensions %s",glGetString(GL_EXTENSIONS));
    g_debug("GL renderer %s",glGetString(GL_RENDERER));
    g_debug("GL vendor %s",glGetString(GL_VENDOR));

    std::string v(version);
    std::string::size_type versionMajorDot = v.find(".");
    if (versionMajorDot == std::string::npos)
	    throw new MAFError(UNDERWARE_MAF_ERROR_SDLINIT, "MAFWindow::Init: Problem with the opengl version: %s\n", version);
    int major = atoi(v.substr(0,versionMajorDot).c_str());
    int minor = 0;
    std::string::size_type versionMinorDot = v.find_first_of(".",versionMajorDot+1);
    if (versionMinorDot == std::string::npos) // no release number like 1.2.1
      // number like 1.2 or 2.0
      minor = atoi(v.substr(versionMajorDot).c_str());
    else
      minor = atoi(v.substr(versionMajorDot+1,versionMinorDot-versionMajorDot-1).c_str());
    if (major < 2 && minor < 3)
      g_debug ("You have to upgrade your opengl driver or hardware. You need at least opengl version 1.3 and you have %s", version);
  }

  mWidth = surface->w;
  mHeight = surface->h;

  mSurface = surface;
  return true;
}
#endif
