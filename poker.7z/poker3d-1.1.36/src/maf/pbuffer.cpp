/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*  Cedric Pinson <cpinson@freesheep.org>
*/

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <maf/pbuffer.h>
#include <glib.h>
#endif

#include <osg/GLExtensions>
#include <GL/gl.h>

#ifdef WIN32

WGLChoosePixelFormatProc wglChoosePixelFormatARB = NULL;
WGLCreatePBufferProc wglCreatePbufferARB = NULL;
WGLGetPBufferDCProc wglGetPbufferDCARB = NULL;
WGLReleasePBufferDCProc wglReleasePbufferDCARB = NULL;
WGLDestroyPBufferProc wglDestroyPbufferARB = NULL;
WGLQueryPBufferProc wglQueryPbufferARB = NULL;

MAFPBuffer::MAFPBuffer(int _width, int _height)
{
	width_ = _width;
	height_ = _height;

	hGLDC_ = NULL;
	hGLRC_ = NULL;

	hPB_ = NULL;
	hPBDC_ = NULL;
	hPBRC_ = NULL;
}

bool MAFPBuffer::_create()
{
	int attr[] =
	{
		WGL_SUPPORT_OPENGL_ARB, TRUE, // pbuffer will be used with gl
		WGL_DRAW_TO_PBUFFER_ARB, TRUE, // enable render to pbuffer
		WGL_RED_BITS_ARB, 8,
		WGL_GREEN_BITS_ARB, 8,
		WGL_BLUE_BITS_ARB, 8,
		WGL_ALPHA_BITS_ARB, 8,
		WGL_DEPTH_BITS_ARB, 24,
		WGL_STENCIL_BITS_ARB, 8, 
		0, 0
	};

	wglChoosePixelFormatARB = (WGLChoosePixelFormatProc) osg::getGLExtensionFuncPtr("wglChoosePixelFormatARB");
	if (!wglChoosePixelFormatARB)
		return false;

	wglCreatePbufferARB = (WGLCreatePBufferProc) osg::getGLExtensionFuncPtr("wglCreatePbufferARB");
	wglGetPbufferDCARB = (WGLGetPBufferDCProc) osg::getGLExtensionFuncPtr("wglGetPbufferDCARB");
	wglReleasePbufferDCARB = (WGLReleasePBufferDCProc) osg::getGLExtensionFuncPtr("wglReleasePbufferDCARB");
	wglDestroyPbufferARB = (WGLDestroyPBufferProc) osg::getGLExtensionFuncPtr("wglDestroyPbufferARB");
	wglQueryPbufferARB = (WGLQueryPBufferProc) osg::getGLExtensionFuncPtr("wglQueryPbufferARB");

	hGLDC_ = wglGetCurrentDC();
	hGLRC_ = wglGetCurrentContext();

	// choose a pixel format that meets our minimum requirements
	unsigned int count = 0;
	int pixelFormat;
	wglChoosePixelFormatARB(hGLDC_, (const int*)attr, NULL, 1, &pixelFormat, &count);

	if(count == 0)
		return false;

	int attribs[]=
	{
		WGL_PBUFFER_LARGEST_ARB, TRUE,
		0, 0
	};

	// allocate the pbuffer
	hPB_ = wglCreatePbufferARB(hGLDC_, pixelFormat, width_, height_, attribs);
	if (hPB_ == NULL)
		return false;

	hPBDC_ = wglGetPbufferDCARB(hPB_);
	if (hPBDC_ == NULL)
		return false;

	hPBRC_ = wglCreateContext(hPBDC_);
	if (hPBRC_ == NULL)
		return false;

	wglShareLists(hGLRC_, hPBRC_);

	// real size of our pbuffer
	wglQueryPbufferARB(hPB_, WGL_PBUFFER_WIDTH_ARB, &width_);
	wglQueryPbufferARB(hPB_, WGL_PBUFFER_HEIGHT_ARB, &height_);

	return true;
}

MAFPBuffer::~MAFPBuffer()
{
	_destroy();
}

void MAFPBuffer::_destroy()
{
	if (hPBRC_) {
		wglDeleteContext(hPBRC_);
		hPBRC_ = NULL;
	}

	if (hPB_ && hPBDC_) {
		wglReleasePbufferDCARB(hPB_, hPBDC_);
		hPB_ = NULL;
		hPBDC_ = NULL;
	}

	if (hPB_) {
		wglDestroyPbufferARB(hPB_);
		hPB_ = NULL;
	}

	wglMakeCurrent(hGLDC_, hGLRC_);
}

void MAFPBuffer::use()
{
	// make sure the pbuffer has been initialized
	if (hPB_ == NULL || hPBDC_ == NULL || hPBRC_ == NULL)
		return;

	// make sure we haven't lost our pbuffer due to a
	// display mode change
	int flag = 0;
	wglQueryPbufferARB(hPB_, WGL_PBUFFER_LOST_ARB, &flag);
	if (flag) {
		_destroy();
		_create();
	}

	wglMakeCurrent(hPBDC_, hPBRC_);

	glViewport(0, 0, width_, height_);

	glDrawBuffer(GL_FRONT);
	glReadBuffer(GL_FRONT);
}

void MAFPBuffer::release()
{
	// make sure the pbuffer has been initialized
	if (hPB_ == NULL || hPBDC_ == NULL || hPBRC_ == NULL)
		return;

	// make sure we haven't lost our pbuffer due to a
	// display mode change
	int flag = 0;
	wglQueryPbufferARB(hPB_, WGL_PBUFFER_LOST_ARB, &flag);
	if (flag) {
		_destroy();
		_create();
	}

	glFlush();
	wglMakeCurrent(hGLDC_, hGLRC_);
}


#else

#if 1
#include <GL/glx.h>

static bool checkGLerror(const char* str)
{
	GLenum err = glGetError();
	if (err != GL_NO_ERROR) {
		std::string error;
		switch (err) {
		case GL_INVALID_ENUM:
			error = "GL_INVALID_ENUM";
			break;
		case GL_INVALID_VALUE:
			error = "GL_INVALID_VALUE";
			break;
		case GL_INVALID_OPERATION:
			error = "GL_INVALID_OPERATION";
			break;
		case GL_STACK_OVERFLOW:
			error = "GL_STACK_OVERFLOW";
			break;
		case GL_STACK_UNDERFLOW:
			error = "GL_STACK_UNDERFLOW";
			break;
		case GL_OUT_OF_MEMORY:
			error = "GL_OUT_OF_MEMORY";
			break;
		}
		g_debug("MAFPBuffer::use GLerror %s - %s",error.c_str(),str);
		return false;
	}
	return true;
}

MAFPBuffer::MAFPBuffer(int _width, int _height)
{
	width_ = _width;
	height_ = _height;

	dpy = glXGetCurrentDisplay();
	if (!dpy) {
		g_debug("MAFPBuffer::MAFPBuffer warning current context is 0");
	}
	FBDC = glXGetCurrentDrawable();
	if (!FBDC) {
		g_debug("MAFPBuffer::MAFPBuffer warning current glx drawable is 0");
	}
		
	FBRC = glXGetCurrentContext();
	if (!FBRC) {
		g_debug("MAFPBuffer::MAFPBuffer warning current context is 0");
	}

	PBRC = 0;
	PBDC = 0;
}

bool MAFPBuffer::_create()
{
	int attr[] =
	{
	GLX_RENDER_TYPE, GLX_RGBA_BIT,
    GLX_DRAWABLE_TYPE, GLX_PBUFFER_BIT,
    GLX_RED_SIZE, 8,
    GLX_GREEN_SIZE, 8,
    GLX_BLUE_SIZE, 8,
    GLX_ALPHA_SIZE, 8,
    GLX_DEPTH_SIZE, 24,
    GLX_STENCIL_SIZE, 8,
    0, 0
	};

	// choose a pixel format that meets our minimum requirements
	int count = 0;

  if (!dpy)
    return false;

	GLXFBConfig *config = glXChooseFBConfig(dpy, 0, attr, &count);

	if (config == NULL || count == 0)
		return false;

	int attribs[] =
	{
	GLX_PRESERVED_CONTENTS, 1, // a preserves Pbuffer is requested
    GLX_PBUFFER_WIDTH, width_,
    GLX_PBUFFER_HEIGHT, height_,
    GLX_LARGEST_PBUFFER, 1,
    0,0
	};

	// allocate the pbuffer
	PBDC = glXCreatePbuffer(dpy, config[0], attribs);
	PBRC = glXCreateNewContext(dpy, config[0], GLX_RGBA_TYPE, FBRC, true);

	if (!PBRC) {
		glXDestroyPbuffer(dpy, PBDC);
		return false;
	}

	XFree(config);

	return true;
}

MAFPBuffer::~MAFPBuffer()
{
	_destroy();
}

void MAFPBuffer::_destroy()
{
  if (!dpy)
    return;

	if (!glXMakeCurrent(dpy, FBDC, FBRC)) {
		g_error("MAFPBuffer::release glXMakeCurrent return false for dpy %p , framebuffer %ld , framebuffer context %p",dpy, FBDC, FBRC);
		return;
	}

	if (dpy && PBRC) {
		glXDestroyContext(dpy, PBRC);
		dpy = NULL;
		PBRC = NULL;
	}

	if (dpy && PBDC) {
		glXDestroyPbuffer(dpy, PBDC);
		dpy = NULL;
		PBDC = 0;
	}
}

void MAFPBuffer::use()
{
	// make sure the pbuffer has been initialized
	if (!PBRC  || !PBDC)
		return;

	// resize view port. generally you'll want to set this to the
	// size of your pbuffer so that you render to the entire pbuffer
	// but there are cases where you might want to render to just a
	// sub-region of the pbuffer.
	if (!glXMakeCurrent(dpy, PBDC, PBRC)) {
		g_error("MAFPBuffer::use glXMakeCurrent return false for dpy %p , pbuffer %ld , pbuffer context %p",dpy, PBDC, PBRC);
		return;
	}

	// be sure to be ok
	if (!checkGLerror("before glViewport"))
		return;
	glViewport(0, 0, width_, height_);
	if (!checkGLerror("after glViewport"))
		return;

	glDrawBuffer(GL_FRONT);
	if (!checkGLerror("after glDrawBuffer(GL_FRONT)"))
		return;
	glReadBuffer(GL_FRONT);
	if (!checkGLerror("after glReadBuffer(GL_FRONT)"))
		return;

	return;
}

void MAFPBuffer::release()
{
	// make sure the pbuffer has been initialized
	if (PBRC == 0 || PBDC == 0)
		return;

	glFlush();

	if (!glXMakeCurrent(dpy, FBDC, FBRC)) {
		g_error("MAFPBuffer::release glXMakeCurrent return false for dpy %p, framebuffer %ld, framebuffer context %p",dpy, FBDC, FBRC);
		return;
	}
}
#else

void MAFPBuffer::use(){}
void MAFPBuffer::release(){}
MAFPBuffer::~MAFPBuffer(){}
void MAFPBuffer::destroy(){}
MAFPBuffer::MAFPBuffer(int width, int height) {}

#endif
#endif
