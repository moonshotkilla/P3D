/*
*
* Copyright (C) 2007 Loic Dachary <loic@dachary.org>
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <maf/shader_mosaic.h>

#include <osg/VertexProgram>
#include <osg/FragmentProgram>
#include <osg/Image>
#include <osg/Texture1D>
#include <osg/StateSet>
#include <osg/Version>
#endif

char MAFFP_MOSAIC[] = 
"!!ARBfp1.0\n"\
"TEMP	uv, tmp;\n"\
"TEX	uv.x, fragment.texcoord[0].x, texture[1], 1D;\n"\
"TEX	uv.y, fragment.texcoord[0].y, texture[1], 1D;\n"\
"TEX	tmp, uv, texture[0], 2D;\n"\
"MOV	result.color, tmp;\n"\
"END\n";

MAFShaderMosaic::MAFShaderMosaic() :
MAFShader(MAFSHADER_USE_FRAGMENT_PROGRAM)
{
	fp_->setFragmentProgram(MAFFP_MOSAIC);
	uvImage_ = NULL;
	uvTexture_ = NULL;
}

MAFShaderMosaic::~MAFShaderMosaic()
{
}

void MAFShaderMosaic::calculateUVTexture(int _step)
{
	if (_step < 1 || _step > 255)
		return;

	if (!uvImage_) {
		uvImage_ = new osg::Image();
		uvImage_->allocateImage(256, 1, 1, GL_LUMINANCE, GL_UNSIGNED_BYTE);
	}

	if (!uvTexture_) {
		uvTexture_ = new osg::Texture1D();
#if OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
		uvTexture_->setTextureSize(256);
#else // OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
		uvTexture_->setTextureWidth(256);
#endif // OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2

		uvTexture_->setFilter(osg::Texture::MIN_FILTER, osg::Texture::NEAREST);
		uvTexture_->setFilter(osg::Texture::MAG_FILTER, osg::Texture::NEAREST);
	}

	unsigned char *pixs = uvImage_->data();
	
	int pos = 0;
	int fw = (256 << 12) / _step;
	int count = 256;
	for (int i = 0; i < 256; i++) {
		pixs[i] = pos >> 12;

		count -= _step;
		if (count <= 0) {
			count += 256;
			pos += fw;
		}
	}

	uvTexture_->setImage(uvImage_);
}

void MAFShaderMosaic::writeProgramToDisk(const char *_vertex_file, const char *_fragment_file)
{
	Parent::writeProgramToDisk(NULL, _fragment_file, NULL, MAFFP_MOSAIC);
}

void MAFShaderMosaic::configureStateSet(osg::StateSet &_ss)
{
	_ss.setTextureAttributeAndModes(1, uvTexture_, osg::StateAttribute::ON);
	Parent::configureStateSet(_ss);
}
