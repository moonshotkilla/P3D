/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <iostream>
#include <maf/maferror.h>
#include <maf/application.h>
#include <maf/depthmask.h>
#include <maf/utils.h>

#include <osg/BlendFunc>
#include <osg/Group>
#include <osg/Geode>
#include <osg/Geometry>
#include <osg/Transform>
#include <cassert>

#endif

#ifdef WIN32
#ifndef snprintf
#define snprintf _snprintf
#endif
#endif

static int g_screenW = 0;
static int g_screenH = 0;

void MAFCreateNodePath(osg::Node *_src, osg::NodePath &_path, int _parentValidMask)
{
  assert(_src);
  osg::NodePath path;
  osg::Node *node = _src;
  while(node) {
    _path.push_back(node);

    int nbParents = node->getNumParents();
    if (!nbParents)
      break;

    osg::Node *child;

    child = node->getParent(0);
#if OPENSCENEGRAPH_VERSION >= 100
		if (std::string(child->className()) == std::string("CameraNode")) {
			child = 0;
			break;
		}
#endif
    node = child;
  }
	std::reverse(_path.begin(), _path.end());
}

osg::Matrix MAFComputeLocalToWorld(osg::Node *_src, int _parentValidMask, int _nodeMaskExclude, int _nodeMaskStop)
{
	static osg::NodePath path;
	path.resize(0);
	MAFCreateNodePath(_src, path, _parentValidMask);
	return osg::computeLocalToWorld(path);
}

osg::Node* GetNode(osg::Node* node, const std::string& name) {

  if(node->getName() == name)
    return node;
  
  if(node->asGroup()) {
    osg::Group* group = node->asGroup();
    for(unsigned int i = 0; i < group->getNumChildren(); i++) {
      osg::Node* found = GetNode(group->getChild(i), name);
      if(found)
				return found;
    }
  }
  return 0;
}

osg::Geode* GetGeode(osg::Node* node) {
  osg::Geode* geode = dynamic_cast<osg::Geode*>(node);
  if(geode != 0)
    return geode;
  
  if(node->asGroup()) {
    osg::Group* group = node->asGroup();
    for(unsigned int i = 0; i < group->getNumChildren(); i++) {
      osg::Geode* found = GetGeode(group->getChild(i));
      if(found)
	return found;
    }
  }
  return 0;
}

float MAFapprox_acos(float _x)
{
	float sq = sqrt(1.0f - _x);
	float e = 1.5707288f - 0.2121144f * _x;
	_x *= _x;
	e += 0.0742610f * _x;
	_x *= _x;
	e += 0.0187293f * _x;
	return sq * e;
}

float MAFapprox_asin(float _x)
{
	// FIXME: bug with negative values
	return MAFapprox_acos( sqrt(1.0f - _x*_x) );
}

void MAFInvertPremultipliedAlpha(osg::Image &_img)
{
	if (_img.getPixelFormat() != GL_RGBA)
		return;

	int w = _img.s();
	int h = _img.t();
	int size = w * h;

	unsigned char *pixs = _img.data();
	for (int i = 0; i < size; i++, pixs += 4) {
		int a = pixs[3];
		if (!a)
			continue;
		float fa = 255.0f / a;
		pixs[0] *= (unsigned char)fa;
		pixs[1] *= (unsigned char)fa;
		pixs[2] *= (unsigned char)fa;
	}
}

int MAFGetNearestHighPow2(int _size)
{
	int sizes[] = { 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 16384, 32768, 65536 };
	for (int i = 0; i < 16; i++) {
		int sz = sizes[i];
		if (_size <= sz)
			return sz;
	}
	return 0;
}

//

MAF_OSGQuad::MAF_OSGQuad(const std::string &_textureName,
												 bool _bInvertUV,
												 const osg::Vec2f &_minPt,
												 const osg::Vec2f &_maxPt,
												 const osg::Vec2f &_minUV,
												 const osg::Vec2f &_maxUV,
												 GLenum _srcBlendFactor,
												 GLenum _dstBlendFactor,
												 bool _bDisableWriteMask)
{
	geode_ = new osg::Geode();
	geom_ = new osg::Geometry();
	geode_->addDrawable(geom_.get());

	geode_->setCullingActive(false);

	vertices_ = new osg::Vec3Array();
	osg::Vec3Array *vert = vertices_.get();
	vert->resize(4);
	geom_->setVertexArray(vert);

	vert[0][0] = osg::Vec3f(_minPt._v[0], _minPt._v[1], 0.1f);
	vert[0][1] = osg::Vec3f(_maxPt._v[0], _minPt._v[1], 0.1f);
	vert[0][2] = osg::Vec3f(_maxPt._v[0], _maxPt._v[1], 0.1f);
	vert[0][3] = osg::Vec3f(_minPt._v[0], _maxPt._v[1], 0.1f);

	uv_ = new osg::Vec2Array();
	if (!_bInvertUV) {
		uv_->push_back( osg::Vec2f(_minUV._v[0], _minUV._v[1]) );
		uv_->push_back( osg::Vec2f(_maxUV._v[0], _minUV._v[1]) );
		uv_->push_back( osg::Vec2f(_maxUV._v[0], _maxUV._v[1]) );
		uv_->push_back( osg::Vec2f(_minUV._v[0], _maxUV._v[1]) );
	}
	else {
		uv_->push_back( osg::Vec2f(_minUV._v[0], _maxUV._v[1]) );
		uv_->push_back( osg::Vec2f(_maxUV._v[0], _maxUV._v[1]) );
		uv_->push_back( osg::Vec2f(_maxUV._v[0], _minUV._v[1]) );
		uv_->push_back( osg::Vec2f(_minUV._v[0], _minUV._v[1]) );
	}
	geom_->setTexCoordArray(0, uv_.get());

	GLushort index[6];
	index[0] = 0;
	index[1] = 1;
	index[2] = 2;
	index[3] = 0;
	index[4] = 2;
	index[5] = 3;

	geom_->addPrimitiveSet(new osg::DrawElementsUShort(osg::PrimitiveSet::TRIANGLES, 6, index));
	geom_->setUseDisplayList(false);
	geom_->setUseVertexBufferObjects(false);

	osg::StateSet *state = geom_->getOrCreateStateSet();
	material_ = new osg::Material;
	state->setAttributeAndModes(material_.get(), osg::StateAttribute::ON);
	state->setMode(GL_LIGHTING, osg::StateAttribute::OFF);
	state->setMode(GL_CULL_FACE, osg::StateAttribute::OFF);
	material_->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(1, 1, 1, 1) );

	texture_ = NULL;
	if (!_textureName.empty()) {
		texture_ = MAFApplication::GetTextureManager()->GetTexture2D(_textureName);
		state->setTextureAttributeAndModes(0, texture_.get(), osg::StateAttribute::ON);
		texture_->setFilter(osg::Texture2D::MIN_FILTER, osg::Texture2D::NEAREST);
		texture_->setFilter(osg::Texture2D::MAG_FILTER, osg::Texture2D::NEAREST);
	}

	osg::BlendFunc *bf = new osg::BlendFunc;
	bf->setFunction(_srcBlendFactor, _dstBlendFactor);
	state->setAttributeAndModes(bf, osg::StateAttribute::ON);

	if (_bDisableWriteMask) {
		DepthMask *dp = new DepthMask(false);
		state->setAttributeAndModes(dp, osg::StateAttribute::ON);
		state->setMode(GL_DEPTH_TEST, FALSE);
	}
}

MAF_OSGQuad::MAF_OSGQuad(MAF_OSGQuadParams &_params)
{
	geode_ = new osg::Geode();
	if (!_params.geomToUse)
		geom_ = new osg::Geometry();
	else
		geom_ = _params.geomToUse;

	geode_->addDrawable(geom_.get());
//	geode_->setCullingActive(false);

	vertices_ = new osg::Vec3Array();
	osg::Vec3Array *vert = vertices_.get();
	vert->resize(4);
	geom_->setVertexArray(vert);

	vert[0][0] = osg::Vec3f(_params.minPt._v[0], _params.minPt._v[1], _params.z);
	vert[0][1] = osg::Vec3f(_params.maxPt._v[0], _params.minPt._v[1], _params.z);
	vert[0][2] = osg::Vec3f(_params.maxPt._v[0], _params.maxPt._v[1], _params.z);
	vert[0][3] = osg::Vec3f(_params.minPt._v[0], _params.maxPt._v[1], _params.z);

	uv_ = new osg::Vec2Array();
	if (!_params.bInvertUV) {
		uv_->push_back( osg::Vec2f(_params.minUV._v[0], _params.minUV._v[1]) );
		uv_->push_back( osg::Vec2f(_params.maxUV._v[0], _params.minUV._v[1]) );
		uv_->push_back( osg::Vec2f(_params.maxUV._v[0], _params.maxUV._v[1]) );
		uv_->push_back( osg::Vec2f(_params.minUV._v[0], _params.maxUV._v[1]) );
	}
	else {
		uv_->push_back( osg::Vec2f(_params.minUV._v[0], _params.maxUV._v[1]) );
		uv_->push_back( osg::Vec2f(_params.maxUV._v[0], _params.maxUV._v[1]) );
		uv_->push_back( osg::Vec2f(_params.maxUV._v[0], _params.minUV._v[1]) );
		uv_->push_back( osg::Vec2f(_params.minUV._v[0], _params.minUV._v[1]) );
	}
	geom_->setTexCoordArray(0, uv_.get());

	GLushort index[4];
	index[0] = 0;
	index[1] = 1;
	index[2] = 2;
	index[3] = 3;

	//geom_->addPrimitiveSet(new osg::DrawElementsUShort(osg::PrimitiveSet::QUADS, 4, index));
	geom_->addPrimitiveSet(new osg::DrawArrays(GL_QUADS,0,4));
	geom_->setUseDisplayList(false);
	geom_->setUseVertexBufferObjects(false);

	osg::StateSet *state = geom_->getOrCreateStateSet();
	material_ = new osg::Material;
	state->setAttributeAndModes(material_.get(), osg::StateAttribute::ON);
	state->setMode(GL_LIGHTING, osg::StateAttribute::OFF);
	state->setMode(GL_CULL_FACE, osg::StateAttribute::OFF);
	material_->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(1, 1, 1, 1) );

	texture_ = NULL;
	if (!_params.textureName.empty()) {
		texture_ = MAFApplication::GetTextureManager()->GetTexture2D(_params.textureName);
		state->setTextureAttributeAndModes(0, texture_.get(), osg::StateAttribute::ON);
	}

	osg::BlendFunc *bf = new osg::BlendFunc;
	bf->setFunction(_params.srcBlendFactor, _params.dstBlendFactor);
	state->setAttributeAndModes(bf, osg::StateAttribute::ON);

	if (_params.bDisableWriteMask) {
		DepthMask *dp = new DepthMask(false);
		state->setAttributeAndModes(dp, osg::StateAttribute::ON);
		state->setMode(GL_DEPTH_TEST, FALSE);
	}
}


MAF_OSGQuad::~MAF_OSGQuad()
{
}

void MAF_OSGQuad::setVertexInWindowCoordinates(float _x, float _y, int _iVertex)
{
	g_assert(_iVertex < 4);
	float x = (_x / g_screenW) * 2 - 1;
	float y = -((_y / g_screenH) * 2 - 1);
	(*vertices_)[_iVertex][0] = x;
	(*vertices_)[_iVertex][1] = y;
}

void MAF_OSGQuad::setVertexInNormalisedCoordinates(float _x, float _y, int _iVertex)
{
	g_assert(_iVertex < 4);
	(*vertices_)[_iVertex][0] = _x;
	(*vertices_)[_iVertex][1] = _y;
}

void MAF_OSGQuad::setVertexInUnitCoordinates(float _x, float _y, int _iVertex)
{
	g_assert(_iVertex < 4);
	(*vertices_)[_iVertex][0] = _x * 2 - 1;
	(*vertices_)[_iVertex][1] = _y * 2 - 1;
}

void MAF_OSGQuad::setScreenResolution(int _w, int _h)
{
	g_screenW = _w;
	g_screenH = _h;
}

////////////////////////////////////////////////////////////////////////


void MAFRGBtoHSL(float _r, float _g, float _b, float *_h, float *_s, float *_l)
{
	float min, max, delta;

	min = MIN( (MIN(_r, _g)), _b);
	max = MAX( (MAX(_r, _g)), _b);
	*_l = max;

	delta = max - min;

	if (max != 0)
		*_s = delta / max;
	else {
		// r = g = b = 0		// s = 0, v is undefined
		*_s = 0;
		*_h = -1;
		return;
	}

	if (*_s == 0) {
		*_h = 0;
		return;
	}

	if (_r == max)
		*_h = (_g - _b) / delta;		// between yellow & magenta
	else if (_g == max)
		*_h = 2 + (_b - _r) / delta;	// between cyan & yellow
	else
		*_h = 4 + (_r - _g) / delta;	// between magenta & cyan

	*_h *= 60;				// degrees
	if (*_h < 0)
		*_h += 360;
}

void MAFHSLtoRGB(float _h, float _s, float _l, float *_r, float *_g, float *_b)
{
	int i;
	float f, p, q, t;

	if (_s == 0) {
		// achromatic (grey)
		*_r = *_g = *_b = _l;
		return;
	}

	_h /= 60;			// sector 0 to 5
	i = (int)floor(_h);
	f = _h - i;			// factorial part of h
	p = _l * (1 - _s);
	q = _l * (1 - _s * f);
	t = _l * (1 - _s * (1 - f) );

	switch (i) {

		case 0:
			*_r = _l;
			*_g = t;
			*_b = p;
			break;

		case 1:
			*_r = q;
			*_g = _l;
			*_b = p;
			break;

		case 2:
			*_r = p;
			*_g = _l;
			*_b = t;
			break;

		case 3:
			*_r = p;
			*_g = q;
			*_b = _l;
			break;

		case 4:
			*_r = t;
			*_g = p;
			*_b = _l;
			break;

		default:		// case 5:
			*_r = _l;
			*_g = p;
			*_b = q;
			break;
	}
}

const char* MAFXPath2Value(xmlXPathContextPtr _context, const char *_xpath)
{
	xmlXPathObjectPtr xpathObj;
	xmlNodeSetPtr nodes;

	xpathObj = xmlXPathEvalExpression((xmlChar*)_xpath, _context);
	nodes = xpathObj->nodesetval;
	if (nodes) {
		xmlNodePtr node = nodes->nodeTab[0];
		const char *value = (const char*)xmlNodeGetContent(node);
		return value;
	}
	return NULL;
}
