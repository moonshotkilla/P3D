/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <maf/shader_brdf.h>
#include <osg/VertexProgram>
#include <osg/FragmentProgram>
#include <osg/StateSet>
#include <osg/TextureCubeMap>
#endif

//
//
// BRDF
// Use both Vertex and Fragment Program
//

char MAFVP_BRDF[] =
"!!ARBvp1.0\n"\
"ATTRIB	pos = vertex.position;\n"\
"PARAM	mv[4] = { state.matrix.modelview };\n"\
"PARAM	mvp[4] = { state.matrix.mvp };\n"\
"PARAM	mvinv[4] = { state.matrix.modelview.invtrans };\n"\
"TEMP	tmp, vtx;\n"\
"# vertex to clip space\n"\
"DP4	result.position.x, mvp[0], vertex.position;\n"\
"DP4	result.position.y, mvp[1], vertex.position;\n"\
"DP4	result.position.z, mvp[2], vertex.position;\n"\
"DP4	result.position.w, mvp[3], vertex.position;\n"\
"# local normal to eye space\n"\
"DP3	result.texcoord[2].x, mvinv[0], vertex.normal;\n"\
"DP3	result.texcoord[2].y, mvinv[1], vertex.normal;\n"\
"DP3	result.texcoord[2].z, mvinv[2], vertex.normal;\n"\
"# vertex to eye space\n"\
"DP4	vtx.x, mv[0], vertex.position;\n"\
"DP4	vtx.y, mv[1], vertex.position;\n"\
"DP4	vtx.z, mv[2], vertex.position;\n"\
"DP4	vtx.w, mv[3], vertex.position;\n"\
"MOV	result.texcoord[4], -vtx;\n"\
"# light to vertex vector\n"\
"SUB	tmp, state.light[0].position, vtx;\n"\
"MOV	result.texcoord[3], tmp;\n"\
"# diffuse color\n"\
"MOV	result.color, state.lightprod[0].diffuse;\n"\
"# tex coords 0 & 1\n"\
"MOV	result.texcoord[0], vertex.texcoord[0];\n"\
"MOV	result.texcoord[1], vertex.texcoord[1];\n"\
"\n"\
"END\n";

// (diffuse texture * brdf texture1) + (specular texture * brdf texture2)

char MAFFP_BRDF[] = 
"!!ARBfp1.0\n"\
"TEMP	N, L, E, H, tex1, tex2, tex3, tmp;\n"\
"MOV	N, fragment.texcoord[2];\n"\
"MOV	L, fragment.texcoord[3];\n"\
"MOV	E, fragment.texcoord[4];\n"\

"TEX	N, N, texture[3], CUBE;\n"\
"TEX	L, L, texture[3], CUBE;\n"\
"TEX	E, E, texture[3], CUBE;\n"\
"MAD	N, N, 2, -1;\n"\
"MAD	L, L, 2, -1;\n"\
"MAD	E, E, 2, -1;\n"\

/*
MAFSHADER_NORMALIZE(N)
MAFSHADER_NORMALIZE(L)
MAFSHADER_NORMALIZE(E)
*/

"DP3	tmp.x, N, L;\n"\
"DP3	tmp.y, N, E;\n"\
"MAD	tmp, tmp, 0.49, 0.5;\n"\

"TXP	tex1, fragment.texcoord[0], texture[0], 2D;\n"\
"TXP	tex2, fragment.texcoord[1], texture[1], 2D;\n"\
"TEX	tex3, tmp, texture[2], 2D;\n"\
"MUL	tex1, tex1, tex3;\n"\
"MUL	tex2, tex2, tex3.w;\n"\
"ADD	tmp, tex1, tex2;\n"\
"MOV	tmp.w, 1;\n"\
"MOV	result.color, tmp;\n"\
"END\n";

MAFShaderBRDF::MAFShaderBRDF()
{
	vp_->setVertexProgram(MAFVP_BRDF);
	fp_->setFragmentProgram(MAFFP_BRDF);
}

MAFShaderBRDF::~MAFShaderBRDF()
{
}

void MAFShaderBRDF::writeProgramToDisk(const char *_vertex_file, const char *_fragment_file)
{
	Parent::writeProgramToDisk(_vertex_file, _fragment_file, MAFVP_BRDF, MAFFP_BRDF);
}

void MAFShaderBRDF::configureStateSet(osg::StateSet &_ss)
{
	Parent::configureStateSet(_ss);

	osg::TextureCubeMap *cubeMap = MAFShader::getCubeMapNormalize();
	_ss.setTextureAttributeAndModes(3, cubeMap, osg::StateAttribute::ON);
}
