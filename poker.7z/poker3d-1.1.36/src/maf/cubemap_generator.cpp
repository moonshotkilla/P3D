
#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <maf/cubemap_generator.h>
#endif

MAFCubeMapGenerator::MAFCubeMapGenerator(int texture_size) : osg::Referenced(),texture_size_(texture_size)
{
	for (int i = 0; i < 6; ++i) {
		osg::ref_ptr<osg::Image> image = new osg::Image;
		unsigned char* data = new unsigned char [texture_size*texture_size*3];
		image->setImage(texture_size, texture_size, 1, 3, GL_RGB, GL_UNSIGNED_BYTE, data, osg::Image::USE_NEW_DELETE);
		images_.push_back(image);
	}
}

MAFCubeMapGenerator::MAFCubeMapGenerator(const MAFCubeMapGenerator &copy, const osg::CopyOp &copyop) : osg::Referenced(copy),texture_size_(copy.texture_size_)
{
	Image_list::const_iterator i;
	for (i = copy.images_.begin(); i != copy.images_.end(); ++i) {
		images_.push_back(static_cast<osg::Image *>(copyop(i->get())));
	}
}

void MAFCubeMapGenerator::generateMap()
{
	const float dst = 2.0f / (texture_size_-1);
	float t = -1;

	osg::Matrix M;
	//M = osg::Matrix::rotate(osg::PI_2, osg::Vec3(1, 0, 0));	M = osg::Matrix::identity();
	for (int i = 0; i < texture_size_; ++i) {
		float s = -1;
		for (int j = 0; j < texture_size_; ++j) {
			set_pixel(0, j, i, compute_color( osg::Vec3(1, -t, -s)  * M));
			set_pixel(1, j, i, compute_color( osg::Vec3(-1, -t, s)  * M));
			set_pixel(2, j, i, compute_color( osg::Vec3(s, 1, t)    * M));
			set_pixel(3, j, i, compute_color( osg::Vec3(s, -1, -t)  * M));
			set_pixel(4, j, i, compute_color( osg::Vec3(s, -t, 1)   * M));
			set_pixel(5, j, i, compute_color( osg::Vec3(-s, -t, -1) * M));
			s += dst;
		}
		t += dst;
	}
}
