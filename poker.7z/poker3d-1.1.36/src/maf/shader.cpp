/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <osg/Image>
#include <osg/Texture1D>
#include <osg/Texture2D>
#include <osg/Vec3>
#include <osg/VertexProgram>
#include <osg/FragmentProgram>
#include <maf/shader.h>
#include <maf/shader_blinn.h>
#include <maf/shader_brdf.h>
#include <maf/shader_embm.h>
#include <maf/shader_mosaic.h>
#include <maf/shader_orennayar.h>
#include <maf/data.h>
#include <maf/cubemap_generator.h>

#include <math.h>
#endif

#define max(a,b)    (((a) > (b)) ? (a) : (b))
#define min(a,b)    (((a) < (b)) ? (a) : (b))

static osg::Texture1D *g_acosTexture = NULL;
static osg::Texture1D *g_asinTexture = NULL;
static MAFShader::TECHNIC_AUTHORISATION g_technicAuthorisation = MAFShader::TECHNIC_AUTHORISATION_VERTEXFRAGMENT_PROGRAM;
static osg::ref_ptr<osg::TextureCubeMap> g_cubeMap;

MAFShader::MAFShader(int _VPflags)
{
	vp_ = NULL;
	fp_ = NULL;

	if (_VPflags & 1)
		vp_ = new MAFVertexProgram(this);
	if (_VPflags & 2)
		fp_ = new MAFFragmentProgram(this);
}

MAFShader::~MAFShader()
{
}

void MAFShader::init()
{
}

MAFShader::TECHNIC_AUTHORISATION MAFShader::getTechnicAuthorisation()
{
	return g_technicAuthorisation;
}

void MAFShader::setTechnicAuthorisation(MAFShader::TECHNIC_AUTHORISATION _authorisation)
{
	g_technicAuthorisation = _authorisation;
}

void MAFShader::configureStateSet(osg::StateSet &_ss)
{
	if (vp_.valid())
		_ss.setAttributeAndModes(vp_.get(), osg::StateAttribute::ON);
	if (fp_.valid())
		_ss.setAttributeAndModes(fp_.get(), osg::StateAttribute::ON);
}

void MAFShader::writeProgramToDisk(const char *vertex_file, const char *fragment_file, const char *vp, const char *fp)
{
	FILE *f;

	if (vertex_file) {
		f = fopen(vertex_file, "w");
		if (f) {
			fwrite(vp, 1, strlen(vp), f);
			fclose(f);
		}
	}

	if (fragment_file) {
		f = fopen(fragment_file, "w");
		if (f) {
			fwrite(fp, 1, strlen(fp), f);
			fclose(f);
		}
	}
}


osg::Texture1D* MAFShader::getAcosTexture()
{
	if (!g_acosTexture) {
		float *table = generateAcosLookup();
		osg::Image *img = new osg::Image();
		img->setImage(1024, 1, 1, GL_LUMINANCE16F_ARB, GL_LUMINANCE, GL_FLOAT, (unsigned char*) table, osg::Image::USE_NEW_DELETE);
		g_acosTexture = new osg::Texture1D();
		//g_acosTexture->setInternalFormatMode(osg::Texture::USE_USER_DEFINED_FORMAT);
		g_acosTexture->setImage(img);

		g_acosTexture->setWrap( osg::Texture::WRAP_R, osg::Texture::CLAMP);
	//	g_acosTexture->setBorderColor(osg::Vec4(0, 0, 0, 0) );
		g_acosTexture->setFilter(osg::Texture::MIN_FILTER, osg::Texture::NEAREST);
		g_acosTexture->setFilter(osg::Texture::MAG_FILTER, osg::Texture::NEAREST);
	}
	return g_acosTexture;
}

osg::Texture1D* MAFShader::getAsinTexture()
{
	if (!g_asinTexture) {
		unsigned char *table = generateAsinLookup();
		osg::Image *img = new osg::Image();
		img->setImage(256, 1, 1, 1, GL_LUMINANCE, GL_UNSIGNED_BYTE, table, osg::Image::USE_NEW_DELETE);
		g_asinTexture = new osg::Texture1D();
		g_asinTexture->setImage(img);

		g_asinTexture->setFilter(osg::Texture::MIN_FILTER, osg::Texture::NEAREST);
		g_asinTexture->setFilter(osg::Texture::MAG_FILTER, osg::Texture::NEAREST);
	}
	return g_asinTexture;
}

float* MAFShader::generateAcosLookup()
{
	float *table = new float[1024];
	for (int i = 0; i < 1024; i++) {
		float val = (i / 1024.0f);
		val = val * 2 - 1; // bias between -1 and 1
		float ac = acos(val);
		//ac *= M_1_PI;
		table[i] = ac;
	}

	//	float val = 0;
	//	float ac = acos(val);
	//	float t = (table[ int(val*511+512) ] / 255.0f) * M_PI;

	return table;
}

unsigned char* MAFShader::generateAsinLookup()
{
	unsigned char *table = new unsigned char[256];
	for (int i = 0; i < 256; i++) {
		float val = (i / 256.0f);
		val = val * 2 - 1; // bias between -1 and 1
		float ac = asin(val);
		ac += M_PI_2;
		ac *= M_1_PI;
		table[i] = (unsigned char)(ac * 255.0f);
	}

        //	float val = -0.987654;
        //	float ac = asin(val);
	//float t = (table[ int(val*511+512) ] / 255.0f) * M_PI - M_PI_2;

        //	float t = (table[ int(val*127+128) ] / 255.0f) * M_PI - M_PI_2;

	return table;
}

class CubeMapGenerator : public MAFCubeMapGenerator {
public:

	CubeMapGenerator() : MAFCubeMapGenerator(128)
	{
	}

	osg::Vec3 compute_color(const osg::Vec3 &_R) const
	{
		osg::Vec3f norm = _R / _R.length();
		norm *= 0.5f;
		norm += osg::Vec3(0.5f, 0.5f, 0.5f);
		return norm;
	}
};

osg::TextureCubeMap* MAFShader::getCubeMapNormalize()
{
	if (g_cubeMap == NULL) {
		osg::ref_ptr<CubeMapGenerator> cubeMapGen = new CubeMapGenerator();
		cubeMapGen = new CubeMapGenerator();

		g_cubeMap = new osg::TextureCubeMap();

		g_cubeMap->setImage(osg::TextureCubeMap::POSITIVE_X, cubeMapGen->getImage( osg::TextureCubeMap::POSITIVE_X ) );
		g_cubeMap->setImage(osg::TextureCubeMap::NEGATIVE_X, cubeMapGen->getImage( osg::TextureCubeMap::NEGATIVE_X ) );
		g_cubeMap->setImage(osg::TextureCubeMap::POSITIVE_Y, cubeMapGen->getImage( osg::TextureCubeMap::POSITIVE_Y ) );
		g_cubeMap->setImage(osg::TextureCubeMap::NEGATIVE_Y, cubeMapGen->getImage( osg::TextureCubeMap::NEGATIVE_Y ) );
		g_cubeMap->setImage(osg::TextureCubeMap::POSITIVE_Z, cubeMapGen->getImage( osg::TextureCubeMap::POSITIVE_Z ) );
		g_cubeMap->setImage(osg::TextureCubeMap::NEGATIVE_Z, cubeMapGen->getImage( osg::TextureCubeMap::NEGATIVE_Z ) );

		g_cubeMap->setWrap(osg::Texture::WRAP_S, osg::Texture::CLAMP);
		g_cubeMap->setWrap(osg::Texture::WRAP_T, osg::Texture::CLAMP);
		g_cubeMap->setWrap(osg::Texture::WRAP_R, osg::Texture::CLAMP);

		g_cubeMap->setFilter(osg::Texture::MIN_FILTER, osg::Texture::NEAREST);
		g_cubeMap->setFilter(osg::Texture::MAG_FILTER, osg::Texture::NEAREST);

		cubeMapGen->generateMap();
	}

	return g_cubeMap.get();
}

bool MAFShader::isVertexProgramSupported()
{
		osg::VertexProgram::Extensions *ext = osg::VertexProgram::getExtensions(0, true);
		return ext->isVertexProgramSupported();
}

bool MAFShader::isFragmentProgramSupported()
{
		osg::FragmentProgram::Extensions *ext = osg::FragmentProgram::getExtensions(0, true);
		return ext->isFragmentProgramSupported();
}



//
//
// TEXTURE1 * DIFFUSE + TEXTURE2 * SPECULAR
// Only fragment program, vertex still use FFP
//

char MAFFP_TEX1xDIFFUSE_ADD_TEX2xSPECULAR[] = 
"!!ARBfp1.0\n"\
"TEMP	tmp, tmp2;\n"\
"TXP	tmp, fragment.texcoord[0], texture[0], 2D;\n"\
"TXP	tmp2, fragment.texcoord[1], texture[1], 2D;\n"\
"MUL	tmp, tmp, fragment.color.primary;\n"\
"MUL	tmp2, tmp2, fragment.color.secondary;\n"\
"ADD	tmp, tmp, tmp2;\n"\
"MOV	result.color, tmp;\n"\
"\n"\
"END\n";








//
//
// SHADOW BLUR
//
/*
char MAFVP_SHADOW[] =
"!!ARBvp1.0\n"\
"PARAM	mv[4] = { state.matrix.modelview };\n"\
"PARAM	mvp[4] = { state.matrix.mvp };\n"\
"PARAM	mvinv[4] = { state.matrix.modelview.invtrans };\n"\
"PARAM	texgenS = state.texgen[1].eye.s;\n"\
"PARAM	texgenT = state.texgen[1].eye.t;\n"\
"PARAM	texgenR = state.texgen[1].eye.r;\n"\
"PARAM	texgenQ = state.texgen[1].eye.q;\n"\
"PARAM	texmat[4] = {state.matrix.texture[1]};\n"\
"TEMP	vertcoords, texcoords;\n"\
"DP4	result.position.x, mvp[0], vertex.position;\n"\
"DP4	result.position.y, mvp[1], vertex.position;\n"\
"DP4	result.position.z, mvp[2], vertex.position;\n"\
"DP4	result.position.w, mvp[3], vertex.position;\n"\
"DP4	vertcoords.x, mv[0], vertex.position;\n"\
"DP4	vertcoords.y, mv[1], vertex.position;\n"\
"DP4	vertcoords.z, mv[2], vertex.position;\n"\
"DP4	vertcoords.w, mv[3], vertex.position;\n"\
"DP4	texcoords.x, texgenS, vertcoords;\n"\
"DP4	texcoords.y, texgenT, vertcoords;\n"\
"DP4	texcoords.z, texgenR, vertcoords;\n"\
"DP4	texcoords.w, texgenQ, vertcoords;\n"\
"DP4	result.texcoord[1].x, texmat[0], texcoords;\n"\
"DP4	result.texcoord[1].y, texmat[1], texcoords;\n"\
"DP4	result.texcoord[1].z, texmat[2], texcoords;\n"\
"DP4	result.texcoord[1].w, texmat[3], texcoords;\n"\
"MOV	result.texcoord[0], vertex.texcoord[0];\n"\
"END\n";
*/

/*
char MAFFP_SHADOW[] = 
"!!ARBfp1.0\n"\
"OPTION ARB_fragment_program_shadow;\n"\
"TEMP	tmp;\n"\
"TEX	tmp.x, fragment.texcoord[1], texture[1], SHADOW2D;\n"\
"END\n";
*/

char MAFFP_SHADOW[] = 
"!!ARBfp1.0\n"\
"TEMP	tmp, tmp2, col, uv;\n"\
"MOV	uv, fragment.texcoord[1];\n"\
"RCP	uv.w, uv.w;\n"\
"MUL	uv.xyz, uv, uv.w;\n"\
"ADD	uv, uv, 1;\n"\
"MUL	uv, uv, 0.5;\n"\
"TEX	col, fragment.texcoord[0], texture[0], 2D;\n"\
"TEX	tmp, uv, texture[1], 2D;\n"\
"SGE	tmp2.x, tmp.x, fragment.texcoord[1].z;\n"\
"MUL	col, col, tmp2.x;\n"\
"MOV	result.color, col;\n"\
"END\n";



bool MAFShader::get(MAFShaderType _type, MAFShader **_shader)
{
	switch(_type) {

	case MAFSHADERTYPE_BLINN:
		*_shader = new MAFShaderBlinn();
		break;

	case MAFSHADERTYPE_BRDF:
		*_shader = new MAFShaderBRDF();
		break;

	case MAFSHADERTYPE_EMBM:
		*_shader = new MAFShaderEMBM();
		break;

	case MAFSHADERTYPE_ORENNAYAR:
		*_shader = new MAFShaderOrenNayar();
		break;

	case MAFSHADERTYPE_MOSAIC:
		*_shader = new MAFShaderMosaic();
		break;

	default:
		return false;
	};

	return true;
}
