/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <maf/StdAfx.h>

#ifndef USE_VS_PCH
#include <osg/Matrix>

#include <maf/flyingitem.h>
#endif

void MAFFlyingItem::goForward(osg::Matrixf &_mat, float _step)
{
	_mat(3, 0) -= _mat(2, 0) * _step;
	_mat(3, 1) -= _mat(2, 1) * _step;
	_mat(3, 2) -= _mat(2, 2) * _step;
}

void MAFFlyingItem::goBackward(osg::Matrixf &_mat, float _step)
{
	_mat(3, 0) += _mat(2, 0) * _step;
	_mat(3, 1) += _mat(2, 1) * _step;
	_mat(3, 2) += _mat(2, 2) * _step;
}

void MAFFlyingItem::goLeft(osg::Matrixf &_mat, float _step)
{
	_mat(3, 0) -= _mat(0, 0) * _step;
	_mat(3, 1) -= _mat(0, 1) * _step;
	_mat(3, 2) -= _mat(0, 2) * _step;
}

void MAFFlyingItem::goRight(osg::Matrixf &_mat, float _step)
{
	_mat(3, 0) += _mat(0, 0) * _step;
	_mat(3, 1) += _mat(0, 1) * _step;
	_mat(3, 2) += _mat(0, 2) * _step;
}

void MAFFlyingItem::goUp(osg::Matrixf &_mat, float _step)
{
	_mat(3, 0) += _mat(1, 0) * _step;
	_mat(3, 1) += _mat(1, 1) * _step;
	_mat(3, 2) += _mat(1, 2) * _step;
}

void MAFFlyingItem::goDown(osg::Matrixf &_mat, float _step)
{
	_mat(3, 0) -= _mat(1, 0) * _step;
	_mat(3, 1) -= _mat(1, 1) * _step;
	_mat(3, 2) -= _mat(1, 2) * _step;
}
