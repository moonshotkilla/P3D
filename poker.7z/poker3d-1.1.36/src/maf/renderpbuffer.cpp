/*
*
* Copyright (C) 2007 Loic Dachary <loic@dachary.org>
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <maf/renderpbuffer.h>
#include <maf/pbuffer.h>
#endif

RenderPBuffer::RenderPBuffer()
{
	pbuffer_ = NULL;
}

RenderPBuffer::~RenderPBuffer()
{
}

void RenderPBuffer::reset()
{
	RenderStage::reset();
}

#if OSG_VERSION_MAJOR != 2
void RenderPBuffer::draw(osg::State& arg, osgUtil::RenderLeaf*& previous)
#else // OSG_VERSION_MAJOR != 2
void RenderPBuffer::draw(osg::RenderInfo& arg, osgUtil::RenderLeaf*& previous)
#endif  // OSG_VERSION_MAJOR != 2
{
	if (_stageDrawnThisFrame)
		return;

	if (!pbuffer_) {
		pbuffer_ = new MAFPBuffer(2048, 2048);
		//setViewport( osg::Viewport(0, 0, 
	}

	//cout << "begining RTTS draw "<<this<< "  "<<_viewport->x()<<","<< _viewport->y()<<","<< _viewport->width()<<","<< _viewport->height()<<std::endl;

	pbuffer_->use();

	RenderStage::draw(arg,previous);
/*
	float *pixs = new float[256*256];
	char *out = new char[256*256*3];
	int depthScale, depthBias;
	glGetIntegerv(GL_DEPTH_SCALE, &depthScale);
	glGetIntegerv(GL_DEPTH_BIAS, &depthBias);

	glReadPixels(_viewport->x(),_viewport->y(),_viewport->width(),_viewport->height(), GL_DEPTH_COMPONENT, GL_FLOAT, pixs);
	int j = 0;
	for (int i = 0; i < 256*256; i++) {
		float p = pixs[i];
		int rgb = 0;
		if (p == 1.0f)
			rgb = 255;

		out[j++] = rgb;
		out[j++] = rgb;
		out[j++] = rgb;
	}

	FILE *f = fopen("c:/test.raw", "wb");
	fwrite(out, 1, 256*256*3, f);
	fclose(f);

	delete [] pixs;
	delete [] out;
*/
	// now copy the rendered image to attached texture.
	if (_texture.valid())
	{
		//cout << "        reading "<<this<< "  "<<_viewport->x()<<","<< _viewport->y()<<","<< _viewport->width()<<","<< _viewport->height()<<std::endl;

#if OSG_VERSION_MAJOR != 2
		_texture->copyTexImage2D(arg,_viewport->x(),_viewport->y(),_viewport->width(),_viewport->height());
#else // OSG_VERSION_MAJOR != 2
		_texture->copyTexImage2D(*arg.getState(),_viewport->x(),_viewport->y(),_viewport->width(),_viewport->height());
#endif  // OSG_VERSION_MAJOR != 2
	}

	if (_image.valid())
		_image->readPixels(_viewport->x(),_viewport->y(),_viewport->width(),_viewport->height(),GL_RGBA,GL_UNSIGNED_BYTE);

	pbuffer_->release();
}
