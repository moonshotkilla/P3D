/*
 *
 * Copyright (C) 2007 Loic Dachary <loic@dachary.org>
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <maf/billboard.h>
#include <osg/Version>
#include <osg/AutoTransform>
#include <osg/CullStack>
#endif

MAFBillBoard::MAFBillBoard() :
        _bActive(true),
	_matrixDirty(true)
{
}

MAFBillBoard::MAFBillBoard(const MAFBillBoard &pat, const osg::CopyOp &copyop) :
	Transform(pat,copyop),
	_bActive(true),
	_matrixDirty(true)
{
}

bool MAFBillBoard::computeLocalToWorldMatrix(osg::Matrix& matrix, osg::NodeVisitor* nv) const
{
//	if (_matrixDirty)
		computeMatrix();

	if (_referenceFrame == RELATIVE_RF) {
		matrix.preMult(_cachedMatrix);
	}
	else {
		// absolute
		matrix = _cachedMatrix;
	}

	return true;
}

bool MAFBillBoard::computeWorldToLocalMatrix(osg::Matrix & matrix, osg::NodeVisitor*) const
{
	return true;
}

void MAFBillBoard::computeMatrix() const
{
//	if (!_matrixDirty)
	//	return;

	 if (_bActive == false) {
		 _cachedMatrix.makeIdentity();
	 }

	_matrixDirty = false;
}

void MAFBillBoard::accept(osg::NodeVisitor & nv)
{
   _matrixDirty = true;

	 osg::NodeVisitor::VisitorType vt = nv.getVisitorType();
	 if (vt == osg::NodeVisitor::CULL_VISITOR && _bActive == true) {
		osg::CullStack *cs = dynamic_cast<osg::CullStack*>(&nv);

#if OSG_VERSION_MAJOR != 2
		osg::RefMatrix &rm = cs->getModelViewMatrix();
#else // OSG_VERSION_MAJOR != 2
		const osg::RefMatrix &rm = *cs->getModelViewMatrix();
#endif  // OSG_VERSION_MAJOR != 2
		osg::Matrix mat;
		mat(0, 0) = rm(0, 0);
		mat(1, 0) = rm(1, 0);
		mat(2, 0) = rm(2, 0);
		mat(0, 1) = rm(0, 1);
		mat(1, 1) = rm(1, 1);
		mat(2, 1) = rm(2, 1);
		mat(0, 2) = rm(0, 2);
		mat(1, 2) = rm(1, 2);
		mat(2, 2) = rm(2, 2);

		mat = osg::Matrix::inverse(mat);

		_cachedMatrix(0, 0) = mat(0, 0);
		_cachedMatrix(1, 0) = mat(1, 0);
		_cachedMatrix(2, 0) = mat(2, 0);

		_cachedMatrix(0, 1) = mat(0, 1);
		_cachedMatrix(1, 1) = mat(1, 1);
		_cachedMatrix(2, 1) = mat(2, 1);

		_cachedMatrix(0, 2) = mat(0, 2);
		_cachedMatrix(1, 2) = mat(1, 2);
		_cachedMatrix(2, 2) = mat(2, 2);
	}

	 // now do the proper accept
	Transform::accept(nv);
}
