/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <maf/emboss.h>
#include <math.h>
#endif

void MAFEmbossXYZ(	const char *_grayScaleImage,
					int _w, int _h,
					float *_output,
					float _width45)
{
	_output += _w * 3;
	for (int y = 1; y < _h-1; y++) {

		const char *s1 = _grayScaleImage + 1;
		const char *s2 = s1 + _w;
		const char *s3 = s2 + _w;

		_output += 3;

		for (int x = 1; x < _w-1; x++) {
			int nx = (s1[-1] + s2[-1] + s3[-1] - s1[1] - s2[1] - s3[1]);
			int ny = (s3[-1] + s3[0] + s3[1] - s1[-1] - s1[0] - s1[1]);
			float nz = _width45;

			float invDist = 1 / sqrtf(nx*nx + ny*ny + nz*nz);

			*_output++ = nx * invDist;
			*_output++ = ny * invDist;
			*_output++ = nz * invDist;

			s1++;
			s2++;
			s3++;
		}

		_grayScaleImage += _w;
		_output += 3;
	}
}


void MAFEmbossRGB(const unsigned char *_grayScaleImage,
				  int _w, int _h,
				  unsigned char *_output,
				  float _width45)
{
	_output += _w * 3;
	_grayScaleImage += _w;

	for (int y = 1; y < _h-1; y++) {

		const unsigned char *s2 = _grayScaleImage + 1;
		const unsigned char *s1 = s2 + _w;
		const unsigned char *s3 = s2 - _w;

		_output += 3;

		for (int x = 1; x < _w-1; x++) {
			float nx = (s1[-1] + s2[-1] + s3[-1] - s1[1] - s2[1] - s3[1]);
			float ny = (s3[-1] + s3[0] + s3[1] - s1[-1] - s1[0] - s1[1]);
			float nz = _width45;

			float invDist = 1 / sqrtf(nx*nx + ny*ny + nz*nz);

			nx *= invDist;
			ny *= invDist;
			nz *= invDist;

			unsigned char R = int( nx * 127.0f + 127.0f );
			unsigned char G = int( ny * 127.0f + 127.0f );
			unsigned char B = int( nz * 127.0f + 127.0f );

			*_output++ = R;
			*_output++ = G;
			*_output++ = B;

			s1++;
			s2++;
			s3++;
		}

		_grayScaleImage += _w;
		_output += 3;
	}
}


void MAFNVEmbossRGB(const unsigned char *_grayScaleImage,
				  int _w, int _h,
				  unsigned char *_output,
				  float _width45)
{
	_output += _w * 3;
	_grayScaleImage += _w;

	for (int y = 1; y < _h-1; y++) {

		const unsigned char *s2 = _grayScaleImage + 1;
		const unsigned char *s1 = s2 - _w;
		const unsigned char *s3 = s2 + _w;

		_output += 3;

		for (int x = 1; x < _w-1; x++) {

			int v00 = s2[0]; // Get the current pixel
			int v01 = s2[1]; // and the pixel to the right
			int vM1 = s2[-1]; // and the pixel to the left
			int v10 = s3[0]; // and the pixel one line below.
			int v1M = s1[0]; // and the pixel one line above.

			int iDu = (vM1-v01); // The delta-u bump value
			int iDv = (v1M-v10); // The delta-v bump value

			if ( (v00 < vM1) && (v00 < v01) )  // If we are at valley
			{
				iDu = vM1-v00;                 // Choose greater of 1st order diffs
				if ( iDu < v00-v01 ) iDu = v00-v01;
			}

			iDu >>= 1;
			iDv >>= 1;
			iDu += 127;
			iDv += 127;

			if (iDu < 0) iDu = 0;
			else if (iDu > 255) iDu = 255;

			if (iDv < 0) iDv = 0;
			else if (iDv > 255) iDv = 255;

			*_output++ = iDu;
			*_output++ = iDv;
			*_output++ = 0;

			s1++;
			s2++;
			s3++;
		}

		_grayScaleImage += _w;
		_output += 3;
	}
}
