/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <maf/imglayers_flatten.h>

#include <osg/Image>
#include <osg/Texture2D>
#endif

MAFImageLayersFlatten::MAFImageLayersFlatten(int _width, int _height)
{
	texture_ = new osg::Texture2D();
	finalImage_ = new osg::Image();

	width_ = _width;
	height_ = _height;

	imgData_ = (unsigned char*) malloc(width_*height_*4);
	finalImage_->setImage(width_, height_, 1, 4, GL_RGBA, GL_BYTE, (unsigned char*) imgData_, osg::Image::USE_MALLOC_FREE);
	texture_->setImage(finalImage_.get());
}

MAFImageLayersFlatten::~MAFImageLayersFlatten()
{
}

void MAFImageLayersFlatten::updateTexture()
{
	int nbLayers = layers_.size();

	if (nbLayers == 0)
		return;

	Layer &firstLayer = layers_[0];
	memcpy(imgData_, firstLayer.img_->data(), width_*height_*4);

	for (int i = 1; i < nbLayers; i++) {
		Layer &layer = layers_[i];

		PIXELOP pixelOp = layer.pixelOp_;

		unsigned char *A = (unsigned char*) imgData_;
		unsigned char *B = layer.img_->data();

		switch(pixelOp) {

			case PIXELOP_NORMAL:
				applyNormalMode(A, B, layer);
				break;

			case PIXELOP_OVERLAY:
				applyOverlayMode(A, B, layer);
				break;

			case PIXELOP_LINEARDODGE:
				applyLinearDodgeMode(A, B, layer);
				break;

			case PIXELOP_MULTIPLY:
				applyMultiplyMode(A, B, layer);
				break;

			default:
				break;
		};

	}
}

void MAFImageLayersFlatten::writeFinalImageToDisk(const char *_fileName)
{
	FILE *file = fopen(_fileName, "wb");

	unsigned char *pixs = imgData_;
	for (int i = 0; i < width_*height_; i++) {
		fwrite(pixs, 3, 1, file);
		pixs += 4;
	}
	fclose(file);
}

void MAFImageLayersFlatten::applyNormalMode(unsigned char *_A, unsigned char *_B, Layer &_layer)
{
	for (int i = 0; i < width_*height_; i++) {
		int r0 = _A[0];
		int g0 = _A[1];
		int b0 = _A[2];

		int r1 = _B[0];
		int g1 = _B[1];
		int b1 = _B[2];
		int a1 = _B[3];

		float opacity = (_layer.opacity_ * a1) / 255.0f;
		float inv_opacity = 1 - opacity;

		_A[0] = r1 * opacity + r0 * inv_opacity;
		_A[1] = g1 * opacity + g0 * inv_opacity;
		_A[2] = b1 * opacity + b0 * inv_opacity;

		_A += 4;
		_B += 4;
	}
}

void MAFImageLayersFlatten::applyOverlayMode(unsigned char *_A, unsigned char *_B, Layer &_layer)
{
	for (int i = 0; i < width_*height_; i++) {
		int r0 = _A[0];
		int g0 = _A[1];
		int b0 = _A[2];

		int r1 = _B[0];
		int g1 = _B[1];
		int b1 = _B[2];
		int a1 = _B[3];

		float opacity = (_layer.opacity_ * a1) / 255.0f;
		float inv_opacity = 1 - opacity;

		int fr, fg, fb;

		if (r0 < 128) {
			fr = (r0 * r1) >> 7;
			if (fr > 255) fr = 255;
		}
		else {
			fr = 255 - ( ((255-r0) * (255-r1)) >> 7);
			if (fr < 0) fr = 0;
		}

		if (g0 < 128) {
			fg = (g0 * g1) >> 7;
			if (fg > 255) fg = 255;
		}
		else {
			fg = 255 - ( ((255-g0) * (255-g1)) >> 7);
			if (fg < 0) fg = 0;
		}

		if (b0 < 128) {
			fb = (b0 * b1) >> 7;
			if (fb > 255) fb = 255;
		}
		else {
			fb = 255 - ( ((255-b0) * (255-b1)) >> 7);
			if (fb < 0) fb = 0;
		}

		_A[0] = fr * opacity + r0 * inv_opacity;
		_A[1] = fg * opacity + g0 * inv_opacity;
		_A[2] = fb * opacity + b0 * inv_opacity;
/*
		_A[0] = r0 + r1;
		_A[1] = g0 + g1;
		_A[2] = b0 + b1;
*/
		_A += 4;
		_B += 4;
	}
}

void MAFImageLayersFlatten::applyLinearDodgeMode(unsigned char *_A, unsigned char *_B, Layer &_layer)
{
	for (int i = 0; i < width_*height_; i++) {
		int r0 = _A[0];
		int g0 = _A[1];
		int b0 = _A[2];

		int r1 = _B[0];
		int g1 = _B[1];
		int b1 = _B[2];
		int a1 = _B[3];

		float opacity = (_layer.opacity_ * a1) / 255.0f;
		float inv_opacity = 1 - opacity;

		int fr = r0 + r1;
		int fg = g0 + g1;
		int fb = b0 + b1;

		if (fr > 255) fr = 255;
		if (fg > 255) fg = 255;
		if (fb > 255) fb = 255;

		_A[0] = fr * opacity + r0 * inv_opacity;
		_A[1] = fg * opacity + g0 * inv_opacity;
		_A[2] = fb * opacity + b0 * inv_opacity;

		_A += 4;
		_B += 4;
	}
}

void MAFImageLayersFlatten::applyMultiplyMode(unsigned char *_A, unsigned char *_B, Layer &_layer)
{
	for (int i = 0; i < width_*height_; i++) {
		int r0 = _A[0];
		int g0 = _A[1];
		int b0 = _A[2];

		int r1 = _B[0];
		int g1 = _B[1];
		int b1 = _B[2];
		int a1 = _B[3];

		float opacity = (_layer.opacity_ * a1) / 255.0f;
		float inv_opacity = 1 - opacity;

		int fr = (r0 * r1) >> 8;
		int fg = (g0 * g1) >> 8;
		int fb = (b0 * b1) >> 8;

		_A[0] = fr * opacity + r0 * inv_opacity;
		_A[1] = fg * opacity + g0 * inv_opacity;
		_A[2] = fb * opacity + b0 * inv_opacity;

		_A += 4;
		_B += 4;
	}
}
