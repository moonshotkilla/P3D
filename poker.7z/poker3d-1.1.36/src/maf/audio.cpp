/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Vincent Caron <zerodeux@gnu.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 */

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <glib.h>

#include <maf/maferror.h>
#include <maf/audio.h>
#include <maf/scene.h>

#include <osgAL/SoundManager>
#include <osgAL/Version>

#endif

MAFAudioDevice* MAFAudioDevice::GetInstance()
{
	static MAFAudioDevice audioDevice;
	return &audioDevice;
}

MAFAudioDevice::MAFAudioDevice()
{
	mSoundEnabled = mSoundDeviceHaveTried = false;
}

MAFAudioDevice::~MAFAudioDevice()
{
}

void MAFAudioDevice::DeInitializeDevice() 
{
	osgAL::SoundManager::instance()->shutdown();
	mSoundDeviceHaveTried = false;
	mSoundEnabled = false;
}

bool MAFAudioDevice::IsSoundDeviceValid() const
{
	return osgAL::SoundManager::instance()->initialized();
}


void MAFAudioDevice::InitializeDevice() 
{
	mSoundDeviceHaveTried = true;
	try {
		osgAL::SoundManager::instance()->init(MAF_AUDIO_NB_CHANNELS);
		osgAL::SoundManager::instance()->getEnvironment()->setDistanceModel(openalpp::InverseDistance);
		osgAL::SoundManager::instance()->getEnvironment()->setGain(1.0);
	} catch (std::runtime_error &error) {
		g_critical("%s", error.what());
		g_critical("MAFSetSoundEnabled::Init can't create audio device with %d sources",MAF_AUDIO_NB_CHANNELS);
	}
}

bool MAFAudioDevice::SetSoundEnabled(bool enable) {
	if (!mSoundDeviceHaveTried)
		InitializeDevice();

	if (enable != mSoundEnabled)
		if (enable) {
			if (osgAL::SoundManager::instance()->initialized())
				mSoundEnabled = enable;
			else
				mSoundEnabled = false;
		} else
			mSoundEnabled = enable;
			
	return mSoundEnabled;
}

void MAFAudioModel::CheckError(const std::string& message) {
  ALenum error = alGetError();
  if(error != AL_NO_ERROR) {
    g_critical("MAFAudioModel::CheckError: Audio <%s> alGetError() = %s", message.c_str(), alGetString(error) );
  }
}

MAFAudioModel::~MAFAudioModel()
{
}


void MAFAudioModel::SetData(MAFAudioData* data)
{
  mParameters.mData=data;
}

void MAFAudioModel::SetPriority(int pri)
{
  mParameters.mPriority=pri;
}

void MAFAudioModel::SetGain(float gain)
{
  mParameters.mGain=gain;
  mSoundState->setGain(gain);
  if (mSoundState->hasSource())
    mSoundState->apply();
}

void MAFAudioModel::SetReferenceDistance(float d)
{
  mParameters.mReferenceDistance=d;
  mSoundState->setReferenceDistance(d);
  if (mSoundState->hasSource())
    mSoundState->apply();
}

float MAFAudioModel::GetGain()
{
  return mParameters.mGain;
}


void MAFAudioModel::SetAmbient(bool a)
{
  mParameters.mAmbient=a;
  mSoundState->setAmbient(a);
  if (mSoundState->hasSource())
    mSoundState->apply();
}


const std::string& MAFAudioModel::GetName()
{
  return mParameters.mName;
}

void MAFAudioModel::SetName(const std::string& name)
{
  mParameters.mName=name;
  mSoundState->setName(name);
}

bool MAFAudioModel::PlayEvent(int priority)
{
	if (!MAFAudioDevice::GetInstance()->IsSoundEnabled())
		return false;

  if (priority==-1)
    priority=GetPriority();
  return osgAL::SoundManager::instance()->pushSoundEvent(mSoundState.get(),priority);
}


void MAFAudioModel::SetSource(openalpp::Source* source)
{
  if (mEventSound)
    return;
  mSoundState->setSource(source);
}


bool MAFAudioModel::GetPlaying()
{
  return mSoundState->isActive();
}


void MAFAudioModel::SetStatePlaying(bool b)
{
	if (b && !MAFAudioDevice::GetInstance()->IsSoundEnabled())
		return;
	if (b)
		ApplyParameter();
  mSoundState->setPlay(b);
}


void MAFAudioModel::SetPlaying(bool b)
{
	if (b && !MAFAudioDevice::GetInstance()->IsSoundEnabled())
		return;
  if (mSoundState->hasSource())
    mSoundState->apply();
	SetStatePlaying(b);
}

int MAFAudioModel::GetPriority()
{
  return mSoundState->getPriority();
}

void MAFAudioModel::SetStopMethod(openalpp::SourceState stop)
{
  mSoundState->setStopMethod(stop);
  if (mSoundState->hasSource())
    mSoundState->apply();
}

MAFAudioModel::MAFAudioModel():mEventSound(false)
{
  mSoundState=new osgAL::SoundState("audiostate_noname");
  mNode= new osgAL::SoundNode;
  mNode->setSoundState(mSoundState.get());
  SetPlaying(false);
}

void MAFAudioModel::SetRolloff(float d)
{
  mSoundState->setRolloffFactor(d);
  if (mSoundState->hasSource())
    mSoundState->apply();
}

float MAFAudioModel::GetRolloff()
{
  return mParameters.mRolloff;
}

float MAFAudioModel::GetReferenceDistance()
{
#if OSGAL_VERSION >= 03
  return mSoundState->getReferenceDistance();
#else // OSGAL_VERSION >= 03
  return mSoundState->getReferenceDistance(0.f);
#endif // OSGAL_VERSION >= 03
}


void MAFAudioModel::DumpState()
{
#if 0
  osg::Vec3 pos=GetPosition();
  g_debug("Sound %s position %f %f %f",mParameters.mName.c_str(),pos[0],pos[1],pos[2]);
  pos=GetDirection();
  g_debug("Sound %s direction %f %f %f",mParameters.mName.c_str(),pos[0],pos[1],pos[2]);
  pos=GetVelocity();
  g_debug("Sound %s velocity  %f %f %f",mParameters.mName.c_str(),pos[0],pos[1],pos[2]);
  g_debug("Sound %s gain %f",mParameters.mName.c_str(),GetGain());
  g_debug("Sound %s relative %d",mParameters.mName.c_str(),GetRelative());
  g_debug("Sound %s reference distance %f",mParameters.mName.c_str(),GetReferenceDistance());
  g_debug("Sound %s rolloff %f",mParameters.mName.c_str(),GetRolloff());
#endif
}

void MAFAudioModel::Init()
{
  // Let the soundstate use the sample we just created
  if (!mParameters.mData)
    return;
  openalpp::SoundData* soundData = mParameters.mData->GetSoundData();
  openalpp::Sample* sample = dynamic_cast<openalpp::Sample*>(soundData);
  if(sample) {
    mSoundState->setSample(sample);
  } else {
    openalpp::Stream* stream = dynamic_cast<openalpp::Stream*>(soundData);
    mSoundState->setStream(stream);
  }
}

void MAFAudioModel::ApplyParameter()
{
	if (!MAFAudioDevice::GetInstance()->IsSoundEnabled())
		return;

  Init();
  mSoundState->setRolloffFactor(mParameters.mRolloff);
  mSoundState->setGain(mParameters.mGain);
  mSoundState->setReferenceDistance(mParameters.mReferenceDistance);
  mSoundState->setAmbient(mParameters.mAmbient);
// 	printf("gain %f refdist %f rolloff %f ambient %d\n",mParameters.mGain, mParameters.mReferenceDistance, mParameters.mRolloff, (int)mParameters.mAmbient);
  if (mSoundState->hasSource())
    mSoundState->apply();
}


/*
 * Controller
 */
void MAFAudioController::Init(void) {
  if(!GetModel())
    SetModel(new MAFAudioModel);
  if(!GetView())
    SetView(new MAFAudioView);
  
  MAFController::Init();
}

void MAFAudioController::BindToScene(MAFSceneController* scene) {
  g_assert(scene != 0);
  scene->GetModel()->mGroup->addChild(GetModel()->GetNode());
}

void MAFAudioController::AttachTo( osg::Group* group )
{
  g_assert(group != 0);
  group->addChild(GetModel()->GetNode());
}

void MAFAudioController::Play(void) 
{
  if (!GetModel()->GetSoundEvent()) {
    if(!GetModel()->GetPlaying()) {
      GetModel()->GetState()->allocateSource(GetModel()->GetPriority());
      GetModel()->SetStopMethod(openalpp::Stopped);
      GetModel()->SetPlaying(true);
    }
  } else
		PlayEvent();
}

void MAFAudioController::PlayEvent(void) 
{
  GetModel()->SetStatePlaying(true);
  if(!GetModel()->PlayEvent()) {
    g_debug("Can't play event %s",GetModel()->GetName().c_str());
  }
}


void MAFAudioController::Stop(void) 
{
  if (GetModel()->GetSoundEvent())
    return;

  if(GetModel()->GetPlaying()) {
    GetModel()->SetPlaying(false);
  }

  GetModel()->GetState()->releaseSource();
}



MAFAudioSourceModel::MAFAudioSourceModel()
{
//   mSource=osgAL::SoundManager::instance()->allocateSource(0); //0,false);
  mSound=new MAFAudioController;
  mSound->Init();
  mSound->GetModel()->GetNode()->setName("Sound Source");
}


void MAFAudioSourceModel::Stop()
{
  mSound->GetModel()->SetPlaying(false);
}


void MAFAudioSourceModel::Play(const std::string& name)
{
  Stop();
  SoundMap::const_iterator it=mSounds.find(name);
  if (it==mSounds.end()) {
    g_critical("MAFAudioSourceModel::Play sound %s not found",name.c_str());
		return;
	}
  const MAFAudioModel::MAFAudioParameter& param=it->second;
  mSound->GetModel()->SetParameter(param);
	//  mSound->GetModel()->ApplyParameter();
  mSound->GetModel()->SetStatePlaying(true);
}

void MAFAudioSourceController::BindToScene(MAFSceneController* scene) {
  g_assert(scene != 0);
  scene->GetModel()->mGroup->addChild(GetModel()->mSound->GetModel()->GetNode());
}

void MAFAudioSourceController::AttachTo( osg::Group* group )
{
  g_assert(group != 0);
  group->addChild(GetModel()->mSound->GetModel()->GetNode());
}

void MAFAudioSourceController::Init()
{
  GetModel()->mSound->GetModel()->GetState()->allocateSource(0);
}

void MAFAudioSourceController::Enable()
{
  if (!GetModel()->mSound->GetModel()->GetState()->hasSource())
    GetModel()->mSound->GetModel()->GetState()->allocateSource(0);
}

void MAFAudioSourceController::Disable()
{
  if (GetModel()->mSound->GetModel()->GetState()->hasSource())
    GetModel()->mSound->GetModel()->GetState()->releaseSource();
}
