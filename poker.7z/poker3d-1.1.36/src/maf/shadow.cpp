/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#include <maf/StdAfx.h>

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */

#ifndef MAF_USE_VS_PCH
#include <maf/mafexport.h>
#include <maf/shadow.h>
#endif

osg::Matrixf MAFBuildShadowMatrix(const osg::Plane &_groundPlane, const osg::Vec4f &_lightPos)
{
	float dot = _groundPlane.asVec4() * _lightPos;

	osg::Matrixf out;
	out(0, 0) = dot - _lightPos.x() * _groundPlane.asVec4().x();
	out(1, 0) = 0.f - _lightPos.x() * _groundPlane.asVec4().y();
	out(2, 0) = 0.f - _lightPos.x() * _groundPlane.asVec4().z();
	out(3, 0) = 0.f - _lightPos.x() * _groundPlane.asVec4().w();

	out(0, 1) = 0.f - _lightPos.y() * _groundPlane.asVec4().x();
	out(1, 1) = dot - _lightPos.y() * _groundPlane.asVec4().y();
	out(2, 1) = 0.f - _lightPos.y() * _groundPlane.asVec4().z();
	out(3, 1) = 0.f - _lightPos.y() * _groundPlane.asVec4().w();

	out(0, 2) = 0.f - _lightPos.z() * _groundPlane.asVec4().x();
	out(1, 2) = 0.f - _lightPos.z() * _groundPlane.asVec4().y();
	out(2, 2) = dot - _lightPos.z() * _groundPlane.asVec4().z();
	out(3, 2) = 0.f - _lightPos.z() * _groundPlane.asVec4().w();

	out(0, 3) = 0.f - _lightPos.w() * _groundPlane.asVec4().x();
	out(1, 3) = 0.f - _lightPos.w() * _groundPlane.asVec4().y();
	out(2, 3) = 0.f - _lightPos.w() * _groundPlane.asVec4().z();
	out(3, 3) = dot - _lightPos.w() * _groundPlane.asVec4().w();

	return out;
}
