/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <maf/StdAfx.h>

#ifndef MAF_USE_VS_PCH
#include <maf/depthmask.h>
#include <maf/mesh.h>
#include <maf/shader.h>
#include <maf/application.h>
#include <maf/shader_blinn.h>
#include <maf/shader_brdf.h>

#include <osg/Geode>
#include <osg/BlendFunc>
#include <osg/Geometry>
#include <osg/Material>
#include <osg/TexGen>
#include <osg/TexMat>
#include <osg/TexEnvCombine>
#include <osgDB/ReadFile>
#include <osgDB/FileNameUtils>
#include <osgDB/FileUtils>
#include <glib.h>

#include <vserial/material.h>
#include <vserial/meshlayer.h>
#include <vserial/meshprimitivespacket.h>
#include <vserial/meshserializer.h>
#include <vserial/pass.h>
#include <vserial/string.h>
#include <vserial/technique.h>
#include <vserial/texture.h>

#endif

static std::map<std::string, osg::Geode*> g_name2geode;

osg::Geode* MAFMesh::getByName(const std::string &_name)
{
	std::string name = underware::fileName2Name(_name);
	if (g_name2geode.find(name) == g_name2geode.end())
		return NULL;

	return g_name2geode[name];
}

osg::Geode* MAFMesh::convertUMH(underware::Mesh &_mesh, const std::string &_basePath, bool _bAuthorizeNormalDiscard)
{
	int i, j, k;
	osg::Geode *geode = new osg::Geode();

	const std::string &meshFileName = _mesh.getFileName();
	underware::MeshLayer *mlayer = _mesh.getLayerByIndex(0);

	bool bVProgOK = MAFShader::isVertexProgramSupported() && (MAFShader::getTechnicAuthorisation() & MAFShader::TECHNIC_AUTHORISATION_VERTEX_PROGRAM);
	bool bFProgOK = MAFShader::isFragmentProgramSupported() && (MAFShader::getTechnicAuthorisation() & MAFShader::TECHNIC_AUTHORISATION_FRAGMENT_PROGRAM);

	underware::Vec3f *points = mlayer->getPoints();
	int nbPrimsPackets = mlayer->getNbPrimitivesPackets();
	for (i = 0; i < nbPrimsPackets; i++) {

		osg::BlendFunc *blendState = NULL;
		underware::MeshPrimitivesPacket *packet = mlayer->getPrimitivesPacket(i);
		underware::MESHPRIM_PACKET_TYPE type = packet->getType();
		underware::Material *mat = packet->getMaterial();
		if (!mat)
			continue;

		const std::string &matName = mat->getFileName();
		underware::Technique *tech = mat->getTechniqueByIndex(0);
		underware::Pass *pass = tech->getPassByIndex(0);

		underware::GPUProgram &vprog = pass->getVertexProgram();
		std::string vprogName = vprog.getName();

		if ( vprogName != "" && (!bVProgOK || !bFProgOK)) {
			// we have a shader but cannot and/or are not authorized to use it
			if (mat->getNbTechniques() == 1) {
				g_critical("MAFMesh::convertUMH: material \"%s\" doesn't have any shader fallback technique", mat->getFileName().c_str());
				continue;
			}

			tech = mat->getTechniqueByIndex(1);
			pass = tech->getPassByIndex(0);
			vprogName = "";
		}

		unsigned short *indexBuffer = packet->getIndexBuffer();
		int nbIndices = packet->getNbIndices();
		int vtx_format = packet->getVertexFormat();
		int nbUVs = underware::Vertex::getNbUVs(vtx_format);

		if (_bAuthorizeNormalDiscard == true && vprogName == "") {
			// not any shader is applied and we are authorized to discard normal
			vtx_format &= ~underware::Vertex::FMT_NORMAL;
		}

		osg::Geometry *geom = new osg::Geometry();
		osg::StateSet *ss = geom->getOrCreateStateSet();

//		geom->setUseDisplayList(false);
	//	geom->setUseVertexBufferObjects(true);

		osg::Material *osg_mat = new osg::Material();

		const underware::Col4f &diffuseCol = pass->getDiffuse();
		osg_mat->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(diffuseCol.r, diffuseCol.g, diffuseCol.b, diffuseCol.a) );

		if (diffuseCol.a < 0.9999999) {
			if (!blendState)
				blendState = new osg::BlendFunc;

			blendState->setFunction(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		}

		const underware::Col4f &emissiveCol = pass->getEmissive();
		osg_mat->setEmission(osg::Material::FRONT_AND_BACK, osg::Vec4f(emissiveCol.r, emissiveCol.g, emissiveCol.b, emissiveCol.a) );

		const underware::Col4f &specularCol = pass->getSpecular();
		osg_mat->setSpecular(osg::Material::FRONT_AND_BACK, osg::Vec4f(specularCol.r, specularCol.g, specularCol.b, specularCol.a) );
		osg_mat->setShininess(osg::Material::FRONT_AND_BACK, 100.0f); // BAD

		const underware::Col4f &ambientCol = pass->getAmbient();
		osg_mat->setAmbient(osg::Material::FRONT_AND_BACK, osg::Vec4f(ambientCol.r, ambientCol.g, ambientCol.b, ambientCol.a) );

		ss->setAttributeAndModes(osg_mat);

		int nbTL = pass->getNbTextureLayers();

		osg::Vec2Array *arrayUVs[8];
		for (j = 0; j < nbUVs; j++) {
			osg::Vec2Array *uv_array = new osg::Vec2Array();
			arrayUVs[j] = uv_array;
		}

		osg::PrimitiveSet *pset;

		if (type == underware::MESHPRIM_TRIANGLES)
      pset = new osg::DrawElementsUShort(GL_TRIANGLES, nbIndices, (GLushort*) indexBuffer);
		else
      pset = new osg::DrawElementsUShort(GL_TRIANGLE_STRIP, nbIndices, (GLushort*) indexBuffer);

		geom->addPrimitiveSet(pset);

		osg::Vec3Array *arrayVertex = new osg::Vec3Array();
		geom->setVertexArray(arrayVertex);

		osg::Vec3Array *arrayNormal;
		if (vtx_format & underware::Vertex::FMT_NORMAL) {
			arrayNormal = new osg::Vec3Array();
			geom->setNormalArray(arrayNormal);
			geom->setNormalBinding(osg::Geometry::BIND_PER_VERTEX);
		}

		underware::Vertex *vertices = packet->getVertexBuffer();
		int nbVertices = packet->getNbVertices();
		for (j = 0; j < nbVertices; j++) {
			underware::Vertex &vertex = vertices[j];
			int geoBind = vertex.geoBind;
			underware::Vec3f &pos = points[geoBind];
			arrayVertex->push_back( osg::Vec3f(pos.x, pos.y, pos.z) );

			if (vtx_format & underware::Vertex::FMT_NORMAL) {
				float nx = vertex.normalx / 32767.0f;
				float ny = short(vertex.normaly & 0xfffe) / 32767.0f;
				float nz = 1 - (nx*nx) - (ny*ny);
				if (nz > FLT_EPSILON)
					nz = sqrt(nz);
				if (vertex.normaly & 1)
					nz = -nz;

				if (nx < -1) nx = -1;
				else if (nx > 1) nx = 1;

				if (ny < -1) ny = -1;
				else if (ny > 1) ny = 1;

				if (nz < -1) nz = -1;
				else if (nz > 1) nz = 1;

				arrayNormal->push_back( osg::Vec3f(nx, ny, nz) );
			}

			for (k = 0; k < nbUVs; k++) {
				underware::Vec2f &uv = vertex.uvs[k];
				arrayUVs[k]->push_back( osg::Vec2f(uv.x, uv.y) );
			}
		}

		for (j = 0; j < nbTL; j++) {
			underware::TextureLayer &tl = pass->getTextureLayer(j);
			underware::Texture *tex = tl.getTexture();
			if (tex) {
				const std::string &fileName = tex->getFileName();
				std::string fname = underware::obtainFilename(fileName, _basePath);

				osg::ref_ptr<osgDB::ReaderWriter::Options> opts = new osgDB::ReaderWriter::Options();
				opts->setObjectCacheHint(osgDB::ReaderWriter::Options::CACHE_ALL);

				bool bGotHDR = false;

				if (fname.find(".hdr") != std::string::npos)
						bGotHDR = true;

				if (bGotHDR) {
					char str[200];
					sprintf(str, "RGBMUL 0.5 YFLIP");
					opts->setOptionString(str);
				}

				osg::Texture2D *osgtex = MAFApplication::GetTextureManager()->GetTexture2D(fname, opts.get());
				ss->setTextureAttributeAndModes(j, osgtex);

				underware::TMAP_TYPE tmap_type = tl.getMapType();
				if (tmap_type == underware::TMAP_UV) {
					int uvIndex = tl.getUVIndex();
					geom->setTexCoordArray(j, arrayUVs[uvIndex]);
				}
				else if (tmap_type == underware::TMAP_REFLECTION) {
					osg::TexGen *texgen = new osg::TexGen;
					texgen->setMode(osg::TexGen::REFLECTION_MAP);
					ss->setTextureAttributeAndModes(j, texgen);

					osg::TexMat *texmat = new osg::TexMat;
					osg::Matrix mat = osg::Matrix::scale(0.5f, 0.5f, 0);
					mat(3, 0) = 0.5f;
					mat(3, 1) = 0.5f;
					texmat->setMatrix(mat);
					ss->setTextureAttributeAndModes(j, texmat);
				}
				else if (tmap_type == underware::TMAP_NORMAL) {
					osg::TexGen *texgen = new osg::TexGen;
					texgen->setMode(osg::TexGen::NORMAL_MAP);
					ss->setTextureAttributeAndModes(j, texgen);

					osg::TexMat *texmat = new osg::TexMat;
					osg::Matrix mat = osg::Matrix::scale(0.5f, 0.5f, 0);
					mat(3, 0) = 0.5f;
					mat(3, 1) = 0.5f;
					texmat->setMatrix(mat);
					ss->setTextureAttributeAndModes(j, texmat);
				}
			}
		}

		for (j = 0; j < nbTL; j++) {
			underware::TextureLayerBind &tlb = pass->getTextureLayerBind(j);
			underware::TEXOP texop = tlb.getTexelOperation();

			osg::TexEnvCombine *envCombine;
			envCombine = new osg::TexEnvCombine;

			if (texop == underware::TEXOP_MUL || texop == underware::TEXOP_MUL2X) {
				envCombine->setCombine_RGB(GL_MODULATE);

				envCombine->setSource0_RGB(GL_TEXTURE);
				envCombine->setSource0_Alpha(GL_TEXTURE);
				envCombine->setOperand0_RGB(GL_SRC_COLOR);
				envCombine->setOperand0_Alpha(GL_SRC_ALPHA);

				envCombine->setSource1_RGB(GL_PREVIOUS_ARB);
				envCombine->setSource1_Alpha(GL_PREVIOUS_ARB);
				envCombine->setOperand1_RGB(GL_SRC_COLOR);
				envCombine->setOperand1_Alpha(GL_SRC_ALPHA);

				if (texop == underware::TEXOP_MUL2X)
					envCombine->setScale_RGB(2.0f);
			}
			else if (texop == underware::TEXOP_ADD) {
				envCombine->setCombine_RGB(GL_ADD);

				envCombine->setSource0_RGB(GL_TEXTURE);
				envCombine->setSource0_Alpha(GL_TEXTURE);
				envCombine->setOperand0_RGB(GL_SRC_COLOR);
				envCombine->setOperand0_Alpha(GL_SRC_ALPHA);

				envCombine->setSource1_RGB(GL_PREVIOUS_ARB);
				envCombine->setSource1_Alpha(GL_PREVIOUS_ARB);
				envCombine->setOperand1_RGB(GL_SRC_COLOR);
				envCombine->setOperand1_Alpha(GL_SRC_ALPHA);
			}
			else if (texop == underware::TEXOP_BLEND) {
				envCombine->setCombine_RGB(GL_BLEND);

				envCombine->setSource0_RGB(GL_TEXTURE);
				envCombine->setSource0_Alpha(GL_TEXTURE);
				envCombine->setOperand0_RGB(GL_SRC_COLOR);
				envCombine->setOperand0_Alpha(GL_SRC_ALPHA);

				envCombine->setSource1_RGB(GL_PREVIOUS_ARB);
				envCombine->setSource1_Alpha(GL_PREVIOUS_ARB);
				envCombine->setOperand1_RGB(GL_SRC_COLOR);
				envCombine->setOperand1_Alpha(GL_SRC_ALPHA);
			}
			else if (texop == underware::TEXOP_PREVIOUSRGB_ALPHAMUL) {
				envCombine->setCombine_RGB(GL_REPLACE);
				envCombine->setCombine_Alpha(GL_MODULATE);

				envCombine->setSource0_RGB(GL_PREVIOUS_ARB);
				envCombine->setSource0_Alpha(GL_TEXTURE);
				envCombine->setOperand0_RGB(GL_SRC_COLOR);
				envCombine->setOperand0_Alpha(GL_SRC_ALPHA);

				envCombine->setSource1_Alpha(GL_PREVIOUS_ARB);
				envCombine->setOperand1_Alpha(GL_SRC_ALPHA);
			}

			ss->setTextureAttributeAndModes(j, envCombine, osg::StateAttribute::ON);
		}

		if (bVProgOK && bFProgOK) {
			if (vprogName == "BLINN") {
				MAFShader *shader = NULL;
				MAFShader::get(MAFSHADERTYPE_BLINN, &shader);
				MAFShaderBlinn *blinn = (MAFShaderBlinn*) shader;
				blinn->configureStateSet(*ss);

				float gloss = pass->getGlossiness();
				blinn->setGlossiness( (gloss * 1) * 1.3f );
			}
			else if (vprogName == "BRDF") {
				MAFShader *shader = NULL;
				MAFShader::get(MAFSHADERTYPE_BRDF, &shader);
				MAFShaderBRDF *brdf = (MAFShaderBRDF*) shader;
				brdf->configureStateSet(*ss);
			}
		}

		underware::PIXOP pixop = pass->getPixelOperation();

		if (pixop != underware::PIXOP_REPLACE) {

			if (!blendState)
				blendState = new osg::BlendFunc;

			if (pixop == underware::PIXOP_BLEND)
				blendState->setFunction(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			else if (pixop == underware::PIXOP_SRCADD)
				blendState->setFunction(GL_SRC_ALPHA, GL_ONE);
		}

		if (blendState) {
			ss->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
			ss->setAttributeAndModes(blendState);
			//ss->setAttributeAndModes( new DepthMask(false) );
//			ss->setAttributeAndModes( new osg::AlphaFunc(osg::AlphaFunc::NOTEQUAL, 0.0f) );
		}

		geode->addDrawable(geom);

//		osgUtil::TriStripVisitor *tsv = new osgUtil::TriStripVisitor();
	//	tsv->setCacheSize(24);
		//tsv->apply(*geode);
		//tsv->stripify();
	}

	std::string meshName = underware::fileName2Name(meshFileName.c_str());
	g_name2geode[meshName] = geode;

	return geode;
}

//
// OSG interface to read from a file.
//
class ReaderWriterUMESH : public osgDB::ReaderWriter {
public:
  virtual const char* className() { return "umesh object reader"; }

  virtual bool acceptsExtension(const std::string& extension) const {
    return osgDB::equalCaseInsensitive(extension, "umesh");
  }

  virtual ReadResult readNode(const std::string& fileName, const Options* options = NULL) const
	{
    std::string ext = osgDB::getLowerCaseFileExtension(fileName);
    if (!acceptsExtension(ext)) return ReadResult::FILE_NOT_HANDLED;

    std::string path = osgDB::findDataFile(fileName, options);
    if(path.empty()) return ReadResult::FILE_NOT_FOUND;

    std::string dir = g_dirname(fileName.c_str());
    std::string file = g_basename(fileName.c_str());

		std::string fullname = underware::obtainFilename(fileName, dir.c_str());
		gchar *basePath = g_path_get_dirname( (const gchar*) fullname.c_str());

		underware::Mesh *mesh;
		underware::MeshSerializer::load(fileName.c_str(), dir.c_str(), &mesh);
		osg::Geode *geode = MAFMesh::convertUMH(*mesh, basePath, true);

    ReadResult result(geode);

    return result;
  }
};

static osgDB::RegisterReaderWriterProxy<ReaderWriterUMESH> static_readerWriter_umesh_Proxy;
