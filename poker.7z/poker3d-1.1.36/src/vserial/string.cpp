/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <glib.h>

#include <vserial/vserial.h>
#include <vserial/string.h>
#endif

ENTER_NAMESPACE_UNDERWARE

std::string retainFileName(const std::string &_fullpath)
{
  int p = _fullpath.rfind('\\');
  if (p == (int)std::string::npos) {
    p = _fullpath.rfind('/');
    if (p == (int)std::string::npos)
      p = -1;
  }  
  return _fullpath.substr(p+1);
}

std::string fileName2Name(const std::string &_fileName)
{
	gchar *baseName = g_path_get_basename(_fileName.c_str());
	char *f = strchr(baseName, '.');
	if (!f)
		return std::string(baseName);
	return std::string(baseName, f);
}

bool copyFile(const std::string &_source, const std::string &_dest)
{
	FILE *src = fopen(_source.c_str(), "rb");
	if (!src)
		return false;

	FILE *dst = fopen(_dest.c_str(), "wb");
	if (!dst) {
		fclose(src);
		return false;
	}

	char tmp[1024];
	while(1) {
		int read = fread(tmp, 1, sizeof(tmp), src);
		fwrite(tmp, read, 1, dst);
		if (read != sizeof(tmp))
			break;
	}

	fclose(src);
	fclose(dst);
	return true;
}

std::string obtainFilename(const std::string &_name, const std::string &_basePath)
{
	if (g_path_is_absolute( (const gchar*) _name.c_str()))
		return _name;

//	const gchar *base = g_path_get_basename( (const gchar*) _name.c_str());
	std::string fname = _basePath + "/" + _name;
	return fname;
}

LEAVE_NAMESPACE
