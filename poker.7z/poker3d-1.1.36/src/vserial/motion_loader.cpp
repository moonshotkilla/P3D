/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>

#include <iostream>

#include <glib.h>

#include <vserial/dataio.h>
#include <vserial/envelope.h>
#include <vserial/keyframe.h>
#include <vserial/motion.h>
#include <vserial/motionserializer.h>
#include <vserial/string.h>
#endif

ENTER_NAMESPACE_UNDERWARE

bool MotionSerializer::load(const char *_fileName, Motion **_res)
{
	DataIn data;

	if (!data.open(_fileName))
		return false;

	return load(data, _res);
}

bool MotionSerializer::load(DataIn &_in, Motion **_res)
{
	MotionSerializer ms;
	ms.motion_ = new Motion();
	ms.in_ = &_in;

	if (!ms.load()) {
		delete ms.motion_;
		return false;
	}

	if (_res)
		*_res = ms.motion_;

	return true;
}

bool MotionSerializer::load()
{
	char tag[4];
	int tagid;
	int subChunkSize;
	char str[500];

	if (in_->read(tag, 4) != 4) {
		return false;
	}

	tagid = MID(tag[0], tag[1], tag[2], tag[3]);
	if (tagid != MID('M','O','T','0')) {
		g_critical("MotionSerializer::load - expected MOT0 (found %d)", tagid);
		return false;
	}

	int startPos = in_->tell();
	int chunkSize = in_->readDword();

	while (in_->tell() < startPos+chunkSize && !in_->error()) {

		in_->read(tag, 4);
		subChunkSize = in_->readDword();
		int pos0 = in_->tell();

		tagid = MID(tag[0], tag[1], tag[2], tag[3]);
		switch (tagid) {

		case MID('N','A','M','E'):
			in_->readStrZ(str);
			motion_->setFileName(str);
			break;

		case MID('E','N','V',' '):
			readENVchunk(subChunkSize);
			break;

		default:
			in_->advance(subChunkSize);
			break;
		}

		int pos1 = in_->tell();
		if (pos1 - pos0 != subChunkSize) {
			g_warning("MotionSerializer::load - a subchunk has an incorrect size in file \"%s\" (read %d bytes instead of %d)", in_->getFileName().c_str(), pos1-pos0, subChunkSize);
			in_->seek( pos0 + subChunkSize );
		}
	}

	return true;
}

bool MotionSerializer::readENVchunk(int _chunkSize)
{
	char tag[4];
	int tagid;
	int subChunkSize;
	int nbKeys = 0;
	EnvelopeBase::VALUE_TYPE valueType;
	EnvelopeBase *env = NULL;

	int startPos = in_->tell();

	while (in_->tell() < (startPos+_chunkSize) && !in_->error()) {
		
		in_->read(tag, 4);
		int subChunkSize = in_->readDword();
		int pos0 = in_->tell();

		tagid = MID(tag[0], tag[1], tag[2], tag[3]);

		switch (tagid) {

		case MID('N','K','E','Y'):
			nbKeys = in_->readDword();
			break;

		case MID('T','Y','P','E'):
			valueType = (EnvelopeBase::VALUE_TYPE) in_->readByte();
			if (valueType == EnvelopeBase::TYPE_FLOAT) {
				env = new EnvelopeFloat();
			}
			else if (valueType == EnvelopeBase::TYPE_QUATERNION) {
				env = new EnvelopeQuaternion();
			}
			if (env)
				motion_->addEnvelope(env);

			break;

		case MID('K','E','Y','S'):
			{
				if (!env)
					break;

				for (int i = 0; i < nbKeys; i++) {

					KeyBase *key;
					if (valueType == EnvelopeBase::TYPE_FLOAT)
						key = new KeyFloat;
					else if (valueType == EnvelopeBase::TYPE_QUATERNION)
						key = new KeyQuaternion;
					else
						break;

					key->time_ = in_->readFloat();
					key->shape_ = (KeyBase::SHAPE) in_->readByte();
					key->tension_ = in_->readFloat();
					key->continuity_ = in_->readFloat();
					key->bias_ = in_->readFloat();
					key->params_[0] = in_->readFloat();
					key->params_[1] = in_->readFloat();
					key->params_[2] = in_->readFloat();
					key->params_[3] = in_->readFloat();

					env->addKey(key);
				}

				if (valueType == EnvelopeBase::TYPE_FLOAT) {
					for (int i = 0; i < nbKeys; i++) {
						KeyFloat *key = (KeyFloat*) env->getKey(i);
						key->value_ = in_->readFloat();
					}
				}
				else if (valueType == EnvelopeBase::TYPE_QUATERNION) {
					for (int i = 0; i < nbKeys; i++) {
						KeyQuaternion *key = (KeyQuaternion*) env->getKey(i);
						key->value_.x = in_->readFloat();
						key->value_.y = in_->readFloat();
						key->value_.z = in_->readFloat();
						key->value_.w = in_->readFloat();
					}
				}
			}
			break;

		default:
			in_->advance(subChunkSize);
			break;
		}

		int pos1 = in_->tell();
		if (pos1 - pos0 != subChunkSize) {
			g_warning("MotionSerializer::readENVchunk - a subchunk has an incorrect size in file \"%s\" (read %d bytes instead of %d)", in_->getFileName().c_str(), pos1-pos0, subChunkSize);
			in_->seek( pos0 + subChunkSize );
		}
	}

	return true;
}

LEAVE_NAMESPACE
