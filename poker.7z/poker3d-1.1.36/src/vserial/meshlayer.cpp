/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <map>
#include <float.h>
#include <vserial/vserial.h>

#include <vserial/floatmap.h>
#include <vserial/meshlayer.h>
#include <vserial/vertexmap.h>
#endif

ENTER_NAMESPACE_UNDERWARE

MeshLayer::MeshLayer(Mesh &_mesh)
{
	owner_ = &_mesh;
	points_ = NULL;
	nbPoints_ = 0;
}

MeshLayer::~MeshLayer()
{
	int i;

	if (points_)
		delete [] points_;

	int nbPackets = packets_.size();
	for (i = 0; i < nbPackets; i++)
		delete packets_[i];

	int nbVMaps = vertexMaps_.size();
	for (i = 0; i < nbVMaps; i++)
		delete vertexMaps_[i];
}

MeshPrimitivesPacket* MeshLayer::addPrimitivesPacket(MESHPRIM_PACKET_TYPE _type)
{
	MeshPrimitivesPacket *packet = new MeshPrimitivesPacket(*this, _type);
	packets_.push_back(packet);
	return packet;
}

void MeshLayer::optimize()
{
	int i, j, k;

	std::vector< std::vector<Vertex*> > geo_2_vertices;
	std::map<Vertex*, int> newvertex_2_index;
	std::map<int, int> oldvindex_2_newvindex;
	std::vector<Vertex> newvbuffer;

	int nbPackets = packets_.size();
	for (i = 0; i < nbPackets; i++) {
		MeshPrimitivesPacket *packet = packets_[i];

		int vertex_format = packet->getVertexFormat();

		geo_2_vertices.clear();
		newvertex_2_index.clear();
		oldvindex_2_newvindex.clear();
		newvbuffer.clear();

		int nbVertices = packet->getNbVertices();

		Vertex *vertices = packet->getVertexBuffer();
		for (j = 0; j  < nbVertices; j++) {
			Vertex &vertex = vertices[j];
			int iGeoBind = vertex.geoBind;
			if (geo_2_vertices.size() <= iGeoBind)
				geo_2_vertices.resize( iGeoBind+1 );

			bool bFound = false;
			std::vector<Vertex*> &cmpVert = geo_2_vertices[iGeoBind];
			int nbToCmp = cmpVert.size();

			Vertex *sameVertex;
			for (k = 0; k < nbToCmp; k++) {
				sameVertex = cmpVert[k];
				if (sameVertex->isSameVertex(vertex, vertex_format)) {
					bFound = true;
					break;
				}
			}

			if (bFound == false) {
				oldvindex_2_newvindex[j] = newvbuffer.size();
				newvertex_2_index[&vertex] = newvbuffer.size();
				newvbuffer.push_back(vertex);
				cmpVert.push_back(&vertex);
			}
			else {
				oldvindex_2_newvindex[j] = newvertex_2_index[sameVertex];
			}
		}

		unsigned short *indexBuffer = packet->getIndexBuffer();
		int nbIndices = packet->getNbIndices();
		for (j = 0; j < nbIndices; j++) {
			int old = indexBuffer[j];
			int nw = oldvindex_2_newvindex[old];
			indexBuffer[j] = nw;
		}

		int newNbVertices = newvbuffer.size();
		packet->setVertexBuffer( &newvbuffer[0], newNbVertices, packet->getVertexFormat() );
	}
}

void MeshLayer::setPoints(Vec3f *_points, int _nbPoints)
{
	if (points_)
		delete [] points_;

	points_ = new Vec3f[_nbPoints];
	memcpy(points_, _points, sizeof(Vec3f) * _nbPoints);
	
	nbPoints_ = _nbPoints;
}

void MeshLayer::getBoundingBox(Vec3f &_min, Vec3f &_max)
{
	_min = Vec3f(FLT_MAX, FLT_MAX, FLT_MAX);
	_max = Vec3f(FLT_MIN, FLT_MIN, FLT_MIN);

	for (int i = 0; i < nbPoints_; i++) {
		Vec3f &pt = points_[i];

		if (pt.x < _min.x)
			_min.x = pt.x;
		if (pt.y < _min.y)
			_min.y = pt.y;
		if (pt.z < _min.z)
			_min.z = pt.z;

		if (pt.x > _max.x)
			_max.x = pt.x;
		if (pt.y > _max.y)
			_max.y = pt.y;
		if (pt.z > _max.z)
			_max.z = pt.z;
	}
}

VertexMap* MeshLayer::addVertexMap(const std::string &_name, VMAP_TYPE _type)
{
	VertexMap *vmap = NULL;

	switch(_type) {
		case VMAP_FLOAT:
			vmap = new FloatMap(_name, *this);
			break;

		default:
			break;
	}

	if (vmap)
		vertexMaps_.push_back(vmap);

	return vmap;
}

VertexMap* MeshLayer::getVertexMapByName(const std::string &_name, VMAP_TYPE _type) const
{
	int nb = vertexMaps_.size();
	for (int i = 0; i < nb; i++) {
		VertexMap *vmap = vertexMaps_[i];
		if (vmap->getName() == _name && vmap->getType() == _type)
			return vmap;
	}
	return NULL;
}

VertexMap* MeshLayer::getVertexMapByIndex(int _index) const
{
	return vertexMaps_[_index];
}

LEAVE_NAMESPACE
