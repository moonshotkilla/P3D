/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <glib.h>
#include <vector>
#include <string>

#include <vserial/vserial.h>
#include <vserial/mesh.h>
#include <vserial/meshlayer.h>
#include <vserial/string.h>
#endif

ENTER_NAMESPACE_UNDERWARE

static std::vector<Mesh*> g_meshes;

int Mesh::getNb()
{
	return g_meshes.size();
}

Mesh* Mesh::getByIndex(int _i)
{
	return unsigned(_i) >= g_meshes.size() ? NULL : g_meshes[_i];
}

Mesh* Mesh::getByName(const std::string &_name)
{
	std::string name1 = fileName2Name(_name.c_str());
	int nb = getNb();
	for (int i = 0; i < nb; i++) {
		Mesh *mesh = g_meshes[i];
		std::string name = fileName2Name( mesh->getFileName().c_str() );
		if (name == name1)
			return mesh;
	}
	return NULL;
}

Mesh::Mesh()
{
	g_meshes.push_back(this);
}

Mesh::~Mesh()
{
	int i;
	int nb = g_meshes.size();
	for (i = 0; i < nb; i++) {
		Mesh *mesh = g_meshes[i];
		if (mesh == this) {
			g_meshes.erase( g_meshes.begin() + i );
			break;
		}
	}

	int nbLayers = layers_.size();
	for (i = 0; i < nbLayers; i++) {
		MeshLayer *ml = layers_[i];
		delete ml;
	}
}

MeshLayer* Mesh::addLayer()
{
	MeshLayer *ml = new MeshLayer(*this);
	layers_.push_back(ml);
	return ml;
}

int Mesh::getNbLayers() const
{
	return layers_.size();
}

MeshLayer* Mesh::getLayerByIndex(int _index) const
{
	return layers_[_index];
}

LEAVE_NAMESPACE
