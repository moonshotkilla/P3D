/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH

//#include <map>
//#include <iostream>

#include <glib.h>

#include <vserial/vserial.h>
#include <vserial/dataio.h>
#include <vserial/mesh.h>
#include <vserial/meshserializer.h>
#include <vserial/motion.h>
#include <vserial/motionserializer.h>
#include <vserial/scene.h>
#include <vserial/scenelight.h>
#include <vserial/scenemesh.h>
#include <vserial/scenenullobject.h>
#include <vserial/sceneserializer.h>
#include <vserial/string.h>
#endif

ENTER_NAMESPACE_UNDERWARE

bool SceneSerializer::load(const char *_fileName, const char *_basePath, Scene **_res)
{
	DataIn data;

	std::string fname = obtainFilename(_fileName, _basePath);
	if (!data.open(fname))
		return false;

	return load(data, _basePath, _res);
}

bool SceneSerializer::load(DataIn &_data, const char *_basePath, Scene **_res)
{
	SceneSerializer ss;
	ss.scene_ = new Scene;
	ss.in_ = &_data;
	ss.path_ = _basePath;

	if (!ss.load()) {
		delete ss.scene_;
		return false;
	}

	if (_res)
		*_res = ss.scene_;

	return true;
}

bool SceneSerializer::load()
{
	char tag[4];
	int tagid;
	int subChunkSize;
	int i;

	if (in_->read(tag, 4) != 4) {
		return false;
	}

	tagid = MID(tag[0], tag[1], tag[2], tag[3]);
	if (tagid != MID('U','S','C','0')) {
		g_critical("SceneSerializer::load - expected USC0 (found %d)", tagid);
		return false;
	}

	std::vector<SceneItem*> sceneItems;
	SceneItem *sceneItem;
	std::map<int, SceneItem *> id2item;

	int startPos = in_->tell();
	int chunkSize = in_->readDword();

	while (in_->tell() < startPos+chunkSize && !in_->error()) {

		in_->read(tag, 4);
		subChunkSize = in_->readDword();
		int pos0 = in_->tell();

		tagid = MID(tag[0], tag[1], tag[2], tag[3]);
		switch (tagid) {

		case MID('M','E','S','H'):
			sceneItem = new SceneMesh();
			sceneItems.push_back(sceneItem);
			if (!readMESHchunk((SceneMesh&)*sceneItem, subChunkSize))
				return false;
			break;

		case MID('N','U','L','O'):
			sceneItem = new SceneNullObject();
			sceneItems.push_back(sceneItem);
			if (!readNULOchunk((SceneNullObject&)*sceneItem, subChunkSize))
				return false;
			break;

		case MID('L','G','T',' '):
			sceneItem = new SceneLight();
			sceneItems.push_back(sceneItem);
			if (!readLGTchunk((SceneLight&)*sceneItem, subChunkSize))
				return false;
			break;

		case MID('M','O','T','0'):
			in_->advance(-8);
			MotionSerializer::load(*in_);
			break;

		default:
			in_->advance(subChunkSize);
			break;
		}

		int pos1 = in_->tell();
		if (pos1 - pos0 != subChunkSize) {
			g_warning("SceneSerializer::load - a subchunk has an incorrect size in file \"%s\" (read %d bytes instead of %d)", in_->getFileName().c_str(), pos1-pos0, subChunkSize);
			in_->seek( pos0 + subChunkSize );
		}
	}

	int nbSceneItems = sceneItems.size();
	for (i = 0; i < nbSceneItems; i++) {
		SceneItem *sceneItem = sceneItems[i];
		if (items2parent_.find(sceneItem) == items2parent_.end()) {
			scene_->setRoot(sceneItem);
			continue;
		}
		int parentid = items2parent_[sceneItem];
		SceneItem *parent = ids2item_[parentid];
		parent->addChild(sceneItem);
	}

	{
		int nbMots = mots2item_.size();
		std::map<std::string, SceneItem*>::iterator it = mots2item_.begin();
		for (; it != mots2item_.end(); ++it) {
			const std::string &motName = it->first;
			SceneItem *sceneItem = it->second;

			Motion *motion = Motion::getByName(motName);
			sceneItem->setMotion(motion);
		}
	}

	return true;
}

bool SceneSerializer::readMESHchunk(SceneMesh &_sceneMesh, int _chunkSize)
{
	int startPos = in_->tell();
	int id;
	char tag[4];
	int tagid;
	Vec3f vec;
	Quaternion quat;
	int parent;
	char str[500];
	Mesh *mesh;

	while (in_->tell() < (startPos+_chunkSize) && !in_->error()) {

		in_->read(tag, 4);
		int subChunkSize = in_->readDword();
		int pos0 = in_->tell();

		tagid = MID(tag[0], tag[1], tag[2], tag[3]);

		bool res = readCommonItemAttributes(tagid, subChunkSize, _sceneMesh);

		if (!res) {
			switch(tagid) {

				case MID('R','E','F',' '):
					in_->readStrZ(str);
					mesh = Mesh::getByName(str);
					if (!mesh) {
						bool res = MeshSerializer::load(str, "", &mesh);
						mesh->setFileName(str);
					}
					_sceneMesh.setMesh(mesh);
					break;

				default:
					in_->advance(subChunkSize);
					break;
			}
		}

		int pos1 = in_->tell();
		if (pos1 - pos0 != subChunkSize) {
			in_->seek( pos0 + subChunkSize );
		}
	}

	return true;
}

bool SceneSerializer::readNULOchunk(SceneNullObject &_sceneNullObject, int _chunkSize)
{
	int startPos = in_->tell();
	int id;
	char tag[4];
	int tagid;
	Vec3f vec;
	Quaternion quat;
	int parent;

	while (in_->tell() < (startPos+_chunkSize) && !in_->error()) {

		in_->read(tag, 4);
		int subChunkSize = in_->readDword();
		int pos0 = in_->tell();
		tagid = MID(tag[0], tag[1], tag[2], tag[3]);

		bool res = readCommonItemAttributes(tagid, subChunkSize, _sceneNullObject);

		if (!res) {

			switch(tagid) {
				default:
					in_->advance(subChunkSize);
					break;
			}
		}

		int pos1 = in_->tell();
		if (pos1 - pos0 != subChunkSize) {
			in_->seek( pos0 + subChunkSize );
		}
	}

	return true;
}

bool SceneSerializer::readLGTchunk(SceneLight &_sceneLight, int _chunkSize)
{
	int startPos = in_->tell();
	int id;
	char tag[4];
	int tagid;
	Vec3f vec;
	Quaternion quat;
	int parent;
	SceneLight::TYPE type;
	SceneLight::FALLOFF fallOff;
	int col;

	while (in_->tell() < (startPos+_chunkSize) && !in_->error()) {

		in_->read(tag, 4);
		int subChunkSize = in_->readDword();
		int pos0 = in_->tell();
		tagid = MID(tag[0], tag[1], tag[2], tag[3]);

		bool res = readCommonItemAttributes(tagid, subChunkSize, _sceneLight);

		if (!res) {

			switch(tagid) {

				case MID('T','Y','P','E'):
					type = (SceneLight::TYPE) in_->readByte();
					_sceneLight.data().type = type;
					break;

				case MID('F','O','F','F'):
					fallOff = (SceneLight::FALLOFF) in_->readByte();
					_sceneLight.data().fallOff = fallOff;
					break;

				case MID('C','O','L',' '):
					col = in_->readDword();
					_sceneLight.data().color.fromDword(col);
					break;

				case MID('D','I','R',' '):
					vec.x = in_->readFloat();
					vec.y = in_->readFloat();
					vec.z = in_->readFloat();
					_sceneLight.data().direction = vec;
					break;

				case MID('R','N','G','E'):
					_sceneLight.data().range = in_->readFloat();
					break;

				case MID('P','A','R','M'):
					_sceneLight.data().att0 = in_->readFloat();
					_sceneLight.data().att1 = in_->readFloat();
					_sceneLight.data().att2 = in_->readFloat();
					_sceneLight.data().theta = in_->readFloat();
					_sceneLight.data().phi = in_->readFloat();
					break;

				default:
					in_->advance(subChunkSize);
					break;
			}
		}

		int pos1 = in_->tell();
		if (pos1 - pos0 != subChunkSize) {
			in_->seek( pos0 + subChunkSize );
		}
	}

	return true;
}

bool SceneSerializer::readCommonItemAttributes(int _tagid, int _chunkSize, SceneItem &_item)
{
	int id;
	int parent;
	Vec3f vec;
	Quaternion quat;
	char str[500];

	switch(_tagid) {

		case MID('I','D',' ',' '):
			id = in_->readDword();
			ids2item_[id] = &_item;
			break;

		case MID('N','A','M','E'):
			in_->readStrZ(str);
			_item.setName(str);
			break;

		case MID('P','I','V','O'):
			vec.x = in_->readFloat();
			vec.y = in_->readFloat();
			vec.z = in_->readFloat();
			_item.setPivot(vec);
			break;

		case MID('P','O','S',' '):
			vec.x = in_->readFloat();
			vec.y = in_->readFloat();
			vec.z = in_->readFloat();
			_item.setPosition(vec);
			break;

		case MID('Q','U','A','T'):
			quat.x = in_->readFloat();
			quat.y = in_->readFloat();
			quat.z = in_->readFloat();
			quat.w = in_->readFloat();
			_item.setQuaternion(quat);
			break;

		case MID('P','R','N','T'):
			parent = in_->readDword();
			items2parent_[&_item] = parent;
			break;

		case MID('M','O','T',' '):
			in_->readStrZ(str);
			mots2item_[str] = &_item;
			break;

		default:
			return false;
	}

	return true;
}

LEAVE_NAMESPACE
