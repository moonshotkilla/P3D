/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>
#include <vserial/matrix.h>
#endif

ENTER_NAMESPACE_UNDERWARE

Matrix::Matrix(const float *_v)
{
	int k = 0;
	for (int j = 0; j < 4; j++)
		for (int i = 0; i < 4; i++)
			v_[j][i] = _v[k++];
}

Matrix::Matrix(const double *_v)
{
	int k = 0;
	for (int j = 0; j < 4; j++)
		for (int i = 0; i < 4; i++)
			v_[j][i] = (float) _v[k++];
}

Matrix::Matrix(const Matrix &_mat)
{
	for (int j = 0; j < 4; j++)
		for (int i = 0; i < 4; i++)
			v_[i][j] = _mat.v_[i][j];
}

void Matrix::identity()
{
	v_[0][0] = 1; v_[0][1] = 0; v_[0][2] = 0; v_[0][3] = 0;
	v_[1][0] = 0; v_[1][1] = 1; v_[1][2] = 0; v_[1][3] = 0;
	v_[2][0] = 0; v_[2][1] = 0; v_[2][2] = 1; v_[2][3] = 0;
	v_[3][0] = 0; v_[3][1] = 0; v_[3][2] = 0; v_[3][3] = 1;
}

void Matrix::rotateX(float _angle)
{
	identity();
	float sin = sinf(_angle);
	float cos = cosf(_angle);
	v_[1][1] = cos;
	v_[1][2] = sin;
	v_[2][1] = -sin;
	v_[2][2] = cos;
}

void Matrix::rotateY(float _angle)
{
	identity();
	float sin = sinf(_angle);
	float cos = cosf(_angle);
	v_[0][0] = cos;
	v_[0][2] = -sin;
	v_[2][0] = sin;
	v_[2][2] = cos;
}

void Matrix::rotateZ(float _angle)
{
	identity();
	float sin = sinf(_angle);
	float cos = cosf(_angle);
	v_[0][0] = cos;
	v_[0][1] = sin;
	v_[1][0] = -sin;
	v_[1][1] = cos;
}

Matrix Matrix::mul(const Matrix &_mat) const
{
	Matrix res;

	for (int j = 0; j < 4; j++) {
		for (int i = 0; i < 4; i++) {
			res.v_[j][i] =	v_[j][0] * _mat.v_[0][i] +
											v_[j][1] * _mat.v_[1][i] +
											v_[j][2] * _mat.v_[2][i] +
											v_[j][3] * _mat.v_[3][i];
		}
	}
	return res;
}

Vec3f Matrix::mul(const Vec3f &_pt) const
{
	float x = _pt.x * v_[0][0] + _pt.y * v_[0][1] + _pt.z * v_[0][2] + v_[0][3];
	float y = _pt.x * v_[1][0] + _pt.y * v_[1][1] + _pt.z * v_[1][2] + v_[1][3];
	float z = _pt.x * v_[2][0] + _pt.y * v_[2][1] + _pt.z * v_[2][2] + v_[2][3];
	return Vec3f(x, y, z);
}

Vec3f Matrix::mulNT(const Vec3f &_pt) const
{
	float x = _pt.x * v_[0][0] + _pt.y * v_[0][1] + _pt.z * v_[0][2];
	float y = _pt.x * v_[1][0] + _pt.y * v_[1][1] + _pt.z * v_[1][2];
	float z = _pt.x * v_[2][0] + _pt.y * v_[2][1] + _pt.z * v_[2][2];
	return Vec3f(x, y, z);
}

void Matrix::transpose()
{
	float t;
	t = v_[0][1]; v_[0][1] = v_[1][0]; v_[1][0] = t;
	t = v_[0][2]; v_[0][2] = v_[2][0]; v_[2][0] = t;
	t = v_[2][1]; v_[2][1] = v_[1][2]; v_[1][2] = t;
	t = v_[3][1]; v_[3][1] = v_[1][3]; v_[1][3] = t;
	t = v_[3][2]; v_[3][2] = v_[2][3]; v_[2][3] = t;
	t = v_[3][0]; v_[3][0] = v_[0][3]; v_[0][3] = t;
}

void Matrix::invert()
{
	Vec3f ftrans = getTranslation();
	transpose();
	Vec3f rtrans = mulNT(ftrans);
	setTranslation(-rtrans);
}

Matrix Matrix::operator * (const Matrix &_mat) const
{
	return _mat.mul(*this);
}

Vec3f Matrix::operator * (const Vec3f &_pt) const
{
	return mul(_pt);
}

LEAVE_NAMESPACE
