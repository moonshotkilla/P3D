/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */
#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>

#include <iostream>
#include <glib.h>

#include <vserial/dataio.h>
#include <vserial/envelope.h>
#include <vserial/motion.h>
#include <vserial/motionserializer.h>
#endif

ENTER_NAMESPACE_UNDERWARE

bool MotionSerializer::save(Motion &_motion, const char *_fileName, SaveOptions *_options)
{
	DataOut data;

	if (!data.open(_fileName))
		return false;

	save(_motion, data, _options);

	return data.close();
}

bool MotionSerializer::save(Motion &_motion, DataOut &_out, SaveOptions *_options)
{
	MotionSerializer ms;
	ms.motion_ = &_motion;
	ms.out_ = &_out;
	ms.saveOptions_ = _options;
	ms.save();

	return true;
}

void MotionSerializer::save()
{
	int i;

	out_->writeStr("MOT0");
	int oldPos = out_->tell();
	out_->advance(4);

	const std::string &name = motion_->getFileName();
	out_->writeStr("NAME");
	out_->writeDword(name.size()+1);
	out_->writeStrZ(name.c_str());

	int nbEnvelopes = motion_->getNbEnvelopes();
	for (i = 0; i < nbEnvelopes; i++) {
		EnvelopeBase *env = motion_->getEnvelope(i);
		writeENVchunk(*env);
	}

	int pos = out_->tell();
	out_->seek(oldPos);
	int size = pos - oldPos - 4;
	out_->writeDword(size);
	out_->seek(pos);
}

void MotionSerializer::writeENVchunk(const EnvelopeBase &_env)
{
	out_->writeStr("ENV ");
	int oldPos = out_->tell();
	out_->advance(4);

	out_->writeStr("TYPE");
	out_->writeDword(1);
	EnvelopeBase::VALUE_TYPE type = _env.getValueType();
	out_->writeByte(type);

	int nbKeys = _env.getNbKeys();
	out_->writeStr("NKEY");
	out_->writeDword(4);
	out_->writeDword(nbKeys);

	{
		out_->writeStr("KEYS");
		int oldPos = out_->tell();
		out_->advance(4);
		_env.write(*out_);

		int pos = out_->tell();
		out_->seek(oldPos);
		int size = pos - oldPos - 4;
		out_->writeDword(size);
		out_->seek(pos);
	}

	int pos = out_->tell();
	out_->seek(oldPos);
	int size = pos - oldPos - 4;
	out_->writeDword(size);
	out_->seek(pos);
}

LEAVE_NAMESPACE
