/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vector>
#include <string>

#include <vserial/vserial.h>
#include <vserial/material.h>
#include <vserial/string.h>
#include <vserial/technique.h>
#endif

ENTER_NAMESPACE_UNDERWARE

std::vector<Material*> g_materials;

Material* Material::getByName(const std::string &_name)
{
	std::string name1 = fileName2Name(_name);
	int nb = g_materials.size();
	for (int i = 0; i < nb; i++) {
		Material *mat = g_materials[i];
		std::string name = fileName2Name( mat->getFileName() );
		if (name == name1)
			return mat;
	}
	return NULL;
}

Material* Material::getByIndex(int _index)
{
	return _index >= getNb() ? NULL : g_materials[_index];
}

int Material::getNb()
{
	return g_materials.size();
}

Material::Material()
{
	g_materials.push_back(this);
}

Material::~Material()
{
	int nb = g_materials.size();
	for (int i = 0; i < nb; i++) {
		Material *mat = g_materials[i];
		if (mat == this) {
			g_materials.erase( g_materials.begin() + i );
			break;
		}
	}
}

Technique* Material::addTechnique(const char *_techniqueName)
{
	Technique *technique = new Technique();
	if (_techniqueName)
		technique->setName(_techniqueName);
	techniques_.push_back(technique);
	return technique;
}

LEAVE_NAMESPACE
