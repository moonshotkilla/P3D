/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>

#include <iostream>

#include <glib.h>

#include <vserial/dataio.h>
#include <vserial/floatmap.h>
#include <vserial/material.h>
#include <vserial/materialserializer.h>
#include <vserial/mesh.h>
#include <vserial/meshlayer.h>
#include <vserial/meshserializer.h>
#include <vserial/string.h>
#include <vserial/vertexmap.h>
#include <vserial/vector3map.h>
#endif

ENTER_NAMESPACE_UNDERWARE

bool MeshSerializer::save(Mesh &_mesh, const char *_fileName, SaveOptions *_options)
{
	DataOut data;

	if (!data.open(_fileName))
		return false;

	save(_mesh, data, _options);

	return data.close();
}

bool MeshSerializer::save(Mesh &_mesh, DataOut &_out, SaveOptions *_options)
{
	MeshSerializer ms;
	ms.mesh_ = &_mesh;
	ms.out_ = &_out;
	ms.saveOptions_ = _options;
	ms.save();

	return true;
}

void MeshSerializer::save()
{
	int i;

	out_->writeStr("UMH0");
	int oldPos = out_->tell();
	out_->advance(4);

	int nbLayers = mesh_->getNbLayers();
	for (i = 0; i < nbLayers; i++) {
		MeshLayer *ml = mesh_->getLayerByIndex(0);
		writeMLAYchunk(*ml);
	}

	if (!saveOptions_ || saveOptions_->bDontSaveMaterials != true) {
		int nbMaterials = materials_.size();
		for (i = 0; i < nbMaterials; i++) {
			Material *mat = materials_[i];
			MaterialSerializer::save(*mat, *out_);
		}
	}

	int pos = out_->tell();
	out_->seek(oldPos);
	int size = pos - oldPos - 4;
	out_->writeDword(size);
	out_->seek(pos);
}

void MeshSerializer::writeMLAYchunk(const MeshLayer &_ml)
{
	int i;

	out_->writeStr("MLAY");
	int oldPos = out_->tell();
	out_->advance(4);

	writeNAMEchunk( _ml.getName().c_str() );

	int nbVMaps = _ml.getNbVertexMaps();
	for (i = 0; i < nbVMaps; i++) {
		VertexMap *vmap = _ml.vertexMaps_[i];
		writeVMAPchunk(*vmap);
	}

	int nbPoints = _ml.getNbPoints();
	out_->writeStr("PNTS");
	out_->writeDword( nbPoints*12 );
	out_->write(_ml.getPoints(), nbPoints*12);

	int nbPackets = _ml.getNbPrimitivesPackets();
	for (i = 0; i < nbPackets; i++) {
		MeshPrimitivesPacket *packet = _ml.getPrimitivesPacket(i);
		writePCKTchunk(*packet);
	}

	int pos = out_->tell();
	out_->seek(oldPos);
	int size = pos - oldPos - 4;
	out_->writeDword(size);
	out_->seek(pos);
}

void MeshSerializer::writePCKTchunk(const MeshPrimitivesPacket &_packet)
{
	int i, j;

	int nbVertices = _packet.getNbVertices();
	int nbPrimitives = _packet.getNbPrimitives();
	int nbIndices = _packet.getNbIndices();
	Material *material = _packet.getMaterial();
	std::string materialName;
	if (material)
		materialName = fileName2Name( material->getFileName() );

	MESHPRIM_PACKET_TYPE type = _packet.getType();
	Vertex *vertices = _packet.getVertexBuffer();
	unsigned short *indices = _packet.getIndexBuffer();
	int vertex_format = _packet.getVertexFormat();

	out_->writeStr("PCKT");
	int oldPos = out_->tell();
	out_->advance(4);

	out_->writeStr("NVER");
	out_->writeDword(4);
	out_->writeDword(nbVertices);

	out_->writeStr("NPRM");
	out_->writeDword(4);
	out_->writeDword(nbPrimitives);

	out_->writeStr("MAT ");
	out_->writeDword( materialName.size()+1 );
	out_->writeStrZ( materialName.c_str() );

	if (material)
		materials_.push_back(material);

	int vertex_size = Vertex::getSize(vertex_format);
	out_->writeStr("VERT");
	out_->writeDword( vertex_size*nbVertices + 4);
	out_->writeDword( vertex_format );
	for (i = 0; i < nbVertices; i++) {
		Vertex &vertex = vertices[i];

		if (vertex_format & Vertex::FMT_GEOBIND)
			out_->writeWord(vertex.geoBind);

		if (vertex_format & Vertex::FMT_NORMAL) {
			out_->writeWord(vertex.normalx);
			out_->writeWord(vertex.normaly);
		}

		if (vertex_format & Vertex::FMT_COLOR1)
			out_->writeDword(vertex.color1);

		if (vertex_format & Vertex::FMT_COLOR2)
			out_->writeDword(vertex.color2);

		int nbUVs = _packet.getNbUVs();
		for (j = 0; j < nbUVs; j++) {
			out_->writeFloat(vertex.uvs[j].x);
			out_->writeFloat(vertex.uvs[j].y);
		}
	}

	out_->writeStr("PRIM");
	out_->writeDword( nbIndices*2 + 1);
	out_->writeByte(type);
	out_->write(indices, nbIndices*2);

	int pos = out_->tell();
	out_->seek(oldPos);
	int size = pos - oldPos - 4;
	out_->writeDword(size);
	out_->seek(pos);
}

void MeshSerializer::writeVMAPchunk(const VertexMap &vmap)
{
	int i;
	int pos, oldPos;

	out_->writeStr("VMAP");
	oldPos = out_->tell();
	out_->advance(4);

	VMAP_TYPE type = vmap.getType();

	int nb = vmap.getNbEntries();
	out_->writeStrZ(vmap.getName().c_str());
	out_->writeByte(type);
	out_->writeWord(nb);

	if (type == VMAP_FLOAT) {
		FloatMap &fmap = (FloatMap&) vmap;
		std::map<unsigned short, float>::const_iterator it = fmap.mapTable_.begin();
		for ( ; it != fmap.mapTable_.end(); ++it) {
			unsigned short index = (*it).first;
			float value = (*it).second;
			out_->writeWord(index);
			out_->writeFloat(value);
		}
	}
	else if (type == VMAP_VECTOR3) {
		Vector3Map &fmap = (Vector3Map&) vmap;
		std::map<unsigned short, Vec3f>::const_iterator it = fmap.mapTable_.begin();
		for ( ; it != fmap.mapTable_.end(); ++it) {
			unsigned short index = (*it).first;
			Vec3f value = (*it).second;
			out_->writeWord(index);
			out_->writeFloat(value.x);
			out_->writeFloat(value.y);
			out_->writeFloat(value.z);
		}
	}

	pos = out_->tell();
	out_->seek(oldPos);
	int siz = pos - oldPos - 4;
	out_->writeDword(siz);
	out_->seek(pos);
}
void MeshSerializer::writeNAMEchunk(const char *_name)
{
	out_->writeStr("NAME");
	out_->writeDword( strlen(_name)+1 );
	out_->writeStrZ( _name );
}

LEAVE_NAMESPACE
