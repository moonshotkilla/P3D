/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <vserial/stdafx.h>

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vector>

#include <vserial/vserial.h>
#include <vserial/texture.h>
#include <vserial/string.h>

#include <glib.h>
#endif

ENTER_NAMESPACE_UNDERWARE

std::vector<Texture*> g_textures;

int Texture::getNb()
{
	return g_textures.size();
}

Texture* Texture::getByIndex(int _index)
{
	return _index >= getNb() ? NULL : g_textures[_index];
}

Texture* Texture::getByName(const std::string &_name)
{
	std::string name1 = fileName2Name(_name.c_str());
	int nb = getNb();
	for (int i = 0; i < nb; i++) {
		Texture *tex = g_textures[i];
		std::string name = fileName2Name( tex->getFileName().c_str() );
		if (name == name1)
			return tex;
	}
	return NULL;
}

void Texture::migrate(const std::string &_destPath, const std::string &_basePath, MigrateOptions _options)
{
	const std::string &fileName = getFileName();
	std::string fullName = obtainFilename(fileName, _basePath);

	gchar *cc = g_path_get_basename( (const gchar*) fullName.c_str() );
	std::string shortName = std::string(cc);

	std::string migrateTo = _destPath + "/" + shortName;
	if (_options == MIGRATE_AND_RENAME || _options == ONLY_MIGRATE)
		copyFile(fullName, migrateTo);

	if (_options == MIGRATE_AND_RENAME || _options == ONLY_RENAME)
		setFileName(shortName);
}

Texture::Texture()
{
	g_textures.push_back(this);
}

Texture::~Texture()
{
	int nb = g_textures.size();
	for (int i = 0; i < nb; i++) {
		Texture *tex = g_textures[i];
		if (tex == this) {
			g_textures.erase( g_textures.begin() + i );
			break;
		}
	}
}

LEAVE_NAMESPACE
