/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include "ugameStdAfx.h"

#ifndef UGAME_USE_VS_PCH
#include <iostream>
#include <sstream>

#include <libxml/xmlreader.h>
#include <libxml/xpath.h>

#include <ugame/timeout.h>
#endif

template<typename T>
static bool xmlReaderGetAttribute(xmlTextReaderPtr reader, const std::string &name, T& attribute)
{
  xmlChar* attributePtr = xmlTextReaderGetAttribute(reader, (const xmlChar*)name.c_str());
  if (attributePtr == 0)
    return false;
  std::istringstream iss((const char *)attributePtr);
  iss >> attribute;
  xmlFree(attributePtr);
  return true;
}



void UGAMETimeOut::Init()
{
	mCounter = 0;
	mColor = osg::Vec4(1,1,1,1);
	mScale = 1;
	mCounterFadeOut = 1;
	mRanges.clear();
	mEnable = false;
}


static bool FillRange(std::map<std::string,std::string>& parameters, UGAMETimeOut::Range& range)
{
	if (parameters.find("scale") != parameters.end())
		range.mScale = atof(parameters["scale"].c_str());

	if (parameters.find("begin") != parameters.end())
		range.mBegin = atof(parameters["begin"].c_str());

	if (parameters.find("end") != parameters.end())
		range.mEnd = atof(parameters["end"].c_str());

	if (parameters.find("red") != parameters.end())
		range.mColor[0] = atof(parameters["red"].c_str());

	if (parameters.find("green") != parameters.end())
		range.mColor[1] = atof(parameters["green"].c_str());

	if (parameters.find("blue") != parameters.end())
		range.mColor[2] = atof(parameters["blue"].c_str());
	return true;
}

static void GetNodeParameters(xmlNodePtr node,std::map<std::string,std::string>& map)
{
	map.clear();
	xmlAttr* attribute;
	for(attribute = node->properties; attribute; attribute = attribute->next) {
		const char* value = (const char*)xmlNodeGetContent((xmlNode*)attribute);
		const char* variable = (const char*)attribute->name;
		map[variable] = value;
		xmlFree((void*)value);
	}
}

bool UGAMETimeOut::Unserialize(struct _xmlDoc* doc,const std::string& xp)
{
	if (!doc)
		return false;
	
	std::string xpath = "/counter_timeout";
	if (!xp.empty())
		xpath = xp + "/counter_timeout";

	{
		std::string xpathToUse = xpath + std::string("/default_range");
		xmlXPathContextPtr context = xmlXPathNewContext(doc);
		xmlXPathObjectPtr object = xmlXPathEvalExpression((xmlChar*)xpathToUse.c_str(), context);
		std::map<std::string,std::string> myMap;
		if (object && object->nodesetval && object->nodesetval->nodeNr>0) {
			xmlNodePtr node = object->nodesetval->nodeTab[0]; // use the first node for the default value
			GetNodeParameters(node,myMap);
			FillRange(myMap, mDefault);
		}
		xmlXPathFreeObject(object);
		xmlXPathFreeContext(context); 
	}

	{
		std::string xpathToUse = xpath + std::string("/range");
		xmlXPathContextPtr context = xmlXPathNewContext(doc);
		xmlXPathObjectPtr object = xmlXPathEvalExpression((xmlChar*)xpathToUse.c_str(), context);
		std::map<std::string,std::string> myMap;
		if (object && object->nodesetval && object->nodesetval->nodeNr>0) {
			xmlNodeSetPtr nodes = object->nodesetval;
			for (int i = 0; i < nodes->nodeNr; i++) {
				xmlNodePtr node = nodes->nodeTab[i]; // use the first node for the default value
				GetNodeParameters(node,myMap);
				Range range;
				FillRange(myMap, range);
				mRanges.push_back(range);
			}
		}
		xmlXPathFreeObject(object);
		xmlXPathFreeContext(context); 
	}
	return true;
}


void UGAMETimeOut::Update(float dt)
{

	float prevCounter = mCounter;

	mCounter-=dt;
	float scale = mDefault.mScale;
	osg::Vec4 color = mDefault.mColor;

	int number=(int)mCounter;
	if (number<0)
		number=0;

	// check if we have changed of number
	if (number!=(int)prevCounter) {
		mCounterFadeOut=1.0;
		if (mCallback.get())
			(*mCallback)(number);
	}

	float prev_scale= mDefault.mScale;

	int rangeSize = (int)mRanges.size();
	for (int i=0; i < rangeSize; i++) {
		const Range& range = mRanges[i];

		if (mCounter < range.mBegin && mCounter >= range.mEnd) {
			float ratioInRange = range.mBegin - range.mEnd;
			ratioInRange = (range.mBegin - mCounter) / ratioInRange;
			
			if (i > 0)
				prev_scale = mRanges[i-1].mScale;

			scale = prev_scale + ( range.mScale - prev_scale) * ratioInRange;
			color = range.mColor;
			break;
		}
	}

	mScale = scale;
	mColor = color;

	mCounterFadeOut -= dt;
	if (mCounterFadeOut<0) {
		mCounterFadeOut=0;
	}
}

void UGAMETimeOut::GetCounterAsIntString(std::string& res) const
{
	std::stringstream str;
	int number=(int)mCounter;
	if (number < 0)
		number = 0;
	str << number+1;
	res = str.str();
}
