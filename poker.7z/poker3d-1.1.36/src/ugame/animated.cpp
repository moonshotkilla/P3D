/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include "ugameStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifndef UGAME_USE_VS_PCH

#include <osg/PositionAttitudeTransform>

#include <cal3d/cal3d.h>
#include <cal3d/model.h>
#include <cal3d/scheduler.h>

#include <ugame/animated.h>
#include <maf/application.h>
#include <maf/data.h>
#endif

static std::string getCal3DError(void) {
  char tmp[32];
  sprintf(tmp, "%d", CalError::getLastErrorLine());
  std::string error = CalError::getLastErrorDescription() + " " +
    CalError::getLastErrorText() + " " +
    CalError::getLastErrorFile() + ":" + tmp;
  return error;
}

// Model

UGAMEAnimatedModel::UGAMEAnimatedModel() :
  mOsgCalModel(0)
{
}

UGAMEAnimatedModel::~UGAMEAnimatedModel()
{
}

void UGAMEAnimatedModel::Init()
{
  UGAMEArtefactModel::Init();
  g_assert(mOsgCalModel.get());

  _init();
}

void UGAMEAnimatedModel::_init()
{
  //	static int lastOutfit=0;

  // mixer
  CalScheduler* scheduler = new CalScheduler;
  scheduler->create(mOsgCalModel->getCalModel());

  mOsgCalModel->getCalModel()->setAbstractMixer(scheduler);
  mOsgCalModel->setUseColorOrTexture(false); // color and texture can be used simultaneously
  // create the calmodel from the calcoremodel
  //  osgCal::CoreModel* coreModel=mOsgCalModel->getCoreModel();

  // activate meshes

#if 0
  if (!mOsgCalModel->loadOutfit(mOutfit)) {

    // we can't manage a default outfit (because of male and female and so on). So if an outfit is not found
    // we use the first outfit from the list as default.
    // A better behaviour should be to try outfit from 0 to nb outfit if there is an error in the default outfit ( index 0)
    g_warning("UGAMEAnimatedModel::Init: outfit %s not found use the first instead",mOutfit.c_str());

		// use an incremental to show more than one outfit on a table
		//		mOutfit=coreModel->getOutfitNameByIndex(0);
		if (lastOutfit>=coreModel->getNbOutfits())
			lastOutfit=0;
		mOutfit=coreModel->getOutfitNameByIndex(lastOutfit++);

    if (!mOsgCalModel->loadOutfit(mOutfit))
      g_error("UGAMEAnimatedModel::Init can't load any outfit");
  }
#endif

  if(!mOsgCalModel->create())
    g_critical("UGAMEAnimatedModel::Init: create failed %s", getCal3DError().c_str());

  SetArtefact(mOsgCalModel.get());
}

void UGAMEAnimatedModel::reinit()
 {
  CalScheduler *oldScheduler = (CalScheduler*) mOsgCalModel->getCalModel()->getAbstractMixer();
	mOsgCalModel->getCalModel()->setAbstractMixer(NULL);
  if (oldScheduler)
    delete oldScheduler;

	osg::ref_ptr<osgCal::CoreModel> core = mOsgCalModel->getCoreModel();
  GetPAT()->removeChild(GetArtefact());

	mOsgCalModel = NULL;
  mOsgCalModel=new osgCal::Model();
  mOsgCalModel->setCoreModel(core.get());
  _init();
}

osgCal::Model* UGAMEAnimatedModel::GetArtefact()
{
  return mOsgCalModel.get();
}

CalCoreBone* UGAMEAnimatedModel::GetCoreBone(const std::string& name)
{
  g_assert(mOsgCalModel.get() != 0);
  g_assert(mOsgCalModel->getCalModel() != 0);
  g_assert(mOsgCalModel->getCalModel()->getSkeleton() != 0);
  g_assert(mOsgCalModel->getCalModel()->getSkeleton()->getCoreSkeleton() != 0);

  CalCoreSkeleton* skeleton = mOsgCalModel->getCalModel()->getSkeleton()->getCoreSkeleton();
  int id = skeleton->getCoreBoneId(name);
  return skeleton->getCoreBone(id);
}

int UGAMEAnimatedModel::GetCoreBoneId(const std::string& name)
{
  g_assert(mOsgCalModel.get() != 0);
  g_assert(mOsgCalModel->getCalModel() != 0);
  g_assert(mOsgCalModel->getCalModel()->getSkeleton() != 0);
  g_assert(mOsgCalModel->getCalModel()->getSkeleton()->getCoreSkeleton() != 0);

  return mOsgCalModel->getCalModel()->getSkeleton()->getCoreSkeleton()->getCoreBoneId(name);
}

CalBone* UGAMEAnimatedModel::GetBone(const std::string& name)
{
  g_assert(mOsgCalModel.get() != 0);
  g_assert(mOsgCalModel->getCalModel() != 0);
  g_assert(mOsgCalModel->getCalModel()->getSkeleton() != 0);
  g_assert(mOsgCalModel->getCalModel()->getSkeleton()->getCoreSkeleton() != 0);

  CalSkeleton* skeleton = mOsgCalModel->getCalModel()->getSkeleton();
  int id = skeleton->getCoreSkeleton()->getCoreBoneId(name);
  return skeleton->getBone(id);
}

CalModel* UGAMEAnimatedModel::GetCalModel(void) {
  g_assert(mOsgCalModel.get() != 0);
  return mOsgCalModel->getCalModel();
}

CalScheduler* UGAMEAnimatedModel::GetScheduler(void) {
  CalModel* model = GetCalModel();
  g_assert(model != 0);
  return (CalScheduler*)(model->getAbstractMixer());
}

CalCoreAnimation* UGAMEAnimatedModel::GetCoreAnimation(const std::string& name)
{
  return GetCoreAnimation(GetCoreAnimationId(name));
}

CalCoreAnimation* UGAMEAnimatedModel::GetCoreAnimation(int id)
{
  g_assert(mOsgCalModel.get() != 0);
  g_assert(mOsgCalModel->getCalCoreModel() != 0);
  return mOsgCalModel->getCalCoreModel()->getCoreAnimation(id);
}

double UGAMEAnimatedModel::GetDuration(int id)
{
  g_assert(id >= 0);
  g_assert(mOsgCalModel.get() != 0);
  g_assert(mOsgCalModel->getCalCoreModel() != 0);
  g_assert(mOsgCalModel->getCalCoreModel()->getCoreAnimation(id) != 0);
  return mOsgCalModel->getCalCoreModel()->getCoreAnimation(id)->getDuration();
}

double UGAMEAnimatedModel::GetDuration(const std::string& name)
{
  return GetDuration(GetCoreAnimationId(name));
}

int UGAMEAnimatedModel::GetCoreAnimationId(const std::string& name)
{
  g_assert(mOsgCalModel.get() != 0);
  g_assert(mOsgCalModel->getCalCoreModel() != 0);
  int a=mOsgCalModel->getCalCoreModel()->getCoreAnimationId(name);
  if (a<0) {
    g_critical("UGAMEAnimatedModel::GetCoreAnimationId id not found for animation %s",name.c_str());
  }
  return a;
}

UGAMEAnimatedModel::Drawables* UGAMEAnimatedModel::GetDrawables(const std::string& materialName)
{
  g_assert(mOsgCalModel.get() != 0);
  return mOsgCalModel->getDrawables(materialName);
}

osgCal::Model* UGAMEAnimatedModel::GetOsgCalModel()
{
	return mOsgCalModel.get();
}

void UGAMEAnimatedModel::SetOsgCalModel(osgCal::Model* model)
{
  mOsgCalModel = model;
}

// Controller

void UGAMEAnimatedController::Init( void ) 
{
  if(!GetModel())
    SetModel(new UGAMEAnimatedModel);
  UGAMEArtefactController::Init();
}
