/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */

#include <iostream>
#include <iomanip>
#include <map>

#ifdef _DEBUG // for Windows python23_d.lib is not in distribution... ugly but works
 #undef _DEBUG
 #include <Python.h>
 #define _DEBUG
#else
 #include <Python.h>
#endif


#include <libxml/tree.h>

#define UNDERWAREAPI_OUTFIT_INTERNAL
#include <pyunderware.h>

//#include <cal3d/scheduler.h>

#include <maf/mafexport.h>
#include <maf/maferror.h>
#include <maf/application.h>
#include <maf/scene.h>
#include <PokerOutfit.h>

#ifdef WIN32
#define VERSION_NAME(W) W
#define PYTHON_VERSION
#endif

class Outfit {
public:
  Outfit() : mOutfit(0), mSceneModel(0) {}

  osg::ref_ptr<PokerOutfitController> mOutfit;
  MAFSceneModel* mSceneModel;
};

//
//
// Outfit class
//
//

static void
Outfit_dealloc(Outfit_Object *self)
{
  std::cerr << "Outfit_dealloc" << std::endl;
  if(self->_Outfit) {
    delete self->_Outfit;
  }
  self->ob_type->tp_free((PyObject *)self);
}

static PyObject *
Outfit_new(PyTypeObject *type, PyObject *args, PyObject *kwds)
{
  Outfit_Object *self;

  assert(type != NULL && type->tp_alloc != NULL);

  self = (Outfit_Object*)type->tp_alloc(type, 0);

  if(self != NULL) {
    self->_Outfit = new Outfit();
  }

  return (PyObject*)self;
}

static char Outfit_create_doc[] =
"Constructor for the animation \n"
"\n";

static PyObject *
Outfit_create(Outfit_Object *self, PyObject *args)
{
  PyObject* application_object = 0;
  if(!PyArg_ParseTuple(args, "O:create", &application_object))
    return NULL;

  if(!MAFApplication_Check(application_object)) {
    PyErr_Format(PyExc_TypeError, "first argument must be an underware object");
    return 0;
  }

  MAFApplication_Object* application = (MAFApplication_Object*)application_object;

  PokerOutfitController* outfit = new PokerOutfitController(application->_MAFApplication);
  self->_Outfit->mOutfit = outfit;
  self->_Outfit->mSceneModel = application->_MAFApplication->GetScene()->GetModel();
  outfit->GetModel()->GetNode()->setNodeMask(0x0);
  application->_MAFApplication->GetScene()->GetModel()->mHUDBackground->addChild(outfit->GetModel()->GetNode());
  application->_MAFApplication->AddController(outfit);

  Py_INCREF(Py_None);
  return Py_None;
}

static char Outfit_uncreate_doc[] =
"Destructor for the animation \n"
"\n";
static PyObject *
Outfit_uncreate(Outfit_Object *self)
{
  if ( self->_Outfit->mOutfit.valid() ){
    MAFApplication* application = (MAFApplication*)  self->_Outfit->mOutfit->GetModel()->mApplication;

    application->GetScene()->GetModel()->mHUDBackground->removeChild(self->_Outfit->mOutfit->GetModel()->GetNode());
    application->RemoveController(self->_Outfit->mOutfit.get());
    self->_Outfit->mOutfit=0;
  }

  Py_INCREF(Py_None);
  return Py_None;
}

static char Outfit_hide_doc[] =
"Hide everything \n"
"\n";

static PyObject *
Outfit_hide(Outfit_Object *self, PyObject *args)
{
  self->_Outfit->mOutfit->Hide();
  
  Py_INCREF(Py_None);
  return Py_None;
}

static char Outfit_show_doc[] =
"Show everything \n"
"\n";

static PyObject *
Outfit_show(Outfit_Object *self, PyObject *args)
{
  self->_Outfit->mOutfit->Show();

  Py_INCREF(Py_None);
  return Py_None;
}

static char Outfit_set_sex_doc[] =
"Set Sex \n"
"\n";

static PyObject *
Outfit_set_sex(Outfit_Object *self, PyObject *args)
{
  char* sex;
  if(!PyArg_ParseTuple(args, "s:setSex", &sex))
    return NULL;

  self->_Outfit->mOutfit->SetSex(sex);
  
  Py_INCREF(Py_None);
  return Py_None;
}

static char Outfit_set_slot_doc[] =
"Set Slot \n"
"\n";

static PyObject *
Outfit_set_slot(Outfit_Object *self, PyObject *args)
{
  char* slot_type;
  char* slot_name;
  int slot_index;
  if(!PyArg_ParseTuple(args, "ssi:setSlot", &slot_type, &slot_name, &slot_index))
    return NULL;

  self->_Outfit->mOutfit->SetSlot(slot_type, slot_name, slot_index);
  
  Py_INCREF(Py_None);
  return Py_None;
}

static char Outfit_set_param_doc[] =
"Set Param \n"
"\n";

static PyObject *
Outfit_set_param(Outfit_Object *self, PyObject *args)
{
  char* parameter;
  char* name;
  int value;
  if(!PyArg_ParseTuple(args, "ssi:setParam", &parameter, &name, &value))
    return NULL;

  self->_Outfit->mOutfit->SetParam(parameter, name, value);
  
  Py_INCREF(Py_None);
  return Py_None;
}

static PyMethodDef Outfit_methods[] = {
  {"uncreate",	(PyCFunction)Outfit_uncreate, METH_VARARGS, Outfit_uncreate_doc},
  {"create",	(PyCFunction)Outfit_create, METH_VARARGS, Outfit_create_doc},
  {"hide",	(PyCFunction)Outfit_hide, METH_VARARGS, Outfit_hide_doc},
  {"show",	(PyCFunction)Outfit_show, METH_VARARGS, Outfit_show_doc},
  {"setSex",	(PyCFunction)Outfit_set_sex, METH_VARARGS, Outfit_set_sex_doc},
  {"setSlot",	(PyCFunction)Outfit_set_slot, METH_VARARGS, Outfit_set_slot_doc},
  {"setParam",	(PyCFunction)Outfit_set_param, METH_VARARGS, Outfit_set_param_doc},
  {NULL,	NULL}		/* sentinel */
};

static char Outfit_doc[] =
"Outfit object\n"
"\n";

static PyTypeObject outfit_Type = {
	PyObject_HEAD_INIT(&PyType_Type)
	0,
	"COutfit",                           	/* tp_name */	  
	sizeof(Outfit_Object),	     	/* tp_basicsize */
	0,				     	/* tp_itemsize */ 
	(destructor)Outfit_dealloc,		/* tp_dealloc */
	0,					/* tp_print */
	0,			 		/* tp_getattr (obsoleted by tp_getattro) */
	0,			 		/* tp_setattr (obsoleted by tp_setattro) */
	0,					/* tp_compare */
	0,					/* tp_repr */
	0,					/* tp_as_number */
	0,					/* tp_as_sequence */
	0,					/* tp_as_mapping */
	0,					/* tp_hash */
	0,					/* tp_call */
	0,					/* tp_str */
	0,					/* tp_getattro */
	0,					/* tp_setattro */
	0,					/* tp_as_buffer */
	Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE, /* tp_flags */
	Outfit_doc,				/* tp_doc */
	0,					/* tp_traverse */
	0,					/* tp_clear */
	0,					/* tp_richcompare */
	0,					/* tp_weaklistoffset */
	0,					/* tp_iter */
	0,					/* tp_iternext */
	Outfit_methods,			/* tp_methods */
	0,					/* tp_members */
	0,					/* tp_getset */
	0,					/* tp_base */
	0,					/* tp_dict */
	0,					/* tp_descr_get */
	0,					/* tp_descr_set */
	0,					/* tp_dictoffset */
	0,					/* tp_init */
	0,					/* tp_alloc */
	Outfit_new,				/* tp_new */
	0,					/* tp_free */
	0,					/* tp_is_gc */
	0,					/* tp_bases */
	0,					/* tp_mro */
	0,					/* tp_cache */
	0,					/* tp_subclasses */
	0					/* tp_weaklist */
};

//
//
// Module
//
//

static PyMethodDef outfit_methods[] = {
  {NULL, NULL, 0, NULL}
};

PyMODINIT_FUNC
VERSION_NAME(initc_outfit)(void)
{
  int index;
  PyObject *module;
  PyObject *dictionary;
  PyObject *apiobj;
  static void* c_api[UNDERWAREAPI_OUTFIT_NUMSLOTS];

  //
  // Declare methods, if any
  //
  if((module = Py_InitModule("c_outfit" PYTHON_VERSION, outfit_methods)) == NULL) {
    /* error */
    return;
  }

  if(PyType_Ready(&outfit_Type) < 0) return;
  
  dictionary = PyModule_GetDict(module);
  if(PyDict_SetItemString(dictionary, "COutfit", (PyObject*)&outfit_Type) < 0)
    return;

  index = 0;

  c_api[index++] = &outfit_Type;

  apiobj = PyCObject_FromVoidPtr(c_api, NULL);
  PyDict_SetItemString(dictionary, UNDERWAREAPI_LOCAL_ENTRY, apiobj);
  Py_DECREF(apiobj);

  import_underware_base();
  import_mafapplication();
}
