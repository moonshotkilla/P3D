/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */

#include <iostream>
#include <iomanip>
#include <map>

#ifdef _DEBUG // for Windows python23_d.lib is not in distribution... ugly but works
 #undef _DEBUG
 #include <Python.h>
 #define _DEBUG
#else
 #include <Python.h>
#endif

#include <pyunderware.h>

#include <maf/mafexport.h>
#include <maf/maferror.h>
#include <maf/application.h>
#include <PokerPlayer.h>

#ifdef WIN32
#define VERSION_NAME(W) W
#define PYTHON_VERSION
#endif

class LookCardState {
public:
	LookCardState() {}
	osg::ref_ptr<PokerPlayer> mPlayer;
};


//
//
// Animated class
//
//

static void
LookCardState_dealloc(LookCardState_Object *self)
{
  if(self->_Cards) {
    if(self->_Cards->mPlayer.valid())
      self->_Cards->mPlayer = 0;
    delete self->_Cards;
  }
  self->ob_type->tp_free((PyObject *)self);
}

static PyObject *
LookCardState_new(PyTypeObject *type, PyObject *args, PyObject *kwds)
{
  LookCardState_Object *self;

  assert(type != NULL && type->tp_alloc != NULL);

  self = (LookCardState_Object*)type->tp_alloc(type, 0);

  if(self != NULL) {
    self->_Cards = new LookCardState();
  }

  return (PyObject*)self;
}

static char LookCardState_setStartLookingCards_doc[] =
"Run animation \n"
"\n";

static PyObject *
LookCardState_setStartLookingCards(LookCardState_Object *self, PyObject *args)
{
  if(self->_Cards->mPlayer.valid()) {
		self->_Cards->mPlayer->SetStartLookingCards();
	}
  Py_INCREF(Py_None);
	return Py_None;
}

static char LookCardState_setLookingCards_doc[] =
"Stop animation \n"
"\n";

static PyObject *
LookCardState_setLookingCards(LookCardState_Object *self, PyObject *args)
{
  if(self->_Cards->mPlayer.valid()) {
		self->_Cards->mPlayer->SetLookingCards();
	}
  Py_INCREF(Py_None);
	return Py_None;
}

static char LookCardState_unsetLookingCards_doc[] =
"Stop animation \n"
"\n";

static PyObject *
LookCardState_unsetLookingCards(LookCardState_Object *self, PyObject *args)
{
  if(self->_Cards->mPlayer.valid()) {
		self->_Cards->mPlayer->UnsetLookingCards();
	}
  Py_INCREF(Py_None);
  return Py_None;
}

static char LookCardState_create_doc[] =
"Constructor for the animation \n"
"\n";

static PyObject *
LookCardState_create(LookCardState_Object *self, PyObject *args)
{
  PyObject* application_object = 0;
  char* name;
  if(!PyArg_ParseTuple(args, "Os:create", &application_object, &name))
    return NULL;

  if(!MAFApplication_Check(application_object)) {
    PyErr_Format(PyExc_TypeError, "first argument must be an underware object");
    return 0;
  }

  MAFApplication_Object* application = (MAFApplication_Object*)application_object;

  osg::Referenced* player = application->_MAFApplication->SearchPlayer(name);
  if(!player) {
    PyErr_Format(PyExc_LookupError, "no player matching %s in the application", name);
    return 0;
  }

  self->_Cards->mPlayer = dynamic_cast<PokerPlayer*>(player);
  
  Py_INCREF(Py_None);
  return Py_None;
}


static char LookCardState_destroy_doc[] =
"Destroy animation \n"
"\n";

static PyObject *
LookCardState_destroy(LookCardState_Object *self, PyObject *args)
{
	self->_Cards->mPlayer = 0;
  Py_INCREF(Py_None);
  return Py_None;
}



static PyMethodDef LookCardState_methods[] = {
  {"create",	(PyCFunction)LookCardState_create, METH_VARARGS, LookCardState_create_doc},
  {"destroy",	(PyCFunction)LookCardState_destroy, METH_VARARGS, LookCardState_destroy_doc},
  {"setStartLookingCards",	(PyCFunction)LookCardState_setStartLookingCards, METH_VARARGS, LookCardState_setStartLookingCards_doc},
  {"setLookingCards",	(PyCFunction)LookCardState_setLookingCards, METH_VARARGS, LookCardState_setLookingCards_doc},
  {"unsetLookingCards",	(PyCFunction)LookCardState_unsetLookingCards, METH_VARARGS, LookCardState_unsetLookingCards_doc},
  {NULL,	NULL}		/* sentinel */
};

static char LookCardState_doc[] =
"Animated object\n"
"\n";

static PyTypeObject lookcardstate_Type = {
	PyObject_HEAD_INIT(&PyType_Type)
	0,
	"CLookCardState",                           	/* tp_name */	  
	sizeof(LookCardState_Object),	     	/* tp_basicsize */
	0,				     	/* tp_itemsize */ 
	(destructor)LookCardState_dealloc,		/* tp_dealloc */
	0,					/* tp_print */
	0,			 		/* tp_getattr (obsoleted by tp_getattro) */
	0,			 		/* tp_setattr (obsoleted by tp_setattro) */
	0,					/* tp_compare */
	0,					/* tp_repr */
	0,					/* tp_as_number */
	0,					/* tp_as_sequence */
	0,					/* tp_as_mapping */
	0,					/* tp_hash */
	0,					/* tp_call */
	0,					/* tp_str */
	0,					/* tp_getattro */
	0,					/* tp_setattro */
	0,					/* tp_as_buffer */
	Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE, /* tp_flags */
	LookCardState_doc,				/* tp_doc */
	0,					/* tp_traverse */
	0,					/* tp_clear */
	0,					/* tp_richcompare */
	0,					/* tp_weaklistoffset */
	0,					/* tp_iter */
	0,					/* tp_iternext */
	LookCardState_methods,			/* tp_methods */
	0,					/* tp_members */
	0,					/* tp_getset */
	0,					/* tp_base */
	0,					/* tp_dict */
	0,					/* tp_descr_get */
	0,					/* tp_descr_set */
	0,					/* tp_dictoffset */
	0,					/* tp_init */
	0,					/* tp_alloc */
	LookCardState_new,				/* tp_new */
	0,					/* tp_free */
	0,					/* tp_is_gc */
	0,					/* tp_bases */
	0,					/* tp_mro */
	0,					/* tp_cache */
	0,					/* tp_subclasses */
	0					/* tp_weaklist */
};

//
//
// Module
//
//

static PyMethodDef lookcardstate_methods[] = {
  {NULL, NULL, 0, NULL}
};

PyMODINIT_FUNC
VERSION_NAME(initc_lookcardstate)(void)
{
  //int index;
  PyObject *module;
  PyObject *dictionary;
  PyObject *apiobj;
  static void* c_api[1];

  //
  // Declare methods, if any
  //
  if((module = Py_InitModule("c_lookcardstate" PYTHON_VERSION, lookcardstate_methods)) == NULL) {
    /* error */
    return;
  }

  if(PyType_Ready(&lookcardstate_Type) < 0) return;
  
  dictionary = PyModule_GetDict(module);
  if(PyDict_SetItemString(dictionary, "CLookCardState", (PyObject*)&lookcardstate_Type) < 0)
    return;

  c_api[0] = &lookcardstate_Type;

  apiobj = PyCObject_FromVoidPtr(c_api, NULL);
  PyDict_SetItemString(dictionary, UNDERWAREAPI_LOCAL_ENTRY, apiobj);
  Py_DECREF(apiobj);

  import_underware_base();
  import_mafapplication();
}
