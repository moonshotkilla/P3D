/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Loic Dachary <loic@gnu.org>
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#ifndef __POKERSTDAFX_H
#define __POKERSTDAFX_H

#ifdef POKER_USE_VS_PCH
#define NOMINMAX

#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <math.h>
#include <iostream>
#include <sstream>

#include <nprofile/profile.h>

#include <osg/AutoTransform>
#include <osg/BlendFunc>
#include <osg/CullFace>
#include <osg/Geode>
#include <osg/Group>
#include <osg/Material>
#include <osg/MatrixTransform>
#include <osg/PolygonOffset>
#include <osg/TexGen>
#include <osg/TexMat>
#include <osg/TextureCubeMap>

#include <maf/audio.h>
#include <maf/animate2d.h>
#include <maf/application.h>
#include <maf/application2d.h>
#include <maf/autoscale.h>
#include <maf/assert.h>
#include <maf/bezier.h>
#include <maf/billboard.h>
#include <maf/camera.h>
#include <maf/controller.h>
#include <maf/data.h>
#include <maf/depthmask.h>
#include <maf/glow_fx.h>
#include <maf/hit.h>
#include <maf/interpolator.h>
#include <maf/maferror.h>
#include <maf/model.h>
#include <maf/monitor.h>
#include <maf/mth_hermite.h>
#include <maf/MultipleAnimationPathCallback.h>
#include <maf/assert.h>
#include <maf/osghelper.h>
#include <maf/packets.h>
#include <maf/pbuffer.h>
#include <maf/scene.h>
#include <maf/shader.h>
#include <maf/shadow.h>
#include <maf/split.h>
#include <maf/timer.h>
#include <maf/utils.h>
#include <maf/view.h>
#include <maf/window.h>
#include <maf/wnc_desktop.h>
#include <maf/wnc_source.h>
#include <maf/textwriter.h>
#include <maf/billboard.h>
#include <maf/renderbin.h>

#include <varseditor/varseditor.h>

#include <ugame/animated.h>
#include <ugame/artefact.h>
#include <ugame/BetSlider>
#include <ugame/Bubble>
#include <ugame/debug.h>
#include <ugame/ugameerror.h>
#include <ugame/text.h>
#include <ugame/timeout.h>

#include <osgCal/CoreModel>
#include <osgCal/SubMeshHardware>
#include <osgCal/SubMeshSoftware>

#include <osgAL/SoundManager>
#include <osgAL/SoundRoot>

#include <osgchips/Stacks>

#include <osg/Depth>
#include <osg/Stencil>

#include "pokerexport.h"
#include "perlin_noise.h"

#include "Poker.h"
#include "PokerApplication.h"
#include "PokerApplication2d.h"
#include "PokerBubble.h"
#include "PokerBubbleManager.h"
#include "PokerBoard.h"
#include "PokerBody.h"
#include "PokerCamera.h"
#include "PokerCard.h"
#include "PokerChipsStack.h"
#include "PokerCursor.h"
#include "PokerDebug2D.h"
#include "PokerDoor.h"
#include "PokerError.h"
#include "PokerFoldAnimation.h"
#include "PokerHUD/PokerHUD.h"
#include "PokerInteractor.h"
#include "PokerMoveChips.h"
#include "PokerMultiTable.h"
#include "PokerNoise.h"
#include "PokerPlayer.h"
#include "PokerPlayerCamera.h"
#include "PokerPlayerTimeOut.h"
#include "PokerOutfit.h"
#include "PokerPot.h"
#include "PokerSeat.h"
#include "PokerSelectable.h"
#include "PokerSound.h"
#include "PokerShowDown.h"
#include "PokerSplashScreen.h"
#include "PokerToolTip.h"
#include "PokerSceneView.h"

#include <cal3d/corekeyframe.h>

#include <CustomAssert/CustomAssert.h>

#endif // WIN32

#endif // __POKERSTDAFX_H
