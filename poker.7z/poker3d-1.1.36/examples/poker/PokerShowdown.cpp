/*
 *
 * Copyright (C) 2007 Loic Dachary <loic@dachary.org>
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include "pokerStdAfx.h"
 
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */
#ifdef WIN32
#include <cstdio>
# define snprintf _snprintf
#endif

#ifndef POKER_USE_VS_PCH

#ifdef WIN32
#define NOMINMAX
#endif

#ifdef USE_NPROFILE
#include <nprofile/profile.h>
#else  //USE_NPROFILE
#define NPROFILE_SAMPLE(a)
#endif //USE_NPROFILE

#include <osg/AutoTransform>
#include <osg/BlendFunc>
#include <osg/CullFace>
#include <osg/Geode>
#include <osg/Group>
#include <osg/Material>
#include <osg/MatrixTransform>
#include <osg/TexMat>
#include <osg/PolygonOffset>

//#include <osgDB/WriteFile>

#include <maf/depthmask.h>
#include <maf/osghelper.h>
#include <maf/assert.h>
#include <maf/renderbin.h>

#include <varseditor/varseditor.h>
#include "PokerError.h"
#include "PokerApplication.h"
#include "PokerCard.h"
#include "PokerShowdown.h"

#include "PokerMultiTable.h"
#endif


    // static config parameters
float       PokerShowdownController::s_alphaFadeInFactor  = 1.0f;
float       PokerShowdownController::s_alphaStayDuration  = 1.0f;
float       PokerShowdownController::s_alphaFadeOutFactor = 1.0f;
float       PokerShowdownController::s_ScaleWon           = 1.5f;
float       PokerShowdownController::s_ScaleLost          = 1.0f;
float       PokerShowdownController::s_ExpandSpeedFactor  = 1.0f;
osg::Vec4   PokerShowdownController::s_ProjectorColorWon  = osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f);
osg::Vec4   PokerShowdownController::s_ProjectorColorLost = osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f);

static std::vector<int> g_ray_index_topleft;
static std::vector<int> g_ray_index_topright;
static std::vector<int> g_ray_index_bottomright;
static std::vector<int> g_ray_index_bottomleft;

osgUtil::RegisterRenderBinProxy s_registerFrontToBackSortedBinProxy("FrontToBackSortedBin",new osgUtil::RenderBin(osgUtil::RenderBin::SORT_FRONT_TO_BACK));

#define CARDS_MAX_ALPHA 0.8f

void CardsGroup::AddCards(PokerApplication* pGame, MAFOSGData* pData, unsigned int controllerID, int CardsCount, const std::string& strModelURL , const std::string& strAnchorTemplate, char cAnchorSide)
{
  g_assert(pGame);
  g_assert(pData);

  char tmp[128];

  for(int j = 0; j < CardsCount; j++) 
  {
    PokerCardController* card = new PokerCardController(pGame, strModelURL, controllerID);
		card->Visible(true);
		card->Fold();
		snprintf(tmp, sizeof(tmp), strAnchorTemplate.c_str(), cAnchorSide, j + 1);    

		MAFAnchor* anchor = pData->GetAnchor(tmp);
    anchor->setNodeMask(MAF_VISIBLE_MASK); // put it only visible else we can't hit interactors in some cases
    card->Anchor(anchor);

		PokerCardModel *model = card->GetModel();
		osg::Node *node = model->GetNode();
		osg::Geode *geode = GetGeode(node);
		//osg::MatrixTransform *mt = (osg::MatrixTransform*) geode->getParent(0);
  //  osg::Matrix mXform = mt->getMatrix();
  //  mXform = mXform * osg::Matrix::translate(0.0f, 0.0f, 0.01f*static_cast<float>(j));
  //  mt->setMatrix(mXform);

    // nudge cards bounding boxes to use BackToFront sort as a FrontToBack one on card groups only.

    std::vector<PokerShowdownBBoxBiasedGeom*> vectToAdd;

    for (unsigned int nDrawable = 0; nDrawable < geode->getNumDrawables(); ++nDrawable)
    {
      osg::Drawable* drawable = geode->getDrawable(nDrawable);
      osg::Geometry* pGeom = drawable->asGeometry();
      MAF_ASSERT(pGeom);
      PokerShowdownBBoxBiasedGeom* pBiasedGeom = new PokerShowdownBBoxBiasedGeom(*pGeom);
      float fZOffset = -0.01f*static_cast<float>(j);
      pBiasedGeom->SetOffset(osg::Vec3(0.0f, 0.0f, fZOffset));

      osg::StateSet* state = pBiasedGeom->getStateSet();
      g_assert(state != 0);

      osg::BlendFunc* bf = dynamic_cast<osg::BlendFunc*>(state->getAttribute(osg::StateAttribute::BLENDFUNC));
      if ( !bf ) bf = new osg::BlendFunc();            
		  bf->setFunction(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		  state->setAttributeAndModes(bf, osg::StateAttribute::ON);
      DepthMask* dm = dynamic_cast<DepthMask*>(state->getAttribute((osg::StateAttribute::Type)DEPTHMASK));
      if ( !dm ) dm = new DepthMask();
      dm->setWriteMask(true);
		  state->setAttributeAndModes(dm);

//	{
	//	int rbvalue;
		//if (!VarsEditor::Instance().Get("RB_ShowdownCards",rbvalue))
//			MAF_ASSERT(0 && "RB_ShowdownCards not found in client.xml");
  //    state->setRenderBinDetails(rbvalue, "DepthSortedBin");
	//}
			if (!MAFRenderBin::Instance().SetupRenderBin("ShowdownCards", state))
				MAF_ASSERT(0 && "ShowdownCards not found in client.xml");

      vectToAdd.push_back(pBiasedGeom);
    }

    while ( geode->getNumDrawables() )
    {
#if OSG_VERSION_MAJOR > 1 || ( OSG_VERSION_MAJOR == 1 && OSG_VERSION_MINOR >= 1 )
      geode->removeDrawables(0,1);
#else // OSG_VERSION_MAJOR > 1 || ( OSG_VERSION_MAJOR == 1 && OSG_VERSION_MINOR >= 1 )
      geode->removeDrawable(0,1);
#endif // OSG_VERSION_MAJOR > 1 || ( OSG_VERSION_MAJOR == 1 && OSG_VERSION_MINOR >= 1 )
    }

    for ( std::vector<PokerShowdownBBoxBiasedGeom*>::const_iterator it = vectToAdd.begin(); it != vectToAdd.end(); ++it)
    {
      geode->addDrawable(*it);
    }

    //geode->getOrCreateStateSet()->setAttributeAndModes(dp, osg::StateAttribute::ON);
    //geode->getOrCreateStateSet()->setRenderBinDetails(11, "DepthSortedBin", osg::StateSet::OVERRIDE_RENDERBIN_DETAILS);
    //geode->getOrCreateStateSet()->setRenderBinDetails(11, "FrontToBackSortedBin");

    m_Cards.push_back(card);

    m_nCardsCount = 0;
    m_nKnownCardsCount = 0;
  }
}

void CardsGroup::SetValues(const std::vector<int>& vCardValues)
{
  g_assert( vCardValues.size() <= m_Cards.size() );

  m_nKnownCardsCount = 0;

  for(unsigned int i = 0; i < vCardValues.size(); i++) 
  {
    m_Cards[i]->Receive();
    m_Cards[i]->SetValue(vCardValues[i]);

    if ( PokerDeck::IsKnownCard(vCardValues[i]) )
    {      
      m_nKnownCardsCount++;
    }
  } 

  for ( std::vector<int>::size_type nToHide = vCardValues.size(); nToHide < m_Cards.size(); ++nToHide )
  {
    m_Cards[nToHide]->Fold();
  }

  m_nCardsCount = vCardValues.size();  
}

void CardsGroup::Clear()
{
  for(Cards_it it = m_Cards.begin(); it !=  m_Cards.end(); ++it) 
  {
    PokerCardController* card = (*it).get();
    card->Fold();
    if ( card->GetModel()->GetArtefact() )
    {
      PokerShowdownController::SetColor(card->GetModel()->GetArtefact(), osg::Vec4(1.0,1.0,1.0,1.0));
    }
  }
  
  m_Glow.get()->setNodeMask(0);
  m_nCardsCount = 0;
  m_nKnownCardsCount = 0;
}

void CardsGroup::SetColor(const osg::Vec4& Color)
{
  //MAF_ASSERT(m_Glow.get());
  //PokerShowdownController::SetColor(m_Glow.get(), Color);

  m_Color = Color;

  ApplyColor(Color);
}

void CardsGroup::SetAlpha(const float& rAlpha)
{
  osg::Vec4 ColorAlphaed(m_Color.x(), m_Color.y(), m_Color.z(), std::min(std::max(0.0f, rAlpha), CARDS_MAX_ALPHA)); 

  ApplyColor(ColorAlphaed);
}

void CardsGroup::ApplyColor(const osg::Vec4& Color)
{
  for(Cards_it it = m_Cards.begin(); it !=  m_Cards.end(); ++it) 
  {
    PokerShowdownController::SetColor((*it).get()->GetModel()->GetArtefact(), Color);
  }
}

void CardsGroup::AddGlow(MAFOSGData* pSeatData, const std::string& strGlowTemplate, char AnchorSide)
{
  char tmp[128];
	snprintf(tmp, sizeof(tmp), strGlowTemplate.c_str(), AnchorSide);
  m_Glow = pSeatData->GetNode(tmp);
	MAF_ASSERT(m_Glow != 0);
	m_Glow->setNodeMask(0);
}

void CardsGroup::ShowCards(bool bShow)
{
  for (int nCard = 0; nCard < m_nCardsCount; ++nCard)
  {
    if ( bShow )
    {
      m_Cards[nCard]->Receive();
    }
    else
    {
      m_Cards[nCard]->Fold();
    }
  }
}  


PokerShowdownModel::PokerShowdownModel(PokerApplication *_game, MAFOSGData *_seatData,unsigned int controllerID) : mGame(_game)
{
  std::string sideNames[CARDS_SIZE] = { "high", "low" };
  char AnchorSides[CARDS_SIZE] = { 'p', 'q' };

	std::string glow_template   = mGame->HeaderGet("sequence", "/sequence/bestHand/@glow");
	std::string anchor_template = mGame->HeaderGet("sequence", "/sequence/bestHand/@anchor");
	std::string url             = mGame->HeaderGet("sequence", "/sequence/bestHand/@url");
	std::string count_string    = mGame->HeaderGet("sequence", "/sequence/bestHand/@count");
	int count = atoi(count_string.c_str());

	for(int i = 0; i < CARDS_SIZE; i++) 
  {
    mCardsGroup[i].AddCards(mGame, _seatData, controllerID, count, url, anchor_template, AnchorSides[i]);    
    mCardsGroup[i].AddGlow(_seatData, glow_template, AnchorSides[i]);
    mColors[i] = GetColorFromConfigFile(mGame, "/sequence/bestHand/" + sideNames[i] + "Color");
    mCardsGroup[i].SetColor(osg::Vec4(1.0f,1.0f,1.0f,1.0f)); // mColors[i]);
	}

  osg::Node* group = _seatData->GetNode("autotransform_showdown");
	//group->setName("PokerShowdown");
//	group->setNodeMask(0x2000 | MAF_VISIBLE_MASK);
	g_assert(group != 0);
	g_assert(group->asGroup() != 0);
	g_assert(group->asGroup()->asTransform() != 0);

	SetNode(group);

	mShowdownCardColor = GetColorFromConfigFile(mGame, "/sequence/bestHand/boardColor");


	// rescale cards if needed by linking them under scale transform node.
	osg::Group* myGrp = group->asGroup();
	g_assert(myGrp);
	mScaleTransform = new osg::MatrixTransform;	
	while ( myGrp->getNumChildren() ) 
  {
		mScaleTransform->addChild(myGrp->getChild(0));
		myGrp->removeChild(0,1);
	}
	myGrp->addChild(mScaleTransform);

  SetScale(1.0f);
}

void PokerShowdownModel::SetScale(float fScale)
{
  mScaleTransform->setMatrix(osg::Matrix::scale(fScale, fScale, fScale));
}

PokerShowdownModel::~PokerShowdownModel() 
{
}

void PokerShowdownModel::Init(void) { }

void PokerShowdownModel::SwapCardGroups()
{
 	CardsGroup& first  = mCardsGroup[0];
	CardsGroup& second = mCardsGroup[1];
  MAF_ASSERT(first.CardsCount() == second.CardsCount());

	for(int i = 0; i < first.CardsCount(); i++) 
  {
		int value = first.GetCard(i)->GetValue();
    first.GetCard(i)->SetValue(second.GetCard(i)->GetValue());
		second.GetCard(i)->SetValue(value);
	}

	osg::Vec4 color = first.GetColor();
  first.SetColor(second.GetColor());
	second.SetColor(color);
}


PokerShowdownController::PokerShowdownController(PokerApplication *_game, MAFOSGData *_seatData,unsigned int controllerID) : UGAMEArtefactController(controllerID)
{
  SetModel(new PokerShowdownModel(_game, _seatData,controllerID));
  Init();
  SetSelectable(true);

	m_game              = _game;
  m_showDownPlayer    = NULL;
  m_auto              = NULL;
  m_seatData          = _seatData;

  m_bFocused          = false;
  m_bWinner           = false;
  m_bProjectorActive  = false;
  m_bExpandProjector  = false;

  m_CurrentColor      = osg::Vec4(1.0f, 1.0f, 1.0f, 0.0f);
  m_TargetColor       = osg::Vec4(1.0f, 1.0f, 1.0f, 0.0f);
  m_CurrentScale      = 0.0f;
  m_TargetScale       = 0.0f;

  m_bProjectorEnabled = true;
  
  {
	  const std::string& lightray_url = _game->HeaderGet("sequence","/sequence/showdownProjector/@lightray");
    if (lightray_url.empty())
      g_error("PokerShowdownController::PokerShowdownController %s not found", lightray_url.c_str());

	  MAFESCNData *data = (MAFESCNData*) _game->mDatas->GetVision(lightray_url);
		osg::Geode *geode = GetGeode(data->GetGroup());
    if (!geode)
      g_error("PokerShowdownController::PokerShowdownController \"set/mesh_lightray.emsh\" not found");

    osg::Geometry *geom = (osg::Geometry*) geode->getDrawable(0);
	  osg::StateSet *ss = geom->getOrCreateStateSet();
	  ss->setMode(GL_LIGHTING, osg::StateAttribute::OFF);
    
	  osg::MatrixTransform *anchorL = (osg::MatrixTransform*) _seatData->GetNode("transform_persoHoloL");
		if (!anchorL)
      g_error("PokerShowdownController::PokerShowdownController \"transform_persoHoloL\" not found");

	  osg::MatrixTransform *anchorR = (osg::MatrixTransform*) _seatData->GetNode("transform_persoHoloR");
    if (!anchorR)
      g_error("PokerShowdownController::PokerShowdownController \"transform_persoHoloR\" not found");

	  for (int i = 0; i < 2; i++) 
    {
		  osg::Geode *geode = new osg::Geode();
      geode->setNodeMask(MAF_VISIBLE_MASK); // put it only visible else we can't hit interactors in some cases
		  m_lightRay[i] = geode;

      osg::MatrixTransform* anchorLR = (i == 0) ? anchorL : anchorR;
		  LightRayGeometry *gg = new LightRayGeometry(*geom, i, this, anchorLR, osg::CopyOp::DEEP_COPY_ALL);

      m_lrgeom[i] = gg;

			gg->setUseDisplayList(false);
		  geode->addDrawable( gg );

		  osg::StateSet *ss = new osg::StateSet( *geom->getOrCreateStateSet() );
		  gg->setStateSet(ss);

      osg::CullFace *cf = new osg::CullFace;
      ss->setAttributeAndModes(cf, osg::StateAttribute::ON);

		  osg::TexMat *texMat = new osg::TexMat();
		  m_lightRayProjMat[i][0] = texMat;
		  ss->setTextureAttributeAndModes(0, texMat);
		  texMat = new osg::TexMat();
		  m_lightRayProjMat[i][1] = texMat;
		  ss->setTextureAttributeAndModes(1, texMat);

		  osg::BlendFunc *bf = new osg::BlendFunc();
		  bf->setFunction(GL_SRC_ALPHA, GL_ONE);
		  ss->setAttributeAndModes(bf, osg::StateAttribute::ON);
			ss->setAttributeAndModes(new DepthMask(false));

		  osg::TexEnv *env;
		  env = new osg::TexEnv;
      env->setMode(osg::TexEnv::MODULATE);
		  ss->setTextureAttributeAndModes(0, env);
		  env = new osg::TexEnv;
      env->setMode(osg::TexEnv::MODULATE);
		  ss->setTextureAttributeAndModes(1, env);

		  osg::Material *newmat = new osg::Material();
		  ss->setAttributeAndModes(newmat, osg::StateAttribute::ON);
		  m_lightRayMaterial[i] = newmat;

		  anchorLR->addChild( geode );
      osg::Matrix mat = MAFComputeLocalToWorld( anchorLR );
      gg->m_invAttachedTo = osg::Matrix::inverse( mat );
	    gg->m_anchorPos = mat.getTrans();
	  }

		if (g_ray_index_topleft.size() == 0) {
		  osg::Vec3Array *arr = (osg::Vec3Array*) geom->getVertexArray();
			const osg::BoundingBox &box = geom->getBound();
		  OSGHelper_getPointsEqualTo(*arr, osg::Vec3(box._min[0], box._max[1], box._min[2]), g_ray_index_topleft );
		  OSGHelper_getPointsEqualTo(*arr, osg::Vec3(box._max[0], box._max[1], box._min[2]), g_ray_index_topright );
		  OSGHelper_getPointsEqualTo(*arr, osg::Vec3(box._max[0], box._max[1], box._max[2]), g_ray_index_bottomright );
		  OSGHelper_getPointsEqualTo(*arr, osg::Vec3(box._min[0], box._max[1], box._max[2]), g_ray_index_bottomleft );
	  }
  }

  PokerShowdownController::ReadStaticParametersFromConfigFile(_game);
}


void PokerShowdownController::ReadStaticParametersFromConfigFile(PokerApplication *_game)
{
  static bool bInitDone = false;
  if ( bInitDone ) return;

  const std::string& str_alphaFadeInFactor = _game->HeaderGet("sequence", "/sequence/showdownProjector/@fadeInDuration");
  if (!str_alphaFadeInFactor.empty())
    s_alphaFadeInFactor = 1.0f / atof(str_alphaFadeInFactor.c_str());

  const std::string& str_alphaFadeOutFactor = _game->HeaderGet("sequence", "/sequence/showdownProjector/@fadeOutDuration");
  if (!str_alphaFadeOutFactor.empty())
    s_alphaFadeOutFactor = 1.0f / atof(str_alphaFadeOutFactor.c_str());

  const std::string& str_alphaStayDuration = _game->HeaderGet("sequence", "/sequence/showdownProjector/@stayDuration");
  if (!str_alphaStayDuration.empty())
    s_alphaStayDuration = atof(str_alphaStayDuration.c_str());

  const std::string& strScaleLosingHand = _game->HeaderGet("sequence", "/sequence/bestHand/@scale_losing_hand");
	if (strScaleLosingHand.empty())
		g_error("PokerShowdownModel::PokerShowdownModel /sequence/bestHand/@scale_losing_hand not found");
	s_ScaleLost = atof(strScaleLosingHand.c_str());

	const std::string& strScaleWinningHand = _game->HeaderGet("sequence", "/sequence/bestHand/@scale_winning_hand");
	if (strScaleWinningHand.empty())
		g_error("PokerShowdownModel::PokerShowdownModel /sequence/bestHand/@scale_winning_hand not found");
	s_ScaleWon = atof(strScaleWinningHand.c_str());

 	const std::string& strExpandSpeedFactor = _game->HeaderGet("sequence", "/sequence/showdownProjector/@expand_speed_factor");
	if (strExpandSpeedFactor.empty())
		g_error("PokerShowdownModel::PokerShowdownModel /sequence/showdownProjector/@expand_speed_factor not found");
	s_ExpandSpeedFactor = atof(strScaleWinningHand.c_str());

  s_ProjectorColorWon  = PokerShowdownModel::GetColorFromConfigFile(_game, "/sequence/showdownProjector/wonColor");
  s_ProjectorColorLost = PokerShowdownModel::GetColorFromConfigFile(_game, "/sequence/showdownProjector/lostColor");

  bInitDone = true;
}


PokerShowdownController::~PokerShowdownController()
{
	osg::MatrixTransform *anchorL = (osg::MatrixTransform*) m_seatData->GetNode("transform_persoHoloL");
	anchorL->removeChild( m_lightRay[0] );

	osg::MatrixTransform *anchorR = (osg::MatrixTransform*) m_seatData->GetNode("transform_persoHoloR");
	anchorR->removeChild( m_lightRay[1] );
}

bool PokerShowdownController::Update(MAFApplication *_application)
{
	if(m_game->HasEvent())
		return true;

  m_bExpandProjector = m_bProjectorEnabled && m_bProjectorActive && HasKnownCards();

  //ShowCards( m_bWinner || (m_bFocused && HasCards()) );
  ShowCards( (m_CurrentColor.w() > 0.0f) && HasKnownCards() );

	float dt = GetDeltaFrame()*1.0f / 1000;
  
	PokerShowdownModel* model = GetModel();
	if( HasHighAndLowCards() )
  {
		UGAMEArtefactController::Update(_application);
		if( model->GetSelected() ) 
    {
      model->SwapCardGroups();
			model->SetSelected(false);
		}
	}

//	for (i = 0; i < PokerShowdownModel::CARDS_SIZE; i++) 
//  {
//		CardsGroup& cardsGroup = model->mCardsGroup[i];
//    for (j = 0; j < cardsGroup.CardsCount(); j++) 
//    {
//      PokerCardController *card = cardsGroup.GetCard(j);
//			if (!card->IsDisplayed())
//				continue;
//
////			osg::MatrixTransform *lastTransform = cardsGroup.mLastTransform[j];
////			osg::NodePath path;
////			MAFCreateNodePath(lastTransform, path);
//			/*
//			for (k = 0; k < path.size(); k++) {
//				osg::Node *node = path[k];
//				const std::string &name = node->getName();
//				if (name == "autotransform_showdown") {
//					path.erase(&path[k]);
//					break;
//				}
//			}
//*/
//			/*
//			osg::Node *node = lastTransform;
//			while(1) {
//				const std::string &name = node->getName();
//				if (name == "autotransform_showdown")
//					break;
//				path.push_back(node);
//				node = node->getParent(0);
//			}
//			std::reverse(path.begin(), path.end());
//			osg::Matrix cm = osg::computeLocalToWorld(path);
////			osg::Matrix cm = MAFComputeLocalToWorld(lastTransform); //, 0, 0);
//
//			//osg::Matrix cm = lastTransform->getMatrix();
//
//			PokerCardModel *model = card->GetModel();
//			MAFOSGData *data = model->GetData();
//			osg::BoundingBox bb = data->GetBound();
//
//			bFound_ = true;
//
////			osg::Vec3f cards_pts[] = {	osg::Vec3f(-6.42, 9.07, 0),
////										osg::Vec3f(6.42, 9.07, 0),
////										osg::Vec3f(6.42, -9.07, 0),
////										osg::Vec3f(-6.42, -9.07, 0) };
//
//			osg::Vec3f cards_pts[] = {	osg::Vec3f(bb._min._v[0], bb._max._v[1], 0),
//										osg::Vec3f(bb._max._v[0], bb._max._v[1], 0),
//										osg::Vec3f(bb._max._v[0], bb._min._v[1], 0),
//										osg::Vec3f(bb._min._v[0], bb._min._v[1], 0) };
//
//			for (k = 0; k < 4; k++) {
//				osg::Vec3f pt = cards_pts[k] * cm;
//
//				for (ii = 0; ii < 3; ii++) { 
//					if (pt._v[ii] < min_._v[ii])
//						min_._v[ii] = pt._v[ii];
//
//					if (pt._v[ii] > max_._v[ii])
//						max_._v[ii] = pt._v[ii];
//				}
//			}
//			*/
//		}
//	}

	/*
	if (bFound_) {
		osg::AutoTransform *grp = (osg::AutoTransform*) m_seatData->GetNode("autotransform_showdown");
		grp->setAutoRotateMode(osg::AutoTransform::ROTATE_TO_SCREEN);

		osg::Matrix matrix = MAFComputeLocalToWorld(grp);

		osg::Vec3f min = min_ * matrix;
		osg::Vec3f max = max_ * matrix;

		((osg::Vec3f&)(*m_arrayVertex)[0]) = osg::Vec3f( min._v[0], min._v[1], min._v[2] );
		((osg::Vec3f&)(*m_arrayVertex)[1]) = osg::Vec3f( max._v[0], min._v[1], min._v[2] );
		((osg::Vec3f&)(*m_arrayVertex)[2]) = osg::Vec3f( max._v[0], min._v[1], max._v[2] );
		((osg::Vec3f&)(*m_arrayVertex)[3]) = osg::Vec3f( min._v[0], min._v[1], max._v[2] );

		((osg::Vec3f&)(*m_arrayVertex)[4]) = osg::Vec3f( min._v[0], max._v[1], min._v[2] );
		((osg::Vec3f&)(*m_arrayVertex)[5]) = osg::Vec3f( max._v[0], max._v[1], min._v[2] );
		((osg::Vec3f&)(*m_arrayVertex)[6]) = osg::Vec3f( max._v[0], max._v[1], max._v[2] );
		((osg::Vec3f&)(*m_arrayVertex)[7]) = osg::Vec3f( min._v[0], max._v[1], max._v[2] );

		for (i = 0; i < 1; i++) {
			osg::Matrix texm;
			texm = osg::Matrix::translate(-0.5f, -0.5f, 0);
			texm = texm * osg::Matrix::rotate(m_textureAngle*0.33f, osg::Vec3(0, 0, 1) );
			texm = texm * osg::Matrix::translate(0.5f, 0.5f, 0);
			m_lightRayProjMat[i][0]->setMatrix(texm);

			texm = osg::Matrix::translate(-0.5f, -0.5f, 0);
			texm = texm * osg::Matrix::rotate(-m_textureAngle*0.25f, osg::Vec3(0, 0, 1) );
			texm = texm * osg::Matrix::translate(0.5f, 0.5f, 0);
			m_lightRayProjMat[i][1]->setMatrix(texm);
		}
	}
*/

  UpdateScale(dt);
  UpdateColor(dt);
  UpdateLightRayGeom();

  SetLightRayColor( m_CurrentColor );

  for ( int nSide = 0; nSide < PokerShowdownModel::CARDS_SIZE; ++nSide )
  {
    GetModel()->mCardsGroup[nSide].SetAlpha(m_CurrentColor.w());
    GetModel()->SetScale( m_CurrentScale );
  }

  // TEST_SinalWave(dt);

	return true;
}

void PokerShowdownController::UpdateScale(float dt)
{
  if ( m_bExpandProjector )
  {
    m_TargetScale = m_bWinner ? s_ScaleWon : s_ScaleLost;
  }
  else
  {
    m_TargetScale = 0.0f;
  }

  if ( fabsf(m_CurrentScale-m_TargetScale) < 0.01f )
  {
    m_CurrentScale = m_TargetScale;
  }
  else
  {
    m_CurrentScale += s_ExpandSpeedFactor*(m_TargetScale-m_CurrentScale)*dt;
  }
}

void PokerShowdownController::UpdateColor(float dt)
{
  if ( m_bExpandProjector )
  {
    m_TargetColor = m_bWinner ? s_ProjectorColorWon : s_ProjectorColorLost;
  }
  else
  {
    m_TargetColor.w() = 0.0f;
  }

  float rScaledDt = s_ExpandSpeedFactor*dt;

  m_CurrentColor.x() += (m_TargetColor.x()-m_CurrentColor.x())*rScaledDt;
  m_CurrentColor.y() += (m_TargetColor.y()-m_CurrentColor.y())*rScaledDt;
  m_CurrentColor.z() += (m_TargetColor.z()-m_CurrentColor.z())*rScaledDt;
  m_CurrentColor.w() += (m_TargetColor.w()-m_CurrentColor.w())*rScaledDt;
}


void PokerShowdownController::Reset(void)
{
	PokerShowdownModel* model = GetModel();
  
	for(int i = 0; i < PokerShowdownModel::CARDS_SIZE; i++) 
  {
    model->mCardsGroup[i].Clear();
	}
	ResetText();

  m_bFocused         = false;
  m_bWinner          = false;
  m_bProjectorActive = false;
  m_bExpandProjector = false;

  m_CurrentColor  = osg::Vec4(1.0f, 1.0f, 1.0f, 0.0f);
  m_TargetColor   = osg::Vec4(1.0f, 1.0f, 1.0f, 0.0f);
  m_CurrentScale  = 0.0f;
  m_TargetScale   = 0.0f;

	//if (m_game->GetPoker()->GetModel()->mBatchMode) 
 // {
	//	m_alpha = 0.0f;
	//	m_sensFade = 0;
	//}
}

void PokerShowdownController::ResetText()
{
	if (GetModel()->mHandValue.get())
		GetModel()->mHandValue->setText("");
}

void PokerShowdownController::TurnProjectorOn()
{
  m_bProjectorActive = true;
}

void PokerShowdownController::TurnProjectorOff()
{
  m_bProjectorActive = false;
}

void PokerShowdownController::SetCards(const std::string& side, std::vector<int> values)
{  
  PokerShowdownModel::Side side_int;

  if(side == "low")
    side_int = PokerShowdownModel::LOW;
  else 
    side_int = PokerShowdownModel::HIGH;

  GetModel()->mCardsGroup[side_int].SetValues(values);

  if ( !values.empty() )
  {    
    UpdateLightRayBoundaries(side_int);
  }
}

void PokerShowdownController::SetWinner(const std::string& handval)
{
  m_bWinner = true;

  if (GetModel()->mHandValue.get())
  {
    GetModel()->mHandValue->setText(handval);
  }
}


void PokerShowdownController::ResetWinner()
{
  m_bWinner = false;
}

//void PokerShowdownController::Set(const std::string& side, std::vector<int> values, const std::string& handval, bool bWinner)
//{
//  m_bWinner = bWinner;
//
//  PokerShowdownModel* model = GetModel();
//  PokerShowdownModel::Side side_int;
//
//  if (model->mHandValue.get())
//    model->mHandValue->setText(handval);
//
//  if(side == "low")
//    side_int = PokerShowdownModel::LOW;
//  else 
//    side_int = PokerShowdownModel::HIGH;
//
//  model->SetScale(bWinner ? m_ScaleWinningHand : m_ScaleLosingHand);
//  model->mCardsGroup[side_int].SetValues(values);
//
//  if ( !values.empty() )
//  {    
//    UpdateLightRayBoundaries(side_int);
//  }
//}

class AlterMaterialColor : public osg::NodeVisitor {
public:
  AlterMaterialColor(const osg::Vec4& color) : osg::NodeVisitor(osg::NodeVisitor::TRAVERSE_ALL_CHILDREN), mColor(color) {
    setNodeMaskOverride(MAF_VISIBLE_MASK | MAF_COLLISION_MASK);
  }

  virtual void apply(osg::Geode& geode) {
    unsigned int num_drawables = geode.getNumDrawables();
    g_assert(num_drawables == 1);
    osg::Drawable* drawable = geode.getDrawable(0);
    osg::StateSet* state = drawable->getStateSet();
    g_assert(state != 0);
    if(state) 
    {
      osg::Material* material = dynamic_cast<osg::Material*>(state->getAttribute(osg::StateAttribute::MATERIAL));
      if(!material) material = new osg::Material;
      material->setColorMode(osg::Material::DIFFUSE);
      material->setDiffuse(osg::Material::FRONT_AND_BACK, mColor);
      state->setAttributeAndModes(material, osg::StateAttribute::ON);
    }
  }

private:
  osg::Vec4 mColor;
};

void PokerShowdownController::SetColor(osg::Node* node, const osg::Vec4& color)
{
  AlterMaterialColor alter(color);
  node->accept(alter);
  node->setNodeMask(MAF_VISIBLE_MASK | MAF_COLLISION_MASK);
}

bool PokerShowdownController::HasCards()
{
  for (int nSide = 0; nSide < PokerShowdownModel::CARDS_SIZE; ++nSide)
  {
    if ( GetModel()->mCardsGroup[nSide].CardsCount() > 0 )
    {
      return true;
    }
  }

  return false;
}

bool PokerShowdownController::HasKnownCards()
{
  for (int nSide = 0; nSide < PokerShowdownModel::CARDS_SIZE; ++nSide)
  {
    if ( GetModel()->mCardsGroup[nSide].KnownCardsCount() > 0 )
    {
      return true;
    }
  }

  return false;
}

bool PokerShowdownController::HasHighAndLowCards()
{
  return (GetModel()->mCardsGroup[PokerShowdownModel::LOW].CardsCount() > 0 && GetModel()->mCardsGroup[PokerShowdownModel::HIGH].CardsCount() > 0);
}

void PokerShowdownController::ShowCards(bool bShow)
{
	for(int i = 0; i < PokerShowdownModel::CARDS_SIZE; i++) 
  {
    GetModel()->mCardsGroup[i].ShowCards(bShow);
	}
}

void PokerShowdownController::BypassFade()
{
  m_CurrentColor = m_TargetColor;
  m_CurrentScale = m_TargetScale;
//m_alpha = m_sensFade ? 1.0f : 0.0f;
}


//void PokerShowdownController::UpdateAlpha(float dt)
//{
//  if (m_sensFade)
//  {
//    m_alpha += dt * m_alphaFadeInFactor;
//    if ( m_alpha >= 1.0f )
//    {
//      m_Stay = m_alphaStayDuration;
//      m_alpha = 1.0f;
//      if ( !m_bFocused )
//        m_sensFade = 0;
//    }
//  }
//  else
//  {
//    if ( m_Stay > 0.0f )
//    {
//      m_Stay -= dt;
//      m_Stay = std::max(m_Stay, 0.0f);
//    }
//    else
//    {
//      m_alpha -= dt * m_alphaFadeOutFactor;
//      m_alpha = std::max(m_alpha, 0.0f);
//    }
//  }
//}


void PokerShowdownController::UpdateLightRayBoundaries(PokerShowdownModel::Side side)
{
  CardsGroup& Group = GetModel()->mCardsGroup[side];
  g_assert(Group.CardsCount() > 0);

  osg::Vec3f cards_pts[] = 
  {	osg::Vec3f(-6.42*1.0f,  9.07*1.0f, 0),
    osg::Vec3f( 6.42*1.0f,  9.07*1.0f, 0),
    osg::Vec3f( 6.42*1.0f, -9.07*1.0f, 0),
    osg::Vec3f(-6.42*1.0f, -9.07*1.0f, 0), 
  };

  PokerCardModel* FirstCardModel  = Group.GetCard(0)->GetModel();
  PokerCardModel* LastCardModel   = Group.GetCard(Group.CardsCount()-1)->GetModel();
  osg::Matrix FirstCardMatrix = static_cast<osg::MatrixTransform*>(FirstCardModel->GetNode()->getParent(0))->getMatrix();
  osg::Matrix LastCardMatrix  = static_cast<osg::MatrixTransform*>(LastCardModel->GetNode()->getParent(0))->getMatrix();

  m_cardsHull[0] = cards_pts[0] * FirstCardMatrix ;
  m_cardsHull[1] = cards_pts[1] * LastCardMatrix  ;
  m_cardsHull[2] = cards_pts[2] * LastCardMatrix  ;
  m_cardsHull[3] = cards_pts[3] * FirstCardMatrix ;
}


void PokerShowdownController::UpdateLightRayGeom()
{
  if (!m_auto) 
  {
    osg::MatrixTransform *transFormBy = (osg::MatrixTransform*) GetModel()->mCardsGroup[PokerShowdownModel::HIGH].GetCard(0)->GetModel()->GetNode()->getParent(0);
    m_auto = (osg::AutoTransform*) transFormBy->getParent(0);
  }

  osg::Matrix mat = MAFComputeLocalToWorld( m_auto );

  osg::Vec3f ws_card_topleft      = m_cardsHull[0] * mat;
  osg::Vec3f ws_card_topright     = m_cardsHull[1] * mat;
  osg::Vec3f ws_card_bottomright  = m_cardsHull[2] * mat;
  osg::Vec3f ws_card_bottomleft   = m_cardsHull[3] * mat;

  osg::Plane plane = osg::Plane(ws_card_topleft, ws_card_topright, ws_card_bottomright);

  for (int i = 0; i < 2; i++) 
  {
    //osg::Matrix texm;
    //texm = osg::Matrix::translate(-0.5f, -0.5f, 0);
    //texm = texm * osg::Matrix::rotate( m_textureAngle*0.33f, osg::Vec3(0, 0, 1) );
    //texm = texm * osg::Matrix::translate(0.5f, 0.5f, 0);
    //m_lightRayProjMat[i][0]->setMatrix(texm);

    //texm = osg::Matrix::translate(-0.5f, -0.5f, 0);
    //texm = texm * osg::Matrix::rotate(-m_textureAngle*0.25f, osg::Vec3(0, 0, 1) );
    //texm = texm * osg::Matrix::translate(0.5f, 0.5f, 0);
    //m_lightRayProjMat[i][1]->setMatrix(texm);

    LightRayGeometry *geom = m_lrgeom[i];
    osg::CullFace *cf = (osg::CullFace*) geom->getOrCreateStateSet()->getAttribute(osg::StateAttribute::CULLFACE);

	  geom->dirtyBound();
    geom->m_cardsHull[0] = ws_card_topleft;
    geom->m_cardsHull[1] = ws_card_topright;
    geom->m_cardsHull[2] = ws_card_bottomright;
    geom->m_cardsHull[3] = ws_card_bottomleft;

    if (plane.distance( geom->m_anchorPos ) > 0) 
    {
      //OutputDebugStr("devant\n");
      cf->setMode(osg::CullFace::BACK);
    }
    else 
    {
      //OutputDebugStr("derriere\n");
      cf->setMode(osg::CullFace::BACK);
    }
  }
}

void PokerShowdownController::SetLightRayColor(const osg::Vec4& Color)
{
  m_lightRayMaterial[0]->setDiffuse( osg::Material::FRONT_AND_BACK, Color );
  m_lightRayMaterial[1]->setDiffuse( osg::Material::FRONT_AND_BACK, Color );
}

#if OSG_VERSION_MAJOR != 2
void PokerShowdownController::LightRayGeometry::drawImplementation(osg::State &arg) const
#else // OSG_VERSION_MAJOR != 2
void PokerShowdownController::LightRayGeometry::drawImplementation(osg::RenderInfo &arg) const
#endif  // OSG_VERSION_MAJOR != 2
{
  NPROFILE_SAMPLE("PokerShowdownController::drawImplementation");
//	int iCard = m_rayIndex;
//	if (!m_cardGroupToProject)
	//	return;

  if (m_showdown->m_CurrentColor.w() <= 0.0f)
    return;

	osg::Geometry *geom = (osg::Geometry*) this;
	osg::Array *arr = geom->getVertexArray();
	osg::Vec3f *data = (osg::Vec3f*) arr->getDataPointer();

	//osg::MatrixTransform *lastTransfomOfTheCard = m_cardGroupToProject->mLastTransform[m_iCardToProject];
	//osg::MatrixTransform *lastTransfomOfTheCard = m_cardGroupToProject->getNode();
//	osg::Node *lastTransfomOfTheCard = m_cardGroupToProject->GetModel()->GetNode();
	//osg::Matrix mat = MAFComputeLocalToWorld(lastTransfomOfTheCard);

  //osg::Matrix mat = MAFComputeLocalToWorld( m_showdown->m_auto ); // * m_invAttachedTo;

//	osg::Vec3f cards_pts[] = {	osg::Vec3f(-6.42, 9.07, 0),
	//							osg::Vec3f(6.42, 9.07, 0),
		//						osg::Vec3f(6.42, -9.07, 0),
			//					osg::Vec3f(-6.42, -9.07, 0) };

  osg::Matrix mm = osg::Matrix::inverse( MAFComputeLocalToWorld( m_attachedTo ) );

	osg::Vec3f card_topleft = m_cardsHull[0] * mm;
	osg::Vec3f card_topright = m_cardsHull[1] * mm;
	osg::Vec3f card_bottomright = m_cardsHull[2] * mm;
	osg::Vec3f card_bottomleft = m_cardsHull[3] * mm;


	// top left
	{
		std::vector<int> &vec = g_ray_index_topleft;
		int nb = vec.size();
		for (int i = 0; i < nb; i++) {
			int ii = vec[i];
			osg::Vec3f *p = &data[ii];
			*p = card_topleft;
		}
	}

	// top right
	{
		std::vector<int> &vec = g_ray_index_topright;
		int nb = vec.size();
		for (int i = 0; i < nb; i++) {
			int ii = vec[i];
			osg::Vec3f *p = &data[ii];
			*p = card_topright;
		}
	}

	// bottom right
	{
		std::vector<int> &vec = g_ray_index_bottomright;
		int nb = vec.size();
		for (int i = 0; i < nb; i++) {
			int ii = vec[i];
			osg::Vec3f *p = &data[ii];
			*p = card_bottomright;
		}
	}

	// bottom left
	{
		std::vector<int> &vec = g_ray_index_bottomleft;
		int nb = vec.size();
		for (int i = 0; i < nb; i++) {
			int ii = vec[i];
			osg::Vec3f *p = &data[ii];
			*p = card_bottomleft;
		}
	}

	Geometry::drawImplementation(arg);
}


osg::Vec4 PokerShowdownModel::GetColorFromConfigFile(PokerApplication* pGame, const std::string& strXMLurl)
{
  std::map<std::string,std::string> color_string = pGame->HeaderGetProperties("sequence", strXMLurl);
  osg::Vec4 Color;
  Color.x() = atof(color_string["red"].c_str())   / 255.0f;
  Color.y() = atof(color_string["green"].c_str()) / 255.0f;
	Color.z() = atof(color_string["blue"].c_str())  / 255.0f;
  if ( color_string.find("alpha") != color_string.end() )
  {
    Color.w() = atof(color_string["alpha"].c_str())  / 255.0f;
  }
  else
  {
	  Color.w() = 1.0f;
  }

  return Color;
}

void PokerShowdownController::TEST_SinalWave(float dt)
{
  static float rTime = 0.0f;
  rTime += 0.5f*dt;

  ShowCards( HasCards() );
  float rScale = 0.5f*(sinf(rTime) + 1.0f);

  GetModel()->SetScale(rScale);
  GetModel()->mCardsGroup[0].SetAlpha(rScale);
  GetModel()->mCardsGroup[1].SetAlpha(rScale);
  SetLightRayColor( osg::Vec4(1.0f, 1.0f, 1.0f, rScale) );
}

void PokerShowdownController::EnableProjector()
{
  m_bProjectorEnabled = true;
}

void PokerShowdownController::DisableProjector()
{
  m_bProjectorEnabled = false;
}
