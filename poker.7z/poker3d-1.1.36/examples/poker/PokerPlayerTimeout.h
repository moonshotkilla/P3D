/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#ifndef _pokerplayertimeout_h
#define _pokerplayertimeout_h

#include <ugame/timeout.h>
#include <ugame/text.h>
#include <maf/controller.h>
#include <osg/Geometry>

class PokerApplication;
class MAFOSGData;

class PokerPlayerTimeout : public MAFController
{
	osg::ref_ptr<UGAMEShadowedText> mTimerThirdPerson;

	osg::ref_ptr<UGAMEBasicText> mTimerFirstPerson;
	osg::ref_ptr<osg::Geometry> mFirstPersonButton;
	osg::ref_ptr<osg::Group> mFirstPersonGroup;

	osg::ref_ptr<UGAMETimeOut> mTimeout;

	bool mFirstPerson;
	bool mDisable;

protected:

	~PokerPlayerTimeout();

public:

	PokerPlayerTimeout(PokerApplication* game, MAFOSGData* seatData, UGAMETimeOut *);

	bool Update(MAFApplication* game);

	UGAMETimeOut* GetTimeOut() { return mTimeout.get(); }

	void Disable();
	void Start();

	void SetFirstPerson(bool state);
};


#endif

