#
# Copyright (C) 2005, 2006 Mekensleep
#
# Mekensleep
# 24 rue vieille du temple
# 75004 Paris
#       licensing@mekensleep.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301, USA.
#
# Authors:
#  Loic Dachary <loic@gnu.org>
#
from pokernetwork import pokernetworkconfig
from poker.version import version

class Config(pokernetworkconfig.Config):

    upgrades_repository = None
    pokernetwork_upgrades_repository = None
    verbose = 0

    def __init__(self, *args, **kwargs):
        pokernetworkconfig.Config.upgrades_repository = Config.pokernetwork_upgrades_repository
        pokernetworkconfig.Config.__init__(self, *args, **kwargs)
        self.version = version

    def load(self, path):
        status = pokernetworkconfig.Config.load(self, path)
        if Config.upgrades_repository:
            if self.checkVersion("poker3d_version", version, Config.upgrades_repository):
                return status
            else:
                return False
        else:
            return status
