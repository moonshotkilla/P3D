/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Johan Euphrosine <johan@mekensleep.com>
 *  Cedric Pinson <cpinson@freesheep.org>
 *  Igor Kravtchenko <igor@tsarevitch.org>
 */

#ifndef __POKERBODY_H
#define __POKERBODY_H

#ifndef POKER_USE_VS_PCH
#include <ugame/animated.h>
#include <vector>
#include <string>

#include <cal3d/scheduler.h>
#include "perlin_noise.h"

#include <maf/depthmask.h>

#include <osg/TexMat>
#include <osg/ShapeDrawable>

#include "pokerexport.h"
#endif

class MAFVisionData;
class CardStartLooking;
class CardEndLooking;
class CardFolding;
class osg::Drawable;
class PokerDeck;
class NoiseElement;
class PlayFoldAnimation;
class PokerFoldAnimation;
class MAFAudioController;
class PokerApplication;


class POKER_EXPORT PokerBodyModel : public UGAMEAnimatedModel
{  
  struct CardEntry {
    osg::ref_ptr<osg::Drawable> back;
    osg::ref_ptr<osg::Drawable> front;
  };


  std::map<int,std::string> mAnimation2Sounds;

 public:
  PlayFoldAnimation* mFoldAnimation; 
  PokerFoldAnimation* mFoldSequence;

	bool mbPlayFoldAnimation;

  PokerBodyModel(MAFApplication* application,MAFOSGData* seat, bool me);
  virtual ~PokerBodyModel();
  virtual void Init();

  // to be called from a python packet
  // animation is the animation fold selected by the python side
  void PlayFold(const std::string& foldAnimation);

  void ShowCard(int i);
  void HideCard(int i);
  void PlayBreath(float time);
  void PlayBlink();
  void PlayLookAt(const osg::Vec3& directionOfPlayerorigin,
                  const osg::Vec3& positionOfPlayer, 
                  const osg::Vec3& target);
  void PlayLookAt(const osg::Vec3& origin, const osg::Vec3& target);
  void BuildQuaternionFromTarget(const osg::Vec3& _origin, const osg::Vec3& _target,CalQuaternion& _result);
  void BuildQuaternionFromTarget(const osg::Vec3& _dir,const osg::Vec3& _origin, const osg::Vec3& _target,CalQuaternion& _result);
  void PlayFacialNoise();
  void StopFacialNoise();
  void Stop();
  void StopAll();
  void InitCardsOfPlayer();
  void DettachCardsDrawableToPlayer();
  void UpdateCardsOfPlayer(const std::vector<int>& cards);
  void DisableCurrentAnimationCallback(const std::string &name);
  void DisableCurrentAnimationCallback(int id);
  void EnableAnimations(void) { mAnimationsEnabled = true; }
  void DisableAnimations(void) { mAnimationsEnabled = false; }
  int GetNbCardsDisplayed();

  bool mMe;
  bool mLoopBreath;
  CardFolding *mFoldCards;
  std::vector<CardEntry> mCards;
  PokerDeck* mDeck;
  int mNbCardsToPlay;
  std::string mDataPath;
  int mLookatId;
  std::vector<NoiseElement*> mNoiseAnimations;
  std::string mFocus;
  float mMinAlpha;
  float mAngleAlpha;
  float mCurrentAlpha;
	bool mForceTransparencyRenderBin;
  bool mAnimationsEnabled;
  int mNumberOfCardsReady; // number of cards the player have to play

	std::map<osg::StateSet*, bool> mOriginallyTransparent;

  osg::ref_ptr<osg::TexMat> texmatEyes_;

	osg::ref_ptr<DepthMask> dmask_;

  osgCal::Model *newModelForTableShadow_;

  std::vector<std::string> mEyesMeshName;

	std::map<osg::StateSet *, bool> mCardsTable;

	osg::ShapeDrawable *mSH;

  void SetAlpha(float alpha);
  float GetAlpha() const { return mCurrentAlpha;}
  float ComputeAlphaFromDirection(const osg::Vec3 camDirection);

	bool GetForceTransparencyRenderBin() const { return mForceTransparencyRenderBin; }
	void SetForceTransparencyRenderBin(bool _b) { mForceTransparencyRenderBin = _b; }

  int IsPlayingAnimationList(const std::vector<std::string, std::allocator<std::string> >&);
  void StopAnimationList(const std::vector<std::string>& animationlist);
  void BuildAnimationSoundMap(MAFAudioSourceController* source);
  void SetupTextureCardsForLookingCards();
};

//Controller

class PokerBodyController : public UGAMEAnimatedController
{
 protected:

  ~PokerBodyController();

 public:

  PokerBodyController(MAFApplication* application,MAFOSGData* seat,unsigned int controllerID, bool me);
  PokerBodyModel *GetModel() { return static_cast<PokerBodyModel *>(UGAMEAnimatedController::GetModel()); }

  void HandleHit(MAFHit& hit);
  bool Update(MAFApplication* application);
  void SetMe(bool value) { GetModel()->mMe = value; }
  void SetDeck(PokerDeck *deck) { GetModel()->mDeck = deck; }
  void SetNbCards(int i) { GetModel()->mNbCardsToPlay = i; }
  int GetNbCards() { return GetModel()->mNbCardsToPlay; }
  void SetDataPath(const std::string &data) { GetModel()->mDataPath = data; }
  void PlayBreath(float time) { GetModel()->PlayBreath(time); }
  void PlayBlink() { GetModel()->PlayBlink(); }
  void PlayLookAt(const osg::Vec3& directionOfPlayerorigin,
		  const osg::Vec3& positionOfPlayer, 
		    const osg::Vec3& target) { GetModel()->PlayLookAt(directionOfPlayerorigin, positionOfPlayer, target); }
  void PlayLookAt(const osg::Vec3& origin, const osg::Vec3& target) { GetModel()->PlayLookAt(origin, target); }
  void PlayFacialNoise() { GetModel()->PlayFacialNoise(); }
  void StopFacialNoise() { GetModel()->StopFacialNoise(); }
  void StopAll() { GetModel()->StopAll(); }
  void InitCardsOfPlayer() { GetModel()->InitCardsOfPlayer(); }
  void DettachCardsDrawableToPlayer() { GetModel()->DettachCardsDrawableToPlayer(); }
  void UpdateCardsOfPlayer(const std::vector<int>& cards) { GetModel()->UpdateCardsOfPlayer(cards); }
  void DisableCurrentAnimationCallback(const std::string &name) { GetModel()->DisableCurrentAnimationCallback(name); }
  void DisableCurrentAnimationCallback(int id) { GetModel()->DisableCurrentAnimationCallback(id); }
  const std::string &GetFocus() { return GetModel()->mFocus; }
  void AddTimeSitIn(float time);
  void AddTimeSitOut(float time);
  void AddTimeSit(int id, float time);
  void PlayGetPot();
	virtual const char* GetControllerName() const { return "PokerBodyController"; }
};



class PlayFoldAnimation : public CalScheduler::StopCallback
{
 protected:
  PokerBodyModel* mBody;

 public:
  PlayFoldAnimation(PokerBodyModel* body):mBody(body) {}
  void process(CalModel* model, CalAnimationAlt* animation);
};


class CardFolding : public CalScheduler::StopCallback
{
  PokerBodyModel* mBody;
 public:
  CardFolding(PokerBodyModel* body);
  void Fold();
  void process(CalModel* model, CalAnimationAlt* animation);
};

class PokerPlayer;
class PokerMoveChipsBase;
class GetPotAfterWin : public CalScheduler::StopCallback
{
 protected:
  PokerPlayer* mPlayer;
  PokerMoveChipsBase* mChips;
  std::vector<int> mAmount;
 public:
  GetPotAfterWin(PokerPlayer* player,PokerMoveChipsBase* chips,const std::vector<int>& amount);
  void process(CalModel* model, CalAnimationAlt* animation);
};

#endif // __POKERBODY_H
