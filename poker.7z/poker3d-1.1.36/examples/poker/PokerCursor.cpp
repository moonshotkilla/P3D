/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include "pokerStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */
#ifdef WIN32
#include <cstdio>
# define snprintf _snprintf
#endif


#ifndef POKER_USE_VS_PCH
#include <PokerCursor.h>
#include <Poker.h>
#include <maf/cursor.h>
#include <maf/window.h>
#include <maf/maferror.h>

#include <osg/Node>
#endif


PokerCursor::PokerCursor(PokerApplication* game):mGame(game),
						 mCurrentCursor("normal"),
						 mCurrentCursorPrevious("normal")
{
}

PokerCursor::~PokerCursor()
{
  if (mGame->GetCursor()==mCursor.get())
    mGame->SetCursor(0);
  mCursor=0;
}


void PokerCursor::Init()
{
  //  MAFCursorModel* amodel=0;
  // select if the cursor is system or in GL
  //  const std::string &prefermouse = mGame->HeaderGet("sequence", "/sequence/cursor/@hardwarecursor");
	MAFCursorController* controller = new MAFCursorController();
//   if (prefermouse=="yes") {
//     {
// 			MAFCursorModelGL* model = new MAFCursorModelGL(mGame);
// 			const std::string &mouseUrl = mGame->HeaderGet("sequence", "/sequence/mouse/@url");
// 			const std::string &mouseName = mGame->HeaderGet("sequence", "/sequence/mouse/@name");
// 			MAFVisionData *visionData = mGame->mDatas->GetVision(mouseUrl);
// 			//		visionData=(MAFVisionData *)visionData->Clone(LEVEL_CLONE_SETTING);
// 			g_assert(visionData);
// 			MAFOSGData* mouseData =  dynamic_cast<MAFOSGData *>(visionData);
// 			g_assert(mouseData);
// 			osg::Node* cursorGL = mouseData->GetNode(mouseName);
// 			g_assert(cursorGL);
// 			model->mCursors.push_back(cursorGL);
// 			controller->mModels.push_back(model);
//     }

//     {
// 			MAFCursorModelGL* model = new MAFCursorModelGL(mGame);
// 			const std::string &mouseUrl = mGame->HeaderGet("sequence", "/sequence/mouse/@sitoutUrl");
// 			const std::string &mouseName = mGame->HeaderGet("sequence", "/sequence/mouse/@sitoutName");
// 			MAFVisionData *visionData = mGame->mDatas->GetVision(mouseUrl);
// 			//		visionData=(MAFVisionData *)visionData->Clone(LEVEL_CLONE_SETTING);
// 			g_assert(visionData);
// 			MAFOSGData* mouseData =  dynamic_cast<MAFOSGData *>(visionData);
// 			g_assert(mouseData);
// 			osg::Node* cursorGL = mouseData->GetNode(mouseName);
// 			g_assert(cursorGL);
// 			model->mCursors.push_back(cursorGL);
// 			controller->mModels.push_back(model);
//     }

//   } else {
// 		if (0)
//     {
// 			MAFCursorModelSDL* model = new MAFCursorModelSDL;
// 			const std::string &cursorUrl = mGame->HeaderGet("sequence", "/sequence/cursor/@url");
// 			MAFCursorData* cursor;
// 			cursor = mGame->mDatas->GetCursor(cursorUrl);
// 			if (!cursor) {
// 				g_debug("Cursor /sequence/cursor/@url not found %s",cursorUrl.c_str());
// 				assert(0);
// 			}
// 			SDL_Cursor* mouseData = cursor->GetOrCreateCursor();
// 			g_assert(mouseData);
// 			model->mCursors.push_back(mouseData);
// 			controller->mModels.push_back(model);			
//     }

//     {
// 			MAFCursorModelAnimated* animated = new MAFCursorModelAnimated;			
// 			{
// 				MAFCursorModelSDL* model = new MAFCursorModelSDL;
// 				std::string cursorUrl	= "work1.cursor";
// 				MAFCursorData* cursor;
// 				cursor = mGame->mDatas->GetCursor(cursorUrl);
// 				if (!cursor) {
// 					g_debug("Cursor /sequence/cursor/@url not found %s",cursorUrl.c_str());
// 					assert(0);
// 				}
// 				SDL_Cursor* mouseData = cursor->GetOrCreateCursor();
// 				g_assert(mouseData);
// 				model->mCursors.push_back(mouseData);
// 				animated->mFrames.push_back(model);
// 			}
// 			{
// 				MAFCursorModelSDL* model = new MAFCursorModelSDL;
// 				std::string cursorUrl = "work2.cursor";
// 				MAFCursorData* cursor;
// 				cursor = mGame->mDatas->GetCursor(cursorUrl);
// 				if (!cursor) {
// 					g_debug("Cursor /sequence/cursor/@url not found %s",cursorUrl.c_str());
// 					assert(0);
// 				}
// 				SDL_Cursor* mouseData = cursor->GetOrCreateCursor();
// 				g_assert(mouseData);
// 				model->mCursors.push_back(mouseData);
// 				animated->mFrames.push_back(model);
// 			}
// 			controller->mModels.push_back(animated);
//     }


//     {
// 			MAFCursorModelSDL* model = new MAFCursorModelSDL;
// 			const std::string &sitoutUrl = mGame->HeaderGet("sequence", "/sequence/cursor/@sitoutUrl");
// 			MAFCursorData* cursor;
// 			cursor = mGame->mDatas->GetCursor(sitoutUrl);
// 			if (!cursor) {
// 				g_debug("Cursor /sequence/cursor/@sitoutUrl not found %s",sitoutUrl.c_str());
// 				assert(0);
// 			}
// 			SDL_Cursor* mouseData = cursor->GetOrCreateCursor();
// 			g_assert(mouseData);
// 			model->mCursors.push_back(mouseData);
// 			controller->mModels.push_back(model);
//     }
//   }

  mCursor=controller;
	//mCursor->SetModel(amodel);
  mCursor->Init(mGame);
  mGame->SetCursor(mCursor.get());
  mCurrentCursorPrevious=mCurrentCursor="normal";
  SetStandardCursor();
}


void PokerCursor::ShowCursor(bool state)
{
  mCursor->ShowCursor(state);
}

void PokerCursor::SetCursor(const std::string& type)
{
	mCursor->SetCursor(type);
  mCurrentCursorPrevious=mCurrentCursor;
  mCurrentCursor=type;
}

void PokerCursor::SetSitoutCursor()
{
  mCursor->SetCursor("sitout");
  mCurrentCursorPrevious=mCurrentCursor;
  mCurrentCursor="sitout";
}

void PokerCursor::SetStandardCursor()
{
  mCursor->SetCursor("normal");
  mCurrentCursorPrevious=mCurrentCursor;
  mCurrentCursor="normal";
}

void PokerCursor::RestoreCursor() 
{
  if (mCurrentCursor==mCurrentCursorPrevious)
    return;

  if (mCurrentCursor=="sitout")
    SetStandardCursor();
  else 
    SetSitoutCursor();
}

void PokerCursor::WarpMouse(int x,int y)
{
  mCursor->WarpMouse(x,y);
}
