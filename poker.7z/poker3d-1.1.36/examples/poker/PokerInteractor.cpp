/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Henry Pr�cheur <henry@precheur.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 */

#include "pokerStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */

#include <maf/maferror.h>
#include <maf/packets.h>
#include <maf/renderbin.h>

#ifndef POKER_USE_VS_PCH
#ifdef USE_NPROFILE
#include <nprofile/profile.h>
#else  //USE_NPROFILE
#define NPROFILE_SAMPLE(a)
#endif //USE_NPROFILE

#include <maf/osghelper.h>
#include <maf/depthmask.h>
#include <maf/assert.h>
#include <osg/Stencil>
#include <osg/Depth>

#include <varseditor/varseditor.h>

#	include "PokerError.h"
#	include "PokerApplication.h"
#	include "PokerInteractor.h"
# include "PokerSceneView.h"
#endif // WIN32

#include "CustomAssert/CustomAssert.h"


PokerInteractorBase::PokerInteractorBase(unsigned int id) : UGAMEArtefactController(id), mClickStatus(false),
					       mWasClickedFocused(false),
					       mDirtyDisplay(false),
								 mScale(1.0f),
								 mCanBeFocused(true),
								 mForceToZoom(false),
								 mBetValue(0),
								 mCanZoom(true),
								 mWaitingForValid(false),
								 mGlowScale(1.0f),
								 mbRaise(false),
								 mbForceToUnclick(false),
								 mOrgVertices(NULL),
								 mMorph(0.0f)
{
}

PokerInteractorBase::~PokerInteractorBase()
{
}

bool PokerInteractorBase::Update(MAFApplication *application)
{
	NPROFILE_SAMPLE("PokerInteractorBase::Update");

	SDL_Event* event = application->GetLastEvent(this);
	float dt = application->GetDeltaFrame() / 1000.0f;

	bool clickStatus = mClickStatus;

	bool focused = (application->GetFocus() == this) && mCanBeFocused;
	bool clickEvent = false;

	mCanZoom = true;

	if (mbForceToUnclick || event)
	{
		if(mbForceToUnclick || (event->type == SDL_MOUSEBUTTONDOWN && event->button.button == SDL_BUTTON_LEFT))
		{
			mbForceToUnclick = false;
			clickStatus = true;
			clickEvent = true;
		}
		else if (event->type == SDL_MOUSEBUTTONUP && event->button.button == SDL_BUTTON_LEFT)
		{
			clickStatus = false;
			clickEvent = true;
			if (!focused)
				mWasClickedFocused = false;
			// 	  application->UnlockMouse(this);
		}
	}
	else {
//		float scale = 1.0f;
	//	float fac = 1.0f;
          //osg::PositionAttitudeTransform *pat = this->GetModel()->GetPAT();

//		mScale = 4;

		if (mCanZoom && !mWaitingForValid)
		{
			if (focused || mForceToZoom) {
				mScale += dt * 8;
				if (mScale > 1.7f)
					mScale = 1.7f;
			}
			else {
				mScale -= dt * 8;
				if (mScale < 1.0f)
					mScale = 1.0f;
			}
		}

		PokerApplication *game = static_cast<PokerApplication *>(application);

		osgUtil::SceneView *sceneView = game->GetScene()->GetView()->GetModel()->mScene.get();
		osg::Matrix camMat = sceneView->getViewMatrix();
		osg::Matrix fmat = MAFComputeLocalToWorld( mMT_3 ) * camMat;
		float z = -fmat.getTrans()._v[2];

		float fac = z * 0.01f;

		if (z < 150) {
			mRScale = mScale * fac;
			mRFac = fac;
		}
		else {
			float blend = (z - 150) / 500.0f;
			if (blend > 1)
				blend = 1;
			float invBlend = 1 - blend;
			mRScale = mScale * fac * invBlend + mScale * blend;
			mRFac = fac * invBlend + blend;
		}

		float a = mMorph;
		float b = 1 - mMorph;

		//float rscale = (mRScale*b + mRScale*a) * 1.2f;
		float rscale = mRScale*b*1.2f + mScale*a;
		//float rscale = mRScale*b*1.2f + 3*a;
		//rscale = b*rscale + a * (rscale*0.8f + 0.5f);
		//rscale = b*rscale + a * rscale;
//		mMT->setMatrix( osg::Matrix::scale( osg::Vec3f(rscale, rscale, 1)) );
		//GetModel()->GetPAT()->setScale( osg::Vec3f(rscale, rscale, 1) );

		for (std::map<std::string, osg::MatrixTransform*>::iterator it = mMT.begin(); it != mMT.end(); ++it) {
			osg::MatrixTransform *mt = (*it).second;
			mt->setMatrix( osg::Matrix::scale(osg::Vec3f(rscale, rscale, 1)) );
		}

		osg::Vec3f rpos = mPos_3 * b + mPos_1 * a;
		osg::Matrix mat = mMT_1->getMatrix();
		rpos *= mRFac*b*0.75f+a;
		mat.setTrans(rpos);
		mMT_1->setMatrix(mat);

		osg::Vec3f rposRoot = mPosRoot_3 * b + mPosRoot_1 * a;
		mat = mRoot_1->getMatrix();
		mat.setTrans(rposRoot);
		mRoot_1->setMatrix(mat);

		if (mbRaise) {
			// Igor: not a very good way to proceed...
			osg::Node *node = mNodes["raise_sel.escn"].get();
			osg::Geode *geode = GetGeode( node );

			//int nbDrawables = geode->getNumDrawables();
			osg::Geometry *geom = (osg::Geometry*) geode->getDrawable(0);
			osg::Vec3Array *vertices = (osg::Vec3Array*) geom->getVertexArray();
			osg::Vec3f *data = (osg::Vec3f*) vertices->getDataPointer();
			int size = vertices->getNumElements();

			geom->getOrCreateStateSet()->setMode(GL_DEPTH_TEST, FALSE);

			if (!mOrgVertices) {
				mOrgVertices = new osg::Vec3f[size];
				memcpy(mOrgVertices, data, size*12);
			}

			for (int i = 0; i < size; i++) {
				float x = mOrgVertices[i]._v[0] * mGlowScale;
				float y = mOrgVertices[i]._v[1] * mGlowScale;
				float z = mOrgVertices[i]._v[2] * mGlowScale;
				data[i][0] = x;
				data[i][1] = y;
				data[i][2] = z;
			}

			geom->dirtyDisplayList();
		}
	}

	if (mWaitingForValid && !focused) {
		clickStatus = false;
		clickEvent = false;
	}

	bool clickAndFocused = clickStatus && clickEvent && focused;
	bool selected =  (!clickStatus && clickEvent && focused && mWasClickedFocused && GetSelectable());
	if (mDirtyDisplay || clickEvent)
	{
		for (unsigned int i = 0; i < mNodes2Clear.size(); i++) {
			const std::string &tclear = mNodes2Clear[i];
			if (mNodes.find(tclear) == mNodes.end()) {
				g_error("%s node was not found", tclear.c_str());
			}
			mNodes[tclear]->setNodeMask(0);
		}

		mNodes2Clear.clear();
		UpdateDisplay(clickAndFocused || mWasClickedFocused || selected);
		mDirtyDisplay = false;
	}

	if (clickEvent)
	{
		if (selected)
			SetSelected(true);

		mClickStatus = clickStatus;
		mWasClickedFocused = clickAndFocused;
	}

	return true;
}

void PokerInteractorBase::UpdateDisplay(bool clickAndFocused)
{
	if (clickAndFocused)
		{
			if (GetNodeDisplayed("default") != !clickAndFocused)
				SetNodeDisplayed("default", !clickAndFocused);
			if (GetNodeDisplayed("clicked") != clickAndFocused)
				SetNodeDisplayed("clicked", clickAndFocused);
		}
	else

		{
			if (GetNodeDisplayed("clicked") != clickAndFocused)
				SetNodeDisplayed("clicked", clickAndFocused);
			if (GetNodeDisplayed("default") != !clickAndFocused)
				SetNodeDisplayed("default", !clickAndFocused);
		}
}

void PokerInteractorBase::Init(PokerApplication* game, MAFOSGData* seatData, const std::string &urlPrefix)
{
  UGAMEArtefactController::Init();

	const std::string &dataPath = game->HeaderGet("settings", "/settings/data/@path");

	mSeatData = seatData;

  const std::string &strRoot1 = game->HeaderGet("sequence", urlPrefix + "/@root_1");
  const std::string &strRoot3 = game->HeaderGet("sequence", urlPrefix + "/@root_3");

  const std::string &anchorName = game->HeaderGet("sequence", urlPrefix + "/@anchor");
	MAFAnchor *tmpNode = seatData->GetAnchor(strRoot1);
	osg::Group *anchorNode = (osg::Group*) OSGHelper_getNodeByName(*tmpNode, anchorName);
  g_assert(anchorNode != 0);
  Anchor(anchorNode);

	mTextMatrix = new osg::MatrixTransform();
	mTextMatrix->setMatrix( osg::Matrix::scale(0.18f, 0.18f, 1.0f) * osg::Matrix::translate(0, -1.2f, 0.0f) );
	mTextMatrix->setNodeMask( MAF_VISIBLE_MASK );

	std::vector<MAFTextWriter::FontElement> fontEl;
	fontEl.push_back( MAFTextWriter::FontElement('0') );
	fontEl.push_back( MAFTextWriter::FontElement('1') );
	fontEl.push_back( MAFTextWriter::FontElement('2') );
	fontEl.push_back( MAFTextWriter::FontElement('3') );
	fontEl.push_back( MAFTextWriter::FontElement('4') );
	fontEl.push_back( MAFTextWriter::FontElement('5') );
	fontEl.push_back( MAFTextWriter::FontElement('6') );
	fontEl.push_back( MAFTextWriter::FontElement('7') );
	fontEl.push_back( MAFTextWriter::FontElement('8') );
	fontEl.push_back( MAFTextWriter::FontElement('9') );
	fontEl.push_back( MAFTextWriter::FontElement('k') );
	fontEl.push_back( MAFTextWriter::FontElement(',', "comma.tga") );
	fontEl.push_back( MAFTextWriter::FontElement('$', "dollar.tga") );
	fontEl.push_back( MAFTextWriter::FontElement('�', "euro.tga") );
	fontEl.push_back( MAFTextWriter::FontElement('.', "dot.tga") );
	mText = new MAFTextWriter(dataPath + "/font_interactor/", fontEl);

	mTextMatrix->addChild( mText.get() );
	mText->setScale( osg::Vec3f(0.19f, 0.19f, 1.0f) );

  std::string urlnode=urlPrefix + "/nodes/node/@url";
  const std::list<std::string> &nodesUrl = game->HeaderGetList("sequence",urlnode);
  if (nodesUrl.empty())
    g_error("PokerInteractorBase::Init %s not found in config file check client.xml",urlnode.c_str());
  std::list<std::string>::const_iterator begin = nodesUrl.begin();
  std::list<std::string>::const_iterator end = nodesUrl.end();
  while(begin != end)
	{
		const std::string &nodeUrl = *begin;
    InitNode(game, nodeUrl);
    begin++;
	}

	osg::Group *root1 = mSeatData->GetAnchor(strRoot1);
	osg::Group *root3 = mSeatData->GetAnchor(strRoot3);

	osg::MatrixTransform *interactor_1 = (osg::MatrixTransform*) OSGHelper_getNodeByName(*root1, anchorName);
	mPos_1 = interactor_1->getMatrix().getTrans();
	mMT_1 = interactor_1;

	osg::MatrixTransform *interactor_3 = (osg::MatrixTransform*) OSGHelper_getNodeByName(*root3, anchorName);
	mPos_3 = interactor_3->getMatrix().getTrans();
	mMT_3 = interactor_3;

	mRoot_1 = (osg::MatrixTransform*) root1;
	mPosRoot_1 = mRoot_1->getMatrix().getTrans();
	mRoot_3 = (osg::MatrixTransform*) root3;
	mPosRoot_3 = mRoot_3->getMatrix().getTrans();

  //game->AddController(this);
  SetSelectable(true);
}

void PokerInteractorBase::Finit(PokerApplication *game)
{
	PokerSceneView *instance = PokerSceneView::getInstance();
	if (instance) {

		std::map<std::string, osg::ref_ptr<osg::Node> >::iterator it = mNodes.begin();
		while (it != mNodes.end()) {
			osg::Node *node = it->second.get();

			osg::Geode *geode = GetGeode(node);
			int nbDrawables = geode->getNumDrawables();
			for (int i = 0; i < nbDrawables; i++) {
				osg::Drawable *drawable = geode->getDrawable(i);
				instance->removeDrawableThatStayInColor(drawable);
			}

			it++;
		}
	}

  //game->RemoveController(this);
  RecursiveClearUserData(GetModel()->GetNode());
}

void PokerInteractorBase::InitNode(PokerApplication* game, const std::string &nodeUrl)
{
  assert(!nodeUrl.empty());
  MAFOSGData *node_base = static_cast<MAFOSGData*>(game->mDatas->GetVision(nodeUrl));
  if (!node_base)
    g_error("PokerInteractorBase::InitNode %s not found",nodeUrl.c_str());
	node_base=(MAFOSGData *)node_base->Clone(LEVEL_CLONE_SETTING);
  osg::Group *node = node_base->GetGroup();

//  osg::PositionAttitudeTransform *pat = new osg::PositionAttitudeTransform;
//  pat->setPosition(osg::Vec3(0.0f, mDelta, 0.0f));
  //pat->addChild(node);

	MAFBillBoard *bb = new MAFBillBoard();
	//osg::AutoTransform *bb = new osg::AutoTransform();
	//bb->setAutoRotateMode( osg::AutoTransform::ROTATE_TO_SCREEN );
	//bb->setActive(false);
	bb->setActive(true);
//	osg::Transform *bb = new osg::Transform();
	osg::MatrixTransform *mt = new osg::MatrixTransform();
	bb->addChild(mt);
	//GetModel()->GetPAT()->addChild( mTextMatrix.get() );
	mt->addChild(node);
	mt->addChild( mTextMatrix.get() );

	mMT[nodeUrl] = mt;

  GetModel()->GetPAT()->addChild(bb);
	mNodes[nodeUrl] = node;


  PokerSceneView *instance = PokerSceneView::getInstance();
  osg::Geode *geode = GetGeode(node);

  // add collision from root to geode
  osg::NodePath pathToAddCollisionMask;
  MAFCreateNodePath(geode, pathToAddCollisionMask);
  for (osg::NodePath::iterator it = pathToAddCollisionMask.begin(); it != pathToAddCollisionMask.end(); it++) {
    unsigned int mask = (*it)->getNodeMask();
    mask = mask | MAF_COLLISION_MASK;
    (*it)->setNodeMask(mask);
  }

  int nbDrawables = geode->getNumDrawables();
  for (int i = 0; i < nbDrawables; i++) {
    osg::Drawable *drawable = geode->getDrawable(i);
    osg::StateSet *ss = drawable->getStateSet();

		ss->setAttributeAndModes( new DepthMask(false) );

		osg::Stencil *stencil = new osg::Stencil;
		stencil->setFunction(osg::Stencil::ALWAYS, 0x80, 0xffffffff);
		stencil->setOperation(osg::Stencil::KEEP, osg::Stencil::KEEP, osg::Stencil::ZERO);
//		stencil->setFunction(osg::Stencil::EQUAL, 0x1, 0xffffffff);
	//	stencil->setOperation(osg::Stencil::KEEP, osg::Stencil::KEEP, osg::Stencil::ZERO);
		ss->setAttributeAndModes(stencil);

		int defaultrbvalue;
		if (!MAFRenderBin::Instance().SetupRenderBin("Interactor", ss))
			MAF_ASSERT(0 && "Interactor not found in client.xml");

		MAFRenderBin::Instance().GetRenderBinIndexOfEntity("Interactor", defaultrbvalue);

		//{
//			if (!VarsEditor::Instance().Get("RB_Interactor",defaultrbvalue))
	//			MAF_ASSERT(0 && "RB_Interactor not found in client.xml");
		//	ss->setRenderBinDetails(defaultrbvalue, "RenderBin");
		//}

    if (instance) {
			int interactorRenderBinValueInHelpMode = defaultrbvalue;
			int interactorRenderBinBeforeHelpMode = ss->getBinNumber();
			//{
//				if (!VarsEditor::Instance().Get("RB_InteractorInHelpMode",interactorRenderBinValueInHelpMode))
	//				MAF_ASSERT(0 && "RB_InteractorInHelpMode not found in client.xml");
			if (!MAFRenderBin::Instance().GetRenderBinIndexOfEntity("InteractorInHelpMode", interactorRenderBinValueInHelpMode))
				MAF_ASSERT(0 && "InteractorInHelpMode not found in client.xml");
			//}

			instance->addDrawableThatStayInColor(drawable, interactorRenderBinBeforeHelpMode, interactorRenderBinValueInHelpMode, "RenderBin", 0);
    }
  }

  node->setNodeMask(0);
}

void PokerInteractorBase::Accept(MAFPacket *packet)
{
  std::string state;
  std::string style;
  packet->GetMember("state", state);
  packet->GetMember("style", style);
  typedef std::map<std::string, std::string >::iterator It;  

  It nameIt = mState2Name.find(state);

  bool nameFound = (nameIt != mState2Name.end());
  if (nameFound)
    {
      if ((*nameIt).second != style)
				{  
					const std::string &nodeName = (*nameIt).second;
					CUSTOM_ASSERT(!nodeName.empty());
					mNodes2Clear.push_back(nodeName);
					//SetNodeDisplayed(state, false);
					if (!style.empty())
						mState2Name[state] = style;
					else
						mState2Name.erase(state);
					mDirtyDisplay = true;
				}
    }
	else 
		{
			if (!style.empty())
				{
					mState2Name[state] = style;
					mDirtyDisplay = true;
				}
		}

  bool nodeDisabled = (style == "");
  if (nodeDisabled)
    {
			mText->setNodeMask(0);
      SetSelectable(false);
      //mNodes2Clear.push_back(mState2Name[state]);
      //SetNodeDisplayed(state, false);
    }
  else if (!GetSelectable())
    SetSelectable(true);
}

void PokerInteractorBase::SetNodeDisplayed(const std::string &state, bool displayed)
{
	if (mState2Name.find(state) == mState2Name.end())
		return;

  const std::string &name = mState2Name[state];
  g_assert(!name.empty());
  g_assert(mNodes.find(name) != mNodes.end());
	unsigned int mask = (displayed ? (MAF_VISIBLE_MASK | MAF_COLLISION_MASK) : 0);
  mNodes[name]->setNodeMask(mask);
	mNodes[name]->setName(name);

//	if (mask != 0) {
		mText->setNodeMask(mask);
	//}
}

bool PokerInteractorBase::GetNodeDisplayed(const std::string &state)
{
  if (mState2Name.find(state) == mState2Name.end())
    return false;

  const std::string &name = mState2Name[state];
  if (name.empty())
    {
      g_debug("PokerInteractorBase::GetNodeDisplayed (empty name) state %s", state.c_str());
      return false;
    }
  if (mNodes.find(name) == mNodes.end())
    {
      g_debug("PokerInteractorBase::GetNodeDisplayed name %s not found state %s", name.c_str(), state.c_str());
      return false;
    }
  return (mNodes[name]->getNodeMask() == (MAF_VISIBLE_MASK | MAF_COLLISION_MASK));
}

void PokerInteractorBase::SetText(const std::string &_text)
{
  PokerSceneView *instance = PokerSceneView::getInstance();
	if (instance) {
		std::vector<osg::Geode*> geodes;
		geodes = mText->getCharacters();
		int nb = geodes.size();
		for (int i = 0; i < nb; i++)
			instance->removeDrawableThatStayInColor( geodes[i]->getDrawable(0) );
	}

	mText->setText(_text);

	if (instance) {
		std::vector<osg::Geode*> geodes;
		geodes = mText->getCharacters();
		int nb = geodes.size();

		int interactorTextRenderBinBeforeHelpMode;
//		{
	//		if (!VarsEditor::Instance().Get("RB_TextInteractor",interactorTextRenderBinBeforeHelpMode))
		//		MAF_ASSERT(0 && "RB_TextInteractor not found in client.xml");
//		}
		if (!MAFRenderBin::Instance().GetRenderBinIndexOfEntity("TextInteractor", interactorTextRenderBinBeforeHelpMode))
			MAF_ASSERT(0 && "RB_TextInteractor not found in client.xml");

		int interactorTextRenderBinValueInHelpMode;
//		{
	//		if (!VarsEditor::Instance().Get("RB_InteractorInHelpMode",interactorTextRenderBinValueInHelpMode))
		//		MAF_ASSERT(0 && "RB_InteractorInHelpMode not found in client.xml");
		//}
		if (!MAFRenderBin::Instance().GetRenderBinIndexOfEntity("TextInteractorInHelpMode", interactorTextRenderBinValueInHelpMode))
			MAF_ASSERT(0 && "InteractorInHelpMode not found in client.xml");

		for (int i = 0; i < nb; i++) {
			osg::Drawable *draw = geodes[i]->getDrawable(0);
			osg::StateSet *ss = draw->getOrCreateStateSet();

			if (!MAFRenderBin::Instance().SetupRenderBin("TextInteractor", ss))
				MAF_ASSERT(0 && "TextInteractor not found in client.xml");

			instance->addDrawableThatStayInColor(draw, interactorTextRenderBinBeforeHelpMode, interactorTextRenderBinValueInHelpMode, "RenderBin", 1);
		}
	}

	float w = mText->getTextWidth(_text);
	if (w < 150)
		mText->setScale( osg::Vec3f(0.19f, 0.19f, 1.0f) );
	else
		mText->setScale( osg::Vec3f(0.15f, 0.15f, 1.0f) );
}

bool PokerInteractorRaise::CanInstallSlider() const
{
  bool bCanInstall = true;
  typedef std::map<std::string, std::string>::const_iterator ConstIt;
  ConstIt raiseInteractorClickedNode = mState2Name.find("clicked");
  ConstIt raiseInteractorDefaultNode = mState2Name.find("default");
  if ((raiseInteractorClickedNode != mState2Name.end()) &&
      (raiseInteractorClickedNode->second == "raise_sel.escn") &&
      (raiseInteractorDefaultNode != mState2Name.end()) && 
      (raiseInteractorDefaultNode->second == "raise_sel.escn"))
    bCanInstall = false;
  return bCanInstall;
}
