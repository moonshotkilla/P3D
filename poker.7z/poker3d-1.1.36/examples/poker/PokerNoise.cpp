/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Johan Euphrosine <johan@mekensleep.com>
 *  Cedric Pinson <cpinson@freesheep.org>
 *  Igor Kravtchenko <igor@tsarevitch.org>
 */



#include "pokerStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifndef POKER_USE_VS_PCH
 #include "PokerNoise.h"
 #include <cmath>
 #include <glib.h>
 #include <osg/Vec3>
 #include <cal3d/coremodel.h>
 #include <cal3d/model.h>
 #include <cal3d/coreskeleton.h>
 #include <cal3d/corekeyframe.h>
 #include <cal3d/corebone.h>
 #include <cal3d/scheduler.h>
#endif //POKER_USE_VS_PCH

// return the frac part of a real
inline double Frac(double _t){return _t-floor(_t);}


double NoiseElement::Noise(double _t,float _amp,float _freq) 
{
  //    double amplitude = 1.0;
  double result = 0.0;
  double freq=1.0;
  double x=_t;
  double persistance;
  for (int i=0; i<_freq; i++) {
    freq=(1<<i);
    persistance=pow(_amp,i);
    result += mNoise.noise(x*freq) * persistance;
  }
  return result;
}

double NoiseElement::NoiseFunction(double _t) 
{
  double t =Frac(_t);
  const double loop=1.0;
  const int freq=2;
  const float amp=0.5;
  double noise=(loop-t)*Noise(t,amp,freq)+ t*Noise(t-loop,amp,freq);
  noise/=loop;
  return noise;
}


CalCoreBone* NoiseElement::GetCoreBone(int boneId) {
  CalCoreModel* coreModel = mModel->getCoreModel();
  g_assert(coreModel != 0);
  g_assert(coreModel->getCoreSkeleton() != 0);
  CalCoreBone* bone = coreModel->getCoreSkeleton()->getCoreBone(boneId);
  g_assert(bone != 0);
  return bone;
}

void NoiseElement::CreateCoreAnimation(const std::string& path, std::list<std::string>& bones) 
{
  CalCoreModel* coreModel = mModel->getCoreModel();
  //
  // Create animation from template containing enough tracks for each bone
  //
  mCoreAnimationId = coreModel->loadCoreAnimation(mDatadir + G_DIR_SEPARATOR_S + path);
  if(mCoreAnimationId < 0)
    g_error("NoiseElement::CreateCoreAnimation: could not load %s", path.c_str());
  mCoreAnimation = coreModel->getCoreAnimation(mCoreAnimationId);
  g_assert(mCoreAnimation != 0);

  //
  // Check that there exists exactly one track for each bone
  //
  if(bones.size() != mCoreAnimation->getListCoreTrack().size())
    g_error("NoiseElement::CreateCoreAnimation: %s has contains %d tracks but expected exactly %d track", path.c_str(), (int)bones.size(), (int)mCoreAnimation->getListCoreTrack().size());

  std::list<std::string>::iterator bone = bones.begin();
  for(std::list<CalCoreTrack *>::iterator coreTrack = mCoreAnimation->getListCoreTrack().begin();
      coreTrack != mCoreAnimation->getListCoreTrack().end();
      coreTrack++, bone++) {
    int boneId = coreModel->getCoreSkeleton()->getCoreBoneId(*bone);
    if(boneId < 0)
      g_error("NoiseElement::CreateCoreAnimation: in %s, boneId of %s not found", path.c_str(), bone->c_str());
    (*coreTrack)->setCoreBoneId(boneId);
  }
}

NoiseElement::NoiseElement(CalModel* model, const std::string&  datadir) : mCoreAnimation(0), mCoreAnimationId(-1), mKeepGoing(true), mModel(model), mDatadir(datadir)
{ 
}

NoiseEyes::NoiseEyes(CalModel* model, const std::string& datadir) : NoiseElement(model, datadir) {
  std::list<std::string> bones;
  bones.push_back("boneEyeL");
  bones.push_back("boneEyeR");
  CreateCoreAnimation("noiseeyes.xaf", bones);
  mCoreAnimation->setName("NoiseEyes");
  }


void NoiseEyes::process(CalModel* model, CalAnimationAlt* animation) {
  if(!mKeepGoing)
    return;
  
  CalScheduler* scheduler = (CalScheduler*)(model->getAbstractMixer());
  
  const double maxAngle=25*3.14/180.0;
  
  std::list<CalCoreTrack*>& tracks = mCoreAnimation->getListCoreTrack();
  int size = tracks.front()->getCoreKeyframeCount();
  double res = NoiseFunction(time(0)/20.0);
  
  osg::Quat quat;
  if (res>maxAngle)
    res=maxAngle;
  if (res<-maxAngle)
    res=-maxAngle;
  quat.makeRotate(res, osg::Vec3(0,1,0));
  //     quat.makeRotate(res, osg::Vec3(0,0,1)); // on demo version axis to rotate eyes are pivoted
  CalQuaternion q2(quat[0],quat[1],quat[2],quat[3]);
  for (int i=0;i<size/2;i++) {
    for(std::list<CalCoreTrack*>::iterator track = tracks.begin();
	track != tracks.end();
	track++) {
      CalCoreBone* bone = GetCoreBone((*track)->getCoreBoneId());
      (*track)->getCoreKeyframe(i)->setTranslation(bone->getTranslation());
      (*track)->getCoreKeyframe(i)->setRotation(q2);
    }
  }
  
  scheduler->run(CalScheduler::FOREGROUND,
		 mCoreAnimationId,
		 CalScheduler::ONCE)
    ->setStopCallback(this);
}

NoiseNose::NoiseNose(CalModel* model, const std::string& datadir) : NoiseElement(model, datadir){
  std::list<std::string> bones;
  bones.push_back("boneNoseL");
  bones.push_back("boneNoseR");
  CreateCoreAnimation("noisenose.xaf", bones);
		mCoreAnimation->setName("NoiseNose");
}

void NoiseNose::process(CalModel* model, CalAnimationAlt* animation) {
  if(!mKeepGoing)
    return;
  
  CalScheduler* scheduler = (CalScheduler*)(model->getAbstractMixer());
  std::list<CalCoreTrack*>& tracks = mCoreAnimation->getListCoreTrack();
  CalCoreTrack* track_left = tracks.front();
  CalCoreBone* bone_left = GetCoreBone(track_left->getCoreBoneId());
  CalCoreTrack* track_right = tracks.back();
  CalCoreBone* bone_right = GetCoreBone(track_right->getCoreBoneId());
  int size = tracks.front()->getCoreKeyframeCount();

  for (int i=0;i<size;i++) {
    double res=fabs(NoiseFunction(time(0)+i*1.0/size));
    CalVector t(0,0,res*2);
    track_left->getCoreKeyframe(i)->setTranslation(bone_left->getTranslation()+t);
    
      res=fabs(NoiseFunction(time(0)+0.5+i*0.1/size));
      t=CalVector(0,0,res*2);
      track_right->getCoreKeyframe(i)->setTranslation(bone_right->getTranslation()+t);
  }
  
  scheduler->run(CalScheduler::FOREGROUND,
		 mCoreAnimationId,
		 CalScheduler::ONCE,
		   1.f,
		 new CalScheduler::FadeInOut(.2f, .2f))
    ->setStopCallback(this);
}


NoiseSkull::NoiseSkull(CalModel* model, const std::string& datadir) : NoiseElement(model, datadir){
  std::list<std::string> bones;
  bones.push_back("boneSkull");
  CreateCoreAnimation("noiseskull.xaf", bones);
  mCoreAnimation->setName("noiseskull");
  CalCoreTrack* track = mCoreAnimation->getListCoreTrack().front();
  //    CalCoreBone* bone = GetCoreBone(track->getCoreBoneId());
  CalQuaternion calq=track->getCoreKeyframe(0)->getRotation();
  mInitialRotation =osg::Quat(calq[0],calq[1],calq[2],calq[3]);
}

void NoiseSkull::process(CalModel* model, CalAnimationAlt* animation) {
  if(!mKeepGoing)
    return;
  
  CalScheduler* scheduler = (CalScheduler*)(model->getAbstractMixer());
  CalCoreTrack* track = mCoreAnimation->getListCoreTrack().front();
  CalCoreBone* bone = GetCoreBone(track->getCoreBoneId());
  
  int size=track->getCoreKeyframeCount();
  for (int i=0;i<size;i++) {
    double res=NoiseFunction((time(0)+i*1.0/size));
    osg::Quat q0,q1;
    q0.makeRotate(res*0.4, osg::Vec3(0,1,0));
    double res2=NoiseFunction((time(0)+0.5+i*0.1/size));
    q1.makeRotate(res2*.05, osg::Vec3(1,0,0)); // 0.5
    q1=mInitialRotation*q1;
    q1*=q0;
      CalQuaternion q(q1[0],q1[1],q1[2],q1[3]);
      track->getCoreKeyframe(i)->setTranslation(bone->getTranslation());
      track->getCoreKeyframe(i)->setRotation(q);
  }
  
  scheduler->run(CalScheduler::FOREGROUND,
		 mCoreAnimationId,
		 CalScheduler::ONCE,
		 1.f,
		 new CalScheduler::FadeInOut(0.25f, 0.25f))
    ->setStopCallback(this);
}

NoiseMouth::NoiseMouth(CalModel* model, const std::string& datadir) : NoiseElement(model, datadir){
  std::list<std::string> bones;
  bones.push_back("boneMouthBL");
  bones.push_back("boneMouthTL");
  bones.push_back("boneMouthCL");
  bones.push_back("boneMouthBR");
  bones.push_back("boneMouthTR");
  bones.push_back("boneMouthCR");
  CreateCoreAnimation("noisemouth.xaf", bones);
  mCoreAnimation->setName("NoiseMouth");
}


void NoiseMouth::process(CalModel* model, CalAnimationAlt* animation) {
  if(!mKeepGoing)
    return;
  
  CalScheduler* scheduler = (CalScheduler*)(model->getAbstractMixer());
  std::list<CalCoreTrack*>& tracks_list = mCoreAnimation->getListCoreTrack();
  std::vector<CalCoreTrack*> tracks(tracks_list.begin(), tracks_list.end());
  std::vector<CalCoreBone*> bones;
  for(std::vector<CalCoreTrack*>::iterator track = tracks.begin();
      track != tracks.end();
      track++)
    bones.push_back(GetCoreBone((*track)->getCoreBoneId()));
  
  int size = tracks.front()->getCoreKeyframeCount();
  
  for (int i=0;i<size;i++) {
    double res=fabs(NoiseFunction(time(0)+i*1.0/size));
    for (int j=0;j<2;j++) {
      CalVector t(res,0,res*0.5);
      tracks[j]->getCoreKeyframe(i)->setTranslation(bones[j]->getTranslation()+t);
    }
    res=fabs(NoiseFunction(time(0)+i*1.0/size+0.2));
    tracks[2]->getCoreKeyframe(i)->setTranslation(bones[2]->getTranslation()+CalVector(res,0,res*0.5));
    
    res=fabs(NoiseFunction(time(0)+i*1.0/size+0.5));
    for (int j=3;j<5;j++) {
      CalVector t(res,0,res*0.5);
      tracks[j]->getCoreKeyframe(i)->setTranslation(bones[j]->getTranslation()+t);
    }
    res=fabs(NoiseFunction(time(0)+i*1.0/size+0.5+0.2));
    tracks[5]->getCoreKeyframe(i)->setTranslation(bones[5]->getTranslation()+CalVector(res,0,res*0.5));
  }
  
  scheduler->run(CalScheduler::FOREGROUND,
		 mCoreAnimationId,
		 CalScheduler::ONCE,
		 1.f,
		 new CalScheduler::FadeInOut(.2f, .2f))
    ->setStopCallback(this);
}


NoiseZygo::NoiseZygo(CalModel* model, const std::string& datadir) : NoiseElement(model, datadir){
  std::list<std::string> bones;
  bones.push_back("boneZygoL");
  bones.push_back("boneZygoR");
  CreateCoreAnimation("noisezygo.xaf", bones);
  mCoreAnimation->setName("NoiseZygo");
}


void NoiseZygo::process(CalModel* model, CalAnimationAlt* animation) {
  if(!mKeepGoing)
    return;
  
  CalScheduler* scheduler = (CalScheduler*)(model->getAbstractMixer());
  std::list<CalCoreTrack*>& tracks = mCoreAnimation->getListCoreTrack();
  CalCoreTrack* track_left = tracks.front();
  CalCoreBone* bone_left = GetCoreBone(track_left->getCoreBoneId());
  CalCoreTrack* track_right = tracks.back();
  CalCoreBone* bone_right = GetCoreBone(track_right->getCoreBoneId());
  int size = tracks.front()->getCoreKeyframeCount();
  
  osg::Quat q0,q1;
  for (int i=0;i<size;i++) {
    double res=fabs(NoiseFunction(time(0)+i*1.0/size));
    //    g_debug("Zygo %f\n", res);
    //       res*=10;
    CalVector t(res,0,res);
      track_left->getCoreKeyframe(i)->setTranslation(bone_left->getTranslation()+t);
      
      res=fabs(NoiseFunction(time(0)+0.5+i*0.1/size));
      //       res*=10;
      t=CalVector(res,0,res);
      track_right->getCoreKeyframe(i)->setTranslation(bone_right->getTranslation()+t);
  }
  
  
  scheduler->run(CalScheduler::FOREGROUND,
		 mCoreAnimationId,
		 CalScheduler::ONCE,
		 1.f,
		 new CalScheduler::FadeInOut(.2f, .2f))
    ->setStopCallback(this);
}


NoiseEpicr::NoiseEpicr(CalModel* model, const std::string& datadir) : NoiseElement(model, datadir){
  std::list<std::string> bones;
  bones.push_back("boneEpicrML");
  bones.push_back("boneEpicrCL");
  bones.push_back("boneEpicrMR");
  bones.push_back("boneEpicrCR");
  CreateCoreAnimation("noiseepicr.xaf", bones);
  mCoreAnimation->setName("NoiseEpicr");
}


void NoiseEpicr::process(CalModel* model, CalAnimationAlt* animation) {
  if(!mKeepGoing)
    return;
  
  CalScheduler* scheduler = (CalScheduler*)(model->getAbstractMixer());
  std::list<CalCoreTrack*>& tracks_list = mCoreAnimation->getListCoreTrack();
  std::vector<CalCoreTrack*> tracks(tracks_list.begin(), tracks_list.end());
  std::vector<CalCoreBone*> bones;
  for(std::vector<CalCoreTrack*>::iterator track = tracks.begin();
      track != tracks.end();
      track++)
    bones.push_back(GetCoreBone((*track)->getCoreBoneId()));
  
  int size = tracks.front()->getCoreKeyframeCount();
  
  for (int i=0;i<size;i++) {
    double res=fabs(NoiseFunction(time(0)+i*1.0/size));
    for (int j=0;j<2;j++) {
      CalVector t(res*.5,res*0.5,0);
      tracks[j]->getCoreKeyframe(i)->setTranslation(bones[j]->getTranslation()+t);
    }
    res=fabs(NoiseFunction(time(0)+i*1.0/size+.5));
    for (int j=2;j<4;j++) {
      CalVector t(res*.5,res*0.5,0);
      tracks[j]->getCoreKeyframe(i)->setTranslation(bones[j]->getTranslation()+t);
    }
  }
  
  scheduler->run(CalScheduler::FOREGROUND,
		 mCoreAnimationId,
		 CalScheduler::ONCE,
		 1.f,
		 new CalScheduler::FadeInOut(.2f, .2f))
    ->setStopCallback(this);
}
