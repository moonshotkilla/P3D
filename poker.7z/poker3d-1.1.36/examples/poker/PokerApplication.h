/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Henry Pr�cheur <henry@precheur.org>
 *  Igor Kravtchenko <igor@tsarevitch.org>
 */

#ifndef	_poker_application_h
#define	_poker_application_h

#ifndef POKER_USE_VS_PCH
#include <maf/application.h>
#include <maf/application2d.h>
#include <maf/camera.h>
#include <maf/scene.h>
#include <maf/audio.h>
#include <ugame/text.h>

#include <Poker.h>
#endif

#include <PokerCamera.h>
#include <PokerSplashScreen.h>

#ifdef WIN32
#include "pokerexport.h"
#endif

class MAFSceneController;
class MAFRepositoryData;
class MAFOSGData;
class PokerDeck;
class PokerController;
class PokerCursor;
class PokerMultiTable;
class PokerApplication2D;

class POKER_EXPORT PokerApplication : public MAFApplication
{
public:
  PokerApplication();
  virtual ~PokerApplication();

  void Load();
  virtual void PythonAccept(PyObject* pypacket);
  virtual void SendPacket(const std::string &packetName);

  virtual void Init(void);
  virtual void InterfaceReady();
  virtual void ShowSplashScreen();
  virtual void HideSplashScreen();
  virtual void UpdateSplashScreen(float ratio, char* message);
  virtual void OnExit(int Code);

  virtual const std::string& SetLogPolicy();
  virtual void Crash();

  void SetPyScheduler(PyObject* scheduler) { mPyScheduler = scheduler; }
  PyObject* GetPyScheduler(void) { return mPyScheduler; }

  virtual osg::Referenced* SearchAnimated(const std::string& name);
  virtual osg::Referenced* SearchPlayer(const std::string& name);

	virtual bool SetSoundEnabled(bool state);
	virtual bool IsSoundEnabled();
	      
  PokerController* GetPoker() { return mPoker.get(); }
  MAFApplication2DController* GetInterface();

	MAFMonitor *GetLoader() { return mSplashScreen.valid() ? mSplashScreen->GetModel() : NULL; }
  std::list<std::string> mLevelList;

  MAFOSGData* mSetData;

  PokerDeck* mDeck;

  bool mShadowFlag;
	bool mGlowFlag;

  PokerCursor* mCursor;

	osg::ref_ptr<PokerMultiTable> mPokerMultiTable;

	// table name
	osg::ref_ptr<UGAMEBasicText> mTableName;
  osg::ref_ptr<osg::MatrixTransform> mTransformTableName;

private:
  PyObject* mPyScheduler;
  osg::ref_ptr<PokerSplashScreenController> mSplashScreen;
  osg::ref_ptr<PokerController> mPoker;
  osg::ref_ptr<PokerApplication2D> mPokerApplication2D;

	friend class PokerModel;
};

#endif /* _poker_application_h */
