/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#include "pokerStdAfx.h"

#include "PokerHUD/PokerHUD.h"
#include "osgSprite/osgSprite.h"
#include "CustomAssert/CustomAssert.h"

#include <ugame/text.h>

#ifndef UNITTEST
 #include <maf/scene.h>
 #include <maf/packets.h>
#else
 #include "packets.mock.h"
#endif

#include <glib.h>

#include <osgText/Text>
#include <osgDB/ReadFile>
#include <osg/StateAttribute>
#include <osg/Projection>
#include <osg/Geometry>
#include <osg/Material>
#include <osg/Depth>

#include <sstream>
#include <iomanip>
#include <libxml/tree.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <libxml/xpathInternals.h>
#include <libxml/xmlsave.h>

PokerHUD::Panel::Text::Text() : mText(0), mTransform(0), mQuad(0), mLeft(0), mCenter(0), mRight(0), mBackgroundEnabled(false), mFramedBackgroundEnabled(false), mBackgroundWidth(0.0f), mTranslate(0.0f, 0.0f, 0.0f), mBackgroundColor(0.0f, 0.0f, 0.0f, 0.0f)
{

}
PokerHUD::Panel::Text::Text(const std::string& text, const std::string& font, unsigned int size, const std::string& align) : mText(0), mTransform(0), mQuad(0), mLeft(0), mCenter(0), mRight(0), mBackgroundEnabled(false), mFramedBackgroundEnabled(false), mBackgroundWidth(0.0f), mTranslate(0.0f, 0.0f, 0.0f), mBackgroundColor(0.0f, 0.0f, 0.0f, 0.0f)
{
  Create(text, font, size, align);
}
void PokerHUD::Panel::Text::Create(const std::string& text, const std::string& font, unsigned int size, const std::string& align)
{
  CUSTOM_ASSERT(mText == NULL);
  CUSTOM_ASSERT(mTransform == NULL);

	osg::ref_ptr<osgDB::ReaderWriter::Options> options = new osgDB::ReaderWriter::Options();
	options->setObjectCacheHint(osgDB::ReaderWriter::Options::CACHE_ALL);
	osgText::Font* osgFont = dynamic_cast<osgText::Font*> (osgDB::readObjectFile(font, options.get()));

  CUSTOM_ASSERT(osgFont != NULL && "readObjectFile");
  osgFont->setMinFilterHint(osg::Texture::NEAREST);
  osgFont->setMagFilterHint(osg::Texture::NEAREST);
  mText = new UGAMEBasicText("", osgFont);
  mText->getOrCreateStateSet()->setMode(GL_CULL_FACE, GL_FALSE);
  mText->getText()->setFontResolution(size, size);
  mText->getText()->setCharacterSize(size);
  mText->getText()->setColor(osg::Vec4f(1, 1, 1, 1));
  mText->getText()->setText(osgText::String(text, osgText::String::ENCODING_UTF8));
  if (align == "CENTER_CENTER")
    {
      mText->getText()->setAlignment(osgText::Text::CENTER_CENTER);
    }
  else if (align == "RIGHT_BOTTOM")
    {
      mText->getText()->setAlignment(osgText::Text::RIGHT_BOTTOM);
    }
  else if (align == "RIGHT_TOP")
    {
      mText->getText()->setAlignment(osgText::Text::RIGHT_TOP);
    }
  else if (align == "LEFT_TOP")
    {
      mText->getText()->setAlignment(osgText::Text::LEFT_TOP);
    }
  else
    {
      CUSTOM_ASSERT(false && "alignement not supported");
    }
  mTransform = new osg::MatrixTransform();
  const float zThreshold = 0.0f;
  mTransform->setMatrix(osg::Matrix::scale(1.0f, -1.0f, 1.0f) * osg::Matrix::translate(0.0f, 0.0f, zThreshold));
  mTransform->addChild(mText.get());

  mQuad = new osgQuad();
  mQuad->setNodeMask(0);
  {
    osgSprite* sprite = new osgSprite();
    mRight = sprite;    
  }
  {
    osgSprite* sprite = new osgSprite();
    mCenter = sprite;    
  }
  {
    osgSprite* sprite = new osgSprite();
    mLeft = sprite;    
  }
  //order matters alpha is on the image right
  mRight->getOrCreateStateSet()->setRenderBinDetails(0, "RenderBin");
  mCenter->getOrCreateStateSet()->setRenderBinDetails(0, "RenderBin");
  mLeft->getOrCreateStateSet()->setRenderBinDetails(0, "RenderBin");
  mQuad->getOrCreateStateSet()->setRenderBinDetails(1, "RenderBin");
  mTransform->getOrCreateStateSet()->setRenderBinDetails(2, "RenderBin");
  addChild(mRight.get());
  addChild(mCenter.get());
  addChild(mLeft.get());
  addChild(mQuad.get());
  addChild(mTransform.get());

  osg::Material* mat = new osg::Material;
  mat->setDiffuse(osg::Material::FRONT_AND_BACK,osg::Vec4(1,1,1,1));
  getOrCreateStateSet()->setAttributeAndModes(mat);
}
void PokerHUD::Panel::Text::Load(const std::string& file, const std::string& path, const std::string& dataDir)
{
  _xmlDoc* doc = xmlParseFile(file.c_str());  
  CUSTOM_ASSERT(doc);
  Load(doc, path, dataDir);
  xmlFreeDoc(doc);
  xmlCleanupParser();
}


void PokerHUD::Panel::Text::Load(_xmlDoc* file, const std::string& path, const std::string& dataDir)
{
  std::string text;
	bool getTextResult = _headerGetT(text, file, path+"/@text");
	CUSTOM_ASSERT(getTextResult);
	std::string font;

	bool getFontResult = _headerGet(font, file, path+"/@font");
	CUSTOM_ASSERT(getFontResult);
	unsigned int fontSize;

	bool getFontSizeResult = _headerGetT(fontSize, file, path+"/@fontSize");
  CUSTOM_ASSERT(getFontSizeResult);

	std::string align;
  bool alignResult =_headerGet(align, file, path+"/@align");
  CUSTOM_ASSERT(alignResult);

  CUSTOM_ASSERT((align == "CENTER_CENTER") || (align == "RIGHT_BOTTOM") || (align == "LEFT_TOP") || (align == "RIGHT_TOP") || (align == "RIGHT_CENTER") || (align == "CENTER_TOP"));

  Create(text, dataDir + font, fontSize, align);

  osg::Vec3 translate;
  bool getTranslateResult = _headerGetT(translate, file, path+"/@translate");
  CUSTOM_ASSERT(getTranslateResult);
  setMatrix(osg::Matrix::translate(translate));
  mTranslate = translate;

  osg::Vec3 textOffset;
  bool getTextOffsetResult = _headerGetT(textOffset, file, path+"/@textOffset");
  if (getTextOffsetResult)
    mTransform->setMatrix(osg::Matrix::scale(1.0f, -1.0f, 1.0f) * osg::Matrix::translate(textOffset));

  osg::Vec4 backgroundColor;
  bool hasBackgroundColor = _headerGetT(backgroundColor, file, path+"/@backgroundColor");
  float backgroundWidth;
  bool hasBackgroundWidth = _headerGetT(backgroundWidth, file, path+"/@backgroundWidth");
  CUSTOM_ASSERT(!(hasBackgroundWidth && !hasBackgroundColor));
  CUSTOM_ASSERT(!(!hasBackgroundWidth && hasBackgroundColor));	
  if (hasBackgroundWidth && hasBackgroundColor)
    {
      EnableBackround(backgroundColor, backgroundWidth);
      mBackgroundColor = backgroundColor;
    }

  std::string backgroundLeft;
  bool hasBackgroundLeft = _headerGetT(backgroundLeft, file, path+"/@backgroundLeft");
  std::string backgroundCenter;
  bool hasBackgroundCenter = _headerGetT(backgroundCenter, file, path+"/@backgroundCenter");
  std::string backgroundRight;
  bool hasBackgroundRight = _headerGetT(backgroundRight, file, path+"/@backgroundRight");
  if (hasBackgroundLeft && hasBackgroundCenter && hasBackgroundRight)
    {
      LoadFramedBackground(file, backgroundLeft, backgroundCenter, backgroundRight, dataDir);      
    }
}

UGAMEBasicText* PokerHUD::Panel::Text::getText()
{
  return mText.get();
}
unsigned int PokerHUD::Panel::Text::lineCount(const std::string& chat)
{
  unsigned int nbLine = 0;
  size_t pos = 0;
  if (chat.empty())
    return 0;
  while((pos = chat.find('\n', pos+1)) != std::string::npos)
    ++nbLine;
  if (chat[chat.size() - 1] != '\n')
    ++nbLine;
  return nbLine;
}
void PokerHUD::Panel::Text::SetText(const std::string& text)
{
  mText->setStringUTF8(text);
  resizeBackground();
}
void PokerHUD::Panel::Text::EnableBackround(const osg::Vec4& color, float width)
{
  CUSTOM_ASSERT(mBackgroundEnabled == false);
  CUSTOM_ASSERT(mText.get());
  CUSTOM_ASSERT(mQuad.get());
  CUSTOM_ASSERT(mQuad->getNodeMask() == 0);
  mBackgroundEnabled = true;
  mBackgroundWidth = width;
  mQuad->setColor(color);
  resizeBackground();
  mQuad->setNodeMask(MAF_VISIBLE_MASK);
}
void PokerHUD::Panel::Text::LoadFramedBackground(_xmlDoc* file, const std::string &leftImage, const std::string &centerImage, const std::string &rightImage, const std::string& dataDir)
{
  CUSTOM_ASSERT(mFramedBackgroundEnabled == false);
  CUSTOM_ASSERT(mText.get());
  CUSTOM_ASSERT(mCenter.get());
  CUSTOM_ASSERT(mRight.get());
  CUSTOM_ASSERT(mLeft.get());
  mFramedBackgroundEnabled = true;
  mLeft->load(file, leftImage, dataDir);
  mCenter->load(file, centerImage, dataDir);
  mRight->load(file, rightImage, dataDir);
  resizeBackground();
}

void PokerHUD::Panel::Text::resizeBackground()
{
  if (mBackgroundEnabled)
    {
      float hudChatTextFontSize = mText->getText()->getCharacterHeight();
      unsigned int line = lineCount(mText->getText()->getText().createUTF8EncodedString());
      float hudChatTextSize = hudChatTextFontSize * line;
      float hudChatBorder = 3;
      if (line > 0)
	hudChatTextSize += mTransform->getMatrix().getTrans().y() + hudChatBorder;
      mQuad->resize(mBackgroundWidth, hudChatTextSize);
    }
  osgText::Text* osgText = getText()->getText();
  CUSTOM_ASSERT(osgText);
  const osg::BoundingBox& bbox = osgText->getBound();
  int length = (int)(bbox.xMax() - bbox.xMin());
  //int height = (int)(bbox.yMax() - bbox.yMin());
  if (mFramedBackgroundEnabled)
    {
      if ((mText->getText()->getAlignment() == osgText::Text::RIGHT_TOP)
	       || (mText->getText()->getAlignment() == osgText::Text::RIGHT_CENTER))
	{
	  int leftImageSize = mLeft->getCurrentFrame()->_iw;
	  mLeft->setMatrix(osg::Matrix::translate(-length-leftImageSize, 0, 0));
	  mCenter->setMatrix(osg::Matrix::translate(-length, 0, 0));
	  int centerQuadHeight = mCenter->getCurrentFrame()->_h;
	  mCenter->getCurrentFrame()->resize(length, centerQuadHeight); //aligned on power of 2 boundary      
	  mRight->setMatrix(osg::Matrix::translate(0, 0, 0));
	}
      else
	{
	  CUSTOM_ASSERT(false && "alignement not implemented");
	}

    }
}

PokerHUD::Panel::Panel(const std::string& file, const std::string& path, unsigned int width, unsigned int height, const std::string& dataDir) :
  mTransform(0),
  mPosition(0.0f, 0.0f, 0.0f),
  mActionSprite(0),
  mDealerSprite(0),
  mHeaderSprite(0),
  mChipsText(0),
  mNameText(0),
  mActionText(0),
  mActionTextIt(0),
  mChatText(0),
  mCardsSprite(0),
  mAction(""),
  mName(""),
  mChat(""),
  mPlayed(false),
  mInPosition(false),
  mDealer(false),
  mChipAmount(0), 
  mWidth(DEFAULT_WIDTH),
  mHeight(DEFAULT_HEIGHT),
  mChatCurrentTime(0.0f),
  mChatTotalTime(1.0f),
  mChatBeginPos(0.0f, 0.0f, 0.0f),
  mChatEndPos(0.0f, 0.0f, 0.0f),
  mChatBeginColor(0.0f, 0.0f, 0.0f, 0.0f),
  mChatEndColor(0.0f, 0.0f, 0.0f, 0.0f),
  mChatTextBeginColor(0.0f, 0.0f, 0.0f, 0.0f),
  mChatTextEndColor(0.0f, 0.0f, 0.0f, 0.0f)
{
  _xmlDoc* doc = xmlParseFile(file.c_str());  
  CUSTOM_ASSERT(doc);
  Load(doc, path, width, height, dataDir);
  xmlFreeDoc(doc);
  xmlCleanupParser();
}
PokerHUD::Panel::Panel(_xmlDoc* file, const std::string& path, unsigned int width, unsigned int height, const std::string& dataDir) :
  mTransform(0),
  mPosition(0.0f, 0.0f, 0.0f),
  mActionSprite(0),
  mDealerSprite(0),
  mHeaderSprite(0),
  mChipsText(0),
  mNameText(0),
  mActionText(0),
  mActionTextIt(0),
  mChatText(0),
  mCardsSprite(0),
  mAction(""),
  mName(""),
  mChat(""),
  mPlayed(false),
  mInPosition(false),
  mDealer(false),
  mChipAmount(0),
  mWidth(DEFAULT_WIDTH),
  mHeight(DEFAULT_HEIGHT),
  mChatCurrentTime(0.0f),
  mChatTotalTime(1.0f),
  mChatBeginPos(0.0f, 0.0f, 0.0f),
  mChatEndPos(0.0f, 0.0f, 0.0f),
  mChatBeginColor(0.0f, 0.0f, 0.0f, 0.0f),
  mChatEndColor(0.0f, 0.0f, 0.0f, 0.0f),
  mChatTextBeginColor(0.0f, 0.0f, 0.0f, 0.0f),
  mChatTextEndColor(0.0f, 0.0f, 0.0f, 0.0f)
{
  Load(file, path, width, height, dataDir);
  int i; //coverage
  i = 0; //hack
}

void PokerHUD::Panel::Load(_xmlDoc* file, const std::string& path, unsigned int width, unsigned int height, const std::string& dataDir)
{
  mWidth = width;
  mHeight = height;

  CUSTOM_ASSERT(mTransform.get() == NULL);
  mTransform = new osg::MatrixTransform();
  SetPosition(osg::Vec3(50.0f, 50.0f, 0.0f));
  addChild(mTransform.get());

  osgSprite* actionSprite = new osgSprite();
  actionSprite->load(file, path + "/spriteAction", dataDir);
  mTransform->addChild(actionSprite);
  mActionSprite = actionSprite;  
  mActionSprite->getOrCreateStateSet()->setRenderBinDetails(1, "RenderBin");

  osgSprite* headerSprite = new osgSprite();
  headerSprite->load(file, path + "/spriteHeader", dataDir);
  mTransform->addChild(headerSprite);
  mHeaderSprite = headerSprite;
  mHeaderSprite->getOrCreateStateSet()->setRenderBinDetails(2, "RenderBin");

  osgSprite* dealerSprite = new osgSprite();
  dealerSprite->load(file, path + "/spriteDealer", dataDir);
  mTransform->addChild(dealerSprite);
  mDealerSprite = dealerSprite;
  mDealerSprite->getOrCreateStateSet()->setRenderBinDetails(3, "RenderBin");
    
	PokerHUD::Panel::Text* chipsText = new PokerHUD::Panel::Text();
  chipsText->Load(file, path + "/textChips", dataDir);
  mTransform->addChild(chipsText);
  mChipsText = chipsText;
  mChipsText->getOrCreateStateSet()->setRenderBinDetails(1, "RenderBin");

  PokerHUD::Panel::Text* nameText = new PokerHUD::Panel::Text();
  nameText->Load(file, path + "/textName", dataDir);
  mTransform->addChild(nameText);
  mNameText = nameText;
  mNameText->getOrCreateStateSet()->setRenderBinDetails(2, "RenderBin");

  PokerHUD::Panel::Text* actionText = new PokerHUD::Panel::Text();
  actionText->Load(file, path + "/textAction", dataDir);
  mTransform->addChild(actionText);
  mActionText = actionText;
  mActionText->getOrCreateStateSet()->setRenderBinDetails(2, "RenderBin");

  PokerHUD::Panel::Text* actionTextIt = new PokerHUD::Panel::Text();
  actionTextIt->Load(file, path + "/textActionIt", dataDir);
  mTransform->addChild(actionTextIt);
  mActionTextIt = actionTextIt;
  mActionTextIt->setNodeMask(0);
  mActionTextIt->getOrCreateStateSet()->setRenderBinDetails(2, "RenderBin");

  PokerHUD::Panel::Text* chatText = new PokerHUD::Panel::Text();
  chatText->Load(file, path + "/textChat", dataDir);
  mTransform->addChild(chatText);
  mChatText = chatText;
  mChatText->getOrCreateStateSet()->setRenderBinDetails(0, "RenderBin");
  mChatText->setNodeMask(0);
  
  osgSprite* cardSprite = new osgSprite();
  cardSprite->load(file, path + "/spriteCard0", dataDir);
  cardSprite->setNodeMask(0);
  mTransform->addChild(cardSprite);
  mCardsSprite.push_back(cardSprite);
  cardSprite->getOrCreateStateSet()->setRenderBinDetails(3, "RenderBin");
  cardSprite = new osgSprite();
  cardSprite->load(file, path + "/spriteCard1", dataDir);
  cardSprite->setNodeMask(0);
  mTransform->addChild(cardSprite);
  mCardsSprite.push_back(cardSprite);
  cardSprite->getOrCreateStateSet()->setRenderBinDetails(3, "RenderBin");

  SetAction("None");
  SetDealer(false);
  SetChipAmount(0);
  SetName("");
  SetPlayed(false);
  SetInPosition(false);
  setNodeMask(MAF_VISIBLE_MASK);
  //getOrCreateStateSet()->setRenderBinDetails(1001, "RenderBin");
}
void PokerHUD::Panel::SetPosition(const osg::Vec3& pos, const osg::Vec3& align)
{
  mPosition = pos;
  float x0 = mPosition.x();
  float y0 = mPosition.y();
  float referenceWidth = DEFAULT_WIDTH;
  float referenceHeight = DEFAULT_HEIGHT;
  float rX0 = (x0 / referenceWidth) * 2 - 1;
  float rY0 = (y0 / referenceHeight) * 2 - 1;

  int sw = mWidth;
  int sh = mHeight;

  rX0 = floor(rX0 * sw) / float(sw);
  rY0 = floor(rY0 * sh) / float(sh);

  rX0 += 0.5f / sw;
  rY0 += 0.5f / sh;  
  mTransform->setMatrix(osg::Matrix::translate(align) * osg::Matrix::scale(2.0f/sw, -2.0f/sh, 1.0f) * osg::Matrix::translate(rX0, -rY0, 0));
}
void PokerHUD::Panel::SetName(const std::string& name)
{
  mName = name;
  mNameText->SetText(name);
}
void PokerHUD::Panel::SetAction(const std::string& action, unsigned int amount)
{
  mAction = action;
  mActionSprite->setCurrentFrame(action);
  if (action == "None")
    {
      mActionText->SetText("");
      mActionTextIt->SetText("");
    }
  else
    {
      std::ostringstream oss;
      oss << action;
      if (amount)
	oss << " " << FormatChipAmount(amount);
      mActionText->SetText(oss.str());
      mActionTextIt->SetText(oss.str());
    }

  if ((action == "Win") || (action == "Lose"))
    {
      for (unsigned int i = 0; i < mCardsSprite.size(); ++i)
	{
	  mCardsSprite[i]->setNodeMask(MAF_VISIBLE_MASK);
	  //CUSTOM_ASSERT(mCardsSprite[i]->getNumChildren() == 0);
	}
    }
  else
    {
      for (unsigned int i = 0; i < mCardsSprite.size(); ++i)
	{
	  mCardsSprite[i]->setNodeMask(0);
	  if (mCardsSprite[i]->getNumChildren())
	    mCardsSprite[i]->removeCurrentFrame();
	}
    }
  SetPlayed(mPlayed);
}
void PokerHUD::Panel::SetInPosition(bool inPosition)
{
  mInPosition = inPosition;
  if (inPosition)
    {
      mHeaderSprite->setCurrentFrame("InPosition");
      mChipsText->mLeft->setCurrentFrame("InPosition");
      mChipsText->mCenter->setCurrentFrame("InPosition");
      mChipsText->mRight->setCurrentFrame("InPosition");
      mChipsText->getText()->getText()->setColor(osg::Vec4(0, 0, 0, 1));
      mNameText->getText()->getText()->setColor(osg::Vec4(0, 0, 0, 1));
      mChipsText->SetText(mChipsText->getText()->getText()->getText().createUTF8EncodedString()); // FIXME: Transparency hack
    }
  else
    {
      mHeaderSprite->setCurrentFrame("OutPosition");
      mChipsText->mLeft->setCurrentFrame("OutPosition");
      mChipsText->mCenter->setCurrentFrame("OutPosition");
      mChipsText->mRight->setCurrentFrame("OutPosition");
      mChipsText->getText()->getText()->setColor(osg::Vec4(1, 1, 1, 1));
      mNameText->getText()->getText()->setColor(osg::Vec4(1, 1, 1, 1));
      mChipsText->SetText(mChipsText->getText()->getText()->getText().createUTF8EncodedString()); // FIXME: Transparency hack
    }
}
void PokerHUD::Panel::SetChipAmount(unsigned int chipAmount)
{
  mChipAmount = chipAmount;
  mChipsText->SetText(FormatChipAmount(chipAmount));
}
std::string PokerHUD::Panel::FormatChipAmount(unsigned int chipAmount)
{
  std::ostringstream oss;
  if (chipAmount % 100 != 0)
    oss << chipAmount / 100  << "." << std::setfill('0') << std::setw(2) << chipAmount % 100 << "$";
  else
    oss << chipAmount / 100 << "$";
  return oss.str();
}
void PokerHUD::Panel::SetDealer(bool dealer)
{
  mDealer = dealer;
  if (dealer)
    mDealerSprite->setCurrentFrame(0);
  else
    mDealerSprite->removeCurrentFrame();
}
void PokerHUD::Panel::SetPlayed(bool played)
{
  mPlayed = played;
  CUSTOM_ASSERT(mActionSprite->getNumChildren() > 0);
  if (played)
    {
      mActionSprite->setCurrentFrame(mAction+"Played");
      mActionTextIt->setNodeMask(0);
      mActionText->setNodeMask(MAF_VISIBLE_MASK);
    }
  else
    {
      mActionSprite->setCurrentFrame(mAction);
      mActionTextIt->setNodeMask(MAF_VISIBLE_MASK);
      mActionText->setNodeMask(0);
    }
}
void PokerHUD::Panel::SetChat(const std::string& chat)
{
  mChat = chat;
  mChatText->SetText(chat);
  mChatCurrentTime = 0.0f;
  mChatTotalTime = 0.2f;
  mChatCurrentShowedTime = 0.0f;
  mChatTotalShowedTime = 5.0f;
  osg::Geode* geode = dynamic_cast<osg::Geode*>(mChatText->mQuad->getChild(0));
  CUSTOM_ASSERT(geode);
  osg::Geometry* geom = dynamic_cast<osg::Geometry*>(geode->getDrawable(0));
  CUSTOM_ASSERT(geom);
  const osg::BoundingBox& bbox = geom->getBound();
  mChatBeginPos = mChatText->mTranslate - osg::Vec3(0.0f, bbox.yMax() - bbox.yMin(), 0.0f);
  mChatEndPos = mChatText->mTranslate;
  osg::Vec4 colorFrom = mChatText->mBackgroundColor;
  colorFrom.w() = 0.0f;
  osg::Vec4 colorTo = mChatText->mBackgroundColor;
  mChatBeginColor = colorFrom;
  mChatEndColor = colorTo;
  mChatTextBeginColor = osg::Vec4(1.0f, 1.0f, 1.0f, 0.0f);
  mChatTextEndColor = osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f);
}
void PokerHUD::Panel::SetCards(const std::vector<std::string>& cards)
{
  CUSTOM_ASSERT(mCardsSprite.size() == cards.size());
  mCardsSprite[0]->setCurrentFrame(cards[0]);
  mCardsSprite[1]->setCurrentFrame(cards[1]);
}
void PokerHUD::Panel::Update(float delta)
{
  CUSTOM_ASSERT(delta >= 0.0f);
  mChatCurrentTime += delta;
  mChatCurrentTime = std::min(mChatCurrentTime, mChatTotalTime);
  float t = mChatCurrentTime / mChatTotalTime;
  //hacky
  bool showing = (mChatTextBeginColor.w() == 0.0f);
  if (showing)
    t = sqrt(t);
  else
    t = t * t;
  CUSTOM_ASSERT((0.0f <= t) && (t <= 1.0f));
  {
    const osg::Vec3& from = mChatBeginPos;
    const osg::Vec3& to = mChatEndPos;
    osg::Vec3 current = from * (1.0f - t) + to * t;
    mChatText->setMatrix(osg::Matrix::translate(current));
  }
  {
    const osg::Vec4& from = mChatBeginColor;
    const osg::Vec4& to = mChatEndColor;
    osg::Vec4 current = from * (1.0f - t) + to * t;
    mChatText->mQuad->setColor(current);
  }
  {
    const osg::Vec4& from = mChatTextBeginColor;
    const osg::Vec4& to = mChatTextEndColor;
    osg::Vec4 current = from * (1.0f - t) + to * t;
    mChatText->getText()->getText()->setColor(current);
  }

  if ((t == 1.0f) && (mChatCurrentShowedTime < mChatTotalShowedTime))
    {
      mChatCurrentShowedTime += delta;
      if (mChatCurrentShowedTime >= mChatTotalShowedTime)
	{
	  mChatTotalShowedTime = mChatTotalShowedTime;
	  mChatCurrentTime = 0.0f;
	  mChatTotalTime = 1.0f;
	  osg::Vec3 current = mChatEndPos;
	  mChatEndPos = mChatBeginPos;
	  mChatBeginPos = current;
	  osg::Vec4 currentColor = mChatEndColor;
	  mChatEndColor = mChatBeginColor;
	  mChatBeginColor = currentColor;
	  osg::Vec4 currentTextColor = mChatTextEndColor;
	  mChatTextEndColor = mChatTextBeginColor;
	  mChatTextBeginColor = currentTextColor;
	}
    }
}
PokerHUD::PokerHUD() : mPanels(0), mPositionFrom(0), mPositionTo(0), mT(0.0f), mMoving(false), mWay(0), mTimeToInterpolate(0.0f)
{
}
PokerHUD::PokerHUD(const std::string& file, const std::string& path, unsigned int width, unsigned int height, const std::string& dataDir) : mPanels(0), mPositionFrom(0), mPositionTo(0), mT(0.0f), mMoving(false), mWay(0), mTimeToInterpolate(0.0f)
{
  Load(file, path, width, height, dataDir);
}
PokerHUD::PokerHUD(const std::vector<osg::Vec3>& positionFrom, const std::vector<osg::Vec3>& positionTo, float timeToInterpolate, const std::string& file, const std::string& path, unsigned int width, unsigned int height, const std::string& dataDir) : mPanels(0), mPositionFrom(0), mPositionTo(0), mT(0.0f), mMoving(false), mWay(0), mTimeToInterpolate(0.0f)
{
  Create(positionFrom, positionTo, timeToInterpolate, file, path, width, height, dataDir);
}
void PokerHUD::Create(const std::vector<osg::Vec3>& positionFrom, const std::vector<osg::Vec3>& positionTo, float timeToInterpolate, const std::string& file, const std::string& path, unsigned int width, unsigned int height, const std::string& dataDir)
{
  _xmlDoc* doc = xmlParseFile(file.c_str());  
	CUSTOM_ASSERT(doc);
  Create(positionFrom, positionTo, timeToInterpolate, doc, path, width, height, dataDir);
  xmlFreeDoc(doc);
  xmlCleanupParser();
}
void PokerHUD::Create(const std::vector<osg::Vec3>& positionFrom, const std::vector<osg::Vec3>& positionTo, float timeToInterpolate, _xmlDoc* file, const std::string& path, unsigned int width, unsigned int height, const std::string& dataDir)
{
  const unsigned int panelCount = PLAYER_COUNT;
  CUSTOM_ASSERT(mPanels.empty());
  CUSTOM_ASSERT(positionFrom.size() == panelCount);
  CUSTOM_ASSERT(positionTo.size() == panelCount);
  CUSTOM_ASSERT(timeToInterpolate >= 0.0f);
  mPanels.resize(panelCount);
  mPositionFrom.resize(panelCount);
  mPositionTo.resize(panelCount);
  mTimeToInterpolate = timeToInterpolate;

  osg::MatrixTransform* modelview_abs = new osg::MatrixTransform;
  modelview_abs->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
  modelview_abs->setMatrix(osg::Matrix::identity());    
  osg::Projection *projection = new osg::Projection;
  osg::Matrix projMat = osg::Matrix::identity();
  projMat(2, 2) = 0.00000f; // z is always 0
  projection->setMatrix( projMat );
  modelview_abs->addChild(projection);   
  addChild(modelview_abs);
  for (unsigned int i = 0; i < mPanels.size(); ++i)
    {
      mPositionFrom[i] = positionFrom[i];
      mPositionTo[i] = positionTo[i];
      Panel* panel = new Panel(file, path, width, height, dataDir);
      //panel->SetPosition(mPositionFrom[i]);      
      projection->addChild(panel);
      mPanels[i] = panel;
      DisablePanel(i);
    }
  //disable hud collision
  getOrCreateStateSet()->setMode(GL_DEPTH_TEST, osg::StateAttribute::OFF);
  setNodeMask(MAF_VISIBLE_MASK);
}
void PokerHUD::Load(const std::string& file, const std::string& path, unsigned int width, unsigned int height, const std::string& dataDir)
{
  _xmlDoc* doc = xmlParseFile(file.c_str());
	CUSTOM_ASSERT(doc);
  Load(doc, path, width, height, dataDir);
  xmlFreeDoc(doc);
  xmlCleanupParser();
}
void PokerHUD::Load(_xmlDoc* file, const std::string& path, unsigned int width, unsigned int height, const std::string& dataDir)
{
  std::vector<osg::Vec3> positionFrom;
  std::vector<osg::Vec3> positionTo;
  float timeToInterpolate;

	bool positionFromHeaderResult = _headerGetListT(positionFrom, file, path + "/positionFrom/position/@translate");
  CUSTOM_ASSERT(positionFromHeaderResult);
  bool positionToHeaderResult =_headerGetListT(positionTo, file, path + "/positionTo/position/@translate");
  CUSTOM_ASSERT(positionToHeaderResult);
  bool timeToInterpolateHeaderResult = _headerGetT(timeToInterpolate, file, path + "/@timeToInterpolate");
  CUSTOM_ASSERT(timeToInterpolateHeaderResult);
  Create(positionFrom, positionTo, timeToInterpolate, file, path, width, height, dataDir);
}
void PokerHUD::EnablePanel(unsigned int index)
{
  CUSTOM_ASSERT_MSG(!IsPanelEnabled(index), "PokerHUD::EnablePanel panel is already Enabled");
  CUSTOM_ASSERT(index < mPanels.size());
  mPanels[index]->setNodeMask(MAF_VISIBLE_MASK);
}
void PokerHUD::DisablePanel(unsigned int index)
{
  CUSTOM_ASSERT_MSG(IsPanelEnabled(index), "PokerHUD::EnablePanel panel is already Disabled");
  CUSTOM_ASSERT(index < mPanels.size());
  mPanels[index]->setNodeMask(0);
}
bool PokerHUD::IsPanelEnabled(unsigned int index) const
{
  if (!CUSTOM_ASSERT(index < mPanels.size())) return false;
  return (mPanels[index]->getNodeMask() == MAF_VISIBLE_MASK);
}
void PokerHUD::Show(unsigned int meIndex)
{
  CUSTOM_ASSERT(meIndex < PokerHUD::PLAYER_COUNT);
  CUSTOM_ASSERT(mPanels.size() == mPositionFrom.size());
  CUSTOM_ASSERT(mPositionFrom.size() == mPositionTo.size());
  mMoving = true;
  mWay = 1.0f;
  UpdatePosition(0.0f, meIndex);
}
void PokerHUD::Hide(unsigned int meIndex)
{
  CUSTOM_ASSERT(meIndex < PokerHUD::PLAYER_COUNT);
  mMoving = true;
  mWay = -1.0f;
  UpdatePosition(0.0f, meIndex);
}
//should be unsigned int meIndex, float delta
void PokerHUD::UpdatePosition(float delta, unsigned int meIndex)
{
  CUSTOM_ASSERT(meIndex < PokerHUD::PLAYER_COUNT);
  const float totalTime = 0.5f;
  float t = mT;
  t += delta/totalTime * mWay;
  t = std::min(std::max(t, 0.0f), 1.0f);
  bool hideInterpolationFinished = (mWay == -1) && (t == 0.0f);
  bool showInterpolationFinished = (mWay == 1) && (t == 1.0f);
  if (hideInterpolationFinished || showInterpolationFinished)
    mMoving = false;
  mT = t;
    
  for (unsigned int i = 0; i < mPanels.size(); ++i)
    {
      Panel* panel = mPanels[i].get();
      if (hideInterpolationFinished)
	{
	  panel->mChatText->setNodeMask(0);
	}
      if (showInterpolationFinished)
	{
	  panel->mChatText->setNodeMask(MAF_VISIBLE_MASK);
	}
      unsigned int positionIndex = seatToPositionIndex(meIndex, i);
      const osg::Vec3& from = mPositionFrom[positionIndex];
      const osg::Vec3& to = mPositionTo[positionIndex];      
      osg::Vec3 current = from*(1.0f - t) + to * t;
      osg::Vec3 align = osg::Vec3(0.0f, 0.0f, 0.0f);
      if (positionIndex < 4)
	{
	}
      else if (positionIndex < 7)
	{
	  align.x() -= 68;
	}
      else
	{
	  align.x() -= 137;
	}
      panel->SetPosition(current, align);
      panel->Update(delta);
      //panel->getOrCreateStateSet()->setRenderBinDetails(10-positionIndex, "RenderBin");
    }
}
void PokerHUD::DealerChangeToSeat(unsigned int seat)
{
	unsigned int panelIndex = seat;
	CUSTOM_ASSERT(panelIndex < mPanels.size());
	CUSTOM_ASSERT(IsPanelEnabled(panelIndex));
	for (unsigned int i = 0; i < mPanels.size(); ++i)
	{
		PokerHUD::Panel* panel = mPanels[i].get();
		bool dealerState = (i == panelIndex);
		if (panel->mDealer != dealerState)
			panel->SetDealer(dealerState);
	}
}

void PokerHUD::DisableDealer()
{
	for (unsigned int i = 0; i < mPanels.size(); ++i)
	{
		PokerHUD::Panel* panel = mPanels[i].get();
		if (panel->mDealer)
			panel->SetDealer(false);
	}
}

void PokerHUD::PositionChangeToSeat(unsigned int seat)
{
  unsigned int panelIndex = seat;
  CUSTOM_ASSERT(panelIndex < mPanels.size());
  for (unsigned int i = 0; i < mPanels.size(); ++i)
    {
      PokerHUD::Panel* panel = mPanels[i].get();
      bool positionState = (i == panelIndex);
      if (panel->mInPosition != positionState)
	panel->SetInPosition(positionState);
      if (positionState)
	{
	  panel->SetPlayed(true);
	  panel->SetAction("None");
	}
    }
}
void PokerHUD::PlayerArrive(unsigned int seat, const std::string& name)
{
  unsigned int panelIndex = seat;
  CUSTOM_ASSERT(panelIndex < mPanels.size());
	if (!IsPanelEnabled(panelIndex)) // we can be called twice when switching table, fix the multitable mechanism!
		EnablePanel(panelIndex);
  mPanels[panelIndex]->SetName(name);
}
void PokerHUD::PlayerLeave(unsigned int seat)
{
  unsigned int panelIndex = seat;
  CUSTOM_ASSERT(panelIndex < mPanels.size());
  mPanels[panelIndex]->SetName("");
  DisablePanel(panelIndex);
}
void PokerHUD::PlayerAction(unsigned int seat, const std::string& action, unsigned int amount)
{
  unsigned int panelIndex = seat;
  CUSTOM_ASSERT(IsPanelEnabled(panelIndex));
  CUSTOM_ASSERT(panelIndex < mPanels.size());
  mPanels[panelIndex]->SetAction(action, amount);
}
void PokerHUD::PlayerPlayed(unsigned int seat, bool played)
{
  unsigned int panelIndex = seat;
  CUSTOM_ASSERT(IsPanelEnabled(panelIndex));
  CUSTOM_ASSERT(panelIndex < mPanels.size());
  mPanels[panelIndex]->SetPlayed(played);
}
void PokerHUD::PlayerChipAmountChanged(unsigned int seat, unsigned int amount)
{
  unsigned int panelIndex = seat;
  CUSTOM_ASSERT(IsPanelEnabled(panelIndex));
  CUSTOM_ASSERT(panelIndex < mPanels.size());
  mPanels[panelIndex]->SetChipAmount(amount);
}
void PokerHUD::PlayerSetCards(unsigned int seat, std::vector<std::string>& cards)
{
  unsigned int panelIndex = seat;
  CUSTOM_ASSERT(IsPanelEnabled(panelIndex));
  CUSTOM_ASSERT(panelIndex < mPanels.size());
  mPanels[panelIndex]->SetCards(cards);
}
void PokerHUD::PlayerChat(unsigned int seat, const std::string& chat)
{
  unsigned int panelIndex = seat;
  CUSTOM_ASSERT(IsPanelEnabled(panelIndex));
  CUSTOM_ASSERT(panelIndex < mPanels.size());
  mPanels[panelIndex]->SetChat(chat);
}
void PokerHUD::NewTurn()
{
  for (unsigned int i = 0; i < mPanels.size(); ++i)
    {
      if (IsPanelEnabled(i))
	{
	  mPanels[i]->SetPlayed(false);
	}
    }
}
void PokerHUD::NewRound()
{
  for (unsigned int i = 0; i < mPanels.size(); ++i)
    {
      if (IsPanelEnabled(i))
	{
	  mPanels[i]->SetPlayed(false);
	  mPanels[i]->SetAction("None");
	}
    }
}
unsigned int PokerHUD::seatToPositionIndex(unsigned int meIndex, unsigned int seatIndex)
{
  if (!CUSTOM_ASSERT(seatIndex < PokerHUD::PLAYER_COUNT)) return 0;
  if (!CUSTOM_ASSERT(meIndex < PokerHUD::PLAYER_COUNT)) return 0;
  unsigned int rIndex = 
    (seatIndex >= meIndex) ?
    (seatIndex - meIndex) : 
    (PokerHUD::PLAYER_COUNT + seatIndex - meIndex);
  if (!CUSTOM_ASSERT(rIndex < PokerHUD::PLAYER_COUNT)) return 0;
  return rIndex;
}
PokerHUDController::PokerHUDController() : mHUD(NULL)
{
}
PokerHUDController::PokerHUDController(PokerHUD* hud) : mHUD(NULL)
{
  Create(hud);
}
PokerHUDController::~PokerHUDController()
{
  mHUD = NULL;
}
void PokerHUDController::Create(PokerHUD* hud)
{
  CUSTOM_ASSERT(hud != NULL);
  CUSTOM_ASSERT(mHUD.get() == NULL);
  mHUD = hud;
}
void PokerHUDController::PythonAccept(const MAFPacket& packet, const std::map<int, unsigned int>& serial2seat)
{
	if (packet.IsType("POKER_DEALER"))
	{
		int dealerSeat;
		packet.GetMember("dealer", dealerSeat);
		if (dealerSeat == -1)
		{
			mHUD->DisableDealer();
		}
		else
		{
			if (mHUD->IsPanelEnabled(dealerSeat) == false)
			{
				g_critical("dealer on a empty seat %i", dealerSeat);
				return;
			}
			mHUD->DealerChangeToSeat(dealerSeat);
		}
	}
  else if (packet.IsType("POKER_PLAYER_ARRIVE"))
    {
      std::string name;
      packet.GetMember("name", name);
      unsigned int seat;
      packet.GetMember("seat", seat);
      mHUD->PlayerArrive(seat, name);
    }
  else if (packet.IsType("POKER_PLAYER_LEAVE"))
    {
      int serial;
      packet.GetMember("serial", serial);
      unsigned int seat;
      packet.GetMember("seat", seat);
      mHUD->PlayerLeave(seat);
    }
  else if (packet.IsType("POKER_FOLD"))
    {
      int serial;
      packet.GetMember("serial", serial);      
			if ((serial == 0) || (serial2seat.find(serial) == serial2seat.end()))
			{
				g_critical("serial %i is dealer or not in serial2seat", serial);
				return;
			}
      unsigned int seat = (*(serial2seat.find(serial))).second;
      mHUD->PlayerAction(seat, "Fold");
    }
  else if (packet.IsType("POKER_CHECK"))
    {
      int serial;
      packet.GetMember("serial", serial);
			if ((serial == 0) || (serial2seat.find(serial) == serial2seat.end()))
			{
				g_critical("serial %i is dealer or not in serial2seat", serial);
				return;
			}
      unsigned int seat = (*(serial2seat.find(serial))).second;
      mHUD->PlayerAction(seat, "Check");
    }
  else if (packet.IsType("POKER_CALL"))
    {
      int serial;
      packet.GetMember("serial", serial);
			if ((serial == 0) || (serial2seat.find(serial) == serial2seat.end()))
			{
				g_critical("serial %i is dealer or not in serial2seat", serial);
				return;
			}
      unsigned int seat = (*(serial2seat.find(serial))).second;
      unsigned int amount = 0;
      //packet.GetMember("amount", amount);
      mHUD->PlayerAction(seat, "Call", amount);
    }
  else if (packet.IsType("POKER_RAISE"))
    {
      int serial;
      packet.GetMember("serial", serial);
			if ((serial == 0) || (serial2seat.find(serial) == serial2seat.end()))
			{
				g_critical("serial %i is dealer or not in serial2seat", serial);
				return;
			}
      unsigned int seat = (*(serial2seat.find(serial))).second;
      unsigned int amount = 0;
      packet.GetMember("amount", amount);
      std::string action = "Bet";
      {
	unsigned int size = mHUD->mPanels.size();
	for (unsigned int i = 0; i < size; i++)
	  {
	    const PokerHUD::Panel* panel = mHUD->mPanels[i].get();
	    const std::string &lastAction = panel->mAction;
	    bool played = panel->mPlayed;
	    bool betIsARaise = played && (lastAction == "Bet" || lastAction == "Call" || lastAction == "Blind" || lastAction == "Raise");
	    if (betIsARaise)
	      {
		action = "Raise";
		break;
	      }
	  }
      }
      mHUD->PlayerAction(seat, action, amount);

    }
  else if (packet.IsType("POKER_BLIND"))
    {
      int serial;
      packet.GetMember("serial", serial);
      if ((serial == 0) || (serial2seat.find(serial) == serial2seat.end()))
			{
				g_critical("serial %i is dealer or not in serial2seat", serial);
				return;
			}
      unsigned int seat = (*(serial2seat.find(serial))).second;
      unsigned int amount = 0;
      packet.GetMember("amount", amount);
      mHUD->PlayerAction(seat, "Blind", amount);
    }
  else if (packet.IsType("POKER_POSITION"))
    {
      int serial;
      packet.GetMember("serial", serial);
      if ((serial == 0) || (serial2seat.find(serial) == serial2seat.end()))
			{
				g_critical("serial %i is dealer or not in serial2seat", serial);
				return;
			}
      unsigned int seat = (*(serial2seat.find(serial))).second;
      mHUD->PositionChangeToSeat(seat);
    }
  else if (packet.IsType("POKER_END_ROUND"))
    {
      mHUD->NewTurn();
    }
  else if (packet.IsType("POKER_START"))
    {
      mHUD->NewRound();
    }
  else if (packet.IsType("POKER_PLAYER_CHIPS"))
    {
      int serial;
      packet.GetMember("serial", serial);
      if ((serial == 0) || (serial2seat.find(serial) == serial2seat.end()))
			{
				g_critical("serial %i is dealer or not in serial2seat", serial);
				return;
			}
      unsigned int seat = (*(serial2seat.find(serial))).second;
      unsigned int money = 0;
      packet.GetMember("money", money);
      mHUD->PlayerChipAmountChanged(seat, money);
    }
  else if (packet.IsType("POKER_WIN"))
    {
      std::vector<int> serials;
      packet.GetMember("serials", serials);
      typedef std::map<int, unsigned int>::const_iterator It;
      for (It i = serial2seat.begin(); i != serial2seat.end(); ++i)
	{	  
	  int serial = (*i).first;
	  unsigned int seat = (*i).second;
	  if (serial == 0)
	    continue; // hack dealer
	  bool found = (std::find(serials.begin(), serials.end(), serial) != serials.end());
	  if (found)
	    {
	      mHUD->PlayerAction(seat, "Win");
	    }
	  else
	    {
	      unsigned int panelIndex = seat;
	      CUSTOM_ASSERT(mHUD->IsPanelEnabled(panelIndex));
	      CUSTOM_ASSERT(panelIndex < mHUD->mPanels.size());
	      if (mHUD->mPanels[panelIndex]->mAction != "Fold") // FIXME: not so stateless
		mHUD->PlayerAction(seat, "Lose");
	    }
	}
    }
  else if (packet.IsType("POKER_CHAT"))
    {
      int serial;
      packet.GetMember("serial", serial);
			if (serial == 0 || serial2seat.find(serial) == serial2seat.end()) {
				g_critical("serial %i is dealer or not in serial2seat", serial);
				return;
			}
      unsigned int seat = (*(serial2seat.find(serial))).second;
      std::string message;
      packet.GetMember("message", message);
      mHUD->PlayerChat(seat, message);
    }
  else if (packet.IsType("POKER_PLAYER_CARDS"))
    {
      int serial;
      packet.GetMember("serial", serial);
			if ((serial == 0) || (serial2seat.find(serial) == serial2seat.end()))
			{
				g_critical("serial %i is dealer or not in serial2seat", serial);
				return;
			}
      unsigned int seat = (*(serial2seat.find(serial))).second;
      char* number2card[] =
	{
	  "2h","3h","4h","5h","6h","7h","8h","9h","Th","Jh","Qh","Kh","Ah",
	  "2d","3d","4d","5d","6d","7d","8d","9d","Td","Jd","Qd","Kd","Ad",
	  "2c","3c","4c","5c","6c","7c","8c","9c","Tc","Jc","Qc","Kc","Ac",
	  "2s","3s","4s","5s","6s","7s","8s","9s","Ts","Js","Qs","Ks","As",
	};
      std::vector<int> cards;
      packet.GetMember("cards", cards);
      std::vector<std::string> strCards;
      for (unsigned int i = 0; i < cards.size(); ++i)
	{
	  int card = cards[i];
	  if (card == 255)
	    continue;
	  card &= 0x3f;
	  CUSTOM_ASSERT(card < int((sizeof(number2card)/sizeof(*number2card))));
	  strCards.push_back(number2card[card]);
	  
	}
      if (2 == strCards.size())
	{
	  mHUD->PlayerSetCards(seat, strCards);
	}
      if (1 == strCards.size())
	{
	  g_critical("only one card is hidden %i %i", cards[0], cards[1]);
	}
    }
}
