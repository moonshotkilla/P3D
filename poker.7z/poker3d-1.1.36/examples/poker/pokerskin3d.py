#!/usr/bin/python
# Copyright (C) 2004, 2005, 2006 Mekensleep
#
# Mekensleep
# 24 rue vieille du temple
# 75004 Paris
#       licensing@mekensleep.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
# Authors:
#  Loic Dachary <loic@gnu.org>
#
#
import sys
import os
import platform

from string import split, lower
from os import makedirs
from os.path import expanduser, exists
import signal
from traceback import print_exc
import libxml2
from shutil import copy

from time import sleep
from random import choice, uniform, randint

from twisted.internet import reactor, error, ssl

from pokernetwork.pokerclient import PokerClientFactory, PokerSkin
from pokernetwork.pokerclientpackets import *
from pokernetwork.proxy import Connector

from pokerui import pokerinterface
from poker.pokeroutfit import PokerOutfit, PokerOutfitEditor

class PokerSkin3D(PokerSkin):
    def __init__(self, *args, **kwargs):
        self.skeletons = ["player.female.cal3d", "player.male.cal3d"]
        settings = kwargs['settings']
        self.verbose = int(settings.headerGet("/settings/@verbose"))
        self.outfit_infos = PokerOutfit(kwargs['settings'])
        self.outfit_editor = PokerOutfitEditor(self.outfit_infos)
        PokerSkin.__init__(self, *args, **kwargs)

    def destroy(self):
        self.outfit_editor.destroy()

    def interfaceReady(self, interface, display):
        self.outfit_editor.setInterface(interface, display)

    def interpret(self, url, outfit):
        if url not in self.skeletons + [ 'random' ]:
            url = "random"
        if url == "random":
            url = choice(self.skeletons)

        if "<?xml" not in outfit:
            outfit = "random"
        else:
            outfit = self.outfit_infos.upgradeString(url, outfit)
            
        if outfit == "random":
            sex = self.outfit_infos.path2sex(url)
            outfit = self.outfit_infos.randomOutfitAsString(sex)
        if self.verbose > 3: print "PokerSkin3D::interpret: url = %s, outfit = %s" % ( url, outfit )
        return (url, outfit)

    def setOutfit(self, outfit):
        PokerSkin.setOutfit(self, self.outfit_infos.upgradeString(self.getUrl(), outfit))
        if "<?xml" in outfit:
            self.outfit_infos.setOutfitFromString(self.getUrl(), self.getOutfit())
        
    def hideOutfitEditor(self):
        self.outfit_editor.hideOutfits()

    def showOutfitEditor(self, select_callback):
        self.outfit_editor.showOutfits(self.url, select_callback)
class PokerSkin3D(PokerSkin):
    def __init__(self, *args, **kwargs):
        self.skeletons = ["player.female.cal3d", "player.male.cal3d"]
        settings = kwargs['settings']
        self.verbose = int(settings.headerGet("/settings/@verbose"))
        self.outfit_infos = PokerOutfit(kwargs['settings'])
        self.outfit_editor = PokerOutfitEditor(self.outfit_infos)
        PokerSkin.__init__(self, *args, **kwargs)

    def destroy(self):
        self.outfit_editor.destroy()

    def interfaceReady(self, interface, display):
        self.outfit_editor.setInterface(interface, display)

    def interpret(self, url, outfit):
        if url not in self.skeletons + [ 'random' ]:
            url = "random"
        if url == "random":
            url = choice(self.skeletons)

        if "<?xml" not in outfit:
            outfit = "random"
        else:
            outfit = self.outfit_infos.upgradeString(url, outfit)
            
        if outfit == "random":
            sex = self.outfit_infos.path2sex(url)
            outfit = self.outfit_infos.randomOutfitAsString(sex)
        if self.verbose > 3: print "PokerSkin3D::interpret: url = %s, outfit = %s" % ( url, outfit )
        return (url, outfit)

    def setOutfit(self, outfit):
        PokerSkin.setOutfit(self, self.outfit_infos.upgradeString(self.getUrl(), outfit))
        if "<?xml" in outfit:
            self.outfit_infos.setOutfitFromString(self.getUrl(), self.getOutfit())
        
    def hideOutfitEditor(self):
        self.outfit_editor.hideOutfits()

    def showOutfitEditor(self, select_callback):
        self.outfit_editor.showOutfits(self.url, select_callback)
class PokerSkin3D(PokerSkin):
    def __init__(self, *args, **kwargs):
        self.skeletons = ["player.female.cal3d", "player.male.cal3d"]
        settings = kwargs['settings']
        self.verbose = int(settings.headerGet("/settings/@verbose"))
        self.outfit_infos = PokerOutfit(kwargs['settings'])
        self.outfit_editor = PokerOutfitEditor(self.outfit_infos)
        PokerSkin.__init__(self, *args, **kwargs)

    def destroy(self):
        self.outfit_editor.destroy()

    def interfaceReady(self, interface, display):
        self.outfit_editor.setInterface(interface, display)

    def interpret(self, url, outfit):
        if url not in self.skeletons + [ 'random' ]:
            url = "random"
        if url == "random":
            url = choice(self.skeletons)

        if "<?xml" not in outfit:
            outfit = "random"
        else:
            outfit = self.outfit_infos.upgradeString(url, outfit)
            
        if outfit == "random":
            sex = self.outfit_infos.path2sex(url)
            outfit = self.outfit_infos.randomOutfitAsString(sex)
        if self.verbose > 3: print "PokerSkin3D::interpret: url = %s, outfit = %s" % ( url, outfit )
        return (url, outfit)

    def setOutfit(self, outfit):
        PokerSkin.setOutfit(self, self.outfit_infos.upgradeString(self.getUrl(), outfit))
        if "<?xml" in outfit:
            self.outfit_infos.setOutfitFromString(self.getUrl(), self.getOutfit())
        
    def hideOutfitEditor(self):
        self.outfit_editor.hideOutfits()

    def showOutfitEditor(self, select_callback):
        self.outfit_editor.showOutfits(self.url, select_callback)

#
# Emacs debug:
# cp /usr/lib/python2.3/pdb.py .
# M-x pdb
# ../../underware pdb.py poker3d.py file:conf/client/mekensleep.xml
#
