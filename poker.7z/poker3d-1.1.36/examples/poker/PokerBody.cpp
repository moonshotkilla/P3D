/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Johan Euphrosine <johan@mekensleep.com>
 *  Cedric Pinson <cpinson@freesheep.org>
 *  Igor Kravtchenko <igor@tsarevitch.org>
 */

#include "pokerStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifndef POKER_USE_VS_PCH
#ifdef WIN32
#include "config_win32.h"
#endif // WIN32
#include <cstdio>

#ifdef USE_NPROFILE
#include <nprofile/profile.h>
#else  //USE_NPROFILE
#define NPROFILE_SAMPLE(a)
#endif //USE_NPROFILE

#include "pokerStdAfx.h"
#include <iostream>

#include <cal3d/scheduler.h>

#include <osg/Material>
#include <osg/Depth>
#include <osg/Texture2D>
#include <osg/BlendFunc>
#include <osg/AlphaFunc>

#include <osgCal/SubMeshSoftware>
#include <osgCal/SubMeshHardware>

#include <maf/application.h>
#include <maf/utils.h>
#include <maf/hit.h>
#include <maf/MultipleAnimationPathCallback.h>
#include <maf/depthmask.h>
#include <maf/packets.h>
#include <maf/assert.h>
#include <maf/renderbin.h>

#include <varseditor/varseditor.h>
#include <cal3d/corekeyframe.h>
#include <PokerBody.h>
#include <PokerError.h>
#include <PokerCard.h>
#include <PokerApplication.h>
#include <PokerFoldAnimation.h>
#include <PokerSceneView.h>
#include <PokerNoise.h>
#include <CustomAssert/CustomAssert.h>
#endif

#ifdef WIN32
# define snprintf _snprintf
#endif
// Noise

#include "PokerPlayer.h"
#include "PokerMoveChips.h"

//using namespace cal3d;

// Model

PokerBodyModel::PokerBodyModel(MAFApplication* application,MAFOSGData* seat,bool me) :
mMe(me),
mLoopBreath(false),
mFoldCards(0),
mCards(0),
mDeck(0),
mNbCardsToPlay(0),
mDataPath(""),
mLookatId(0),
mNoiseAnimations(0),
mFocus(""),
mForceTransparencyRenderBin(false),
mAnimationsEnabled(true)
{
  mCurrentAlpha=1;
  mMinAlpha=0.5;
  mNumberOfCardsReady=0;

  mFoldAnimation=new PlayFoldAnimation(this);
  mFoldSequence=new PokerFoldAnimation((PokerApplication*)application,seat);
  texmatEyes_ = new osg::TexMat();
  newModelForTableShadow_ = NULL;
	mbPlayFoldAnimation = false;
	mSH = NULL;
}


float PokerBodyModel::ComputeAlphaFromDirection(const osg::Vec3 camDirection)
{
  osg::Matrix tr=MAFComputeLocalToWorld(GetArtefact());
  //  osg::Vec3 dir(tr(2,0),tr(2,1),tr(2,2));
  osg::Vec3 dir(tr(2,0),0,tr(2,2));

  osg::Vec3 myCam=camDirection;
  myCam[1]=0;
  myCam.normalize();

  // use only x,z no y
  float a=myCam*dir;
  float alpha=1;
  float maxAngle=cos(mAngleAlpha);
  if (a>maxAngle) {
    alpha=mMinAlpha+1-(a-maxAngle)/(1.0-maxAngle);
    if (alpha>1)
      alpha=1;
  }

  return alpha;
}


void PokerBodyModel::SetAlpha(float _alpha) 
{
//	return;

	if (_alpha < 0)
		_alpha = 0;
	if (_alpha > 1)
		_alpha = 1;

	int nb = GetArtefact()->getNumDrawables();

	mCurrentAlpha = _alpha;

	for (int i = 0; i < nb; i++) {
		osg::Drawable *drawable = GetArtefact()->getDrawable(i);
		osg::StateSet *state = drawable->getStateSet();

		if (!state)
			continue;

		if (mOriginallyTransparent.find(state) == mOriginallyTransparent.end()) {
			osg::BlendFunc *bf = (osg::BlendFunc*) state->getAttribute(osg::StateAttribute::BLENDFUNC);
			mOriginallyTransparent[state] = bf ? true : false;
		}

		osg::BlendFunc *bf = (osg::BlendFunc*) state->getAttribute(osg::StateAttribute::BLENDFUNC);
		if (!bf) {
			bf = new osg::BlendFunc();
			state->setAttributeAndModes(bf, osg::StateAttribute::ON);
		}
	}

	if (mCurrentAlpha == 1) { // && !mForceTransparencyRenderBin) {

		for (int i = 0; i < nb; i++) {

			osg::Drawable *drawable = GetArtefact()->getDrawable(i);
			osg::StateSet *state = drawable->getStateSet();
			osg::Material *material = NULL;

			if (state)
				material = dynamic_cast<osg::Material*>(state->getAttribute(osg::StateAttribute::MATERIAL));

			if (material) {
				// 	g_error("PokerBodyController::Update no material in the drawable of osgCal::Model");

				osg::Vec4f diffuse = material->getDiffuse(osg::Material::FRONT_AND_BACK);
				diffuse._v[3] = 1;
				material->setDiffuse(osg::Material::FRONT_AND_BACK, diffuse);

				if (mOriginallyTransparent[state] == false) {
					state->setMode(GL_BLEND, osg::StateAttribute::OFF);
					if (!MAFRenderBin::Instance().SetupRenderBin("PlayerTransparency", state))
						MAF_ASSERT(0 && "PlayerTransparency not found in client.xml");
				} else {
					state->setMode(GL_BLEND, osg::StateAttribute::ON);
					state->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
				}
			}

		}
	} else {

		for (int i = 0 ; i < nb; i++) {

			osg::Drawable *drawable = GetArtefact()->getDrawable(i);
			osg::StateSet *state = drawable->getStateSet();
			osg::Material *material = NULL;

			// dont modify the cards transparency
			if (!state || mCardsTable.find(state) != mCardsTable.end())
				continue;

			material = dynamic_cast<osg::Material*> (state->getAttribute(osg::StateAttribute::MATERIAL));

			if (material) {
				osg::Vec4f diffuse = material->getDiffuse(osg::Material::FRONT_AND_BACK);
				diffuse._v[3] = _alpha;
				material->setDiffuse(osg::Material::FRONT_AND_BACK, diffuse);
				state->setMode(GL_BLEND, osg::StateAttribute::ON);

				state->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
			}
		}
	}
}

PokerBodyModel::~PokerBodyModel()
{
	g_debug("PokerBodyModel::~PokerBodyModel");
  for(std::vector<NoiseElement*>::iterator i = mNoiseAnimations.begin();
      i != mNoiseAnimations.end();
      i++)
    delete *i;

  if (mFoldCards)
    delete mFoldCards;

  delete mFoldCards;
  delete mFoldSequence;
  delete mFoldAnimation;

	PokerSceneView *instance = PokerSceneView::getInstance();
	if (instance) {
		int nbDraw = mOsgCalModel->getNumDrawables();
		for (int i = 0; i < nbDraw; i++) {
			osg::Drawable *drawable = mOsgCalModel->getDrawable(i);
			const std::string &className = drawable->className();
			std::string name;
			if (className == "SubMeshSoftware")
				name = ((osgCal::SubMeshSoftware*)drawable)->getName();
			else
				name = ((osgCal::SubMeshHardware*)drawable)->getName();

			if (name.rfind("chair") != std::string::npos ) {
				if (instance) {
					instance->removeDrawableThatStayInColor(drawable);
				}
			}
		}

		int nb = mCards.size();
		for (int i = 0; i < nb; i++) {
			osg::Drawable *front = mCards[i].front.get();
			osg::Drawable *back = mCards[i].back.get();

			if (instance && mMe) {
				instance->removeDrawableThatStayInColor(front);
				instance->removeDrawableThatStayInColor(back);
			}
		}
	}
}

void PokerBodyModel::Init()
{
  UGAMEAnimatedModel::Init();

  GetNode()->setName("PokerBody");
  
  g_assert(GetCalModel() != 0);
  g_assert(GetCalModel()->getCoreModel());
  CalCoreModel* coreModel = GetCalModel()->getCoreModel();

//   CreateCoreAnimation("common.cal3d/noiseepicr.xaf", bones);
  mLookatId = coreModel->loadCoreAnimation(mDataPath + "/lookat.xaf");
  if(mLookatId < 0)
    g_error("PlayerAnimation::PlayerAnimation: could not load lookat.xaf");
  CalCoreTrack* coreTrack = GetCoreAnimation(mLookatId)->getListCoreTrack().front();
  g_assert(coreTrack != 0);
  coreTrack->setCoreBoneId(coreModel->getCoreSkeleton()->getCoreBoneId("boneSkull"));
  if (!coreModel->addAnimationName("lookat",mLookatId))
    assert(0);

	dmask_ = new DepthMask(false);

  InitCardsOfPlayer();

  //
  // Facial noise animations
  //
  const std::string &dir = mDataPath;
  mNoiseAnimations.push_back(new NoiseSkull(GetCalModel(), dir));
  mNoiseAnimations.push_back(new NoiseEyes(GetCalModel(), dir));


//   mNoiseAnimations.push_back(new NoiseNose(GetCalModel(), dir));
//   mNoiseAnimations.push_back(new NoiseMouth(GetCalModel(), dir));
//   mNoiseAnimations.push_back(new NoiseZygo(GetCalModel(), dir));
//   mNoiseAnimations.push_back(new NoiseEpicr(GetCalModel(), dir));

  // hack get eyes mesh of player 	 
#if 0
  osgCal::CoreModel::Outfit resultOfSearchEye; 	 
  if (!GetArtefact()->getCoreModel()->getOutfit(&resultOfSearchEye, "/cal3d/outfits/outfit[@name='" + GetOutfit() + "']/item[@name='eyes']/mesh")) 	 
    g_critical("PokerBodyModel::Init Hey guy don't forget to put eyes on your characters !!!"); 	 

  if (resultOfSearchEye.size()>1) 	 
    g_critical("PokerBodyModel::Init Only two eyes are required for a character !!!"); 	 

  int end=(int)resultOfSearchEye.size(); 	 
  for (int i=0;i<end;i++) { 	 
    mEyesMeshName.push_back(resultOfSearchEye[i]["name"]); 	 
    g_debug("PokerBodyModel::Init Eyes %s found",mEyesMeshName.back().c_str());
  }
#endif

#if 0
  if (GetArtefact()->getCoreModel()->_outfits[GetOutfit()].find("eyes")!=GetArtefact()->getCoreModel()->_outfits[GetOutfit()].end() && !GetArtefact()->getCoreModel()->_outfits[GetOutfit()]["eyes"].meshes.empty())
    mEyesMeshName.push_back(GetArtefact()->getCoreModel()->_outfits[GetOutfit()]["eyes"].meshes.front()["name"]);
#endif

#ifdef NEW_OUTFIT_SYSTEM
  std::vector<std::string> a=GetArtefact()->getMeshFromSlot("eyes");
  if (a.empty())
    g_critical("PokerBodyModel::Init no eyes mesh found !!!"); 	 

  mEyesMeshName.insert(mEyesMeshName.end(),a.begin(),a.end());
#endif

	if (mMe) {
		int nbDraw = mOsgCalModel->getNumDrawables();
		for (int i = 0; i < nbDraw; i++) {
			osg::Drawable *drawable = mOsgCalModel->getDrawable(i);
			const std::string &className = drawable->className();
			std::string name;
			if (className == "SubMeshSoftware")
				name = ((osgCal::SubMeshSoftware*)drawable)->getName();
			else
				name = ((osgCal::SubMeshHardware*)drawable)->getName();

			if (name.rfind("chair") != std::string::npos ) {
				PokerSceneView *instance = PokerSceneView::getInstance();
				if (instance) {
					//instance->addDrawableThatStayInColor(drawable, 0, 20, "RenderBin", 0);
				}
			}
		}
	}
}

struct SeekTime : CalAnimationAlt::TimeFunction
{
  float mTime;
  SeekTime() : mTime(0)
  {
  }
  SeekTime(const SeekTime &cpy) : CalAnimationAlt::TimeFunction(cpy), mTime(cpy.mTime)
  {    
  }
  virtual Function* clone() { return new SeekTime(*this); }
  void AddTime(float time) 
  { 
    float newTime = mTime + time;
    if (newTime >= 1.0f)
      newTime = 0.99f;
    else if (newTime < 0.0f)
      newTime = 0.0f;
    mTime = newTime;
  }
  virtual float process(CalAnimationAlt* pAnimation)
  {
    return mTime * pAnimation->getDuration();
  }
};


void PokerBodyModel::PlayBreath(float time)
{
  if(!mAnimationsEnabled) return;
  // we play the breath only one time in loop mode
  if (!mLoopBreath)
    GetScheduler()->run(CalScheduler::FOREGROUND,
			GetCoreAnimationId("breath"),
			CalScheduler::FOREVER,
			1.f,
			new CalScheduler::FadeInOut(.3f, .3f),
			time);
  mLoopBreath=true;
}

void PokerBodyModel::PlayBlink()
{
  if(!mAnimationsEnabled) return;
  GetScheduler()->run(CalScheduler::FOREGROUND,
		      GetCoreAnimationId("blink"),
		      CalScheduler::ONCE);
}

int PokerBodyModel::IsPlayingAnimationList(const std::vector<std::string>& animationlist)
{
  int i=0;
  int end=(int)animationlist.size();
  for (;i<end;i++) {
    if (GetScheduler()->isAnimationActive(GetCoreAnimationId(animationlist[i])))
      return i;
  }
  return -1;
}

void PokerBodyModel::StopAnimationList(const std::vector<std::string>& animationlist)
{
  int i=0;
  int end=(int)animationlist.size();
  for (;i<end;i++) {
    GetScheduler()->stopOrRemoveEntry(GetCoreAnimationId(animationlist[i]));
  }
}


#if 0
void PokerBodyModel::PlayAnimationWin(const std::string& name)
{
  mLastGetPotPlayed
}
#endif

void PokerBodyModel::PlayLookAt(const osg::Vec3& directionOfPlayerorigin,
																const osg::Vec3& positionOfPlayer, 
																const osg::Vec3& target)
{
  if(!mAnimationsEnabled) return;

  if (GetScheduler()->getAnimation(mLookatId))
    return;

  std::vector<std::string> animationlist;
  animationlist.push_back("fold");
  animationlist.push_back("check");
  animationlist.push_back("bet");
  animationlist.push_back("lookA");
  animationlist.push_back("lookB");
  animationlist.push_back("lookC");
  float delay=0;
  int i=0;
  int end=3;
  for (;i<end;i++) {
    float a=GetCoreAnimation(animationlist[i])->getDuration();
    if (a>delay)
      delay=a;
  }

  CalQuaternion quat;

  // recompute direction to be in an axis aligned plane
  osg::Vec3 dir = directionOfPlayerorigin;
  dir.y() = 0;
  dir.normalize();

  BuildQuaternionFromTarget(dir, positionOfPlayer, target, quat);
  CalCoreTrack* track = GetCoreAnimation(mLookatId)->getListCoreTrack().front();
  g_assert(track != 0);
  CalBone* bone = GetBone("boneSkull");

  int size=track->getCoreKeyframeCount();
  for (int i=0;i<size;i++) {
    track->getCoreKeyframe(i)->setTranslation(bone->getTranslation());
    track->getCoreKeyframe(i)->setRotation(quat);
  }
  
  GetScheduler()->run(CalScheduler::FOREGROUND,
		      mLookatId,
		      CalScheduler::ONCE,
		      1.f,
		      new CalScheduler::FadeInOut(.5f, .5f),
		      delay);
  g_debug("DELAY %f",delay);
}


void PokerBodyModel::BuildQuaternionFromTarget(const osg::Vec3& _origin, const osg::Vec3& _target,CalQuaternion& _result)
{
  osg::Quat quat;

  osg::Vec3 origin(_origin[0],_origin[1],_origin[2]);
  osg::Vec3 target(_target[0],_target[1],_target[2]);
  
  osg::Vec3 f(target-origin);
  f.normalize();

  osg::Vec3 reference;
  osg::Vec3 targetSide(target);
  reference=osg::Vec3(0.f, 0.f, origin.z()) - origin;
  reference.normalize();
  osg::Vec3 repere=reference^osg::Vec3(0,1,0);
  float sign=repere*target; // give me the sign of angle

	float dot = reference*f;
	if (dot < -1.0f) dot = -1.0f;
	else if (dot > 1.0f) dot = 1.0f;
  float angle = acos(dot);
  angle*=(sign<0?-1:1);

#if 0
	// orientation of skullbone is fixed for superman. so axis come from characters studio
	osg::Matrix matrix,matrix2;
	matrix.makeRotate(M_PI,osg::Vec3(0,1,0) );
	matrix2.makeRotate(M_PI*0.5,osg::Vec3(0,0,1) );
	matrix=matrix * matrix2;

	osg::Matrix boneOrientation;
	boneOrientation.makeRotate(angle,osg::Vec3(0,1,0));
	
	osg::Matrix finalTransform=matrix * boneOrientation;
	finalTransform.get(quat);
#else
	quat.makeRotate(angle, osg::Vec3(0,1,0));
#endif

  _result=CalQuaternion(quat[0],quat[1],quat[2],quat[3]);
}

void PokerBodyModel::BuildQuaternionFromTarget(const osg::Vec3& _dir,const osg::Vec3& _origin, const osg::Vec3& _target,CalQuaternion& _result)
{
  osg::Quat quat;
 
 osg::Vec3 origin(_origin[0],_origin[1],_origin[2]);
  osg::Vec3 target(_target[0],_target[1],_target[2]);
  
  osg::Vec3 dir=-_dir;

  // direction from player1 to player to look at
  osg::Vec3 f(target-origin);
  f.normalize();

  osg::Vec3 repere=dir^osg::Vec3(0,1,0);
  float sign=repere*target-_origin*repere; // give me the sign of angle

  float val=dir*f;
  if (val>1.0)
    val=1.0;
  else if (val<-1.0)
    val=-1.0;
  float angle=acos(val);
  angle*=(sign<0?-1:1);

  // attenuate angle
  angle*=0.6;

	//  quat.makeRotate(angle, osg::Vec3(0,1,0));
  quat.makeRotate(angle, osg::Vec3(1,0,0));

  _result=CalQuaternion(quat[0],quat[1],quat[2],quat[3]);
}

void PokerBodyModel::PlayFacialNoise()
{
  if(!mAnimationsEnabled) return;

  for(std::vector<NoiseElement*>::iterator noise = mNoiseAnimations.begin();
      noise != mNoiseAnimations.end();
      noise++) {
    (*noise)->SetKeepGoing(true);
    (*noise)->process(GetCalModel(), 0);
  }
}

void PokerBodyModel::StopFacialNoise()
{
  for(std::vector<NoiseElement*>::iterator noise = mNoiseAnimations.begin();
      noise != mNoiseAnimations.end();
      noise++) {
    (*noise)->SetKeepGoing(false);
    GetScheduler()->stop((*noise)->GetCoreAnimationId());
  }
}


void PokerBodyModel::Stop()
{
  GetScheduler()->stop(CalScheduler::ALL);
}

void PokerBodyModel::StopAll()
{
  StopFacialNoise();
  Stop();
}

void PokerBodyModel::InitCardsOfPlayer()
{
	// 
	// Init data to manage looking card
	//

	PokerSceneView *instance = PokerSceneView::getInstance();

	mCards.clear();
	mCardsTable.clear();

	for(int i = 0; i < 5; i++) {
		char tmp[32];
		CardEntry cards;
		snprintf(tmp, sizeof(tmp), "bentcard%d", i);
		UGAMEAnimatedController::Drawables* drawables = GetDrawables(tmp);
		if (!drawables || drawables->empty()) {
			g_critical("PokerBodyModel::InitCardsOfPlayer: %s: no drawables for %s", CalError::getLastErrorText().c_str(), tmp);
			continue;
		}
		if (drawables->size() != 2) {
		  g_critical("PokerBodyModel::InitCardsOfPlayer: %d drawables for %s instead of 2", (int)drawables->size(), tmp);
			continue;
		}

		for(int j = 0; j < 2; j++) {

			osg::Drawable *drawable = (*drawables)[j].get();
			osg::StateSet *ss = drawable->getStateSet();

			if(!ss) {
				g_critical("PokerBodyModel::InitCardsOfPlayer: no stateSet for drawable %d of %s", j, tmp);
				continue;
			}
			if(ss->getTextureAttribute(0, osg::StateAttribute::TEXTURE) == 0) {
				g_critical("PokerBodyModel::InitCardsOfPlayer: no texture for drawable %d of %s", j, tmp);
				continue;
			}

			osg::AlphaFunc *alphaFunc = new osg::AlphaFunc();
			alphaFunc->setReferenceValue(0.2f);
			alphaFunc->setFunction(osg::AlphaFunc::GREATER);
			ss->setAttributeAndModes(alphaFunc);

			osg::Material *mat = (osg::Material*) ss->getAttribute(osg::StateAttribute::MATERIAL);
			mat->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(0.0f, 0.0f, 0.0f, 1.0f) );
			mat->setEmission(osg::Material::FRONT_AND_BACK, osg::Vec4f(1.0f, 1.0f, 1.0f, 1.0f) );

			mCardsTable[ss] = true;

			if(j == 0) {
				cards.front = drawable;

				if (instance && mMe) {
					int cardRenderBinBeforeHelpMode;

//					if (!VarsEditor::Instance().Get("RB_CardsPlayerOnTable",cardRenderBinBeforeHelpMode))
	//					MAF_ASSERT(0 && "RB_CardsPlayerOnTable not found in client.xml");
					if (!MAFRenderBin::Instance().GetRenderBinIndexOfEntity("CardsPlayerOnTable", cardRenderBinBeforeHelpMode))
						MAF_ASSERT(0 && "CardsPlayerOnTable not found in client.xml");

					int cardRenderBinInHelpMode;
//					if (!VarsEditor::Instance().Get("RB_CardsPlayerOnTableInHelpMode",cardRenderBinInHelpMode))
	//					MAF_ASSERT(0 && "RB_CardsPlayerOnTableInHelpMode not found in client.xml");

					if (!MAFRenderBin::Instance().GetRenderBinIndexOfEntity("CardsPlayerOnTableInHelpMode", cardRenderBinInHelpMode))
						MAF_ASSERT(0 && "CardsPlayerOnTableInHelpMode not found in client.xml");

					instance->addDrawableThatStayInColor(drawable, cardRenderBinBeforeHelpMode, cardRenderBinInHelpMode, "DepthSortedBin", 1);
				}
			}
			else {
				cards.back = drawable;

				if (instance && mMe) {
					int cardMeRenderBinBeforeHelpMode;
//					if (!VarsEditor::Instance().Get("RB_CardsPlayerMeOnTable",cardMeRenderBinBeforeHelpMode))
	//					MAF_ASSERT(0 && "RB_CardsPlayerMeOnTable not found in client.xml");
					if (!MAFRenderBin::Instance().GetRenderBinIndexOfEntity("CardsPlayerMeOnTable", cardMeRenderBinBeforeHelpMode))
						MAF_ASSERT(0 && "CardsPlayerMeOnTable not found in client.xml");

					int cardMeRenderBinInHelpMode;
//					if (!VarsEditor::Instance().Get("RB_CardsPlayerMeOnTableInHelpMode",cardMeRenderBinInHelpMode))
	//					MAF_ASSERT(0 && "RB_CardsPlayerMeOnTableInHelpMode not found in client.xml");
					if (!MAFRenderBin::Instance().GetRenderBinIndexOfEntity("CardsPlayerMeOnTableInHelpMode", cardMeRenderBinInHelpMode))
						MAF_ASSERT(0 && "CardsPlayerMeOnTableInHelpMode not found in client.xml");

					instance->addDrawableThatStayInColor(drawable, cardMeRenderBinBeforeHelpMode, cardMeRenderBinInHelpMode, "DepthSortedBin", 1);
				}
			}
		}
		// stack
		mCards.push_back(cards);
	}

	DettachCardsDrawableToPlayer();
	g_debug("Cards found %d\n", (int)mCards.size());
}


void PokerBodyModel::UpdateCardsOfPlayer(const std::vector<int>& cards)
{
  mNumberOfCardsReady=cards.size();

  //if (!mMe)
  //  return;

  if (cards.empty())
    return;

  unsigned int nb=mNbCardsToPlay;
  if (mCards.size() < nb) 
  {
    g_critical("Data of player missing not enough cards (wanted %d currently %d)\n",nb,(int)mCards.size());
    nb=mCards.size();
  }

  for (unsigned int i = 0; i < nb; i++) 
  {
    osg::StateSet* state = mCards[i].front->getStateSet();
    if (!state)
      g_error("PokerBodyModel::UpdateCardsOfPlayer osg::state not found for a cards of player. check materials card of player");
    g_assert(state != 0);

    osg::Texture2D* current_texture = dynamic_cast<osg::Texture2D*>(state->getTextureAttribute(0, osg::StateAttribute::TEXTURE));
    g_assert(current_texture != 0);
    osg::Texture2D* new_texture = mDeck->GetImage(cards[i]);
    g_assert(new_texture != 0);

    state->setTextureAttribute(0, new_texture);
  }
}


void PokerBodyModel::DettachCardsDrawableToPlayer()
{
  osgCal::Model* model = GetArtefact();

	PokerSceneView *instance = PokerSceneView::getInstance();

	int nb = mCards.size();
	for (int i = 0; i < nb; i++) {
		osg::Drawable *front = mCards[i].front.get();
		osg::Drawable *back = mCards[i].back.get();

		model->removeDrawable(front);
		model->removeDrawable(back);

		if (newModelForTableShadow_) {
			newModelForTableShadow_->removeDrawable(front);
			newModelForTableShadow_->removeDrawable(back);
		}
		if (instance && mMe) {
			instance->removeDrawableThatStayInColor(front);
			instance->removeDrawableThatStayInColor(back);
		}
	}
}

int PokerBodyModel::GetNbCardsDisplayed()
{
  int nbCards=0;
  osgCal::Model* model = GetArtefact();
  for (int i=0;i<(int)mCards.size();i++) {
    if (model->getDrawableIndex(mCards[i].front.get())!=model->getNumDrawables())
      nbCards++;
  }
  return nbCards;
}

void PokerBodyModel::ShowCard(int i)
{
	if (i>=mNumberOfCardsReady)
		return;
	CUSTOM_ASSERT(i>=0 && i<(int)mCards.size());
	osgCal::Model* model = GetArtefact();

	PokerSceneView *ui_instance = PokerSceneView::getInstance();

	if (model->getDrawableIndex(mCards[i].front.get())==model->getNumDrawables()) {
		osg::Drawable *front = mCards[i].front.get();
		model->addDrawable(front);
		if (newModelForTableShadow_)
			newModelForTableShadow_->addDrawable(front);
		if (ui_instance && mMe) {
			int cardRenderBinBeforeHelpMode;
			if (!MAFRenderBin::Instance().GetRenderBinIndexOfEntity("CardsPlayer", cardRenderBinBeforeHelpMode))
				MAF_ASSERT(0 && "CardsPlayer not found in client.xml");

			int cardRenderBinInHelpMode;
			if (!MAFRenderBin::Instance().GetRenderBinIndexOfEntity("CardsPlayerInHelpMode", cardRenderBinInHelpMode))
				MAF_ASSERT(0 && "CardsPlayerInHelpMode not found in client.xml");

			ui_instance->addDrawableThatStayInColor(front, cardRenderBinBeforeHelpMode, cardRenderBinInHelpMode, "DepthSortedBin", 0);
		}
	}

	if (model->getDrawableIndex(mCards[i].back.get())==model->getNumDrawables()) {
		osg::Drawable *back = mCards[i].back.get();
		model->addDrawable(back);
		if (newModelForTableShadow_)
			newModelForTableShadow_->addDrawable(back);
		if (ui_instance && mMe) {
			int cardRenderBinBeforeHelpMode;
			if (!MAFRenderBin::Instance().GetRenderBinIndexOfEntity("CardsPlayer", cardRenderBinBeforeHelpMode))
				MAF_ASSERT(0 && "CardsPlayer not found in client.xml");

			int cardRenderBinInHelpMode;
			if (!MAFRenderBin::Instance().GetRenderBinIndexOfEntity("CardsPlayerInHelpMode", cardRenderBinInHelpMode))
				MAF_ASSERT(0 && "CardsPlayerInHelpMode not found in client.xml");

			ui_instance->addDrawableThatStayInColor(back, cardRenderBinBeforeHelpMode, cardRenderBinInHelpMode, "DepthSortedBin", 0);
		}
	}
}

void PokerBodyModel::HideCard(int i)
{
  assert(i>=0 && i<(int)mCards.size());

	osgCal::Model* model = GetArtefact();
	osg::Drawable *front = mCards[i].front.get();
	osg::Drawable *back = mCards[i].back.get();

  model->removeDrawable(front);
  model->removeDrawable(back);
  if (newModelForTableShadow_) {
		newModelForTableShadow_->removeDrawable(front);
		newModelForTableShadow_->removeDrawable(back);
  }

	PokerSceneView *instance = PokerSceneView::getInstance();
	if (instance && mMe) {
		instance->removeDrawableThatStayInColor(front);
		instance->removeDrawableThatStayInColor(back);
	}
}


void PokerBodyModel::DisableCurrentAnimationCallback(const std::string &name)
{
  DisableCurrentAnimationCallback(GetCoreAnimationId(name));
}

void PokerBodyModel::DisableCurrentAnimationCallback(int id)
{
  if (GetScheduler()->isAnimationActive(id)) {
    CalAnimationAlt* a = GetScheduler()->getAnimation(id);
    a->setStopCallback(0);
  }
}




// at the end animation start the PokerFoldSequence
// see file PokerFoldSequence.h/cpp
void PlayFoldAnimation::process(CalModel* model, CalAnimationAlt* animation)
{
  int nb=mBody->mNbCardsToPlay;
  for (int i=0;i<nb;i++) {
    mBody->HideCard(i);
    mBody->mFoldSequence->ShowCard(i);
  }
	mBody->mNbCardsToPlay=0;
  mBody->mFoldSequence->StartSequence();
  // because of update call order. So we can call that a HACK
  mBody->mFoldSequence->Update(0);
  osg::MultipleAnimationPathCallback* cb = dynamic_cast<osg::MultipleAnimationPathCallback*>(mBody->mFoldSequence->mTransformPosition->getUpdateCallback());
  CUSTOM_ASSERT(cb);
  cb->update(*mBody->mFoldSequence->mTransformPosition.get());
  // end hack because of update call
	mBody->mbPlayFoldAnimation = false;
}


// animation must be a fold animation.
void PokerBodyModel::PlayFold(const std::string& foldAnimation)
{
  if(!mAnimationsEnabled) return;
  int id=GetCoreAnimationId(foldAnimation);
  CalAnimationAlt *a;
  a=GetScheduler()->run(CalScheduler::FOREGROUND,
                        id,
                        CalScheduler::ONCE); // 1e4 means that this animation will be the one seen by the user
  a->setStopCallback(mFoldAnimation);

	mbPlayFoldAnimation = true;
}
  





// Controller 

PokerBodyController::PokerBodyController(MAFApplication* application,MAFOSGData* seat,unsigned int controllerID, bool me) : UGAMEAnimatedController(controllerID)
{
  SetModel(new PokerBodyModel(application,seat,me));

  PokerApplication *game = dynamic_cast<PokerApplication *>(application);
  const std::string &baseAlphaStr=game->HeaderGet("sequence", "/sequence/player/@baseAlpha");
  if (baseAlphaStr.length())
    GetModel()->mMinAlpha=atof(baseAlphaStr.c_str());
  else
    g_error("PokerBodyController::PokerBodyController /sequence/player/@baseAlpha not found in config file");

  const std::string &angleAlphaStr=game->HeaderGet("sequence", "/sequence/player/@angleAlpha");
  if (angleAlphaStr.length())
    GetModel()->mAngleAlpha=osg::PI/180.0*atof(angleAlphaStr.c_str());
  else
    g_error("PokerBodyController::Init /sequence/player/@angleAlpha not found in config file");
}

PokerBodyController::~PokerBodyController()
{
	g_debug("PokerBodyController::~PokerBodyController");
}


void PokerBodyController::HandleHit(MAFHit& hit) 
{
  typedef osgCal::SubMeshSoftware subMesh;
  subMesh *mesh = dynamic_cast<subMesh *>(hit.mHit._drawable.get());
  if (mesh != 0)
    GetModel()->mFocus = mesh->getName();
  else
    GetModel()->mFocus = "";
}



bool PokerBodyController::Update(MAFApplication* application)
{
  NPROFILE_SAMPLE("PokerBodyController::Update");

  PokerApplication *game = dynamic_cast<PokerApplication *>(application);

   if (GetModel()->mMe)
     if (game->GetFocus() != this)
       GetModel()->mFocus = "";


   GetModel()->mFoldSequence->Update(0);

  PokerCameraModel* camera=(dynamic_cast<PokerCameraController*>(game->GetScene()->GetModel()->mCamera.get()))->GetModel();
  osg::Vec3 camDirection=camera->GetTarget()-camera->GetPosition();
  camDirection.normalize();

  float alpha=1;
  alpha=GetModel()->ComputeAlphaFromDirection(camDirection);
  
  //float currentAlpha=GetModel()->GetAlpha(); // unused 

  float camDuraction=camera->mTimer.GetDuration();
  float camCurrentTime=camera->mTimer.GetCurrentTime();

  if (GetModel()->mMe) {
    switch (camera->GetMode()) {
    case PokerCameraModel::CAMERA_DIRECT_MODE: 
    case PokerCameraModel::CAMERA_GAME_MODE: 
    case PokerCameraModel::CAMERA_ENTER_MODE: 
      {
      osg::Vec3 camPrevDirection=camera->mCamPrevTarget-camera->mCamPrevPosition;
      camPrevDirection.normalize();
      float srcAlpha=GetModel()->ComputeAlphaFromDirection(camPrevDirection);
      float dstAlpha=1;
      float timeState=camCurrentTime/camDuraction;
      timeState=camera->mLengthBInterpolator.GetT(timeState);
      alpha=srcAlpha+(dstAlpha-srcAlpha)*timeState;
//        g_debug("ENTERMODE srcAlpha %f currentAlpha %f timestate %f",srcAlpha,alpha,timeState);
      }
      break;
    case PokerCameraModel::CAMERA_LEAVE_MODE:
      {
      osg::Vec3 camPrevDirection=camera->mCamNextTarget-camera->mCamNextPosition;
      camPrevDirection.normalize();
      float dstAlpha=GetModel()->ComputeAlphaFromDirection(camPrevDirection);
      float srcAlpha=1;
      float timeState=camCurrentTime/camDuraction;
      timeState=camera->mLengthBInterpolator.GetT(timeState);
      alpha=srcAlpha+(dstAlpha-srcAlpha)*timeState;
//        g_debug("LEAVEMODE srcAlpha %f currentAlpha %f timestate %f",dstAlpha,alpha,timeState);
      }
      break;
    default:
//       g_debug("NOMODE %f",alpha);
      break;
    }
  }

  GetModel()->SetAlpha(alpha);

  PokerBodyModel *bm = GetModel();
  CalBone *bone = bm->GetBone("boneEyeL");
  const CalQuaternion &quat = bone->getRotation();
  CalVector vec(0, 0, 1);
  vec *= quat;

  // hack for eyes
  if (!GetModel()->mEyesMeshName.empty()) {
    osgCal::Model::Drawables *draws = bm->GetDrawables(GetModel()->mEyesMeshName[0]);
    if (!draws)
      g_critical("PokerBodyController::Update no mesh eyes found for outfit %s",GetModel()->GetOutfit().c_str());
    else {
      if (!draws->size())
        g_critical("PokerBodyController::Update mesh eyes found but empty for outfit %s",GetModel()->GetOutfit().c_str());
      else {
        int end=(int)draws->size();
        for (int i=0;i<end;i++) {
          osg::Drawable *draw = (*draws)[i].get();
          osg::Matrix mat;
          mat = osg::Matrix::translate(-vec.x*(24/256.0f), -vec.y*(24/256.0f), 0);
          bm->texmatEyes_->setMatrix(mat);
          draw->getOrCreateStateSet()->setTextureAttributeAndModes(0, bm->texmatEyes_.get(), osg::StateAttribute::ON);
        }
      }
    }
  }

	{
	  PokerBodyModel *bm = GetModel();

		osg::Vec3f min(FLT_MAX, FLT_MAX, FLT_MAX);
		osg::Vec3f max(-FLT_MAX, -FLT_MAX, -FLT_MAX);

//		osg::Node *anchor = bm->GetAnchor();
	//	osg::Matrix mat = MAFComputeLocalToWorld(anchor);
		//mat = osg::Matrix::inverse(mat);

		int nbDraw = bm->GetOsgCalModel()->getNumDrawables();
		int i;
		for (i = 0; i < nbDraw; i++) {
			osg::Drawable *drawable = bm->GetOsgCalModel()->getDrawable(i);
			const std::string &className = drawable->className();
			if (className == "SubMeshSoftware") {
				const std::string &name = ((osgCal::SubMeshSoftware*)drawable)->getName();
				if (name != "__chairFront")
					continue;

				osg::BoundingBox bb = drawable->getBound();

				if (bb._min < min)
					min = bb._min;
				if (max < bb._max)
					max = bb._max;
			}
		}

		osg::Vec3f center = (min + max) / 2;
		osg::Vec3f extent = (max - min) / 2;
		extent *= 1.5f;

		min = center - extent;
		max = center + extent;

		osg::BoundingBox hwBB(min, max);
		for (int i = 0; i < nbDraw; i++) {
			osg::Drawable *drawable = bm->GetOsgCalModel()->getDrawable(i);
			const std::string &className = drawable->className();
			if (className == "SubMeshHardware") {
				osgCal::SubMeshHardware *sbHW = (osgCal::SubMeshHardware*) drawable;
				sbHW->_staticbbox = hwBB;

				hwBB._min._v[2] -= 0.01f;
				hwBB._max._v[2] -= 0.01f;
			}
			else {
				osgCal::SubMeshSoftware *sbSW = (osgCal::SubMeshSoftware*) drawable;
				sbSW->_staticbbox = hwBB;

				hwBB._min._v[2] -= 0.01f;
				hwBB._max._v[2] -= 0.01f;
			}
		}
	}

  return true;
}

void PokerBodyController::AddTimeSitIn(float time)
{
  int sitDownId = GetModel()->GetCoreAnimationId("seatDown");
  AddTimeSit(sitDownId, time);
}

void PokerBodyController::AddTimeSitOut(float time)
{
  int sitOutId = GetModel()->GetCoreAnimationId("seatUp");
  AddTimeSit(sitOutId, time);
}

void PokerBodyController::AddTimeSit(int id, float time)
{
  CalAnimationAlt *a = GetModel()->GetScheduler()->getAnimation(id);
  if (a)
    {
      CalAnimationAlt::TimeFunction *timeFunction = a->getTimeFunction();
      bool seeked = (timeFunction != 0);
      if (seeked)
	{
	  SeekTime *seek = static_cast<SeekTime *>(timeFunction);
	  seek->AddTime(time); 
	}
    }
}


void PokerBodyController::PlayGetPot()
{
  GetModel()->GetScheduler()->run(CalScheduler::FOREGROUND,
                                  GetModel()->GetCoreAnimationId(std::string("getPot")),
                                  CalScheduler::ONCE,
                                  1e6,
                                  new CalScheduler::FadeInOut(.1f, .1f));
}





void PokerBodyModel::SetupTextureCardsForLookingCards()
{
	if (mMe) {
		if (GetNbCardsDisplayed() != mNumberOfCardsReady) {
			DettachCardsDrawableToPlayer();
			for (int i=0;i<mNumberOfCardsReady;i++)
				ShowCard(i);
		}
	}
}



void PokerBodyModel::BuildAnimationSoundMap(MAFAudioSourceController* source)
{
  mAnimation2Sounds.clear();
  for (MAFAudioSourceModel::SoundMap::iterator it=source->GetModel()->mSounds.begin();it!=source->GetModel()->mSounds.end();it++) {
    std::string name=it->first;
    int id=GetCoreAnimationId(name);
    if (id!=-1) {
      mAnimation2Sounds[id]=name;
      g_debug("PokerBodyModel::BuildAnimationSoundMap assign sound %s to id %d",name.c_str(),id);
    } else {
      g_debug("PokerBodyModel::BuildAnimationSoundMap sound %s not assigned to animation",name.c_str());
    }
  }

#ifdef HACK_SOUND_IN_CAL3D
  GetScheduler()->mAnimation2Sounds=&mAnimation2Sounds;
  GetScheduler()->mSounds=source;
#endif
}



GetPotAfterWin::GetPotAfterWin(PokerPlayer* player,PokerMoveChipsBase* chips,const std::vector<int>& amount) : mPlayer(player) ,mChips(chips),  mAmount(amount){}

void GetPotAfterWin::process(CalModel* model, CalAnimationAlt* animation)
{
  mChips->Display(false);
  mPlayer->GetBody()->PlayGetPot();
  mPlayer->StartGetPotAnimation(mAmount);
}
