/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include "pokerStdAfx.h"

#ifndef POKER_USE_VS_PCH
#include <PokerPlayerTimeout.h>
#include <PokerApplication.h>
#include <maf/window.h>
#include <maf/data.h>
#include <maf/renderbin.h>
#include <maf/assert.h>
#include <maf/depthmask.h>
#include <osg/Material>
#include <osg/BlendFunc>
#endif

PokerPlayerTimeout::~PokerPlayerTimeout()
{
	// remove element from tree
	mFirstPersonGroup->getParent(0)->removeChild(mFirstPersonGroup.get());
	mTimerThirdPerson->getParent(0)->getParent(0)->removeChild(mTimerThirdPerson->getParent(0));
}

PokerPlayerTimeout::PokerPlayerTimeout(PokerApplication* game, MAFOSGData* seatData, UGAMETimeOut *timeOut)
{
	//mDisable = true;
	
	osgText::Font* font = MAFLoadFont(game->HeaderGet("settings", "/settings/data/@path") + "/FreeSansBold.ttf");

	mTimerThirdPerson = new UGAMEShadowedText("",font);
	{

		mTimerThirdPerson->setCharacterSize(10);
		mTimerThirdPerson->setCharacterSizeMode(osgText::Text::OBJECT_COORDS);
		mTimerThirdPerson->setLayout(osgText::Text::LEFT_TO_RIGHT);
		mTimerThirdPerson->setAlignment(osgText::Text::CENTER_CENTER);
		mTimerThirdPerson->setAxisAlignment(osgText::Text::SCREEN);
		mTimerThirdPerson->setText("");

		// set up the drawstate.
		osg::StateSet*	state = mTimerThirdPerson->getOrCreateStateSet();
		osg::Material* material = new osg::Material;
		material->setDiffuse(osg::Material::FRONT, osg::Vec4(1.f, 1.f, 1.f, 1.f));
		state->setAttributeAndModes(material);
		state->setMode(GL_CULL_FACE, osg::StateAttribute::OFF);
		state->setMode(GL_LIGHTING, osg::StateAttribute::OFF);

		if (!MAFRenderBin::Instance().SetupRenderBin("TimeOut", state))
			MAF_ASSERT(0 && "TimeOut not found in client.xml");

		osg::BlendFunc* blendfunc=new osg::BlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
		state->setAttribute(blendfunc);
		state->setMode(GL_BLEND, osg::StateAttribute::ON);
		state->setAttributeAndModes(new DepthMask(false) );

		std::string anchor_player = game->HeaderGet("sequence", "/sequence/player_timeout/third_person/@anchor");
    std::map<std::string,std::string> properties = game->HeaderGetProperties("sequence", "/sequence/player_timeout/third_person/offset_position");
    osg::Vec3 pos;
    pos.x() = atof(properties["x"].c_str());
    pos.y() = atof(properties["y"].c_str());
    pos.z() = atof(properties["z"].c_str());

		osg::MatrixTransform* tr=new osg::MatrixTransform;
		tr->setMatrix(osg::Matrix::translate(pos));
		tr->addChild(mTimerThirdPerson.get());
		seatData->GetAnchor(anchor_player)->addChild(tr);
		mTimerThirdPerson->setNodeMask(0);
	}

	mTimerFirstPerson = new UGAMEBasicText("",font);
	{
		mTimerFirstPerson->getText()->setCharacterSize(40);
		mTimerFirstPerson->getText()->setCharacterSizeMode(osgText::Text::OBJECT_COORDS);
		mTimerFirstPerson->getText()->setLayout(osgText::Text::LEFT_TO_RIGHT);
		mTimerFirstPerson->getText()->setAlignment(osgText::Text::CENTER_CENTER);
		mTimerFirstPerson->getText()->setAxisAlignment(osgText::Text::SCREEN);
		mTimerFirstPerson->getText()->setText(osgText::String("", osgText::String::ENCODING_UTF8));
		mTimerFirstPerson->getText()->setColor(osg::Vec4(0,0,0,1));

		// set up the drawstate.
		osg::StateSet*	state = mTimerFirstPerson->getText()->getOrCreateStateSet();
		osg::Material* material = new osg::Material;
		material->setDiffuse(osg::Material::FRONT, osg::Vec4(1.f, 1.f, 1.f, 1.f));
		state->setAttributeAndModes(material);
		state->setMode(GL_CULL_FACE, osg::StateAttribute::OFF);
		state->setMode(GL_LIGHTING, osg::StateAttribute::OFF);
		osg::BlendFunc* blendfunc=new osg::BlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
		state->setRenderingHint(osg::StateSet::TRANSPARENT_BIN);
		state->setAttribute(blendfunc);
		state->setMode(GL_BLEND, osg::StateAttribute::ON);

		std::map<std::string,std::string> properties = game->HeaderGetProperties("sequence", "/sequence/player_timeout/first_person/button");
		if (properties.empty())
			g_assert(0 && "/sequence/player_timeout/first_person/button missed in client.xml");

		std::map<std::string,std::string> fontproperties = game->HeaderGetProperties("sequence", "/sequence/player_timeout/first_person/font");
		if (fontproperties.empty())
			g_assert(0 && "/sequence/player_timeout/first_person/font missed in client.xml");

		osg::Geometry* firstPersonButton = new osg::Geometry;

		const std::string&	path = game->HeaderGet("settings", "/settings/data/@path");
		const std::string& textureName = game->HeaderGet("sequence", "/sequence/player_timeout/first_person/@texture");
		if (textureName.empty())
			g_assert(0 && "/sequence/player_timeout/first_person/@texture is empty");

		osg::Texture2D *texture = MAFApplication::GetTextureManager()->GetTexture2D(path+G_DIR_SEPARATOR_S+textureName);
		g_assert(texture);

		osg::ref_ptr<osg::Vec3Array> vertexes = new osg::Vec3Array;
		osg::ref_ptr<osg::Vec2Array> uvs = new osg::Vec2Array;
	
		int delta_x = atoi(properties["x"].c_str());
		int delta_y = atoi(properties["y"].c_str());
		int width = atoi(properties["width"].c_str());
		int height = atoi(properties["height"].c_str());

		int delta_xfont = atoi(fontproperties["x"].c_str());
		int delta_yfont = atoi(fontproperties["y"].c_str());
		int size = atoi(fontproperties["size"].c_str());


		int screenW = game->GetWindow(true)->GetWidth()/2;
                //		int screenH = game->GetWindow(true)->GetHeight()/2;


		vertexes->push_back(osg::Vec3(screenW - width/2 + delta_x, - height/2 + delta_y, 0.01));
		vertexes->push_back(osg::Vec3(screenW + width/2 + delta_x, - height/2 + delta_y, 0.01));
		vertexes->push_back(osg::Vec3(screenW + width/2 + delta_x, height/2 + delta_y, 0.01));
		vertexes->push_back(osg::Vec3(screenW - width/2 + delta_x, height/2 + delta_y, 0.01));

		mTimerFirstPerson->getText()->setPosition(osg::Vec3(screenW + delta_x + delta_xfont, delta_y + delta_yfont,0));
		mTimerFirstPerson->getText()->setCharacterSize(size);

		int s = 0;
		int t = 0;
		if (texture->getUserData()) {
			TextureInformation* info = dynamic_cast<TextureInformation*>(texture->getUserData());
			if (info) {
				s = info->getWidth();
				t = info->getHeight();
			} else {
				g_assert(0 && "can't deduce texture size");
			}
		} else {
			s=texture->getTextureWidth();
			t=texture->getTextureHeight();
		}

		float su = width * 1.0 / s;
		float sv = height * 1.0 / t;

		uvs->push_back(osg::Vec2(0,0));
		uvs->push_back(osg::Vec2(su,0));
		uvs->push_back(osg::Vec2(su,sv));
		uvs->push_back(osg::Vec2(0,sv));

		firstPersonButton->setVertexArray(vertexes.get());
		firstPersonButton->setTexCoordArray(0,uvs.get());

		firstPersonButton->addPrimitiveSet(new osg::DrawArrays(GL_QUADS,0,4));

		osg::Geode* geode = new osg::Geode;
		geode->getOrCreateStateSet()->setTextureAttributeAndModes(0,texture);
		geode->getOrCreateStateSet()->setMode(GL_CULL_FACE, osg::StateAttribute::OFF);
		osg::Material* mat = new osg::Material;
		mat->setDiffuse(osg::Material::FRONT_AND_BACK,osg::Vec4(1,1,1,1));
		geode->getOrCreateStateSet()->setAttributeAndModes(mat,osg::StateAttribute::ON);
		geode->getOrCreateStateSet()->setAttributeAndModes(new osg::BlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA), osg::StateAttribute::ON);

		geode->addDrawable(firstPersonButton);

		mFirstPersonGroup = new osg::Group;
		mFirstPersonGroup->setName("TimerFirstPerson");
		mFirstPersonGroup->addChild(geode);
		mFirstPersonGroup->addChild(mTimerFirstPerson.get());
	
		osg::Group *HUDgroup = game->GetScene()->GetModel()->mHUDGroup.get();
		HUDgroup->addChild(mFirstPersonGroup.get());
	}

	mTimeout = timeOut;
	mTimeout->Init();
	mTimeout->Unserialize(game->GetHeaders()["sequence"],"/sequence/player_timeout");
	Disable();
}


void PokerPlayerTimeout::Disable()
{
	mTimerThirdPerson->setNodeMask(0);
	mFirstPersonGroup->setNodeMask(0);
//	mDisable = true;
}

void PokerPlayerTimeout::Start()
{
	//mTimeout->SetCounter(time);
	//mDisable = false;
	if (mFirstPerson)
		mFirstPersonGroup->setNodeMask(MAF_VISIBLE_MASK);
	else
		mTimerThirdPerson->setNodeMask(MAF_VISIBLE_MASK);

}


bool PokerPlayerTimeout::Update(MAFApplication* game)
{
  //	SDL_Event* event = game->GetLastEvent(this);

  if (!game->HasEvent() && mTimeout->IsEnable()) {
		//mTimeout->Update(GetDeltaFrame()/1000.0);

		float time = mTimeout->GetCounter();
		if (time < 0.001)
			Disable();

		else {

			if (mFirstPerson) {
				mFirstPersonGroup->setNodeMask(MAF_VISIBLE_MASK);
				mTimerThirdPerson->setNodeMask(0);
			} else {
				mTimerThirdPerson->setNodeMask(MAF_VISIBLE_MASK);
				mFirstPersonGroup->setNodeMask(0);
			}

			std::string str;
			if (mFirstPerson){
				mTimeout->GetCounterAsIntString(str);
        mTimerFirstPerson->getText()->setText(osgText::String(str, osgText::String::ENCODING_UTF8));
			} else {
				float fadeout = mTimeout->GetFadeOut();
				mTimerThirdPerson->setCharacterSize( 10 + mTimeout->GetScale() * (1- fadeout) );
				osg::Vec4 color = mTimeout->GetColor();
				color[3] = fadeout;
        mTimerThirdPerson->setColor(color);
				mTimeout->GetCounterAsIntString(str);
				mTimerThirdPerson->setText(str);
      }
		}
	}
	return true;
}

void PokerPlayerTimeout::SetFirstPerson(bool state)
{
	mFirstPerson = state;
}
