/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 * Henry Precheur	<henry@precheur.org>
 * Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include "pokerStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */

#ifndef POKER_USE_VS_PCH
#ifdef USE_NPROFILE
#include <nprofile/profile.h>
#else  //USE_NPROFILE
#define NPROFILE_SAMPLE(a)
#endif //USE_NPROFILE
#include <maf/maferror.h>
#include <maf/window.h>
#include <maf/hit.h>
#include <ugame/text.h> // FIXME < > or " " ?

#include "PokerApplication.h"
#include "PokerToolTip.h"
#include "PokerBody.h"
#include "PokerPlayer.h"
#endif

static const float	pre_fade_in_time = 3000.0f;
static const float	fade_in_time = 400.0f;
static const float	fade_out_time = 200.0f;

PokerToolTipController::PokerToolTipController(PokerApplication* app)
  : mScreenWidth(app->GetWindow(true)->GetWidth()),
    mScreenHeight(app->GetWindow(true)->GetHeight()),
    mApplication(app), mState(NONE), mTime(0)
{
  // UGAMEArtefact Init
  MAFVisionModel*	model = new MAFVisionModel();
  SetModel(model);
  Init();

  // Create Tooltip 3D model
  std::string	data_path = app->HeaderGet("settings", "/settings/data/@path");
  mPat = new osg::PositionAttitudeTransform;
  mText = new UGAMEFramedText("WWW",
		      MAFLoadImage(data_path + "/tooltip.tga"),
		      MAFLoadFont(data_path + "/FreeSans.ttf"));
  mText->getText()->setColor(osg::Vec4(0, 0, 0, 0));
  mText->getText()->setCharacterSize(12);
  mPat->setNodeMask(0);
  mPat->addChild(mText);
  model->SetNode(mPat.get());

  // fade in / out color
  osg::Vec4	tmp_colors[1] = { osg::Vec4(1, 1, 1, 0) };
  mColor = new osg::Vec4Array(tmp_colors, tmp_colors + 1);
  osg::Geometry *geometry = mText->getGeometry();
  geometry->setColorArray(mColor);
  geometry->setColorBinding(osg::Geometry::BIND_OVERALL);

  // create path => tooltip map
  std::list<std::string> tooltip_id_list =
    app->HeaderGetList("sequence", "/sequence/tooltips/tooltip/@id");
  std::list<std::string> tooltip_text_list =
    app->HeaderGetList("sequence", "/sequence/tooltips/tooltip/@text");

  std::list<std::string>::const_iterator i = tooltip_id_list.begin();
  std::list<std::string>::const_iterator j = tooltip_text_list.begin();
  while (i != tooltip_id_list.end())
    mId2Text[*i++] = *j++;

	mItemID = NULL;
}

PokerToolTipController::~PokerToolTipController()
{
  mPat = NULL;
}

bool PokerToolTipController::Update(MAFApplication* app)
{
  NPROFILE_SAMPLE("PokerToolTipController::Update");

	if (app->HasEvent() || !mApplication->GetPoker()->GetModel())
		return true;

	float alpha;

	switch (mState) {

	case PREFADEIN:
		mTime += GetDeltaFrame();
		if (mTime > pre_fade_in_time) {
			mTime = 0;
			mState = FADEIN;
			mPat->setNodeMask(MAF_VISIBLE_MASK);
			const osg::BoundingBox &bbox = mText->getBoundingBox();
			float	x_len = bbox.xMax() - bbox.xMin();
			int mouseX = mApplication->getMouseX();
			int mouseY = mApplication->getMouseY();
			mPat->setPosition(osg::Vec3(mouseX - x_len, mScreenHeight - mouseY, 0));
			setAlpha(0);
		}
		break;

	case FADEIN:
		{
			mTime += GetDeltaFrame();
			if (mTime > fade_in_time) {
				mTime = fade_in_time;
				mState = DISPLAYED;
			}
			alpha = mTime / fade_in_time;
			setAlpha(alpha);

		// mPat->setScale(osg::Vec3(scale, scale, scale));
		}
		break;

	case DISPLAYED:
		break;

	case FADEOUT:
		mTime += GetDeltaFrame();
		// mPat->setScale(osg::Vec3(scale, scale, scale));
		if (mTime > fade_out_time) {
			mTime = fade_out_time;
			mState = NONE;
			mPat->setNodeMask(0);
		}
		alpha = mTime / fade_out_time;
		setAlpha(1.0f - alpha);

		break;

	default:
	case NONE:
		break;
	}

	PokerModel *pokerModel = mApplication->GetPoker()->GetModel();
	guint playerID = pokerModel->mMe;
	PokerPlayer *player = NULL;
	if (pokerModel->mSerial2Player.find( playerID ) != pokerModel->mSerial2Player.end())
		player = pokerModel->mSerial2Player[ playerID ].get();

	void* itemID = NULL;
	bool bFound = false;
	MAFController *ctrl = mApplication->GetFocus();

	if (ctrl) {
		PokerBodyController *body = dynamic_cast<PokerBodyController*> (ctrl);
		if (body && body->GetFocus().rfind("__chair") == std::string::npos) {
			itemID = (void*) body;
			bFound = true;

			int nbPlayers = pokerModel->mSeat2Player.size();
			for (int i = 0; i < nbPlayers; i++) {
				PokerPlayer *player = pokerModel->mSeat2Player[i].get();
				if (!player)
					continue;
				PokerBodyController *player_body = player->GetBody();

				if (player_body == body) {
                                  //const std::string &playerName = player->GetName();
					if (player->GetMe() && (player->GetBody()->GetNbCards() != 0) ) {
						mText->setStringUTF8("Click to see cards");
					} else {
						bFound = false;
					}
					break;
				}
			}
		}
		else {
			const std::string &ctrlName = ctrl->GetControllerName();

			if (ctrlName == "PokerInteractorFold") {
				mText->setStringUTF8( mId2Text["PokerInteractorFold"] );
				itemID = (void*) ctrl;
				bFound = true;
			}
			else if (ctrlName == "PokerInteractorCheck") {
				mText->setStringUTF8( mId2Text["PokerInteractorCheck"] );
				itemID = (void*) ctrl;
				bFound = true;
			}
			else if (ctrlName == "PokerDoorController") {
				mText->setStringUTF8( mId2Text["PokerDoorController"] );
				itemID = (void*) ctrl;
				bFound = true;
			}
			else if (ctrlName == "PokerChipsStackController") {
				PokerChipsStackController *stack = (PokerChipsStackController*) ctrl;
				if (player && player->mBetStack.get() == stack) {
					mText->setStringUTF8( mId2Text["PokerChipsStackController"] );
					itemID = (void*) stack;
					bFound = true;
				}
			}
		}
	}
	else {
		MAFSceneView *view = dynamic_cast<MAFSceneView*>(mApplication->GetScene()->GetView());
		const std::string &path = view->GetLastPickedItem();
		if (path.find("mesh_button") != std::string::npos) {
			mText->setStringUTF8( mId2Text["mesh_button"] );
			itemID = NULL; // dummy ID, we don't care
			bFound = true;
		}
	}

	if (bFound) {
		if (itemID != mItemID) {
			mTime = 0;
			mState = PREFADEIN;
			setAlpha(0);
			mPat->setNodeMask(0);
		}
	}
	else {
		if (mState != FADEOUT)  {
			mState = FADEOUT;
			mTime = 0;
		}
	}

	mItemID = itemID;

	return true;
}

osg::Node* PokerToolTipController::GetNode()
{
  return mPat.get();
}

void PokerToolTipController::setAlpha(float _alpha)
{
  (*mColor)[0] = osg::Vec4(1, 1, 1, _alpha);
  osgText::Text *text = mText->getText();
  osg::Vec4	text_color = text->getColor();
  text_color.w() = _alpha;
  text->setColor(text_color);
}

void	PokerToolTipController::reset()
{
  mTime = 0;
  mState = NONE;
  setAlpha(0.0f);
}
