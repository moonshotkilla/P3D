/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Johan Euphrosine <johan@mekensleep.com>
*
*/

#include "pokerStdAfx.h"

#ifndef POKER_USE_VS_PCH
#include "PokerEditor.h"
#include <iostream>
#include <assert.h>
#endif

void PokerEditorUnitTest()
{
	static int var1 = 10;
	PokerEditor::Instance().Edit("var1", var1);
	std::string getVar1ResultStr;
	bool getVar1Result = PokerEditor::Instance().Get("var1", getVar1ResultStr);
	assert(getVar1Result == true);
	assert(getVar1ResultStr == "10");
	bool setVar1Result = PokerEditor::Instance().Set("var1", "11");
	assert(setVar1Result == true);
	assert(var1 == 11);
	std::string getVar1Result2Str;
	bool getVar1Result2 = PokerEditor::Instance().Get("var1", getVar1Result2Str);
	assert(getVar1Result2 == true);
	assert(getVar1Result2Str == "11");
	std::string getVar1Result3Str("toto");
	bool getVar1Result3 = PokerEditor::Instance().Get("var2", getVar1Result2Str);
	assert(getVar1Result3 == false);
	assert(getVar1Result3Str == "toto");
	bool setVar1Result4 = PokerEditor::Instance().Set("var2", "zzz");
	assert(setVar1Result4 == false);
	assert(var1 == 11);
	var1 = 2;
	std::string getVar1Result5Str;
	bool getVar1Result5 = PokerEditor::Instance().Get("var1", getVar1Result5Str);
	assert(getVar1Result5 == true);
	assert(getVar1Result5Str == "2");
	float vars[100];
	for (int i = 0; i < 100; i++)
		{
			std::ostringstream ossVar;
 			ossVar << "_vars" << i;
 			PokerEditor::Instance().Edit(ossVar.str(), vars[i]);
 			std::ostringstream ossValue;
 			ossValue << i;
			bool setVarResult = PokerEditor::Instance().Set(ossVar.str(), ossValue.str());
			assert(setVarResult == true);
			assert(vars[i] == i);
			{
				std::ostringstream ossValue;
				ossValue << i + 1;
				bool setVarResult = PokerEditor::Instance().Set(ossVar.str(), ossValue.str());
				assert(setVarResult == true);
				assert(vars[i] == i + 1);
			}
		}
	for (int i = 0; i < 100; i++)
		{
			std::ostringstream ossVar;
			ossVar << "_vars" << i;
			std::string result;
			bool getVarResult = PokerEditor::Instance().Get(ossVar.str(), result);
			assert(getVarResult == true);
			std::ostringstream ossValue;
			ossValue << i + 1;
			assert(result == ossValue.str());			
		}
	for (int i = 0; i < 100; i++)
		{
			std::ostringstream ossVar;
			ossVar << "__vars" << i;
			std::string result;
			bool getVarResult = PokerEditor::Instance().Get(ossVar.str(), result);
			assert(getVarResult == false);
		}
}
