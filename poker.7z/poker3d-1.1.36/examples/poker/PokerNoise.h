/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Johan Euphrosine <johan@mekensleep.com>
 *  Cedric Pinson <cpinson@freesheep.org>
 *  Igor Kravtchenko <igor@tsarevitch.org>
 */

#ifndef __POKERNOISE_H
#define __POKERNOISE_H

#ifndef POKER_USE_VS_PCH
#include <cal3d/animationalt.h>
#include <osg/Quat>
#include "perlin_noise.h"
#endif

class NoiseElement : public CalAnimationAlt::StopCallback
{
 protected:
  CalCoreAnimation* mCoreAnimation;
  int mCoreAnimationId;
  bool mKeepGoing;
  CalModel* mModel;
  PerlinNoise1D mNoise;
  std::string mDatadir;
  double Noise(double _t,float _amp,float _freq);
  virtual double NoiseFunction(double _t);
  CalCoreBone* GetCoreBone(int boneId);
  void CreateCoreAnimation(const std::string& path, std::list<std::string>& bones);
 public:
  virtual ~NoiseElement() {}
  NoiseElement(CalModel* model, const std::string& datadir);
  void SetKeepGoing(bool keepGoing) { mKeepGoing = keepGoing; }
  virtual void process(CalModel* model, CalAnimationAlt* animation) = 0;
  int GetCoreAnimationId() { return mCoreAnimationId;}
};

class NoiseEyes : public NoiseElement
{
 public:
  NoiseEyes(CalModel* model, const std::string& datadir);
  virtual void process(CalModel* model, CalAnimationAlt* animation);
};

class NoiseNose : public NoiseElement
{
 public:
  NoiseNose(CalModel* model, const std::string& datadir);
  virtual void process(CalModel* model, CalAnimationAlt* animation);
};

class NoiseSkull : public NoiseElement
{
 protected:
  osg::Quat mInitialRotation;
 public:
  NoiseSkull(CalModel* model, const std::string& datadir);  
  virtual void process(CalModel* model, CalAnimationAlt* animation);
};

class NoiseMouth : public NoiseElement
{
 public:
  NoiseMouth(CalModel* model, const std::string& datadir);
  virtual void process(CalModel* model, CalAnimationAlt* animation);
};

class NoiseZygo : public NoiseElement
{
 public:
  NoiseZygo(CalModel* model, const std::string& datadir);
  virtual void process(CalModel* model, CalAnimationAlt* animation);
};

class NoiseEpicr : public NoiseElement
{
 public:
  NoiseEpicr(CalModel* model, const std::string& datadir);
  virtual void process(CalModel* model, CalAnimationAlt* animation);
};

#endif //__POKERNOISE_H
