/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 * Loic Dachary <loic@gnu.org>
 * Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include "pokerStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */
#ifdef WIN32
#include <cstdio>
# define snprintf _snprintf
#endif

#ifndef POKER_USE_VS_PCH

#ifdef USE_NPROFILE
#include <nprofile/profile.h>
#else  //USE_NPROFILE
#define NPROFILE_SAMPLE(a)
#endif //USE_NPROFILE

#include <glib.h>
#include <string>
#include <algorithm>
#include <list>
#include <vector>
#include <cstdlib>

#include <maf/maferror.h>
#include <maf/autoscale.h>
#include <maf/data.h>
#include <maf/scene.h>
#include <maf/window.h>
#include <maf/utils.h>
#include <maf/depthmask.h>
#include <maf/assert.h>
#include <maf/renderbin.h>
#include <ugame/text.h>

#include <varseditor/varseditor.h>

#include <osgDB/Registry>
#include <osgDB/ReadFile>
#include <osgDB/WriteFile>

#include <ugame/debug.h>
#include <ugame/BetSlider>

#include <osg/Vec3>
#include <osg/Vec4>
#include <osg/AutoTransform>
#include <osg/Material>
#include <osg/BlendFunc>

#include <osgchips/Stacks>
#include <ugame/text.h>
#include <maf/data.h>
#endif

#include <libintl.h>
#define _(String) gettext (String)

#include <GL/glu.h>

#ifndef POKER_USE_VS_PCH
#	include "PokerSceneView.h"
#	include "PokerChipsStack.h"
#	include "PokerCursor.h"
#	include "PokerApplication.h"
#endif

static const char* fake = _("FAKE");
static const osg::Vec3	anchors[] = 
  {
    osg::Vec3(0,0,0),
    osg::Vec3(-0.9,0,0.52),
    osg::Vec3(0.88,0,0.52),
    osg::Vec3(0,0,1.05),
    osg::Vec3(-0.9,0,1.56),
    osg::Vec3(0.88,0,1.57),
    osg::Vec3(-1.79,0,1.03),
    osg::Vec3(1.78,0,1.06),
    osg::Vec3(-1.78,0,0),
    osg::Vec3(1.79,0,0.01),
    osg::Vec3(-0.89,0,-0.52),
    osg::Vec3(0.9,0,-0.51),
    osg::Vec3(0,0,-1.05),
  };

static const size_t	anchors_count = sizeof (anchors) / sizeof (osg::Vec3);

void PokerChipsStackModel::InitTooltip(PokerApplication* game)
{

	mTooltip = new UGAMEShadowedText("", MAFLoadFont("data/FreeSansBold.ttf"));
	mTooltip->setCharacterSize(8);
	mTooltip->setCharacterSizeMode(osgText::Text::OBJECT_COORDS);
	mTooltip->setPosition(osg::Vec3(0,0,0));
	mTooltip->setColor( osg::Vec4f(1, 1, 1, 1) );
	mTooltip->setAlignment( osgText::Text::CENTER_CENTER);
	mTooltipAlpha = 0;
	mTooltipFadeOutDelay = 0;
	mTooltipFadeIn = false;

	osg::MatrixTransform *offset = new osg::MatrixTransform();
	offset->setMatrix( osg::Matrix::translate(0, 20, 0) );
	mOffset = offset;

	MAFAutoScale* autot = new MAFAutoScale();
	autot->setNodeMask( MAF_VISIBLE_MASK );
	autot->getOrCreateStateSet()->setMode(GL_DEPTH_TEST, 0);
	//	autot->addChild(mt);
	autot->addChild(mTooltip.get());
	offset->addChild(autot);
	GetPAT()->addChild(offset);
}

void PokerChipsStackModel::ShowTooltip(bool state, float fadeTime)
{
  if (state) {
    unsigned int result = GetChipsAmount();
    if (!result)
      return;
    const std::string& result_str = MAFformat_amount(result);
    mTooltip->setText(osgText::String(result_str, osgText::String::ENCODING_UTF8));

		mTooltipFadeIn = true;
		mTooltipFadeOutDelay = 0.25f;
	}
	else {

		if (!mTooltipFadeIn) {
			mTooltipAlpha -= fadeTime * 2;
			if (mTooltipAlpha < 0) {
				mTooltipAlpha = 0;
				mTooltip->setNodeMask(~(MAF_VISIBLE_MASK|MAF_COLLISION_MASK));
			}
		}
	}

	if (mTooltipFadeIn) {
		mTooltip->setNodeMask( MAF_VISIBLE_MASK );
		mTooltipAlpha += fadeTime * 4;
		if (mTooltipAlpha > 1.0f) {
			mTooltipAlpha = 1.0f;
			mTooltipFadeOutDelay -=  fadeTime;
			if (mTooltipFadeOutDelay < 0)
				mTooltipFadeIn = false;
		}
	}

	mTooltip->setColor( osg::Vec4f(1, 1, 1, mTooltipAlpha) );
}

unsigned int PokerChipsStackModel::GetChipsAmount() const
{
  unsigned int result=0;
  for(unsigned int i = 0; i < mStacks->getNumStacks(); i++) {
    const osgchips::Stack* stack = mStacks->getStack(i);
    if(stack && stack->getChip()) {
      const osgchips::ChipBank::Chip* chip = stack->getChip();
      result += chip->_value * stack->getCount();
    }
  }

  return result;
}

PokerChipsStackModel::PokerChipsStackModel(PokerApplication* game) :
  mBetValue(0),
  mSliderActive(false),
	mbCanBeDisplay(true),
  mSelected(false),
	mForceToDisplayTooltip(false)
{
  Init();
  mStacks = new osgchips::ManagedStacks;
  mStacks->addController(new osgchips::ManagedStacks::ArithmeticController(mStacks.get()));
  mStacks->addEventHandler(new osgchips::ManagedStacks::ScaledPlacementEventHandler);
  std::string max_height_string = game->HeaderGet("sequence", "/sequence/chips/@stack_max_height"); 
  unsigned int max_height = atoi(max_height_string.c_str());

  for(size_t i = 0; i < anchors_count; i++) {
    osgchips::Stack* stack = new osgchips::Stack;
    stack->setMaxHeight(max_height);
    stack->setCount(0);
    stack->setPosition(anchors[i]);
    mStacks->addStack(stack);
  }
  mStacks->getOrCreateStateSet()->setMode(GL_LIGHTING, osg::StateAttribute::OFF);

  osg::Group* group = new osg::Group;

  group->setName("PokerChipsStack");
  group->addChild(mStacks.get());

  SetArtefact(group);
  InitTooltip(game);

	mPreviousMouseX = mPreviousMouseY = 0;
}

PokerChipsStackModel::~PokerChipsStackModel() {
}

PokerChipsStackController::PokerChipsStackController(PokerApplication* game,unsigned int controllerID):UGAMEArtefactController(controllerID) {
  SetModel(new PokerChipsStackModel(game));
}

PokerChipsStackController::~PokerChipsStackController()
{
	PokerSceneView *instance = PokerSceneView::getInstance();
	if (instance && GetModel()->mShadowStacks.valid()) {
		osgchips::ManagedStacks* stacks = GetModel()->mShadowStacks.get();
		int nbStacks = stacks->getNumStacks();
		for (int i = 0; i < nbStacks; i++) {
			osgchips::Stack *stack = stacks->getStack(i);
			instance->removeDrawableThatStayInColor(stack);
		}
	}
}

void PokerChipsStackController::SetChips(const std::vector<int>& chips) {
  osgchips::ManagedStacks::ArithmeticController* controller = GetModel()->mStacks->getArithmeticController();
  controller->setChips(chips);
  //g_assert(GetModel()->mStacks->getNumStacks() <= 13);
}

void PokerChipsStackController::SetChips(const std::map<unsigned int,unsigned int>& chips)
{
  osgchips::ManagedStacks::ArithmeticController* controller = GetModel()->mStacks->getArithmeticController();
  controller->setChips(chips);
  //g_assert(GetModel()->mStacks->getNumStacks() <= 13);
}

void PokerChipsStackController::AddChips(const osgchips::ManagedStacks::ArithmeticController::ChipsMap& chips) {
  osgchips::ManagedStacks::ArithmeticController* controller = GetModel()->mStacks->getArithmeticController();
  controller->addChips(chips);
  //g_assert(GetModel()->mStacks->getNumStacks() <= 13);
}

void PokerChipsStackController::SubChips(const osgchips::ManagedStacks::ArithmeticController::ChipsMap& chips) {
  osgchips::ManagedStacks::ArithmeticController* controller = GetModel()->mStacks->getArithmeticController();
  controller->subChips(chips);
}

osgchips::ManagedStacks::ArithmeticController::ChipsMap PokerChipsStackController::GetChips() const {
  osgchips::ManagedStacks::ArithmeticController::ChipsMap chipsMap;
  GetModel()->mStacks->getArithmeticController()->getChipsMap(chipsMap);
  return chipsMap;
}

void PokerChipsStackController::CreateSlider(PokerApplication* game) {
  betslider::BetSlider* slider = new betslider::BetSlider;
  slider->unserialize(game->GetHeaders()["sequence"], game->GetOptions());
  PokerChipsStackModel* model = GetModel();
  model->mSlider = slider;
  model->mSliderPosition = new osg::PositionAttitudeTransform;
  model->mSliderPosition->setPosition(osg::Vec3(game->GetWindow(true)->GetWidth() / 2.f, 200.f, 0.f));
	//model->mSliderPosition->setPosition(osg::Vec3(0, 0, 0.f));
  model->mSliderPosition->addChild(slider);

  std::list<std::string> names = game->HeaderGetList("sequence", "/sequence/interactors3d/shadowstacks/color/@name");
  for(std::list<std::string>::iterator i = names.begin(); i != names.end(); i++) {
    std::string& name = (*i);
    std::map<std::string,std::string> properties = game->HeaderGetProperties("sequence", "/sequence/interactors3d/shadowstacks/color[@name=\"" + name + "\"]");
    osg::Vec4 color;
    color.x() = atof(properties["red"].c_str()) / 255;
    color.y() = atof(properties["green"].c_str()) / 255;
    color.z() = atof(properties["blue"].c_str()) / 255;
    color.w() = atof(properties["alpha"].c_str());
    model->mColors[name] = color;
  }
}

void PokerChipsStackController::MoveSlider(PokerApplication *game, float x, float y)
{
  PokerChipsStackModel *model = GetModel();
	model->mSliderPosition->setPosition( osg::Vec3f(x, y, 0.0f) );
}

void PokerChipsStackController::InstallSlider(PokerApplication* application) {
  PokerChipsStackModel* model = GetModel();

  if(model->mSelected == false) {
    model->mSelected = true;
    //LOCK_MOUSE(application, this);
    application->mCursor->ShowCursor(false);
    application->GetScene()->GetModel()->mHUDGroup->removeChild(model->mSliderPosition.get());
    application->GetScene()->GetModel()->mHUDGroup->addChild(model->mSliderPosition.get());
  }
}

void PokerChipsStackController::UninstallSlider(PokerApplication* application) {
  PokerChipsStackModel* model = GetModel();

  if(model->mSelected == true) {
    model->mSelected = false;
    //UNLOCK_MOUSE(application, this);
    application->mCursor->ShowCursor(true);
    application->GetScene()->GetModel()->mHUDGroup->removeChild(model->mSliderPosition.get());
  }
}

void PokerChipsStackController::SetShadowChips(const osgchips::ManagedStacks::ArithmeticController::ChipsMap& chips, const std::string& style) {
  osgchips::ManagedStacks* stacks = GetModel()->mShadowStacks.get();
  osgchips::ManagedStacks::ArithmeticController* arithmetic = stacks->getArithmeticController();
  if(arithmetic) {
    arithmetic->setChips(chips);
    osg::Vec4& color = GetModel()->mColors[style];
    osg::StateSet* state = stacks->getStateSet();
    osg::Material* material = dynamic_cast<osg::Material*>(state->getAttribute(osg::StateAttribute::MATERIAL));
    material->setDiffuse(osg::Material::FRONT_AND_BACK, color);
    GetModel()->mSliderActive = true;
  } else {
    g_critical("PokerChipsStackController::SetShadowChips: no arithmetic controller");
  }
}

void PokerChipsStackController::ClearShadowChips(PokerApplication* application) {
  osgchips::ManagedStacks::ArithmeticController::ChipsMap chipsMap;
  osgchips::ManagedStacks* stacks = GetModel()->mShadowStacks.get();
  osgchips::ManagedStacks::ArithmeticController* arithmetic = stacks->getArithmeticController();
  if(arithmetic) {
    arithmetic->setChips(chipsMap);
    GetModel()->mSliderActive = false;
    UninstallSlider(application);
  } else {
    g_critical("PokerChipsStackController::ClearShadowChips: no arithmetic controller");
  }
}

void PokerChipsStackController::CreateShadowStacks(PokerApplication* game) {
  osgchips::ManagedStacks* shadowStacks = new osgchips::ManagedStacks;
  GetModel()->mShadowStacks = shadowStacks;
  new osgchips::ManagedStacks::OnTopEventHandler(shadowStacks, GetModel()->mStacks.get());
  osgchips::ManagedStacks::ArithmeticController* arithmetic = new osgchips::ManagedStacks::ArithmeticController(shadowStacks);
  arithmetic->setPattern("%d-white");
  shadowStacks->addController(arithmetic);
  osg::Group* group = GetModel()->GetArtefact()->asGroup();
  if(group) {
    osg::Material* material = new osg::Material;
    material->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4(0.f, 0.f, 1.f, 1.f));
    material->setColorMode(osg::Material::DIFFUSE);
    osg::StateSet* state = shadowStacks->getOrCreateStateSet();
    state->setAttributeAndModes(material, osg::StateAttribute::ON);
 		state->setAttributeAndModes(new DepthMask(false));
    state->setMode(GL_LIGHTING, osg::StateAttribute::OFF);
    osg::BlendFunc* blendFunc = new osg::BlendFunc();
    blendFunc->setFunction(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    state->setAttributeAndModes(blendFunc);
//		{
	//		int rbvalue;
		//	if (!VarsEditor::Instance().Get("RB_ChipsStackShadow",rbvalue))
			//	MAF_ASSERT(0 && "RB_ChipsStackShadow not found in client.xml");
			//state->setRenderBinDetails(rbvalue, "DepthSortedBin");
		//}
		if (!MAFRenderBin::Instance().SetupRenderBin("ChipsStackShadow", state))
			MAF_ASSERT(0 && "ChipsStackShadow not found in client.xml");

    group->addChild(shadowStacks);

  } else {
    g_critical("PokerChipsStackController::CreateShadowStacks: artefact is not a Group");
  }


	PokerSceneView *instance = PokerSceneView::getInstance();
	if (instance) {
		int shadowStackBeforeHelpMode;
//		if (!VarsEditor::Instance().Get("RB_ChipsStackShadow",shadowStackBeforeHelpMode))
	//		MAF_ASSERT(0 && "RB_ChipsStackShadow not found in client.xml");
		if (!MAFRenderBin::Instance().GetRenderBinIndexOfEntity("ChipsStackShadow", shadowStackBeforeHelpMode))
			MAF_ASSERT(0 && "ChipsStackShadow not found in client.xml");

		int shadowStackInHelpMode;
//		if (!VarsEditor::Instance().Get("RB_ChipsStackShadowInHelpMode",shadowStackInHelpMode))
	//		MAF_ASSERT(0 && "RB_ChipsStackShadowInHelpMode not found in client.xml");
		if (!MAFRenderBin::Instance().GetRenderBinIndexOfEntity("ChipsStackShadowInHelpMode", shadowStackInHelpMode))
			MAF_ASSERT(0 && "ChipsStackShadowInHelpMode not found in client.xml");

		int nbStacks = shadowStacks->getNumStacks();
		for (int i = 0; i < nbStacks; i++) {
			osgchips::Stack *stack = shadowStacks->getStack(i);
			instance->addDrawableThatStayInColor(stack, shadowStackBeforeHelpMode, shadowStackInHelpMode, "DepthSortedBin", 0);
		}
	}
}

bool PokerChipsStackController::Update(MAFApplication* application)
{
  NPROFILE_SAMPLE("PokerChipsStackController::Update");

  PokerApplication* game = static_cast<PokerApplication*>(application);
  //SDL_Event* event = game->GetLastEvent(this);

  PokerChipsStackModel* model = GetModel();

	double deltaS = GetDeltaFrame()/1000.0;

  // focus ->Showtooltip
  if (game->GetFocus() == this && model->mbCanBeDisplay || model->mForceToDisplayTooltip)
    GetModel()->ShowTooltip(true, deltaS);
  else
		GetModel()->ShowTooltip(false, deltaS);
  
	return true;
}

unsigned int PokerChipsStackController::GetBetValue(bool& isCall) {
  isCall = false;
  if(GetModel()->mSlider.valid() &&
     GetModel()->mBetValue > 0 &&
     GetModel()->mSlider->getCurrentIndex() == betslider::BetSlider::ROW_CALL)
    isCall = true;
  
  return GetModel()->mBetValue;
}

void PokerChipsStackController::SetBetLimits(int min, int max, int step, int call, int allin, int pot) {
  g_assert(GetModel()->mSlider.valid());
  GetModel()->mSlider->setLimits(call, min, max, allin, pot, step);
}
