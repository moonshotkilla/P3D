/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *  Loic Dachary <loic@gnu.org>
 *  Henry Precheur <henry@precheur.org>
 *
 */

#include "pokerStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */

#ifndef POKER_USE_VS_PCH
#	include <PokerBubble.h>
#	include <PokerError.h>
#	include <PokerApplication.h>

#include <algorithm>
#include <iostream>
#include <math.h>

#include <osg/Material>
#include <osg/MatrixTransform>
#include <osg/AutoTransform>
// #include <osg/PositionAttitudeTransform>

#include <ugame/debug.h>
#include <ugame/Bubble>

#include "PokerBubble.h"
#include "PokerBubbleManager.h"

#endif

// PokerBubble osg tree
// 
//  + Artefact PAT
//  |
//  + PAT to scale bubble
//  |
//  + osgbubble::Bubble

struct BubbleHelper
{
  static osg::Vec3 Node2ScreenPos(osg::Node *node, PokerApplication *game)
  {
    osg::Matrix toworld = MAFComputeLocalToWorld(node);
    osg::Vec3 worldPos = osg::Vec3(0.0f, 0.0f, 0.0f) * toworld;
    return World2ScreenPos(worldPos, game);
  }
  static osg::Vec3 World2ScreenPos(const osg::Vec3 &worldPos, PokerApplication *game)
  {
    const osg::Matrix &v = game->GetScene()->GetModel()->mScene->getViewMatrix();
    const osg::Matrix &p = game->GetScene()->GetModel()->mScene->getProjectionMatrix();
    osg::Matrix mvp = v * p;    
    return worldPos * mvp;
  }
};

PokerBubbleController::PokerBubbleController(unsigned int controllerID)  : UGAMEArtefactController(controllerID)
{
}

PokerBubbleController::PokerBubbleController(PokerApplication *game,unsigned int controllerID) : UGAMEArtefactController(controllerID)
{
  Init(game);
}

void PokerBubbleController::Init(PokerApplication *game)
{
  UGAMEArtefactController::Init();
  GetModel()->GetNode()->setName("PokerBubble");
  GetModel()->GetNode()->setNodeMask(MAF_VISIBLE_MASK);
  mState = NONE;

  mMinScale = osg::Vec3(0.2f, 0.2f, 0.2f);
  mMaxScale = osg::Vec3(1.0f, 1.0f, 1.0f);
  mCurrentScale = mMinScale;

  const float growTimeout = 200.f;
  const float shrinkTimeout = 200.f;
  const float showTimeout = 3000.f;
  
  mGrowTimeout = growTimeout;
  mShrinkTimeout = shrinkTimeout;
  mShowTimeout = showTimeout;

  // SetArtefact(at);

  // avoid text showing
  {
    mBubble = new osgbubble::Bubble();

		bool res =  mBubble->unserialize(game->GetHeaders()["sequence"]);
		assert(res);

		mBubble->init();
    mBubble->mTextPAT->setNodeMask(0);
    //mBubble->mTailGeode->setNodeMask(0);
    GetModel()->SetArtefact(mBubble.get());
    mPAT = mBubble->mBodyPAT;
    mPAT->setNodeMask(0);
  }	
}

PokerBubbleController::~PokerBubbleController()
{
  mBubble->clean();
}

void PokerBubbleController::SetTextMessage(const std::string &msg)
{
  if (msg.size() == 0)
    return;
  mDisplayedText = msg;
  mBubble->setText(msg);

  const osg::Vec3 &from = mMinScale;
  const osg::Vec3 &to = mMaxScale;

  SetInterpolator(from, to, mGrowTimeout);
  mPAT->setScale(from);
  mPAT->setNodeMask(MAF_VISIBLE_MASK);
  GetModel()->GetPAT()->setNodeMask(MAF_VISIBLE_MASK); // hacky
  mState = GROW;
}


bool PokerBubbleController::Update(MAFApplication* application)
{
	// 	mBubble->mTextPAT->setNodeMask(MAF_VISIBLE_MASK);
	// 	mBubble->mTailGeode->setNodeMask(MAF_VISIBLE_MASK);
	
  float delta = GetDelta();
  switch(mState)
    {
    case GROW:
      {
				//std::cout << "GROW" << std::endl;
				AddTimeAndScale(delta);
				if (mTimer.Finished())
					{
						mBubble->mTextPAT->setNodeMask(MAF_VISIBLE_MASK);
						//mBubble->mTailGeode->setNodeMask(MAF_VISIBLE_MASK);
						//mBubble->mDebugGeode->setNodeMask(MAF_VISIBLE_MASK);						

						// calculate display time based on the lenght of the text
						size_t	str_size = mDisplayedText.size();
						float	time = MIN(10.0f,
								 MAX(2.0f,
								 static_cast<float>(str_size) / 5.0f));
						//time = str_size ? time : 0;						
						mTimeout = 1000.0f * time;
						mState = SHOW;
					}
      }
      break;
    case SHOW:
      {
				//std::cout << "SHOW" << std::endl;
				mTimeout -= delta;
				if (mTimeout <= 0)
					{
						mState = SHRINK;
						SetInterpolator(mCurrentScale, mMinScale, mShrinkTimeout);
					}
      }
      break;
    case SHRINK:
      {
				//std::cout << "SHRINK" << std::endl;
				AddTimeAndScale(delta);
				if (mTimer.Finished())
					{
						mPAT->setNodeMask(0);
						mState = NONE;
					}
      }
      break;
    case NONE:
      {
				mDisplayedText = "";
				mBubble->mDebugGeode->setNodeMask(0);
				//std::cout << "NONE" << std::endl;
      }
      break;
    }	
  return true;
}

void PokerBubbleController::AddTimeAndScale(float delta)
{
  mTimer.AddTime(delta);
  mTimer.Get(mCurrentScale, mInterpolator);
  mPAT->setScale(mCurrentScale);
}

void PokerBubbleController::SetInterpolator(const osg::Vec3 &from, const osg::Vec3 &to, float timeout)
{
  mTimer.Init(timeout);
  mInterpolator.Init(from, to);
  mBubble->mTextPAT->setNodeMask(0);
  //mBubble->mTailGeode->setNodeMask(0);			      
}

void PokerBubbleController::Hide()
{
  mBubble->mTextPAT->setNodeMask(0);
  //mBubble->mTailGeode->setNodeMask(0);
  mPAT->setNodeMask(0);
  mState = NONE;
}
