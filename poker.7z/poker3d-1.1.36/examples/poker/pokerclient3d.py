#!/usr/bin/python
# Copyright (C) 2004, 2005, 2006 Mekensleep
#
# Mekensleep
# 24 rue vieille du temple
# 75004 Paris
#       licensing@mekensleep.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
# Authors:
#  Loic Dachary <loic@gnu.org>
#  Cedric Pinson <cpinson@freesheep.org>
#
import sys
import os
import platform

from twisted.internet import reactor, error, ssl

from string import split, lower
from os import makedirs
from os.path import expanduser, exists
import signal
from traceback import print_exc
import libxml2
from shutil import copy

from time import sleep
from random import choice, uniform, randint

from pokernetwork.pokerclient import PokerClientFactory, PokerSkin
from pokernetwork.pokerclientpackets import *
from pokernetwork.proxy import Connector

from poker.pokerskin3d import PokerSkin3D
from poker.pokerrenderer3d import PokerRenderer3D
from poker.pokerdisplay3d import PokerDisplay3D
from pokerui import pokerinterface
from poker.pokerchildren3d import PokerChildXwnc, PokerChildInterface, CHILD_INTERFACE_READY, CHILD_INTERFACE_GONE
from poker.config import Config
from poker.version import version

class PokerClientFactory3D(PokerClientFactory):
    def __init__(self, *args, **kwargs):
        PokerClientFactory.__init__(self, *args, **kwargs)

        settings = self.settings
        config = self.config

        self.logToFile = self.settings.headerGet("/settings/@logToFile") or 'no'
        if platform.system() != 'Windows':
            self.logToFile = 'no';

        self.initDisplay()

        self.skin = PokerSkin3D(settings = self.settings)
        self.renderer = PokerRenderer3D(self)
        self.interface = None
        
    def initDisplay(self):
        if self.settings.headerGet("/settings/screen/@fullscreen") == "yes":
            self.config.headerSet("/sequence/application2d/window[@title='menu_window']/@mouseTrigger", "true")
        self.display = PokerDisplay3D(settings = self.settings,
                                      config = self.config,
                                      factory = self)
        self.display.init()

    def initChildren(self):
        settings = self.settings
        config = self.config
        
        xwnc = PokerChildXwnc(config, settings)
        if not xwnc.ready:
            print "ERROR: cannot configure xwnc "
            return False
        if self.children.spawn(xwnc):
            interface = PokerChildInterface(config, settings)
            interface.registerHandler(CHILD_INTERFACE_READY, self.setInterface)
            interface.registerHandler(CHILD_INTERFACE_GONE, self.unsetInterface)
            try:
                self.children.spawn(interface)
            except error.CannotListenError:
                self.quit()
        else:
            return False

    def setInterface(self, interfaceChild, interface, interfaceFactory):
        self.display.interfaceReady()
        self.interface = interface
        if self.settings.headerGet("/settings/@upgrades") == "yes":
            self.checkClientVersion((version.major(), version.medium(), version.minor()))
        else:
            self.clientVersionOk()
            
    def preloadInterface(self):
        message = "dummy"        
        self.renderer.showCashier()
        self.renderer.showBuyIn()
        self.renderer.showLobby()
        self.renderer.chatShow()
        self.renderer.chatHistoryShow()
        self.interface.command("outfit", "show")
        self.renderer.showTournaments()

    def hideInterface(self):
        self.renderer.hideCashier()
        self.renderer.hideBuyIn()
        self.renderer.hideLobby()
        self.renderer.render(PacketPokerInterfaceCommand(window = "lobby_tabs_window", command = "hide"))
        self.renderer.hideOutfit()        
        self.renderer.hideTournaments()
        self.renderer.render(PacketPokerInterfaceCommand(window = "tournaments_lobby_tabs_window", command = "hide"))
        self.renderer.chatHide()
        self.renderer.chatHistoryHide()
        self.renderer.hideBackgroundLobbyCashier()
        self.renderer.hideClockWindow()

    def clientVersionOk(self):
        if self.interface:
            self.renderer.interfaceReady(self.interface)
        self.display.load()
        if self.interface:
            self.skin.interfaceReady(self.interface, self.display)        
            self.display.hideProgressBar()
            self.showServers()
        else:
            self.quit()
            raise Exception, "FATAL: the 2D interface is not available (poker-interface process is probably not running)"


    def needUpgrade(self, version):
        self.display.hideProgressBar()
        interface = self.interface
        interface.yesnoBox("A new client version is available, do you want to upgrade now ?")
        interface.registerHandler(pokerinterface.INTERFACE_YESNO, lambda result: self.upgradeConfirmed(result, version))

    def upgradeConfirmed(self, confirmed, version):
        self.display.showProgressBar()        
        if confirmed:
            self.upgrade(version, ())
        else:
            self.quit()

    def unsetInterface(self, interfaceChild, interface, interfaceFactory):
        self.interface = None
        self.children.kill(interfaceChild)
        if hasattr(self, "factory") and not self.factory.shutting_down:
            print "2D interface process is gone, can't continue without it."
            reactor.stop()

    def showServers(self):
        servers = split(self.settings.headerGet("/settings/servers"))
        if len(servers) > 1:
            interface = self.interface
            interface.chooser("Choose a poker3d server", servers)
            interface.registerHandler(pokerinterface.INTERFACE_CHOOSER, self.selectServer)
        else:
            self.selectServer(servers[0])
        self.display.render(PacketPokerInterfaceCommand(window = "chooser_window", command = "show"))
            
    def selectServer(self, server):
        self.display.render(PacketPokerInterfaceCommand(window = "chooser_window", command = "hide"))
        (self.host, self.port) = split(server, ":")
        if ";" in self.port:
            (self.port, want_ssl) = split(self.port, ";")
        else:
            want_ssl = None
        self.port = int(self.port)

        ssl_context = want_ssl and ssl.ClientContextFactory()
        
        settings = self.settings
        proxy = settings.headerGet("/settings/servers/@proxy")
        if proxy:
            if self.verbose > 1:
                print "connection thru proxy " + proxy
            ( host, port ) = proxy.split(':')
            port = int(port)
        else:
            ( host, port ) = ( self.host, self.port )

        timeout = settings.headerGetInt("/settings/@tcptimeout")

        c = Connector(host, port, self, ssl_context, timeout, None, reactor)
        if proxy:
            c.setProxyHost("%s:%d" % (self.host, self.port))
        c.connect()
        
    def buildProtocol(self, addr):
        protocol = PokerClientFactory.buildProtocol(self, addr)
        self.renderer.setProtocol(protocol)
        self.display.setProtocol(protocol)
        return protocol

    def clientConnectionFailed(self, connector, reason):
        print "connectionFailed: %s" % reason
        self.interface.messageBox("Unable to reach the poker3d\nserver at %s:%d" % ( self.host, self.port ))
        self.interface.registerHandler(pokerinterface.INTERFACE_MESSAGE_BOX, self.showServers)
        
    def clientConnectionLost(self, connector, reason):
        self.renderer.setProtocol(None)
        reconnect = True
        if hasattr(self, "reconnect"):
            reconnect = self.reconnect
            del self.reconnect

        if reconnect:
            message = "The poker3d server connection was closed"
            if not reason.check(error.ConnectionDone):
                message += " " + str(reason)
            print message
            if self.interface:
                self.interface.messageBox("Lost connection to poker3d\nserver at %s:%d" % ( self.host, self.port ))
                self.interface.registerHandler(pokerinterface.INTERFACE_MESSAGE_BOX, self.showServers)
