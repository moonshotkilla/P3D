/**
 * Copyright (C) 2007 Loic Dachary <loic@dachary.org>
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Henry Pr�cheur <henry@precheur.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 *  Igor Kravtchenko <igor@ozos.net>
 */

#include "pokerStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */
#ifdef WIN32
#include <cstdio>
#endif

#ifndef POKER_USE_VS_PCH
#include <string>

#ifdef USE_NPROFILE
#include <nprofile/profile.h>
#else  //USE_NPROFILE
#define NPROFILE_SAMPLE(a)
#endif //USE_NPROFILE

#include <maf/depthmask.h>
#include <maf/maferror.h>
#include <maf/osghelper.h>
#include <maf/scene.h>
#include <maf/utils.h>
#include <maf/assert.h>
#include <maf/renderbin.h>

#include <varseditor/varseditor.h>

#include <osg/AlphaFunc>
#include <osg/AutoTransform>
#include <osg/BlendFunc>
#include <osg/CullFace>
#include <osg/Geode>
#include <osg/Material>
#include <osg/MatrixTransform>
#include <osg/Quat>
#include <osg/ShapeDrawable>
#include <osg/Stencil>

#include "PokerApplication.h"
#include "PokerCard.h"
#include "Poker.h"

#include <PokerBoard.h>
#endif

#define MAX_V 3.0f

static std::vector<int>	g_ray_index_base;
static std::vector<int>	g_ray_index_topleft;
static std::vector<int>	g_ray_index_topright;
static std::vector<int>	g_ray_index_bottomright;
static std::vector<int>	g_ray_index_bottomleft;

static std::vector<int>	g_lightcone_index_vertex_top;
static std::vector<int>	g_lightcone_index_vertex_bottom;

void PokerBoardController::EnableSound()
{
  if (mSoundCardEffect.valid()) {
    if (!mSoundCardEffect->GetModel()->GetState()->hasSource()) {
      mSoundCardEffect->Play();
    }
  }
}

void PokerBoardController::DisableSound()
{
  if (mSoundCardEffect.valid()) {
    mSoundCardEffect->Stop();
  }
}

PokerBoardController::PokerBoardController(PokerApplication* game,unsigned int controllerID) : MAFController(controllerID), mGame(game) 
{
  mSoundStarted=false;
  mSoundAngleThreshold=1;
  std::string soundAngleThreshold_url = game->HeaderGet("sequence", "/sequence/projector/@soundAngleThreshold");
  if (soundAngleThreshold_url.empty())
    g_warning("PokerBoardController::PokerBoardController tag /sequence/projector/@soundAngleThreshold not found, use a default value");
  else
    mSoundAngleThreshold=atof(soundAngleThreshold_url.c_str());
  
  char tmp[256];
  std::string card_url = game->HeaderGet("sequence", "/sequence/projector/@url");
  std::string anchor_card = game->HeaderGet("sequence", "/sequence/projector/@anchor");
  std::string board_count = game->HeaderGet("sequence", "/sequence/projector/@count");
  std::vector<std::string> anchors;

  // no check here because we can't be here if set is not loaded
  mSetData = (MAFESCNData*) mGame->mSetData;
	mTransformProjector = (osg::MatrixTransform*) OSGHelper_getNodeByName(*mSetData->GetGroup(), "transform_ProjCenter");
	mTransformProjector->setNodeMask(MAF_VISIBLE_MASK);

	mCpath04_transform = (osg::MatrixTransform*) OSGHelper_getNodeByName(*mSetData->GetGroup(), "transform_cpath04");
	mCpath05_transform = (osg::MatrixTransform*) OSGHelper_getNodeByName(*mSetData->GetGroup(), "transform_cpath05");

  mCards.resize(atoi(board_count.c_str()));
  int i;
  for (i = 0; i < (int)mCards.size(); i++) {
    sprintf(tmp, anchor_card.c_str(), i + 1);
    //anchors.push_back(tmp);
    
		PokerCardController *card = new PokerCardController(game, card_url);
		card->Fold();

		osg::MatrixTransform *grp = (osg::MatrixTransform*) game->mSetData->GetAnchor(tmp);
		osg::MatrixTransform *cardMatrix = new osg::MatrixTransform;
		grp->addChild(cardMatrix);
		card->Anchor(cardMatrix);

		mOrgCardsTranslation[i] = grp->getMatrix().getTrans();

		mCardsNode[i] = grp;
		mCardsMatrix[i] = cardMatrix;
		mCards[i] = card;
  }

	mBillBoard = (MAFBillBoard*) game->mSetData->GetAnchor("autotransform_flopcenter");
	mBillBoard->setActive(false);

	// o     -> mCardsNode
	// |
	// o     -> mCardsMatrix
	// |
	// o     -> mCards

	mCurrentTranslationFactor = 0;
	mSourceTranslation = mOrgCardsTranslation[0];
	mDestinationTranslation = mOrgCardsTranslation[0];

	{
		const std::string &lightcone_url = game->HeaderGet("sequence","/sequence/projector/@lightcone");
		if (lightcone_url.empty())
			g_error("PokerBoardController::PokerBoardController /sequence/projector/@lightcone not found or empty");

		MAFESCNData *data = (MAFESCNData*) mGame->mDatas->GetVision(lightcone_url);
		if (!data)
			g_error("PokerBoardController::PokerBoardController %s not found",lightcone_url.c_str());
		//data=(MAFESCNData*)data->Clone();//LEVEL_CLONE_SETTING|osg::CopyOp::DEEP_COPY_DRAWABLES | osg::CopyOp::DEEP_COPY_STATESETS| osg::CopyOp::DEEP_COPY_STATEATTRIBUTES | osg::CopyOp::DEEP_COPY_ARRAYS | osg::CopyOp::DEEP_COPY_PRIMITIVES | osg::CopyOp::DEEP_COPY_SHAPES);
		//data = (MAFESCNData*)data->Clone(osg::CopyOp::SHALLOW_COPY);

		mLightCone = (osg::Group*) data->GetGroup()->clone(LEVEL_CLONE_SETTING_ALLEXCEPT_IMG_AND_TEX);
		mLightCone->setNodeMask(0);

		osg::Geode *geode = GetGeode( mLightCone );
		if (!geode)
			g_error("PokerBoardController::PokerBoardController set/mesh_lightcone not found");

		osg::Geometry *geom = (osg::Geometry*) geode->getDrawable(0);
		geom->setUseDisplayList(false);

//		{
	//		int rbvalue;
		//	if (!VarsEditor::Instance().Get("RB_LightCone",rbvalue))
			//	MAF_ASSERT(0 && "RB_LightCone not found in client.xml");
//			geom->getOrCreateStateSet()->setRenderBinDetails(rbvalue, "DepthSortedBin");
	//	}
		if (!MAFRenderBin::Instance().SetupRenderBin("LightCone", geom->getOrCreateStateSet()))
			MAF_ASSERT(0 && "LightCone not found in client.xml");

		osg::Vec3Array *arr = (osg::Vec3Array*) geom->getVertexArray();
		osg::Vec3f *pnts = (osg::Vec3f*) arr->getDataPointer();
		mLightconeVertex = pnts;

		if (g_lightcone_index_vertex_top.size() == 0) {
			const osg::BoundingBox &box = geom->getBound();

			OSGHelper_getPointsWithYOf(*arr, box._max._v[1], g_lightcone_index_vertex_top, 1.0f );
			OSGHelper_getPointsWithYOf(*arr, box._min._v[1], g_lightcone_index_vertex_bottom, 1.0f );
		}

		int nb = g_lightcone_index_vertex_top.size();
		mLightconeVertexTop_bak = new osg::Vec3f[nb];
		for (i = 0; i < nb; i++) {
			int index = g_lightcone_index_vertex_top[i];
			mLightconeVertexTop_bak[i] = pnts[index];
		}

		nb = g_lightcone_index_vertex_bottom.size();
		mLightconeVertexBottom_bak = new osg::Vec3f[nb];
		for (i = 0; i < nb; i++) {
			int index = g_lightcone_index_vertex_bottom[i];
			mLightconeVertexBottom_bak[i] = pnts[index];
		}

		osg::StateSet *ss = geom->getOrCreateStateSet();
		mLightConeTexMat[0] = new osg::TexMat();
		mLightConeTexMat[1] = new osg::TexMat();
		ss->setTextureAttributeAndModes(0, mLightConeTexMat[0]);
		ss->setTextureAttributeAndModes(1, mLightConeTexMat[1]);
		ss->setMode(GL_LIGHTING, osg::StateAttribute::OFF);

		osg::Material *newmat = new osg::Material();
		ss->setAttributeAndModes(newmat, osg::StateAttribute::ON);
		newmat->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(1, 1, 1, 0) );
		mLightConeMaterial = newmat;

		osg::BlendFunc *bf = new osg::BlendFunc();
		bf->setFunction(GL_SRC_ALPHA, GL_ONE);
		ss->setAttributeAndModes(bf, osg::StateAttribute::ON);
		ss->setAttributeAndModes(new DepthMask(false));
	}

	const std::string &cpath_url = game->HeaderGet("sequence","/sequence/projector/@cpath");
	if (cpath_url.empty())
		g_error("PokerBoardController::PokerBoardController %s not found",cpath_url.c_str());

	for (i = 0; i < 2; i++) {
		char str[200];
		sprintf(str, cpath_url.c_str(), i+4);

		MAFESCNData *data = (MAFESCNData*) mGame->mDatas->GetVision(str);
		if (!data)
			g_error("PokerBoardController::PokerBoardController %s not found",str);
		//		data = (MAFESCNData*) data->Clone();//LEVEL_CLONE_SETTING|osg::CopyOp::DEEP_COPY_DRAWABLES | osg::CopyOp::DEEP_COPY_STATESETS);
		osg::Group *cpath = (osg::Group*) data->GetGroup()->clone(LEVEL_CLONE_SETTING_ALLEXCEPT_IMG_AND_TEX);
		mCPath[i] = cpath;
	}

	for (i = 3; i < 5; i++) {
		osg::TexMat *texmat = new osg::TexMat();
		char str[200];
		//sprintf(str, "set/mesh_cpath%.2d.emsh", i+1);
		sprintf(str, "set/mesh_cpath%.2d.umesh", i+1);
		osg::Geode *geode = (osg::Geode*) OSGHelper_getNodeByName(*mCPath[i-3], str);
		if (!geode) {
			sprintf(str, "set/mesh_cpath%.2d.emsh", i+1);
			geode = (osg::Geode*) OSGHelper_getNodeByName(*mCPath[i-3], str);
			if (!geode)
				g_error("PokerBoardController::PokerBoardController %s not found", str);
		}

		osg::Geometry *geom0 = (osg::Geometry*) geode->getDrawable(0);
		osg::Geometry *geom1 = (osg::Geometry*) geode->getDrawable(1);

		geode->setNodeMask(0);

		osg::AlphaFunc *alphaFunc = new osg::AlphaFunc();
		alphaFunc->setReferenceValue(0);
		alphaFunc->setFunction(osg::AlphaFunc::NOTEQUAL);

		osg::StateSet *ss0 = geom0->getStateSet();
		osg::StateSet *ss1 = geom1->getStateSet();

		ss0->setAttributeAndModes(alphaFunc);
		ss1->setAttributeAndModes(alphaFunc);

		osg::Texture *tx = (osg::Texture*) ss0->getTextureAttribute(0, osg::StateAttribute::TEXTURE);
		if (tx) {
			tx->setBorderColor( osg::Vec4f(0, 0, 0, 0) );
			tx->setWrap(osg::Texture::WRAP_S, osg::Texture::CLAMP_TO_BORDER);
			tx->setWrap(osg::Texture::WRAP_T, osg::Texture::CLAMP_TO_BORDER);
		}

		tx = (osg::Texture*) ss1->getTextureAttribute(0, osg::StateAttribute::TEXTURE);
		if (tx) {
			tx->setBorderColor( osg::Vec4f(0, 0, 0, 0) );
			tx->setWrap(osg::Texture::WRAP_S, osg::Texture::CLAMP_TO_BORDER);
			tx->setWrap(osg::Texture::WRAP_T, osg::Texture::CLAMP_TO_BORDER);
		}

		geom0->getOrCreateStateSet()->setTextureAttributeAndModes(0, texmat);
		geom1->getOrCreateStateSet()->setTextureAttributeAndModes(0, texmat);

		mSlots[i].cpath_texmat = texmat;
		mSlots[i].geode_cpath = geode;
	}

	{
		const std::string &lightray_url = game->HeaderGet("sequence","/sequence/projector/@lightray");
		if (lightray_url.empty())
			g_error("PokerBoardController::PokerBoardController %s not found", lightray_url.c_str());

		MAFESCNData *data = (MAFESCNData*) mGame->mDatas->GetVision(lightray_url);
		if (!data)
			g_error("PokerBoardController::PokerBoardController %s not found", lightray_url.c_str());
		//data = (MAFESCNData*) data->Clone();

		//int copyop = osg::CopyOp::DEEP_COPY_DRAWABLES | osg::CopyOp::DEEP_COPY_STATEATTRIBUTES | osg::CopyOp::DEEP_COPY_STATESETS | osg::CopyOp::DEEP_COPY_TEXTURES;
		int copyop = osg::CopyOp::SHALLOW_COPY;

		osg::Geode *geode = (osg::Geode*) GetGeode( data->GetGroup() )->clone(copyop);
		if (!geode)
			g_error("PokerBoardController::PokerBoardController set/mesh_lightray not found");
		osg::Geometry *geom = (osg::Geometry*) geode->getDrawable(0); //->clone(osg::CopyOp::DEEP_COPY_ALL & (~(osg::CopyOp::DEEP_COPY_TEXTURES | osg::CopyOp::DEEP_COPY_IMAGES)));
		osg::StateSet *ss = geom->getOrCreateStateSet();
		ss->setMode(GL_LIGHTING, osg::StateAttribute::OFF);

		for (i = 0; i < 5; i++) {
			osg::Geode *geode = new osg::Geode();
			mLightRay[i] = geode;

			LightRayGeometry *gg = new LightRayGeometry(*geom, i, this, osg::CopyOp::DEEP_COPY_ALL);
			gg->setUseDisplayList(false);
			geode->addDrawable( gg );

			osg::StateSet *ss = new osg::StateSet( *geom->getOrCreateStateSet() );
			gg->setStateSet(ss);

			osg::TexMat *texMat = new osg::TexMat();
			mLightRayProjMat[i][0] = texMat;
			ss->setTextureAttributeAndModes(0, texMat);
			texMat = new osg::TexMat();
			mLightRayProjMat[i][1] = texMat;
			ss->setTextureAttributeAndModes(1, texMat);

			osg::BlendFunc *bf = new osg::BlendFunc();
			bf->setFunction(GL_SRC_ALPHA, GL_ONE);
			ss->setAttributeAndModes(bf, osg::StateAttribute::ON);

			ss->setAttributeAndModes(new DepthMask(false));

			osg::TexEnv *env;
			env = new osg::TexEnv;
			env->setMode(osg::TexEnv::MODULATE);
			ss->setTextureAttributeAndModes(0, env);
			env = new osg::TexEnv;
			env->setMode(osg::TexEnv::MODULATE);
			ss->setTextureAttributeAndModes(1, env);

			osg::Material *newmat = new osg::Material();
			newmat->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(1, 1, 1, 0) );
			ss->setAttributeAndModes(newmat, osg::StateAttribute::ON);
			mLightRayMaterial[i] = newmat;
		}

		if (g_ray_index_topleft.size() == 0) {
			osg::Vec3Array *arr = (osg::Vec3Array*) geom->getVertexArray();
			const osg::BoundingBox &box = geom->getBound();

			OSGHelper_getPointsEqualTo(*arr, osg::Vec3(box._min._v[0], box._max._v[1], box._min._v[2]), g_ray_index_topleft );
			OSGHelper_getPointsEqualTo(*arr, osg::Vec3(box._max._v[0], box._max._v[1], box._min._v[2]), g_ray_index_topright );
			OSGHelper_getPointsEqualTo(*arr, osg::Vec3(box._max._v[0], box._max._v[1], box._max._v[2]), g_ray_index_bottomright );
			OSGHelper_getPointsEqualTo(*arr, osg::Vec3(box._min._v[0], box._max._v[1], box._max._v[2]), g_ray_index_bottomleft );
			OSGHelper_getPointsEqualTo(*arr, osg::Vec3( 0, 0, 0), g_ray_index_base );
		}
	}

	osg::MatrixTransform *node_transform = (osg::MatrixTransform*) OSGHelper_getNodeByName(*mSetData->GetGroup(), "transform_ProjCenter");
	if (!node_transform)
		g_critical("Leaks \"transform_ProjCenter\" matrix!");
	mRayBaseInv = osg::Matrix::inverse( node_transform->getMatrix() );
	mRayBase = node_transform->getMatrix().getTrans();
	node_transform->addChild( mLightRay[0] );
	node_transform->addChild( mLightRay[1] );
	node_transform->addChild( mLightRay[2] );
	node_transform->addChild( mLightRay[3] );
	node_transform->addChild( mLightRay[4] );
	node_transform->addChild( mLightCone );

	osg::MatrixTransform *cpath04_transform = (osg::MatrixTransform*) OSGHelper_getNodeByName(*mSetData->GetGroup(), "transform_cpath04");
	osg::MatrixTransform *cpath05_transform = (osg::MatrixTransform*) OSGHelper_getNodeByName(*mSetData->GetGroup(), "transform_cpath05");
	cpath04_transform->addChild( mCPath[0] );
	cpath05_transform->addChild( mCPath[1] );

	mSlots[3].cpath = cpath04_transform;
	mSlots[4].cpath = cpath05_transform;

	mPreviousCardsSize = 0;
	for (i = 0; i < 5; i++)
		mPreviousCardsValue[i] = -999; // safety impossible first value to have

	mAllCardsGo = false;
	mCounterAllCardsGo = 0;
	mConeMatrixCounter = 0;
	mConeFactor = 0;
	mConeStatus = 0;
	mCallAgainSetCards = false;

	std::string anchor_center = game->HeaderGet("sequence", "/sequence/projector/@board_center");
	if (anchor_center.empty())
		g_error("PokerModel::PokerModel /sequence/projector/@board_center not found");
	mBoardCenter = game->mSetData->GetAnchor(anchor_center)->asTransform()->asMatrixTransform();

	mSamples.Init(50, osg::Vec3(0,0,0)); // 50 value per second
	mSamples.SetDelay(0.5);
	mSamples.SetSampleRate(1.0/50.0);

	std::string paramTextYTranslate = game->HeaderGet("sequence", "/sequence/projector/@text_ytranslation");
	if (paramTextYTranslate.empty())
		g_error("PokerModel::PokerModel /sequence/projector/@text_ytranslation not found");
	mParamTextYTranslate = atof(paramTextYTranslate.c_str());

	std::string paramTextYOffset = game->HeaderGet("sequence", "/sequence/projector/@text_yoffset");
	if (paramTextYOffset.empty())
		g_error("PokerModel::PokerModel /sequence/projector/@text_yoffset not found");
	mParamYoffsetForText = atof(paramTextYOffset.c_str());

	std::string winningCardsTranslation = game->HeaderGet("sequence", "/sequence/projector/@winningcards_translation");
	if (winningCardsTranslation.empty())
		g_error("PokerModel::PokerModel /sequence/projector/@winningCardsTranslation not found");
	mParamWinningCardsTranslation = atof(winningCardsTranslation.c_str());

	std::string redRayColor = game->HeaderGet("sequence", "/sequence/projector/rayColor/@red");
	std::string greenRayColor = game->HeaderGet("sequence", "/sequence/projector/rayColor/@green");
	std::string blueRayColor = game->HeaderGet("sequence", "/sequence/projector/rayColor/@blue");
	if (redRayColor.empty() || greenRayColor.empty() || blueRayColor.empty())
		g_error("PokerModel::PokerModel /sequence/projector/rayColor/ not found");

	mLightRayColor._v[0] = atof( redRayColor.c_str() ) / 255.0f;
	mLightRayColor._v[1] = atof( greenRayColor.c_str() ) / 255.0f;
	mLightRayColor._v[2] = atof( blueRayColor.c_str() ) / 255.0f;

	mTextBillboard = new MAFBillBoard();
	mTextAnchor = new osg::MatrixTransform;
	mTextAnchor->setMatrix(osg::Matrix::translate(0, mParamYoffsetForText, 0));
	mTextBillboard->addChild( mTextAnchor.get() );
	mBillBoard->addChild(mTextBillboard.get());

	std::string datadir = game->HeaderGet("settings", "/settings/data/@path");
	if (datadir.empty())
		g_assert(0 && "Stop to play remount data please");

	mLabel = new UGAMEShadowedText("yopa", MAFLoadFont(datadir + "/FreeSansBold.ttf"));
	mLabel->setCharacterSize(10);
	mLabel->setAlignment(osgText::Text::CENTER_CENTER);

	//mLabel->Anchor(mTextAnchor.get());
	mTextAnchor->addChild( mLabel.get() );

	{
		std::string paramDuration = game->HeaderGet("sequence", "/sequence/projector/@fadein_duration");
		if (paramDuration.empty())
			g_error("PokerModel::PokerModel /sequence/projector/@fadein_duration not found");
		mParamFadeInDuration = atof(paramDuration.c_str());
	}
	StopToDisplayShowDown();

	float volume_projector = 1.0;
	float soundReferenceDistance = 1.0;

	const std::string &soundVolume_url = mGame->HeaderGet("sequence","/sequence/projector/@soundVolume");
	if (soundVolume_url.empty())
		g_debug("PokerBoardController::PokerBoardController %s not found", soundVolume_url.c_str());
	volume_projector = atof(soundVolume_url.c_str());

	const std::string &soundReference_url = mGame->HeaderGet("sequence","/sequence/projector/@soundReferenceDistance");
	if (soundReference_url.empty())
		g_debug("PokerBoardController::PokerBoardController %s not found", soundReference_url.c_str());
	soundReferenceDistance = atof(soundReference_url.c_str());

	const std::string &soundOpen_url = mGame->HeaderGet("sequence","/sequence/projector/@soundOpen");
	if (soundOpen_url.empty())
		g_debug("PokerBoardController::PokerBoardController %s not found", soundOpen_url.c_str());
	else {
		MAFAudioData *data = mGame->mDatas->GetAudio(soundOpen_url);
		if (data) {
			MAFAudioModel* audio_model = new MAFAudioModel;
			audio_model->SetName("soundOpenProjo");
			audio_model->SetData(data);
			audio_model->SetAmbient(false);
			audio_model->SetGain(volume_projector);
			audio_model->SetReferenceDistance(soundReferenceDistance);
			audio_model->SetSoundEvent(true);
			mSoundOpen = new MAFAudioController;
			mSoundOpen->SetModel(audio_model);
			mSoundOpen->Init();
			mSoundOpen->AttachTo(node_transform);
		}
	}

	const std::string &soundClose_url = mGame->HeaderGet("sequence","/sequence/projector/@soundClose");
	if (soundClose_url.empty())
		g_debug("PokerBoardController::PokerBoardController %s not found", soundClose_url.c_str());
	else {
		MAFAudioData *data = mGame->mDatas->GetAudio(soundClose_url);
		if (data) {
			MAFAudioModel* audio_model = new MAFAudioModel;
			audio_model->SetName("soundCloseProjo");
			audio_model->SetData(data);
			audio_model->SetAmbient(false);
			audio_model->SetGain(volume_projector);
			audio_model->SetSoundEvent(true);
			audio_model->SetReferenceDistance(soundReferenceDistance);
			mSoundClose = new MAFAudioController;
			mSoundClose->SetModel(audio_model);
			mSoundClose->Init();
			mSoundClose->AttachTo(node_transform);
		}
	}

	mWinningCards.resize(5);
}

PokerBoardController::~PokerBoardController() 
{
}


void PokerBoardController::SetCards(const std::vector<int> &_cards)
{
	mCardsValue = _cards;

	if (mGame->GetPoker()->GetModel()->mBatchMode) {

		for (int i = 0; i < 5; i++) {
			Slot &slot = mSlots[i];
			slot.alphaRay = 0;
			slot.rayState = -1;
			slot.state = -1;
			mPreviousCardsValue[i] = -999;
		}

		FoldCards();
		mAllCardsGo = false;

		if (_cards.size() > 0) {
			mConeFactor = 1000;
			mConeStatus = 2;
			mLightCone->setNodeMask(MAF_VISIBLE_MASK);
		}
		else {
			mLightCone->setNodeMask(0);
			mConeStatus = 0;
		}

		for (unsigned int i = 0; i < _cards.size(); i++) {

			int cardValue = _cards[i];
			MakeCardNikel(i);

			if(cardValue != 255) {
				mCards[i]->SetValue(cardValue);
				mCards[i]->Visible(true);
			}
			else {
				mCards[i]->Visible(false);
			}

			mPreviousCardsValue[i] = cardValue;
		}

		mSourceTranslation = mDestinationTranslation;
		mDestinationTranslation = mOrgCardsTranslation[0] + (mOrgCardsTranslation[_cards.size()-1] - mOrgCardsTranslation[0])/2;
		mCurrentTranslationFactor = 1;

		mPreviousCardsSize = _cards.size();

		Update(mGame);

		return;
	}

	std::vector<int> usedCards = _cards;

	if (mPreviousCardsSize == 0 && usedCards.size() > 0)
		MakeConeArrive();

	if (mPreviousCardsSize == 0 && usedCards.size() > 3) {
		usedCards.resize(3);
		mCallAgainSetCards = true;
	}

	if (mPreviousCardsSize == 3 && usedCards.size() == 5) {
		usedCards.resize(4);
		mCallAgainSetCards = true;
	}

	int nbVisible = 0;
	for (unsigned int i = 0; i < mCards.size(); i++) {
		if (i < usedCards.size()) {
//			mCards[i]->Receive();

			if (mPreviousCardsValue[i] != usedCards[i]) {
				MakeCardArrive(i, usedCards[i]);
				mPreviousCardsValue[i] = usedCards[i];
			}

			if (usedCards[i] != 255) {
				mCards[i]->SetValue(usedCards[i]);
				mCards[i]->Visible(true);
				nbVisible++;
			}
			else {
				mCards[i]->Visible(false);
			}
		}
		else {
//			if (m_previousCardsValue[i] != -123) {
//				m_previousCardsValue[i] = -123;
//				makeCardGo(i);
//			}
//			mCards[i]->Fold();
		}
	}

	if (!nbVisible) {
//		StopToDisplayShowDown();

		if (mPreviousCardsSize > 0 && usedCards.size() == 0) {

			SetHandValue(" ");

			MakeConeGo();
			MakeAllCardsGo();
		}
	}


	mPreviousCardsSize = usedCards.size();

	Update(mGame);

	//StartToDisplayShowDown();
}


bool PokerBoardController::Update(MAFApplication* application)
{
  NPROFILE_SAMPLE("PokerBoardController::Update");

	int i;

	if (mGame->HasEvent())
		return true;

	float dt = GetDeltaFrame() / 1000.0f;

	PokerCameraModel *camera = (dynamic_cast<PokerCameraController*>(mGame->GetScene()->GetModel()->mCamera.get()))->GetModel();
	float zoomCard = 1.0f;

	{
		osgUtil::SceneView *sceneView = mGame->GetScene()->GetView()->GetModel()->mScene.get();
		osg::Matrix camMat = sceneView->getViewMatrix();
		osg::Matrix fmat = MAFComputeLocalToWorld( mBoardCenter.get() ) * camMat;
		float z = -fmat.getTrans()._v[2];

		if (z > 300) {
			zoomCard = z / 300;
		}

	}

	osg::Vec3f translate = mSourceTranslation * (1 - mCurrentTranslationFactor) + mDestinationTranslation * mCurrentTranslationFactor;
	for (i = 0; i < 5; i++) {

		osg::Vec3f translation = mOrgCardsTranslation[i];
		translation._v[0] -= translate._v[0];

//		if (mShowDownTime)
//			translation._v[1] += mParamYoffsetForCards * mLabelAlpha;

		if (mShowDownTime) {
			int c1 = mCards[i]->GetValue();
			bool bFound = false;
			for (int j = 0; j < 5; j++) {
				int c2 = mWinningCards[j];
				if (c1 == c2) {
					bFound = true;
					break;
				}
			}

			if (bFound)
				translation += osg::Vec3f(0, mParamWinningCardsTranslation * mLabelAlpha, 0);
			else
				translation -= osg::Vec3f(0, mParamWinningCardsTranslation * mLabelAlpha, 0);
		}

		mCardsNode[i]->setMatrix( osg::Matrix::translate(translation * zoomCard) );
//		mCardsNode[i]->setMatrix( osg::Matrix::translate(translation) );

		//osg::Material *mat = mCards[i]
	}

	mCurrentTranslationFactor += dt * 4;
	if (mCurrentTranslationFactor > 1)
		mCurrentTranslationFactor = 1;

	if (mAllCardsGo) {
		for (i = 0; i < 5; i++) {

			osg::MatrixTransform *mt = mCardsNode[i].get();

			osg::Matrix mat;
			osg::Vec3f pp(0, 0, 0);

			if (mCounterAllCardsGo < 1) {
				pp = pp * mCounterAllCardsGo + mt->getMatrix().getTrans() * (1 - mCounterAllCardsGo);
				mat = osg::Matrix::scale( _lerp(1, 0.05, mCounterAllCardsGo), _lerp(1, 3, mCounterAllCardsGo), 1);
			}
			else {
				mat = osg::Matrix::scale( 0.05, _lerp(3, 0, mCounterAllCardsGo-1), 1);
			}

			mCardsNode[i]->setMatrix( osg::Matrix::translate(pp) * mat);
		}

		mCounterAllCardsGo += dt * 2;
		if (mCounterAllCardsGo > 2) {
			for (i = 0; i < 5; i++) {
				Slot &slot = mSlots[i];
					slot.state = -1;
					//slot.geode->setNodeMask(0);
					//mCards[i]->Fold();
			}
			//m_counterAllCardsGo = 0;
			mAllCardsGo = false;
			FoldCards();
		}
	}
	else {
		for (i = 0; i < 3; i++) {
			Slot &slot = mSlots[i];
			if (slot.state == -1)
				continue;

			if (slot.state == 0) {

				slot.rayState = 1;

				slot.matrix_factor += dt * 2;
				if (slot.matrix_factor > 1)
					slot.matrix_factor = 1;

				//osg::MatrixTransform *mt = mCardsNode[i].get();

				osg::Matrix mat;
				osg::Vec3f pp(0, 10, 0);

				if (slot.scale < 1) {
					mat = osg::Matrix::scale( 0.01, _lerp(0, 3, slot.scale), 1);
				}
				else {
					if (slot.scale > 2) {
						slot.scale = 2;
						slot.state = 1;

						if (i == 0 && mCallAgainSetCards) {
							mCallAgainSetCards = false;
							SetCards(mCardsValue);
						}
					}
					pp *= (2 - slot.scale);
					mat = osg::Matrix::scale( _lerp(0.01, 1, slot.scale - 1), _lerp(3, 1, slot.scale - 1), 1);
				}

				mat = mat * osg::Matrix::translate(pp);

				osg::Matrix mm = mCardsNode[i]->getMatrix();
				mCardsNode[i]->setMatrix(mm * mat);

				slot.scale += dt * 2 * 1.0f;
			}
		}
	}

	for (i = 3; i < 5; i++) {
		Slot &slot = mSlots[i];
		if (slot.state == -1)
			continue;

		osg::Matrix mt = slot.cpath->getMatrix();
		osg::Vec3f orgTrans = mt.getTrans();
		mt = osg::Matrix::scale(zoomCard, zoomCard, 1.0f);
		mt.setTrans(orgTrans);
		slot.cpath->setMatrix(mt);

		//slot.cpath_currentPos = 0.05f;
		osg::Matrix mat = osg::Matrix::translate(0, -slot.cpath_currentPos, 0);
		slot.cpath_texmat->setMatrix(mat);

		if (slot.state == 0) {
			slot.cpath_currentPos += dt * 4.5f;
			slot.rayState = 1;
			if (slot.cpath_currentPos > MAX_V - 1) {
				slot.cpath_currentPos = MAX_V - 1;
				slot.state = 1;
				mCards[i]->Receive();
				slot.geode_cpath->setNodeMask(0);
				if (i == 3 && mCallAgainSetCards) {
					mCallAgainSetCards = false;
					SetCards(mCardsValue);
				}
			}
		}
		else if (slot.state == 1) {
			slot.matrix_factor += dt * 2;
			if (slot.matrix_factor > 1.0f) {
				slot.matrix_factor = 1;
				slot.state = 2;
			}
		}
		else if (slot.state == 10) {
			slot.matrix_factor -= dt * 2;
			if (slot.matrix_factor < 0) {
				slot.state = 11;
				mCards[i]->Fold();
				slot.geode_cpath->setNodeMask(MAF_VISIBLE_MASK);
			}
		}
		else if (slot.state == 11) {
			slot.rayState = 0;
			slot.cpath_currentPos -= dt * 4;
			if (slot.cpath_currentPos < -1) {
				slot.cpath_currentPos = -1;
				slot.state = -1;
				slot.geode_cpath->setNodeMask(0);
			}
		}
	}

	osg::Vec3f camDirection = camera->GetPosition() - mBoardCenter->getMatrix().getTrans();
	camDirection[1] = 0; // lock in y orientation
	camDirection.normalize();

	osg::Vec3f samplePrevCamera;
	mSamples.GetSample(samplePrevCamera);
	samplePrevCamera.normalize();

	mSamples.Update(dt);
	mSamples.SetSample(camDirection);

	float angle;
	if (!mShowDownTime || mShowDownTime) {
		osg::Vec3f dir = samplePrevCamera;
		dir.normalize();

		osg::Matrix mat;
		osg::Vec3 side = osg::Vec3(0, 1, 0) ^ dir;
		mat.makeIdentity();
		mat(0,0) = side[0];
		mat(0,1) = side[1];
		mat(0,2) = side[2];
		mat(0,1) = 0;
		mat(1,1) = 1;
		mat(2,1) = 0;
		mat(2,0) = dir[0];
		mat(2,1) = dir[1];
		mat(2,2) = dir[2];
		mat.setTrans(mBoardCenter->getMatrix().getTrans());
		mBoardCenter->setMatrix(mat);

		osg::Vec3f dd = camera->GetTarget() - camera->GetPosition();
		dd.normalize();
		osg::Vec3f dd2 = dd;
		dd2[1] = 0;
		dd2.normalize();
		float dot = dd * dd2;
		if (dot < -1) dot = -1;
		if (dot > 1) dot = 1;
		angle = acos(dot); // azimuth angle

		dot = samplePrevCamera * camDirection;
		if (dot < -1) dot = -1;
		if (dot > 1) dot = 1;
		float h = -acos(dot);
		if (h > osg::PI)
			h = osg::PI;
		else if (h < -osg::PI)
			h = -osg::PI;

		osg::Vec3f tmp = osg::Vec3f(0, 1, 0) ^ samplePrevCamera;
		tmp.normalize();
		dot = tmp * camDirection;
		h *= dot < 0 ? -1 : 1;

		for (i = 0 ; i < 5; i++) {
			if (i > 2) {
				mCardsMatrix[i]->setMatrix( osg::Matrix::scale(zoomCard, zoomCard, 1.0f) * osg::Matrix::rotate(h, osg::Vec3(0, 1, 0)) * osg::Matrix::rotate(-angle * mSlots[i].matrix_factor, osg::Vec3(1, 0, 0)) );
			}
			else {
				mCardsMatrix[i]->setMatrix( osg::Matrix::scale(zoomCard, zoomCard, 1.0f) * osg::Matrix::rotate(h, osg::Vec3(0, 1, 0)) * osg::Matrix::rotate(-angle, osg::Vec3(1, 0, 0)) );
			}
		}
		//mTextAnchor->setMatrix( osg::Matrix::rotate(-angle, osg::Vec3(1, 0, 0) ) );
	}
	else {
		osg::Vec3f dir = camDirection;
		dir.normalize();

		osg::Matrix mat;
		osg::Vec3 side = osg::Vec3(0, 1, 0) ^ dir;
		mat.makeIdentity();
		mat(0,0) = side[0];
		mat(0,1) = side[1];
		mat(0,2) = side[2];
		mat(0,1) = 0;
		mat(1,1) = 1;
		mat(2,1) = 0;
		mat(2,0) = dir[0];
		mat(2,1) = dir[1];
		mat(2,2) = dir[2];
		mat.setTrans(mBoardCenter->getMatrix().getTrans());
		mBoardCenter->setMatrix(mat);

//		osg::Matrix mat;
//		mat.setTrans(mBoardCenter->getMatrix().getTrans());
//		mBoardCenter->setMatrix(mat);

		osg::Vec3f dd = camera->GetTarget() - camera->GetPosition();
		dd.normalize();
		osg::Vec3f dd2 = dd;
		dd2[1] = 0;
		dd2.normalize();
		float dot = dd * dd2;
		if (dot < -1) dot = -1;
		if (dot > 1) dot = 1;
		angle = acos(dot); // azimuth angle

		for (i = 0 ; i < 5; i++) {
			if (i > 2) {
				mCardsMatrix[i]->setMatrix( osg::Matrix::scale(zoomCard, zoomCard, 1.0f) * osg::Matrix::rotate(-angle * mSlots[i].matrix_factor, osg::Vec3(1, 0, 0)) );
			}
			else {
				mCardsMatrix[i]->setMatrix( osg::Matrix::scale(zoomCard, zoomCard, 1.0f) * osg::Matrix::rotate(-angle, osg::Vec3(1, 0, 0)) );
			}
		}
		//mTextAnchor->setMatrix( osg::Matrix::rotate(-angle, osg::Vec3(1, 0, 0) ) );
	}

	for (i = 0; i < 5; i++) {
		Slot &slot = mSlots[i];

		slot.textureAngle += dt;

		osg::Matrix texm;
		texm = osg::Matrix::translate(-0.5f, -0.5f, 0);
		texm = texm * osg::Matrix::rotate(slot.textureAngle*0.33f, osg::Vec3(0, 0, 1) );
		texm = texm * osg::Matrix::translate(0.5f, 0.5f, 0);
		//m_lightRayProjMat[i][0]->setMatrix(texm);

		texm = osg::Matrix::translate(-0.5f, -0.5f, 0);
		texm = texm * osg::Matrix::rotate(-slot.textureAngle*0.25f, osg::Vec3(0, 0, 1) );
		texm = texm * osg::Matrix::translate(0.5f, 0.5f, 0);
		//m_lightRayProjMat[i][1]->setMatrix(texm);

		float alpha = slot.alphaRay;

		osg::Material *mat = mLightRayMaterial[i];
		mat->setDiffuse( osg::Material::FRONT_AND_BACK, osg::Vec4f(mLightRayColor._v[0], mLightRayColor._v[1], mLightRayColor._v[2], alpha) );

		if (slot.rayState == 0) {
			slot.alphaRay -= dt * 2;
			if (slot.alphaRay < 0)
				slot.alphaRay = 0;
		}
		else if (slot.rayState == 1) {
			slot.alphaRay += dt * 2;
			if (slot.alphaRay > 1)
				slot.alphaRay = 1;
			}
	}

	if (mConeStatus == 1) {
		int nb;
		nb = g_lightcone_index_vertex_top.size();
		for (i = 0; i < nb; i++) {
			const osg::Vec3f &orgPt = mLightconeVertexTop_bak[i];
			int index = g_lightcone_index_vertex_top[i];
			osg::Vec3f pt;
			if (orgPt.x() < 0) pt.x() = -1.0f;
			else pt.x() = 1.0f;
			pt.y() = _lerp(0, orgPt.y()*6, mConeFactor);
			if (orgPt.z() < 0) pt.z() = -1.0f;
			else pt.z() = 1.0f;
			mLightconeVertex[index] = pt;
		}

		nb = g_lightcone_index_vertex_bottom.size();
		for (i = 0; i < nb; i++) {
			const osg::Vec3f &orgPt = mLightconeVertexBottom_bak[i];
			int index = g_lightcone_index_vertex_bottom[i];
			osg::Vec3f pt;
			if (orgPt.x() < 0) pt.x() = -1.0f;
			else pt.x() = 1.0f;
			pt.y() = _lerp(0, orgPt.y()*6, mConeFactor);
			if (orgPt.z() < 0) pt.z() = -1.0f;
			else pt.z() = 1.0f;
			mLightconeVertex[index] = pt;
		}

		mConeFactor += dt * 2.0f; // * 0.05f;
		if (mConeFactor > 1) {
			mConeFactor = 1;
			mConeStatus = 2;
		}
	}
	else if (mConeStatus == 2) {
		int nb;
		nb = g_lightcone_index_vertex_top.size();

		mConeFactor += dt * 2.0f; // * 0.4f;
		if (mConeFactor > 2) {
			mConeFactor = 2;
			mConeStatus = 3;
		}

		for (i = 0; i < nb; i++) {
			const osg::Vec3f &orgPt = mLightconeVertexTop_bak[i];
			int index = g_lightcone_index_vertex_top[i];
			osg::Vec3f pt;
			if (orgPt.x() < 0) pt.x() = -1.0f;
			else pt.x() = 1.0f;
			pt.x() = _lerp(pt.x(), orgPt.x(), mConeFactor - 1);

			pt.y() = _lerp(orgPt.y()*6, orgPt.y(), mConeFactor-1);

			if (orgPt.z() < 0) pt.z() = -1.0f;
			else pt.z() = 1.0f;
			pt.z() = _lerp(pt.z(), orgPt.z(), mConeFactor - 1);

//			pt.x() = orgPt.x();
//		pt.y() = orgPt.y();
//	pt.z() = orgPt.z();

			mLightconeVertex[index] = pt;
		}

		nb = g_lightcone_index_vertex_bottom.size();
		for (i = 0; i < nb; i++) {
			const osg::Vec3f &orgPt = mLightconeVertexBottom_bak[i];
			int index = g_lightcone_index_vertex_bottom[i];
			osg::Vec3f pt;
			if (orgPt.x() < 0) pt.x() = -1.0f;
			else pt.x() = 1.0f;
			pt.x() = _lerp(pt.x(), orgPt.x(), mConeFactor - 1);

			pt.y() = _lerp(orgPt.y()*6, orgPt.y(), mConeFactor-1);

			if (orgPt.z() < 0) pt.z() = -1.0f;
			else pt.z() = 1.0f;
			pt.z() = _lerp(pt.z(), orgPt.z(), mConeFactor - 1);

//			pt.x() = orgPt.x();
//		pt.y() = orgPt.y();
//	pt.z() = orgPt.z();

			mLightconeVertex[index] = pt;
		}
	}
	else if (mConeStatus == 10) {
		int nb;
		nb = g_lightcone_index_vertex_top.size();
		for (i = 0; i < nb; i++) {
			const osg::Vec3f &orgPt = mLightconeVertexTop_bak[i];
			int index = g_lightcone_index_vertex_top[i];
			osg::Vec3f pt;
			if (orgPt.x() < 0) pt.x() = -1.0f;
			else pt.x() = 1.0f;
			pt.x() = _lerp(orgPt.x(), pt.x(), mConeFactor);

			pt.y() = orgPt.y() * (mConeFactor*5+1);

			if (orgPt.z() < 0) pt.z() = -1.0f;
			else pt.z() = 1.0f;
			pt.z() = _lerp(orgPt.z(), pt.z(), mConeFactor);

			mLightconeVertex[index] = pt;
		}

		nb = g_lightcone_index_vertex_bottom.size();
		for (i = 0; i < nb; i++) {
			const osg::Vec3f &orgPt = mLightconeVertexBottom_bak[i];
			int index = g_lightcone_index_vertex_bottom[i];
			osg::Vec3f pt;
			if (orgPt.x() < 0) pt.x() = -1.0f;
			else pt.x() = 1.0f;
			pt.x() = _lerp(pt.x(), orgPt.x(), mConeFactor);

			pt.y() = orgPt.y() * (mConeFactor*5+1);

			if (orgPt.z() < 0) pt.z() = -1.0f;
			else pt.z() = 1.0f;
			pt.z() = _lerp(pt.z(), orgPt.z(), mConeFactor);

			mLightconeVertex[index] = pt;
		}

		mConeFactor += dt * 2.0f; // * 0.4f;
		if (mConeFactor > 1) {
			mConeFactor = 1;
			mConeStatus = 11;
		}
	}
	else if (mConeStatus == 11) {

		mConeFactor += dt * 2.0f; // * 0.4f;
		if (mConeFactor > 2) {
			mConeFactor = 2;
			mConeStatus = 0;
			mLightCone->setNodeMask(0);
		}

		int nb;
		nb = g_lightcone_index_vertex_top.size();
		for (i = 0; i < nb; i++) {
			const osg::Vec3f &orgPt = mLightconeVertexTop_bak[i];
			int index = g_lightcone_index_vertex_top[i];
			osg::Vec3f pt;
			if (orgPt.x() < 0) pt.x() = -1.0f;
			else pt.x() = 1.0f;

			pt.y() = _lerp(orgPt.y()*6, 0, mConeFactor-1);

			if (orgPt.z() < 0) pt.z() = -1.0f;
			else pt.z() = 1.0f;

			mLightconeVertex[index] = pt;
		}

		nb = g_lightcone_index_vertex_bottom.size();
		for (i = 0; i < nb; i++) {
			const osg::Vec3f &orgPt = mLightconeVertexBottom_bak[i];
			int index = g_lightcone_index_vertex_bottom[i];
 			osg::Vec3f pt;
			if (orgPt.x() < 0) pt.x() = -1.0f;
			else pt.x() = 1.0f;

			pt.y() = _lerp(orgPt.y()*6, 0, mConeFactor-1);

			if (orgPt.z() < 0) pt.z() = -1.0f;
			else pt.z() = 1.0f;

			mLightconeVertex[index] = pt;
		}
	}

	{
		osg::Vec3f to = camera->GetPosition() - camera->GetTarget();
		to.normalize();
		//float alpha = 1 - to._v[1];
		//m_lightConeMaterial->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(1, 1, 1, alpha) );
		mLightConeMaterial->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(1, 1, 1, 1) );
	}

	//float fadeInValue = 0;

	if (mShowDownTime) {
		mLabelAlpha += dt * mParamFadeInDuration;
		if (mLabelAlpha > 1)
			mLabelAlpha = 1;

		osg::Matrix mat = osg::Matrix::scale(zoomCard, zoomCard, 1) * osg::Matrix::translate(0, (mParamYoffsetForText + mLabelAlpha*mParamTextYTranslate) * zoomCard, 0); 
		mTextAnchor->setMatrix(mat);
	}

	SetTextColor(osg::Vec4(1, 1, 1, mLabelAlpha));

	return true;
}

void PokerBoardController::FoldCards()
{
	for(unsigned int i = 0; i < mCards.size(); i++)
		mCards[i]->Fold();
	StopToDisplayShowDown();
}

void PokerBoardController::MakeCardArrive(int _slot, int _iCard)
{
	Slot &slot = mSlots[_slot];
	slot.state = 0;
	slot.matrix_factor = 0;
	slot.cpath_currentPos = -1;
	slot.alphaRay = 0;
	slot.scale = 0;

	mSourceTranslation = mDestinationTranslation;
	mDestinationTranslation = mOrgCardsTranslation[_slot];
	mDestinationTranslation._v[0] = mOrgCardsTranslation[0]._v[0] + (mOrgCardsTranslation[_slot]._v[0] - mOrgCardsTranslation[0]._v[0])/2;
	mCurrentTranslationFactor = 0;

	if (_slot < 3) {
		mCards[_slot]->Receive();
	}
	else {
		mCards[_slot]->Fold();

		osg::Drawable *drawable = slot.geode_cpath->getDrawable(0);
		osg::Texture2D *texture = (osg::Texture2D*) drawable->getOrCreateStateSet()->getTextureAttribute(0, osg::StateAttribute::TEXTURE);

		slot.geode_cpath->setNodeMask(MAF_VISIBLE_MASK);

		texture = mGame->mDeck->GetImage(_iCard);
		texture->setBorderColor( osg::Vec4f(0, 0, 0, 0) );
		texture->setWrap(osg::Texture::WRAP_S, osg::Texture::CLAMP_TO_BORDER);
		texture->setWrap(osg::Texture::WRAP_T, osg::Texture::CLAMP_TO_BORDER);
		drawable->getOrCreateStateSet()->setTextureAttribute(0, texture);
	}
}

void PokerBoardController::MakeConeArrive()
{
	mConeStatus = 1;
	mConeFactor = 0;
	mLightCone->setNodeMask(MAF_VISIBLE_MASK);
//	m_bAllCardsGo = false;

	if (mSoundOpen.valid())
		mSoundOpen->Play();
}

 void PokerBoardController::MakeConeGo()
 {
 //	if (m_coneStatus != 3)
 //		return;
 
 mConeStatus = 10;
 mConeFactor = 0;
 
 //makeAllCardsGo();
 //	for (int i = 0; i < 5; i++)
 //		g_projectorCard->makeCardGo(i);
 
	if (mSoundClose.valid())
		mSoundClose->Play();
}

void PokerBoardController::MakeCardNikel(int i)
{
	Slot &slot = mSlots[i];
	mCards[i]->Receive();
	if (slot.geode_cpath)
		slot.geode_cpath->setNodeMask(0);
	slot.state = -1;
	slot.scale = 1;
	slot.alphaRay = 1;
	slot.rayState = -1;
	slot.matrix_factor = 1;
}

void PokerBoardController::MakeAllCardsGo()
{
	mAllCardsGo = true;
	mCounterAllCardsGo = 0;
	for (int i = 0; i < 5; i++) {
		Slot &slot = mSlots[i];
		slot.rayState = 0;
		slot.matrix_factor = 1;
		mPreviousCardsValue[i] = -999; // safety impossible to have first value
	}
}

bool PokerBoardController::StartToDisplayShowDown(PokerPlayer *_player)
{
	mTextAnchor->setNodeMask(MAF_VISIBLE_MASK);
	SetTextColor(osg::Vec4(1,1,1,0));

	mShowDownTime = true;
	mLabelAlpha = 0.0f;

//	mBillBoard->setActive(true);

	return true;
}

bool PokerBoardController::StopToDisplayShowDown()
{
	mTextAnchor->setNodeMask(0);  
	mLabelAlpha = 0.0f;
	mShowDownTime = false;

	mBillBoard->setActive(false);

	return true;
}

#if OSG_VERSION_MAJOR != 2
void PokerBoardController::LightRayGeometry::drawImplementation(osg::State &arg) const
#else // OSG_VERSION_MAJOR != 2
void PokerBoardController::LightRayGeometry::drawImplementation(osg::RenderInfo &arg) const
#endif  // OSG_VERSION_MAJOR != 2
{
  NPROFILE_SAMPLE("PokerBoardController::drawImplementation");
	int iCard = mRayIndex;

	osg::Geometry *geom = (osg::Geometry*) this;
	osg::Array *arr = geom->getVertexArray();
	osg::Vec3f *data = (osg::Vec3f*) arr->getDataPointer();

//	osg::MatrixTransform *mt = g_projectorCard->mTransformCards[iCard].get();
	osg::Node *mt = mProjectorCard->mCards[iCard].get()->GetModel()->GetNode();
	osg::Matrix cm = MAFComputeLocalToWorld(mt);

	osg::Vec3f raybase = mProjectorCard->mRayBase;
	osg::Matrix inv = mProjectorCard->mRayBaseInv;

	osg::Vec2f pt0, pt1, pt2, pt3;
	osg::Geode *geode = GetGeode(mt);
	if (geode) {
		const osg::BoundingBox &bbox = geode->getBoundingBox();
		pt0 = osg::Vec2f(bbox._min._v[0], bbox._max._v[1]);
		pt1 = osg::Vec2f(bbox._max._v[0], bbox._max._v[1]);
		pt2 = osg::Vec2f(bbox._max._v[0], bbox._min._v[1]);
		pt3 = osg::Vec2f(bbox._min._v[0], bbox._min._v[1]);
	}

	osg::Vec3f vcard_topleft = osg::Vec3f(pt0._v[0], pt0._v[1], -0) * cm - raybase;
	osg::Vec3f vcard_topright = osg::Vec3f(pt1._v[0], pt1._v[1], -0) * cm - raybase;
	osg::Vec3f vcard_bottomright = osg::Vec3f(pt2._v[0], pt2._v[1], -0) * cm - raybase;
	osg::Vec3f vcard_bottomleft = osg::Vec3f(pt3._v[0], pt3._v[1], -0) * cm - raybase;

	osg::Vec3f card_topleft = (vcard_topleft * 1.0f + raybase) * inv;
	osg::Vec3f card_topright = (vcard_topright * 1.0f + raybase) * inv;
	osg::Vec3f card_bottomright = (vcard_bottomright * 1.0f + raybase) * inv;
	osg::Vec3f card_bottomleft = (vcard_bottomleft * 1.0f + raybase) * inv;

	// top left
	{
		std::vector<int> &vec = g_ray_index_topleft;
		int nb = vec.size();
		for (int i = 0; i < nb; i++) {
			int ii = vec[i];
			osg::Vec3f *p = &data[ii];
			*p = card_bottomleft;
		}
	}

	// top right
	{
		std::vector<int> &vec = g_ray_index_topright;
		int nb = vec.size();
		for (int i = 0; i < nb; i++) {
			int ii = vec[i];
			osg::Vec3f *p = &data[ii];
			*p = card_bottomright;
		}
	}

	// bottom right
	{
		std::vector<int> &vec = g_ray_index_bottomright;
		int nb = vec.size();
		for (int i = 0; i < nb; i++) {
			int ii = vec[i];
			osg::Vec3f *p = &data[ii];
			*p = card_topright;
		}
	}

	// bottom left
	{
		std::vector<int> &vec = g_ray_index_bottomleft;
		int nb = vec.size();
		for (int i = 0; i < nb; i++) {
			int ii = vec[i];
			osg::Vec3f *p = &data[ii];
			*p = card_topleft;
		}
	}

	Geometry::drawImplementation(arg);
}

osg::BoundingBox PokerBoardController::LightRayGeometry::computeBound()
{
	return osg::BoundingBox( osg::Vec3f(-50000, -50000, -50000), osg::Vec3f(50000, 50000, 50000) );
}
