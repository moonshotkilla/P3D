/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#include "pokerStdAfx.h"

#ifndef POKER_USE_VS_PCH
#include <osg/Group>
#include <osgUtil/SceneView>
#include <osg/MatrixTransform>
#include <osg/Image>
#include <osg/Texture2D>
#include <osg/TexEnvCombine>
#include <osg/BlendFunc>

#include <maf/depthmask.h>
#include <maf/pbuffer.h>
#include <maf/timer.h>
#include <maf/vision.h>
#include <maf/glow_fx.h>
#include <maf/assert.h>
#include <maf/renderbin.h>

#include <varseditor/varseditor.h>

#include <osgCal/CoreModel>
#include <osgCal/SubMeshHardware>
#include <osgCal/SubMeshSoftware>

#include "PokerApplication.h"
#include "PokerSceneView.h"
#include "PokerBody.h"
#endif

#include "maf/window.h"
#include "maf/utils.h"

#include <osg/Image>
#include <osg/Texture2D>
#include <osg/MatrixTransform>
#include <osg/Geode>
#include <osg/TexEnvCombine>

#include "PokerSceneView.h"
#include "PokerPlayer.h"

#ifndef SAFE_DELETE
#define SAFE_DELETE(a) if (a) { delete a; a = NULL; }
#endif

// standard constant to convert a color to gray
const float R_SCALE = 0.299f;
const float G_SCALE = 0.587f;
const float B_SCALE = 0.114f;

const float PANEL_WIDTH = 267.0f / 1024.0f;

#define PINK_COLOR osg::Vec4f(1.0f, 0.58f, 0.58f, 0.5f)

static int g_mx;
static int g_my;

// final image is obtained as follow:
// RGB = R*R_SCALE + G*G_SCALE + B*B_SCALE

static PokerSceneView *g_instance = NULL;

PokerSceneView* PokerSceneView::getInstance()
{
	return g_instance;
}

PokerSceneView::PokerSceneView(PokerApplication *_game, int _grayTextureSize)
{
	if (g_instance)
		g_error("Only one instance of PokerSceneView allowed. Review your code!");

	g_instance = this;

	m_colorMask = NULL;
	m_bActivated = false;
	m_grayTexture = NULL;
	m_grayTextureWidth = _grayTextureSize;
	m_grayTextureHeight = _grayTextureSize;
	m_game = _game;
	m_button = NULL;
	m_bSetuped = false;
	m_bButtonAvailable = false;
	m_panelProjo = NULL;

	m_topQuad = NULL;
	m_middleQuad = NULL;
	m_lowQuad = NULL;
	m_alphaPanel = 0;

	m_bDescriptionLocked = false;

	m_dummyDrawCallback = NULL;

	m_glowCounter = 0;

	m_currentFocus = -1;

	m_TLFGroup = new osg::Group();
	m_TLFState = new osg::State();

	m_dataPath = m_game->HeaderGet("settings", "/settings/data/@path");
}

PokerSceneView::~PokerSceneView()
{
}

void PokerSceneView::Init()
{
	Parent::Init();

	m_pbuffer = new MAFPBuffer(m_grayTextureWidth, m_grayTextureHeight);
	if (m_pbuffer->_create() == true) {
		m_grayTextureWidth = m_pbuffer->getWidth();
		m_grayTextureHeight = m_pbuffer->getHeight();

	}
	else {
		// pbuffer not available

		m_grayTextureWidth = 512;
		m_grayTextureHeight = 512;

		m_pbuffer = NULL;
	}

  MAFGlowFX::init(256, true, m_pbuffer.get() );
	//MAFGlowFX::init(256, true, NULL, 512);
}

void PokerSceneView::uninit()
{
	m_game->RemoveController(m_mouseController.get());
	m_mouseController = NULL;

	MAFGlowFX::uninit();

	//osg::Group *HUDgroup = _parent->GetModel()->mHUDGroup.get();
	//		HUDgroup->addChild(m_button->getGeode());
	//Anchor(NULL);
}

void PokerSceneView::setup()
{
	osgUtil::SceneView *scene = GetModel()->mScene.get();
	osg::Group *root = (osg::Group*) scene->getSceneData();

	m_TLFState = new osg::State();

	m_grayTexture = new osg::Texture2D();
	m_grayTexture->setInternalFormat(GL_RGB);
	m_grayTexture->setFilter(osg::Texture::MIN_FILTER, osg::Texture::LINEAR);
	m_grayTexture->setFilter(osg::Texture::MAG_FILTER, osg::Texture::LINEAR);

//	if (m_grayTextureHeight < 1024 || m_grayTextureHeight < 1024)
	//	m_grayTexture->setFilter(osg::Texture::MAG_FILTER, osg::Texture::LINEAR);

	m_grayTexture->setTextureSize(m_grayTextureWidth, m_grayTextureHeight);
	m_grayTexture->copyTexImage2D(*scene->getState(), 0, 0, m_grayTextureWidth, m_grayTextureHeight);

	{
		int *pixs = new int[1];
		*pixs = 0x7f7f7f7f;
		osg::Image *img = new osg::Image();
		img->setImage(1, 1, 1, 3, GL_RGB, GL_UNSIGNED_BYTE, (unsigned char* )pixs, osg::Image::USE_NEW_DELETE);
		m_gtex = new osg::Texture2D();
		m_gtex->setImage(img);

		m_gtex->setFilter(osg::Texture::MIN_FILTER, osg::Texture::NEAREST);
		m_gtex->setFilter(osg::Texture::MAG_FILTER, osg::Texture::NEAREST);
	}

	osg::MatrixTransform* modelview_abs = new osg::MatrixTransform;
	modelview_abs->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
	modelview_abs->setMatrix(osg::Matrix::identity());
	m_grayQuad = modelview_abs;
	m_grayQuad->setNodeMask(0);
	root->addChild(modelview_abs);

	m_colorMask = new osg::ColorMask();
	m_colorMask->setMask(true, true, true, true);
	root->getOrCreateStateSet()->setAttributeAndModes(m_colorMask.get());

	osg::Projection *projection = new osg::Projection;
	osg::Matrix projMat = osg::Matrix::identity();
	projection->setMatrix( projMat );
	modelview_abs->addChild(projection);

	projection->getOrCreateStateSet()->setAttributeAndModes(new DepthMask(false));
	projection->getOrCreateStateSet()->setAttributeAndModes(new osg::ColorMask(true, true, true, true));
	projection->getOrCreateStateSet()->setMode(GL_DEPTH_TEST, FALSE);
//	{
//		int rbvalue;
	//	if (!VarsEditor::Instance().Get("RB_PokerSceneViewBlackNWhite",rbvalue))
		//	MAF_ASSERT(0 && "RB_PokerSceneViewBlackNWhite not found in client.xml");
		//projection->getOrCreateStateSet()->setRenderBinDetails(rbvalue, "RenderBin");
	//}
	if (!MAFRenderBin::Instance().SetupRenderBin("PokerSceneViewBlackNWhite", projection->getOrCreateStateSet()) )
		MAF_ASSERT(0 && "RB_PokerSceneViewBlackNWhite not found in client.xml");

	osg::Geode *geode = new osg::Geode();
	osg::Geometry *geom = new osg::Geometry();
	geode->addDrawable(geom);
	projection->addChild(geode);

	osg::Vec3Array *array = new osg::Vec3Array();
	array->resize(4);
	geom->setVertexArray(array);

	array[0][0] = osg::Vec3f(-1, -1, 0);
	array[0][1] = osg::Vec3f(1, -1, 0);
	array[0][2] = osg::Vec3f(1, 1, 0);
	array[0][3] = osg::Vec3f(-1, 1, 0);

	osg::Vec2Array *uv = new osg::Vec2Array();
	uv->push_back( osg::Vec2f(0, 0) );
	uv->push_back( osg::Vec2f(1, 0) );
	uv->push_back( osg::Vec2f(1, 1) );
	uv->push_back( osg::Vec2f(0, 1) );

	geom->setTexCoordArray(0, uv);

	GLushort *index = new GLushort[6];
	index[0] = 0;
	index[1] = 1;
	index[2] = 2;
	index[3] = 0;
	index[4] = 2;
	index[5] = 3;

	geom->addPrimitiveSet(new osg::DrawElementsUShort(osg::PrimitiveSet::TRIANGLES, 6, index));
	geom->setUseDisplayList(false);
	geom->setUseVertexBufferObjects(false);

	osg::StateSet *ss = geom->getOrCreateStateSet();
	ss->setTextureAttributeAndModes(0, m_grayTexture.get(), osg::StateAttribute::ON);
	ss->setTextureAttributeAndModes(1, m_grayTexture.get(), osg::StateAttribute::ON);

	osg::TexEnvCombine *combiner;

	combiner = new osg::TexEnvCombine();
	combiner->setCombine_RGB(GL_INTERPOLATE_ARB);

	combiner->setSource0_RGB(GL_TEXTURE);
	combiner->setSource0_Alpha(GL_TEXTURE);
	combiner->setOperand0_RGB(GL_SRC_COLOR);
	combiner->setOperand0_Alpha(GL_SRC_ALPHA);

	combiner->setSource1_RGB(GL_CONSTANT_ARB);
	combiner->setSource1_Alpha(GL_CONSTANT_ARB);
	combiner->setOperand1_RGB(GL_SRC_COLOR);
	combiner->setOperand1_Alpha(GL_SRC_ALPHA);

	combiner->setSource2_RGB(GL_CONSTANT_ARB);
	combiner->setSource2_Alpha(GL_CONSTANT_ARB);
	combiner->setOperand2_RGB(GL_SRC_ALPHA);
	combiner->setOperand2_Alpha(GL_SRC_ALPHA);

	combiner->setConstantColor( osg::Vec4f(1.0f, 1.0f, 1.0f, 0.5f) );

	ss->setTextureAttributeAndModes(0, combiner, osg::StateAttribute::ON);

	combiner = new osg::TexEnvCombine();
	combiner->setCombine_RGB(GL_DOT3_RGB_ARB);

	combiner->setSource0_RGB(GL_PREVIOUS_ARB);
	combiner->setSource0_Alpha(GL_PREVIOUS_ARB);
	combiner->setOperand0_RGB(GL_SRC_COLOR);
	combiner->setOperand0_Alpha(GL_SRC_ALPHA);

	combiner->setSource1_RGB(GL_CONSTANT_ARB);
	combiner->setSource1_Alpha(GL_CONSTANT_ARB);
	combiner->setOperand1_RGB(GL_SRC_COLOR);
	combiner->setOperand1_Alpha(GL_SRC_ALPHA);

	combiner->setConstantColorAsLightDirection( osg::Vec3f(R_SCALE, G_SCALE, B_SCALE) );

	ss->setTextureAttributeAndModes(1, combiner, osg::StateAttribute::ON);

	std::string	path = m_game->HeaderGet("settings", "/settings/data/@path");

	{
		osg::MatrixTransform* modelview_abs = new osg::MatrixTransform;
		modelview_abs->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
		modelview_abs->setNodeMask(MAF_VISIBLE_MASK);
//		{
	//		int rbvalue;
		//	if (!VarsEditor::Instance().Get("RB_PokerSceneViewUIHelp",rbvalue))
			//	MAF_ASSERT(0 && "RB_PokerSceneViewUIHelp not found in client.xml");
//			modelview_abs->getOrCreateStateSet()->setRenderBinDetails(rbvalue, "RenderBin");
	//	}
		if (!MAFRenderBin::Instance().SetupRenderBin("PokerSceneViewUIHelp", modelview_abs->getOrCreateStateSet()))
			MAF_ASSERT(0 && "PokerSceneViewUIHelp not found in client.xml");

		//modelview_abs->setMatrix( osg::Matrix::translate(1, 0, 0) );
		m_panelMatrix = modelview_abs;

		m_panelProjo = new osg::Projection;

		m_panelProjo->getOrCreateStateSet()->setAttributeAndModes( new DepthMask(false) );
		m_panelProjo->getOrCreateStateSet()->setMode(GL_DEPTH_TEST, FALSE);
		m_panelProjo->getOrCreateStateSet()->setAttributeAndModes( new osg::ColorMask() );

		osg::Matrix projMat = osg::Matrix::identity();
		projMat(2, 2) = 0.00000f; // z is always 0
		projection->setMatrix( projMat );

		root->addChild(modelview_abs);
		modelview_abs->addChild(m_panelProjo.get());

		float vmin = 1.0f / 20.0f;
		float vmax = 19.0f / 20.0f;
		m_topQuad = new MAF_OSGQuad(path + "/uihelp_top.tga", true, osg::Vec2f(0, vmin), osg::Vec2f(1, vmax), osg::Vec2f(0, vmin), osg::Vec2f(1, vmax) );
		m_middleQuad = new MAF_OSGQuad(path + "/uihelp_middle.tga");
		m_lowQuad = new MAF_OSGQuad(path + "/uihelp_low.tga", true, osg::Vec2f(0, vmin), osg::Vec2f(1, vmax), osg::Vec2f(0, vmin), osg::Vec2f(1, vmax));

		m_panelProjo->addChild(m_topQuad->getGeode());
		m_panelProjo->addChild(m_middleQuad->getGeode());
		m_panelProjo->addChild(m_lowQuad->getGeode());

		float xx = PANEL_WIDTH;

		osg::Vec3Array *arr;

		arr = m_topQuad->getVerticesArray();
		arr[0][0][0] = -xx;
		arr[0][1][0] = xx;
		arr[0][2][0] = xx;
		arr[0][3][0] = -xx;

		arr = m_middleQuad->getVerticesArray();
		arr[0][0][0] = -xx;
		arr[0][1][0] = xx;
		arr[0][2][0] = xx;
		arr[0][3][0] = -xx;

		arr = m_lowQuad->getVerticesArray();
		arr[0][0][0] = -xx;
		arr[0][1][0] = xx;
		arr[0][2][0] = xx;
		arr[0][3][0] = -xx;
	
    //		Sleep(5000);
		m_font = MAFLoadFont(path + "/FreeSans.ttf");

		m_fontMatrix = new osg::MatrixTransform();
		m_fontMatrix->setMatrix( osg::Matrix::scale(0.003f, 0.003f, 0) );
		m_panelProjo->addChild(m_fontMatrix.get());
		m_panelProjo->setNodeMask(0);

		m_text = new UGAMEBasicText("", m_font.get());
		m_text->getText()->setCharacterSize(12);
		m_text->getText()->setAlignment( osgText::Text::CENTER_CENTER );
		m_text->getOrCreateStateSet()->setAttributeAndModes(new osg::BlendFunc(osg::BlendFunc::SRC_ALPHA, osg::BlendFunc::ONE_MINUS_SRC_ALPHA), osg::StateAttribute::ON);

		m_fontMatrix->addChild(m_text.get());

		std::list<std::string> urls = m_game->HeaderGetList("sequence", "/sequence/uihelp/description/@name");
		std::list<std::string>::const_iterator it = urls.begin();
		while (it != urls.end() ) {
			const std::string &name = (*it);

			char str[200];
			sprintf(str, "/sequence/uihelp/description[@name=\"%s\"]", name.c_str() );
			std::list<std::string> desc = m_game->HeaderGetList("sequence", str);

			std::string &dc = desc.front();
			char *token = strtok( (char*) dc.c_str(), "\n");
			while (token) {
				m_desc[name].push_back(token);
				token = strtok(NULL, "\n");
			}
			++it;
		}

	}

	//Sleep(5000);

	{
		std::map<std::string,std::string> properties = m_game->HeaderGetProperties("sequence", "/sequence/uihelp/button_help");
		if (properties.empty())
			g_assert(0 && "/sequence/uihelp/button_help is missed in client.xml");
		mDelta_x = atoi(properties["x"].c_str());
		mDelta_y = atoi(properties["y"].c_str());
		mWidth = atoi(properties["width"].c_str());
		mHeight = atoi(properties["height"].c_str());

		int screenW = m_game->GetWindow(true)->GetWidth();
		int screenH = m_game->GetWindow(true)->GetHeight();

		MAF_OSGQuad::setScreenResolution(screenW, screenH);

		m_button = new MAF_OSGQuad(path + "/uihelp_button_norm.tga", false);
//		m_button->setVertexInWindowCoordinates(screenW-64, screenH-64, 0);
	//	m_button->setVertexInWindowCoordinates(screenW, screenH-64, 1);
		//m_button->setVertexInWindowCoordinates(screenW, screenH, 2);
		//m_button->setVertexInWindowCoordinates(screenW-64, screenH, 3);


// 		m_button->setVertexInNormalisedCoordinates(screenW-64, 64, 0);
// 		m_button->setVertexInNormalisedCoordinates(screenW, 64, 1);
// 		m_button->setVertexInNormalisedCoordinates(screenW, 0, 2);
// 		m_button->setVertexInNormalisedCoordinates(screenW-64, 0, 3);

		
		m_button->setVertexInNormalisedCoordinates(screenW - mWidth + mDelta_x, mHeight + mDelta_y, 3);
		m_button->setVertexInNormalisedCoordinates(screenW + mDelta_x, mHeight + mDelta_y, 2);
		m_button->setVertexInNormalisedCoordinates(screenW + mDelta_x, 0 + mDelta_y, 1);
		m_button->setVertexInNormalisedCoordinates(screenW - mWidth + mDelta_x, 0 + mDelta_y, 0);

		//m_button->getGeode()->setNodeMask(MAF_VISIBLE_MASK | MAF_COLLISION_MASK);

		/*
		osg::MatrixTransform* modelview_abs = new osg::MatrixTransform;
		modelview_abs->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
		modelview_abs->setMatrix(osg::Matrix::identity());
		osg::Projection *projection = new osg::Projection;
		osg::Matrix projMat = osg::Matrix::identity();
		projection->setMatrix( projMat );
		modelview_abs->addChild(projection);
		projection->addChild(m_button->geode_);
		m_game->mSetData->GetGroup()->addChild(modelview_abs);
		*/
	}

	//m_FXState->setContextID(1);

	m_mouseController = new PokerUIMouseController(this);

	m_dummyDrawCallback = new PokerUIDummyDrawCallback();

	m_bSetuped = true;
}

void PokerSceneView::Update(MAFWindow *_win)
{
	int i;

	int win_w = _win->GetWidth();
	int win_h = _win->GetHeight();
	float dt = m_game->GetDeltaFrame() / 1000.0f;
	osgUtil::SceneView* scene = GetModel()->mScene.get();

	float alpha;
	//alpha = sin(g_opa * 3.0f) * 0.5f + 0.5f;
	//alpha = alpha * 0.75f + 0.25f;

	if (m_glowCounter < 0.1f)
		alpha = (m_glowCounter / 0.1f)*0.75f + 0.25f;
	else if (m_glowCounter < 0.5f)
		alpha = 1 - ((m_glowCounter-0.1f) / 0.4f)*0.75f;
	else if (m_glowCounter < 0.6f)
		alpha = ((m_glowCounter-0.5f) / 0.1f)*0.75f + 0.25f;
	else if (m_glowCounter < 1.0f)
		alpha = 1 - ((m_glowCounter-0.6f) / 0.4f)*0.75f;
	else
		alpha = 0.25f; //1 - (m_glowCounter - 0.5f) / 2.0f;

	MAFGlowFX::setGlowTextureOpacity(alpha);

	m_glowCounter += dt;
	if (m_glowCounter > 2.0f)
		m_glowCounter -= 2.0f;

	if (m_bSetuped) {

		if (m_bButtonAvailable) {
			MAF_OR_NODEMASK(m_button->getGeode(), MAF_VISIBLE_MASK | MAF_COLLISION_MASK);
		}
		else {
			MAF_REMOVE_NODEMASK(m_button->getGeode(), MAF_VISIBLE_MASK | MAF_COLLISION_MASK);
		}

		std::string textureName = "uihelp_button_norm.tga";
		int m_x = m_game->getMouseX();
		int m_y = m_game->getMouseY();

		int focusIWant = -1;

		// ugly should use picking instead
// 		if (m_x > (win_w-64) && m_x < win_w &&
// 			m_y > (win_h-64) && m_y < win_h) {
		if (m_x > (win_w-mWidth+mDelta_x) && m_x < (win_w+mDelta_x) && 
				m_y > (win_h-mHeight+mDelta_y) && m_y < (win_h+mDelta_y)) {

			if (!m_bActivated)
				textureName = "uihelp_button_over.tga";

			focusIWant = 0;
		}

		if (focusIWant != m_currentFocus) {
			if (m_mouseController->bLMB_ != true)
				m_currentFocus = focusIWant;
		}

		if (m_currentFocus == 0) {

			if (m_mouseController->bLMB_) {
				m_mouseController->bLMB_ = false;
				if (m_bActivated)
					setActivated(false);
				else
					setActivated(true);
			}
		}

		if (m_bActivated)
			textureName = "uihelp_button_pushed.tga";

		osg::ref_ptr<osgDB::ReaderWriter::Options> opts = new osgDB::ReaderWriter::Options();
		opts->setObjectCacheHint(osgDB::ReaderWriter::Options::CACHE_ALL);
		osg::Texture2D *texture = MAFApplication::GetTextureManager()->GetTexture2D(m_dataPath + G_DIR_SEPARATOR_S + textureName, opts.get());
		m_button->getGeometry()->getOrCreateStateSet()->setTextureAttributeAndModes(0, texture);
	}

	if (MAFApplication::mbVisible) {
		if (MAFGlowFX::getPBuffer()) {
			osg::ref_ptr<osg::State> oldState = scene->getState();
			osg::ref_ptr<osg::Node> oldSceneData = scene->getSceneData();

			scene->setState( m_TLFState.get() );
			scene->setSceneData( m_TLFGroup.get() );

			scene->update();
			scene->cull();
			scene->setDrawBufferValue(GL_FRONT);

			MAFGlowFX::getPBuffer()->use();
			scene->draw();
			MAFGlowFX::getPBuffer()->release();

			scene->setState(oldState.get());
			scene->setSceneData(oldSceneData.get());
			scene->setDrawBufferValue(GL_BACK);
		}
		else {
			osg::ref_ptr<osg::Node> oldSceneData = scene->getSceneData();
			scene->setSceneData( m_TLFGroup.get() );
			scene->update();
			scene->cull();
			scene->draw();
			scene->setSceneData(oldSceneData.get());
		}
	}

	if (!m_bActivated || !GetModel()->mCamera.valid()) {
		// normal Update() as previously...

		if (m_grayQuad.valid())
			m_grayQuad->setNodeMask(0);

		if (m_colorMask.get())
			m_colorMask->setMask(true, true, true, true);

		if (m_panelProjo.get())
			m_panelProjo->setNodeMask(0);

		Parent::Update(_win);

		return;
	}

	PokerModel *pokerModel = m_game->GetPoker()->GetModel();
	if (!pokerModel)
		return;

	g_mx = m_game->getMouseX();
	g_my = m_game->getMouseY();

	if (m_grayQuad.valid())
		m_grayQuad->setNodeMask( MAF_VISIBLE_MASK );

	guint playerID = pokerModel->mMe;
	PokerPlayer *player = NULL;
	if (pokerModel->mSerial2Player.find( playerID ) != pokerModel->mSerial2Player.end())
		player = pokerModel->mSerial2Player[ playerID ].get();

	if (!m_bDescriptionLocked) {
		UGAMEArtefactController *focus  = dynamic_cast<UGAMEArtefactController*> (m_game->GetFocus());
		if (!focus)
			setCurrentSelectionedItem("", false, NULL);
		else {
			const std::string &controllerName = focus->GetControllerName();
			if (controllerName == "PokerBodyController") {
				PokerBodyController *body = (PokerBodyController*) focus;
				std::string narrow_focus = body->GetFocus();

				if (!player || ( player->GetNbCardsDisplayed() == 0 && (narrow_focus == "__cardzone" || narrow_focus == "__cardzone2")) || body != player->GetBody() )
					setCurrentSelectionedItem("", false, NULL);
				else {

					if (m_game->GetPoker()->GetModel()->mSeatManager->GetMainPlayerStatus() == PokerSeatManager::MAINPLAYER_SEAT_OUT && (narrow_focus == "__chair" || narrow_focus == "__chairFront") )
						narrow_focus += "_seatUp";

					setCurrentSelectionedItem(narrow_focus, false, body);
				}

				//setCurrentSelectionedItem("", false, -1);
				char str[200];
				sprintf(str, "Narrow focus is %s\n", narrow_focus.c_str());
				//OutputDebugStr(str);
			}
			else if (controllerName == "PokerChipsStackController") {
				PokerChipsStackController *stack = (PokerChipsStackController*) focus;
				if (player && player->mBetStack.get() == stack)
					setCurrentSelectionedItem(controllerName, false, stack);
				else
					setCurrentSelectionedItem("", false, NULL);
			}
			else if (controllerName == "PokerSeatController") {
//				if (m_game->GetPoker()->GetModel()->mSeatManager->GetMainPlayerStatus() == PokerSeatManager::MAINPLAYER_OUT)
					setCurrentSelectionedItem(controllerName, false, focus);
	//			else
		//			setCurrentSelectionedItem("", false, -1);
			}
			else
				setCurrentSelectionedItem(controllerName, false, focus);
		}
	}

	m_topQuad->getMaterial()->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(1, 1, 1, m_alphaPanel) );
	m_middleQuad->getMaterial()->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(1, 1, 1, m_alphaPanel) );
	m_lowQuad->getMaterial()->setDiffuse(osg::Material::FRONT_AND_BACK, osg::Vec4f(1, 1, 1, m_alphaPanel) );
	m_text->getText()->setColor( osg::Vec4f(1, 1, 1, m_alphaPanel) );

	m_alphaPanel -= dt * 4;
	if (m_alphaPanel < 0)
		m_alphaPanel = 0;

	// we are in UIHelp mode...

	// Update Time
	if (NULL != GetModel()) {
		const_cast<osg::FrameStamp*>(GetModel()->mScene->getFrameStamp())->setReferenceTime(GetRealTime()-mStartTime);
		const_cast<osg::FrameStamp*>(GetModel()->mScene->getFrameStamp())->setFrameNumber(mFrameNumber);
		mFrameNumber++;
	}

	osg::State *oldState = NULL;
	if (MAFApplication::mbVisible && m_pbuffer.valid()) {
		oldState = scene->getState();
		scene->setState(m_TLFState.get());
		m_pbuffer->use();
		scene->setDrawBufferValue(GL_FRONT);
	}

	osg::Group *HUD = GetModel()->mHUDProjection.get();
	MAF_REMOVE_NODEMASK(HUD, MAF_VISIBLE_MASK);

	MAFCameraModel* camera = GetModel()->mCamera->GetModel();
	const osg::BoundingSphere &bs = scene->getSceneData()->getBound();

	scene->setProjectionMatrixAsPerspective(camera->GetFov(),
		(((float) win_w)/win_h),
		1.0f,
		bs.radius()*2.0f);

	scene->setViewMatrixAsLookAt(camera->GetPosition(),
		camera->GetTarget(),
		camera->GetUp());

	scene->update();

	int nbGroupInColor = m_stayInColor.size();

	changeDrawableRender(false);

	for (i = 0; i < nbGroupInColor; i++) {
		DrawableThatStayInColor &grp = m_stayInColor[i];
		grp.oldDrawCallback = grp.drawable->getDrawCallback();
		grp.drawable->setDrawCallback( m_dummyDrawCallback.get() );
	}

	//m_colorGroup->setNodeMask(0);
	m_colorMask->setMask(true, true, true, true);
	scene->setViewport(0, 0, m_grayTextureWidth, m_grayTextureHeight);
//	GetModel()->mHUDProjection->setMatrix(osg::Matrix::ortho2D(0, m_grayTextureSize, 0, m_grayTextureSize));
	GetModel()->mHUDProjection->setMatrix(osg::Matrix::ortho2D(0, win_w, 0, win_h));

	m_grayQuad->setNodeMask(0);
	int panelProjoNodeMask = m_panelProjo->getNodeMask();
	m_panelProjo->setNodeMask(0);

	if (MAFApplication::mbVisible) {
		scene->cull();
		scene->draw();
	}

	if (MAFApplication::mbVisible)
		m_grayTexture->copyTexImage2D(*scene->getState(), 0, 0, m_grayTextureWidth, m_grayTextureHeight);

	if (MAFApplication::mbVisible && m_pbuffer.valid()) {
		m_pbuffer->release();
		scene->setState(oldState);
		scene->setDrawBufferValue(GL_BACK);
	}

	// second pass

	for (i = 0; i < nbGroupInColor; i++) {
		DrawableThatStayInColor &grp = m_stayInColor[i];

		grp.drawable->setDrawCallback( grp.oldDrawCallback );
		grp.drawable->getOrCreateStateSet()->setRenderBinDetails(grp.renderBinToUse, grp.orgRenderBinName);
	}


	m_colorMask->setMask(false, false, false, false);

	m_grayQuad->setNodeMask(MAF_VISIBLE_MASK);
	MAF_OR_NODEMASK(HUD, MAF_VISIBLE_MASK);
	m_panelProjo->setNodeMask(panelProjoNodeMask);

	scene->setViewport(0, 0, win_w, win_h );
	GetModel()->mHUDProjection->setMatrix(osg::Matrix::ortho2D(0, win_w, 0, win_h));
	if (MAFApplication::mbVisible) {
		scene->cull();
		scene->draw();
	}

	for (i = 0; i < nbGroupInColor; i++) {
		DrawableThatStayInColor &grp = m_stayInColor[i];
		grp.drawable->getOrCreateStateSet()->setRenderBinDetails(grp.orgRenderBinNum, grp.orgRenderBinName);

	}
}

void PokerSceneView::addDrawableThatStayInColor(osg::Drawable *_drawable, int _orgRenderBin, int _renderBinToUse, const std::string &_renderName, int _flags)
{
	int nb = m_stayInColor.size();
	for (int i = 0; i < nb; i++) {
		if (m_stayInColor[i].drawable == _drawable)
			return;
	}

	DrawableThatStayInColor stay;

	osg::StateSet *ss = _drawable->getOrCreateStateSet();

	stay.drawable = _drawable;
	stay.flags = _flags;
	/*
	stay.orgRenderBinName = ss->getBinName();
	stay.orgRenderBinNum = ss->getBinNumber();

	if (_renderBinToUse == -200)
		stay.renderBinToUse = stay.orgRenderBinNum + 5;
	else if (_renderBinToUse == -100)
		stay.renderBinToUse = stay.orgRenderBinNum + 50;
	else
		stay.renderBinToUse = _renderBinToUse;

	if (stay.orgRenderBinName.empty())
		stay.orgRenderBinName = "RenderBin";
		*/

	stay.orgRenderBinNum = _orgRenderBin;
	stay.renderBinToUse = _renderBinToUse;
	stay.orgRenderBinName = _renderName;

	osg::StateSet::TextureAttributeList &attr_list = ss->getTextureAttributeList();
	int siz = attr_list.size();
	for (int j = 0; j < siz; j++) {
		osg::Texture2D *texture = (osg::Texture2D*) ss->getTextureAttribute(j, osg::StateAttribute::TEXTURE);
		stay.orgTexture[j] = texture;
	}

	stay.orgColor = osg::Vec4f(0, 0, 0, -1);
	osg::Material *mat = (osg::Material*) ss->getAttribute(osg::StateAttribute::MATERIAL);
	if (mat)
		stay.orgColor = mat->getDiffuse( osg::Material::FRONT_AND_BACK );

	osg::ColorMask *cm = (osg::ColorMask*) ss->getAttribute(osg::StateAttribute::COLORMASK);
	if (!cm) {
		cm = new osg::ColorMask(true, true, true, true);
		ss->setAttributeAndModes(cm, osg::StateAttribute::ON);
	}
	cm->setMask(true, true, true, true);

	m_stayInColor.push_back(stay);
}

void PokerSceneView::removeDrawableThatStayInColor(osg::Drawable *_drawable)
{
	int nb = m_stayInColor.size();
	for (int i = 0; i < nb; i++) {
		DrawableThatStayInColor &stay = m_stayInColor[i];
		if (stay.drawable == _drawable) {

			osg::StateSet *ss = _drawable->getStateSet();
			if (ss) {

				if (stay.flags & 1) {
				}
				else {
					osg::StateSet::TextureAttributeList &attr_list = ss->getTextureAttributeList();
					int siz = attr_list.size();
					for (int j = 0; j < siz; j++) {
						if (stay.orgTexture[j])
							ss->setTextureAttributeAndModes(j, stay.orgTexture[j]);
					}
				}
			}

			m_stayInColor.erase( m_stayInColor.begin()+i );

			return;
		}
	}
}

void PokerSceneView::setCurrentSelectionedItem(const std::string &_selected, bool _bDescriptionLocked, void* _itemID)
{
	m_bDescriptionLocked = _bDescriptionLocked;

	if (_selected.empty() || m_desc.find(_selected) == m_desc.end()) {
		//m_panelProjo->setNodeMask(0);
		if (_itemID == NULL)
			m_currentDescID = _itemID;
		return;
	}

	m_alphaPanel = 1;

	std::vector< std::string > &text = m_desc[_selected];
	int nbLines = text.size();

	//std::string &txt = text[0];
	//std::string txt = "toto le heros kfd dhg hgdhg dkgkdhgkdhg kdhg khg\nhello\nhgkf";

	std::string txt;
	for (int i = 0; i < nbLines; i++) {
		txt += text[i] + "\n";
	}

	m_text->getText()->setText(osgText::String(txt, osgText::String::ENCODING_UTF8));
	m_panelProjo->setNodeMask(MAF_VISIBLE_MASK);

	//std::string desc = "hello world!";

	float height = nbLines * 0.018f;
	float yy = 20 / 768.0f * 2;

	float y0 = height + yy;
	float y1 = height;
	float y2 = -height;
	float y3 = -height - yy;

	osg::Vec3Array *arr;
	arr = m_topQuad->getVerticesArray();
	arr[0][0][1] = y0;
	arr[0][1][1] = y0;
	arr[0][2][1] = y1;
	arr[0][3][1] = y1;

	arr = m_middleQuad->getVerticesArray();
	arr[0][0][1] = y1;
	arr[0][1][1] = y1;
	arr[0][2][1] = y2;
	arr[0][3][1] = y2;

	arr = m_lowQuad->getVerticesArray();
	arr[0][0][1] = y2;
	arr[0][1][1] = y2;
	arr[0][2][1] = y3;
	arr[0][3][1] = y3;

	if (m_currentDescID != _itemID) {

		int m_x = g_mx; //m_game->getMouseX();
		int m_y = g_my; //m_game->getMouseY();
		int w = m_game->GetWindow(true)->GetWidth();
		int h = m_game->GetWindow(true)->GetHeight();

		float tx = (float(m_x) / w) * 2 - 1;
		float ty = -((float(m_y) / h) * 2 - 1);

		tx += PANEL_WIDTH;
		ty -= (y0 - y3) * 0.5f;

		tx += 30.0f / w;
		ty -= 30.0f / h;

		if (PANEL_WIDTH + tx > 1.0f)
			tx -= (PANEL_WIDTH + tx) - 1.0f + (10.0f / w);

		if (ty + y3 < -1) {
			ty = -((float(m_y) / h) * 2 - 1);
			ty += (y0 - y3) * 0.5f;
			ty += 30.0f / h;
		}

		m_panelMatrix->setMatrix( osg::Matrix::translate(tx, ty, 0) );
	}

	m_currentDescID = _itemID;
}

void PokerSceneView::changeDrawableRender(bool _bOrgRender)
{
	int nb = m_stayInColor.size();

	for (int i = 0; i < nb; i++) {
		DrawableThatStayInColor &grp = m_stayInColor[i];
		osg::Drawable *drawable = grp.drawable;

		int flags = grp.flags;
		osg::StateSet *ss = drawable->getStateSet();
		if (!ss)
			continue;

		osg::StateSet::TextureAttributeList &attr_list = ss->getTextureAttributeList();
		int siz = attr_list.size();

		if (_bOrgRender) {
			if (flags & 1) {
			}
			else {
				if (siz == 0) {
					if (grp.orgColor == osg::Vec4f(0, 0, 0, -1))
						ss->removeAttribute(osg::StateAttribute::MATERIAL);
					else {
						osg::Material *mat = (osg::Material*) ss->getAttribute(osg::StateAttribute::MATERIAL);
						mat->setDiffuse(osg::Material::FRONT_AND_BACK, grp.orgColor);
					}
				}
				else {
					for (int j = 0; j < siz; j++) {
						ss->setTextureAttributeAndModes(j, grp.orgTexture[j]);
					}
				}
			}
		}
		else {

			if (flags & 1) {
			}
			else {

				if (siz == 0) {
					osg::Material *mat = (osg::Material*) ss->getAttribute(osg::StateAttribute::MATERIAL);
					if (!mat) {
						mat = new osg::Material();
						ss->setAttributeAndModes(mat);
					}
					mat->setDiffuse(osg::Material::FRONT_AND_BACK, PINK_COLOR );
				}
				else {
					for (int j = 0; j < siz; j++) {
						osg::Texture2D *texture = (osg::Texture2D*) ss->getTextureAttribute(j, osg::StateAttribute::TEXTURE);
						if (!texture)
							continue;

						if (grp.orgTextureName[j].empty()) {
							TextureInformation *inf = (TextureInformation*) texture->getUserData();
							if (!inf)
								continue;
							grp.orgTextureName[j] = inf->getName();
						}

						std::string textureName = grp.orgTextureName[j];
						if (textureName.rfind(".hdr") == std::string::npos) {
							renameTextureName(textureName);

							osg::ref_ptr<osgDB::ReaderWriter::Options> opts = new osgDB::ReaderWriter::Options();
							opts->setObjectCacheHint(osgDB::ReaderWriter::Options::CACHE_ALL);

							osg::Texture2D *newTex = MAFApplication::GetTextureManager()->GetTexture2D(textureName, opts.get() );
							if (newTex)
								ss->setTextureAttributeAndModes(j, newTex);
						}
						else {
							ss->setTextureAttributeAndModes(j, m_gtex.get());
						}
					}
				}
			}
		}
	}
}

void PokerSceneView::renameTextureName(std::string &_name)
{
	size_t pos = _name.rfind("_mc");
	if (pos != std::string::npos)
		return;

	if (_name.rfind("card") != std::string::npos) {
	  int a = 0;
	  (void)a;
	}

	pos = _name.rfind(".");
	_name.insert(pos, "_mc");
}

void PokerSceneView::showActivateButton(bool _bShow)
{
	m_bButtonAvailable = _bShow;
}



PokerUIMouseController::PokerUIMouseController(PokerSceneView *_parent)
{
	_parent->m_mouseController = this;
	parent_ = _parent;
	bLMB_ = false;

	UGAMEArtefactModel *model = new UGAMEArtefactModel;
	model->Init();
	SetModel(model);
	Init();

	group_ = new osg::Group();
	group_->setName("PokerSceneView");
	group_->addChild( _parent->m_button->getGeode() );
	//_parent->m_button->getGeode()->setName("MYYYYGEEOODE");
	group_->setNodeMask(MAF_VISIBLE_MASK | MAF_COLLISION_MASK);

	GetModel()->SetArtefact( group_.get() );

	osg::Group *HUDgroup = _parent->GetModel()->mHUDGroup.get();
	Anchor(HUDgroup);

	SetSelectable(true);

	_parent->m_game->AddController(this);
}

PokerUIMouseController::~PokerUIMouseController()
{
	Anchor(NULL);
}

bool PokerUIMouseController::Update(MAFApplication *_app)
{
	SDL_Event *event = _app->GetLastEventIgnoreLocking();
	if (!event)
		return true;

	switch (event->type) {

	case SDL_MOUSEBUTTONUP:
		if (_app->GetFocus() == this) {
			if (bLMB_) {
				bLMB_ = false;
			}
		}
		else {
			bLMB_ = false;
		}
		break;

	case SDL_MOUSEBUTTONDOWN:
		if(_app->GetFocus() == this) {
			bLMB_ = true;
		}
		else {
			bLMB_ = false;
		}

		break;
	}
	return true;
}
