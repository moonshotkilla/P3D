/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#include "pokerStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */

#ifndef POKER_USE_VS_PCH
#ifdef USE_NPROFILE
#include <nprofile/profile.h>
#else  //USE_NPROFILE
#define NPROFILE_SAMPLE(a)
#endif //USE_NPROFILE
#include <sstream>
#include <iomanip>
#include <map>

#include <osg/Shape>
#include <osg/ShapeDrawable>
#include <osg/Geode>
#include <osg/MatrixTransform>
#include <osgUtil/IntersectVisitor>

#include <PokerDoor.h>
#include <PokerApplication.h>
#include <maf/interpolator.h>
#include <PokerError.h>
#endif

PokerDoorModel::PokerDoorModel() : mDoorData(0)
{
}

void PokerDoorModel::Init()
{
  UGAMEArtefactModel::Init();
  osg::Quat from(0.0f, osg::Vec3(0.0f, 1.0f, 0.0f));
  osg::Quat to(osg::PI_2, osg::Vec3(0.0f, 1.0f, 0.0f));
  mRotationInterpolator.Init(from, to);
  mTimer.Init(0.5);
}

PokerDoorController::PokerDoorController(unsigned int controllerID):PokerSelectableController(controllerID)
{
  SetModel(new PokerDoorModel());
}

PokerDoorController::~PokerDoorController()
{
	g_debug("PokerDoorController::~PokerDoorController()");
  GetModel()->mDoorCollNode = 0;
  Anchor(0);

  delete (GetModel()->mDoorData);

	osg::NodeVisitor* leakNodes = RecursiveLeakCollect(GetModel()->GetNode());
	RecursiveLeakCheck(leakNodes); 
}

void PokerDoorController::Init(PokerApplication *game, const std::string &path)
{
  PokerSelectableController::Init(game);
  const std::string &doorNodeName = game->HeaderGet("sequence", path + "/@url");
  const std::string &doorCollName = game->HeaderGet("sequence", path + "/@collide");
  const std::string &doorAnchorName = game->HeaderGet("sequence", path + "/@anchor");
  const std::string &splineUrl = "splines.xml";
  const std::string &splineName = game->HeaderGet("sequence", path + "/@spline");

  MAFOSGData *doorData = static_cast<MAFOSGData *>(game->mDatas->GetVision(doorNodeName)->Clone(LEVEL_CLONE_SETTING));
  g_assert(doorData != 0);
  osg::Node *doorNode = doorData->GetGroup();
  g_assert(doorNode != 0);
  GetModel()->SetArtefact(doorNode);
  GetModel()->mDoorData = doorData;

  MAFAnchor *doorAnchor = game->mSetData->GetAnchor(doorAnchorName);
  g_assert(doorAnchor != 0);

  osg::Node *doorCollNode = game->mSetData->GetNode(doorCollName);
  g_assert(doorCollNode != 0);
  GetModel()->mDoorCollNode = doorCollNode;

	// add collision from root to transform
	osg::NodePath pathToAddCollisionMask;
	MAFCreateNodePath(doorCollNode, pathToAddCollisionMask);
	for (osg::NodePath::iterator it = pathToAddCollisionMask.begin(); it != pathToAddCollisionMask.end(); it++) {
		unsigned int mask = (*it)->getNodeMask();
		mask =  mask | MAF_COLLISION_MASK;
		(*it)->setNodeMask(mask);
	}
  doorCollNode->setNodeMask(MAF_COLLISION_MASK); // no display 

  MAFXmlData *data = game->mDatas->GetXml(splineUrl);
  LoadSpline(GetModel()->mRotationInterpolator, data, splineName);

  BindToNode(doorCollNode);
  doorAnchor->setNodeMask(MAF_VISIBLE_MASK); // no collisions with door only with collid mesh
  Anchor(doorAnchor);
  GetModel()->SetSelectable(true);
}

bool PokerDoorController::Update(MAFApplication *game)
{
  NPROFILE_SAMPLE("PokerChipsStackController::Update");
  PokerSelectableController::Update(game);

  if(game->HasEvent())
    return true;
  
  bool focused = (game->GetFocus() == this);

  float delta = GetDeltaFrame()/1000.f;
  delta = (focused ? delta : -delta);

  GetModel()->mTimer.AddTime(delta);

  osg::Quat rot;
  GetModel()->mTimer.Get(rot, GetModel()->mRotationInterpolator);
  GetModel()->GetPAT()->setAttitude(rot);
  
  return true;
}

void PokerDoorController::Enable()
{
  GetModel()->GetArtefact()->setNodeMask(MAF_VISIBLE_MASK | MAF_COLLISION_MASK);
  SetSelectable(true);
}

void PokerDoorController::Disable()
{
  GetModel()->GetArtefact()->setNodeMask(0);
  SetSelectable(false);
}

void PokerDoorController::LoadKeys(std::vector<osg::Vec2> &keys, MAFXmlData *data, const std::string &name)
{
  if (data != NULL) {
    const std::list<std::string> &xResultList = data->GetList("/splines/" + name + "/list/entry/@xvalue");
    const std::list<std::string> &yResultList = data->GetList("/splines/" + name + "/list/entry/@yvalue");
    
    g_assert(xResultList.size() == yResultList.size());
    typedef std::list<std::string>::const_iterator It;
    It xbegin = xResultList.begin();
    It xend = xResultList.end();
    
    It ybegin = yResultList.begin();
    It yend = yResultList.end();
    
    while(xbegin != xend) {
      keys.push_back(osg::Vec2(atof((*xbegin).c_str()), atof((*ybegin).c_str())));
      xbegin++;
      ybegin++;
    }
  }
}

