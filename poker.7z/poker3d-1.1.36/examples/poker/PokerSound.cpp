/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include "pokerStdAfx.h"

#ifndef POKER_USE_VS_PCH
#	include <PokerSound.h>
#	include <maf/data.h>
#	include <maf/maferror.h>

#include <list>
#endif

// bool LoadSoundSettings(std::vector<MAFAudioModel::MAFAudioParameter>& settings, MAFXmlData *data);
bool LoadSoundSettings(std::vector<SoundInit>& settings, MAFXmlData *data)
{
  if (!data)
    return false;

  const std::list<std::string> &names = data->GetList("/sounds/item/@name");
  const std::list<std::string> &snames = data->GetList("/sounds/item/@soundname");
  const std::list<std::string> &anchors = data->GetList("/sounds/item/@anchor");
  const std::list<std::string> &refDistance = data->GetList("/sounds/item/@referenceDistance");
	const std::list<std::string> &gain = data->GetList("/sounds/item/@gain");
  const std::list<std::string> &rolloff = data->GetList("/sounds/item/@rolloff");
  const std::list<std::string> &priority = data->GetList("/sounds/item/@priority");
  const std::list<std::string> &event = data->GetList("/sounds/item/@event");

  settings.clear();
	if ( names.size() != snames.size())
		g_assert(0 && "LoadSoundSettings a name and sound name have not the same size in /sounds/item");

  if (names.size() != anchors.size()) {
		unsigned int a = names.size();
		if (anchors.size() > a)
			a = anchors.size();
		typedef std::list<std::string>::const_iterator It2;
		It2 nameBegin = names.begin();
		It2 nameEnd = names.end();
		It2 anchorBegin = anchors.begin();

		for (unsigned int i = 0; i < a; i++) {
			g_debug("name %s anchor %s", std::string(*nameBegin).c_str(), std::string(*anchorBegin).c_str());
			nameBegin++;
			anchorBegin++;
		}
		g_assert(0 && "LoadSoundSettings a name or an anchor is missed in /sounds/item");
	}

	if ( names.size() != refDistance.size()) {
		unsigned int a = names.size();
		if (refDistance.size() > a)
			a = refDistance.size();
		typedef std::list<std::string>::const_iterator It2;
		It2 nameBegin = names.begin();
		It2 nameEnd = names.end();
		It2 refDist = refDistance.begin();
		g_debug("name %i referenceDistance %i", (int)names.size(), (int)refDistance.size());
		for (unsigned int i = 0; i < a; i++) {
			g_debug("name %s referenceDistance %s", std::string(*nameBegin).c_str(), std::string(*refDist).c_str());
			nameBegin++;
			refDist++;
		}
		g_assert(0 && "LoadSoundSettings a name and referenceDistance have not the same size in /sounds/item");
	}
	if ( names.size() != rolloff.size())
		g_assert(0 && "LoadSoundSettings a name and rolloff have not the same size in /sounds/item");

	if ( names.size() != priority.size())
		g_assert(0 && "LoadSoundSettings a name and priority have not the same size in /sounds/item");

	if ( names.size() != gain.size())
		g_assert(0 && "LoadSoundSettings a name and gain have not the same size in /sounds/item");

	if ( names.size() != event.size())
		g_assert(0 && "LoadSoundSettings a name and event have not the same size in /sounds/item");

  typedef std::list<std::string>::const_iterator It;
  It nameBegin = names.begin();
  It nameEnd = names.end();

  It snameBegin = snames.begin();
  It anchorBegin = anchors.begin();
  It refDistBegin = refDistance.begin();
  It rolloffBegin = rolloff.begin();
  It priorityBegin = priority.begin();
  It eventBegin = event.begin();
  It gainBegin = gain.begin();
  
  while (nameBegin != nameEnd) {
    float refDistTmp = atof(refDistBegin->c_str());
    float rolloffTmp = atof(rolloffBegin->c_str());
    float gainTmp = atof(gainBegin->c_str());
    int priorityTmp = atoi(priorityBegin->c_str());
    //    int isEvent=atoi(eventBegin->c_str());
    settings.push_back(SoundInit(*nameBegin,*snameBegin,*anchorBegin, refDistTmp, rolloffTmp, priorityTmp, gainTmp));
    nameBegin++;
    snameBegin++;
    anchorBegin++;
    refDistBegin++;
    rolloffBegin++;
    priorityBegin++;
    eventBegin++;
    gainBegin++;
  }
  return true;
}
