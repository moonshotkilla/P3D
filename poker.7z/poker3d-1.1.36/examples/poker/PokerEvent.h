/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@mekensleep.com>
 *
 */

#ifndef _POKER_EVENT_H_
#define _POKER_EVENT_H_

#include <vector>

struct PokerEventPlayerFold
{
  int mSerial;
PokerEventPlayerFold(int serial): mSerial(serial) {}
};

struct PokerEventSwitchToExistingTable
{
};

struct PokerEventGameStart
{
};

struct PokerEventEndRound
{
};

struct PokerEventQuit
{
};

struct PokerEventStartFirstPerson
{
};

struct PokerEventEndFirstPerson
{
};

struct PokerEventEndLeaveFirstPerson
{};

struct PokerEventChipsPot2Player
{
  bool& mBatchMode;
  int mSerial;
  std::vector<int>& mAmounts;
  int mPot;
PokerEventChipsPot2Player(bool& batchMode,int serial, std::vector<int>& amount, int pot): 
  mBatchMode(batchMode), mSerial(serial), mAmounts(amount), mPot(pot) {}
};

struct PokerEventChipsBet2Pot
{
  bool& mBatchMode;
  int mSerial;
  std::vector<int>& mAmounts;
  int mPot;
PokerEventChipsBet2Pot(bool& batchMode,int serial, std::vector<int>& amount, int pot): 
  mBatchMode(batchMode), mSerial(serial), mAmounts(amount), mPot(pot) {}
};

struct PokerEventPlayerLeave
{
  int mSerial;
PokerEventPlayerLeave(int serial) : mSerial(serial) {}
};

struct PokerEventPotChips
{
  std::vector<int>& mAmounts;
  int mIndex;
PokerEventPotChips(std::vector<int>& amount, int index) : mAmounts(amount), mIndex(index) {}
};


#endif
