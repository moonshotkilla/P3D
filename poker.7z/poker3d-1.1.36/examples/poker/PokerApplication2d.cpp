/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */
#include "pokerStdAfx.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */
#ifdef WIN32
#include <cstdio>
# define snprintf _snprintf
#endif

#ifndef POKER_USE_VS_PCH 
#include <PokerApplication2d.h>
#include <maf/wnc_desktop.h>
#include <maf/application.h>
#include <maf/animate2d.h>
#include <maf/application2d.h>
#endif //POKER_USE_VS_PCH
#include <CustomAssert/CustomAssert.h>

PokerApplication2D::PokerApplication2D()
{
}

PokerApplication2D::~PokerApplication2D()
{
}


bool PokerApplication2D::InitStackPriorityDesktop(MAFApplication* application, std::map<std::string,int>& result)
{
  result.clear();
  MAFApplication::PropertiesList priority_list = application->HeaderGetPropertiesList("sequence", "/sequence/application2d/priority");
  for(MAFApplication::PropertiesList::iterator i = priority_list.begin(); i != priority_list.end(); i++) {
    MAFApplication::Properties& properties = *i;
    if (properties.find("title") != properties.end()) {
      const std::string& name = properties["title"];
      if (properties.find("priorityStack") != properties.end()) {
        int priority = atoi(properties["priorityStack"].c_str());
        result[name] = priority;
      } else
        CUSTOM_ASSERT(0 && "InitStackPriorityDesktop bad entry /sequence/application2d/priority for client.xml");
    }
  }
  return true;
}


MAFApplication2DController* PokerApplication2D::GetApplication2D() 
{
  return mApplication2D.get();
}

bool PokerApplication2D::CreateDesktop(MAFApplication* application, XwncDesktop* desktop)
{
  {
    MAFApplication2DModel* chat_model = new MAFApplication2DModel;
    chat_model->SetDesktop(desktop);
    mApplication2D = new MAFApplication2DController(application);
    mApplication2D->SetModel(chat_model);
    mApplication2D->Init();
    mApplication2D->SetDefaultFocusedWindow("login_window",0);
    mApplication2D->SetDefaultFocusedWindow("chat_entry_window",1);
    MAFName2Animate& name2animate = mApplication2D->GetName2Animate();

    MAFApplication::PropertiesList properties_list = application->HeaderGetPropertiesList("sequence", "/sequence/application2d/window");

    for(MAFApplication::PropertiesList::iterator i = properties_list.begin(); i != properties_list.end(); i++) {
      MAFApplication::Properties& properties = *i;
      const std::string& name = properties["title"];

      MAFApplication2DAnimate* animate = new MAFApplication2DAnimate();
      name2animate[name] = animate;

      if(properties["virtual"] != "") {
        animate->SetAsVirtualWindow(true);
      }

      if(properties["slide"] != "") {
        int directionFlags = 0;
        if(properties["slide_axis"] == "x")
          directionFlags |= MAFApplication2DSlide::AXIS_X;
        else if(properties["slide_axis"] == "y")
          directionFlags |= MAFApplication2DSlide::AXIS_Y;
        else
          directionFlags |= MAFApplication2DSlide::AXIS_Y;

        if(properties["slide_direction"] == "negative")
          directionFlags |= MAFApplication2DSlide::DIRECTION_NEGATIVE;
        else if(properties["slide_direction"] == "positive")
          directionFlags |= MAFApplication2DSlide::DIRECTION_POSITIVE;
        else
          directionFlags |= MAFApplication2DSlide::DIRECTION_POSITIVE;

        MAFApplication2DSlide* slider;

        if(properties["slide"] == "slide")
          slider = new MAFApplication2DSlide(directionFlags);
        else if(properties["slide"] == "slide_in_out")
          slider = new MAFApplication2DSlideInOut(directionFlags);
        else
          slider = new MAFApplication2DSlide(directionFlags);

        float delay = 500;
        if(properties["slide_delay"] != "")
          delay = atof(properties["slide_delay"].c_str());
        slider->SetDelay(delay);

        slider->SetMouseTrigger(properties["mouseTrigger"] == "true");

        slider->SetVisible(properties["visible"] == "true");

        animate->push_back(slider);
      }

      if(properties["alpha"] != "") {
        MAFApplication2DAlpha* alpha = new MAFApplication2DAlpha(atof(properties["alpha"].c_str()));
        animate->push_back(alpha);
      }

      if(properties["background_left"] != "") {
        MAFApplication2DDecorateSquare* decorate = new MAFApplication2DDecorateSquare;
        float left = atof(properties["background_left"].c_str());
        float bottom = atof(properties["background_bottom"].c_str());
        float right = atof(properties["background_right"].c_str());
        float top = atof(properties["background_top"].c_str());
        decorate->SetGeometry(left, bottom, right, top);
        if(properties["background_border"] != "")
          decorate->SetBorder(atof(properties["background_border"].c_str()));
        osg::Vec4 background(atof(properties["background_red"].c_str()) / 255,
                             atof(properties["background_green"].c_str()) / 255,
                             atof(properties["background_blue"].c_str()) / 255,
                             atof(properties["background_alpha"].c_str()));
        decorate->SetBackgroundColor(background);
        decorate->SetBorderColor(osg::Vec4(0.31f, 0.31f, 0.31f, 1.0f));
        animate->push_back(decorate);
      }

      // to this in xml instead
      animate->push_back(new MAFApplication2DAlphaFade());
    }
  }
  return true;
}
