#!/usr/bin/python
# Copyright (C) 2004, 2005, 2006 Mekensleep
#
# Mekensleep
# 24 rue vieille du temple
# 75004 Paris
#       licensing@mekensleep.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
# Authors:
#  Loic Dachary <loic@gnu.org>
#
#
import sys

sys.path.insert(0, "..")
sys.path.insert(0, "../../python")

import os
import platform

if platform.system() == "Windows":
    os.environ["path"] += ";..\\..\\python\\Lib\\site-packages\\pywin32_system32"
    import win32process
    import win32api
    import win32net
    import win32gui
    from win32com.shell import shell, shellcon

    from twisted.internet import win32eventreactor
    win32eventreactor.install()


from string import split, lower
from os import makedirs
from os.path import expanduser, exists
import signal
from traceback import print_exc
import libxml2
from shutil import copy

from time import sleep
from random import choice, uniform, randint
import webbrowser

from poker.config import Config
from poker.version import version
from poker.pokerclient3d import PokerClientFactory3D

from poker.pokerdisplay3d import PokerDisplay3D
from poker.pokerrenderer3d import PokerRenderer3D
from poker.pokerchildren3d import PokerChildXwnc
from poker.pokerskin3d import PokerSkin3D

class Main:
    "Poker gameplay"

    def __init__(self, configfile, settingsfile):
        self.settings = Config([''])
        self.settings.load(settingsfile)
        self.shutting_down = False
        if self.settings.header:
            rcdir = self.configureDirectory()
            self.dirs = split(self.settings.headerGet("/settings/path"))
            self.config = Config([''] + self.dirs)
            self.config.load(configfile)
            self.verbose = self.settings.headerGetInt("/settings/@verbose")
            self.poker_factory = None
        print "verbose level %s" % str(self.verbose)

    def configOk(self):
        return self.settings.header and self.config.header

    def shutdown(self, signal, stack_frame):
        self.shutting_down = True
        self.poker_factory.display.finish()
        if self.verbose:
            print "received signal %s, exiting" % signal
            
    def configureDirectory(self):
        settings = self.settings
        if not settings.headerGet("/settings/user/@path"):
            print """
No <user path="user/settings/path" /> found in file %s.
Using current directory instead.
""" % settings.url
            return
        
        rcdir = expanduser(settings.headerGet("/settings/user/@path"))
        if not exists(rcdir):
            os.mkdir(rcdir)

    def run(self):
        settings = self.settings
        config = self.config

        signal.signal(signal.SIGINT, self.shutdown)
        if platform.system() != "Windows":
            signal.signal(signal.SIGQUIT, self.shutdown)
        signal.signal(signal.SIGTERM, self.shutdown)

        poker_factory = None
        status = 1
        try:
            poker_factory = PokerClientFactory3D(settings = settings,
                                                 config = config)
            poker_factory.initChildren()
            self.poker_factory = poker_factory
            
            if poker_factory.display:
                status = poker_factory.display.run()
            else:
                raise Exception, "PokerClientFactory3D instance has no display"
        except:
            status = 1

        if status:
            print_exc()
            if str(sys.exc_value).find("opengl") != -1:
                try:
                    web = self.settings.headerGet("/settings/web")
                    webbrowser.open(web+"tilt.html#OpenGL", 1, 1)
                except:
                    print_exc() #webbrowser.open throws if browser popup a message box                    
        
        if poker_factory:
            if status: 
                poker_factory.crashing = True
            if poker_factory.children:
                from twisted.internet import defer
                reactor.addSystemEventTrigger('before', 'shutdown', lambda: defer.DeferredList(map(lambda child: child.deferred,  poker_factory.children.children)))
                poker_factory.children.killall()
            #reactor.disconnectAll()
            if poker_factory.display:
                poker_factory.display.finish()
                poker_factory.display = None
        return status

from twisted.internet import reactor, error, ssl

from pokernetwork.pokerclient import PokerClientFactory, PokerSkin
from pokernetwork.pokerclientpackets import *
from pokernetwork.proxy import Connector

from pokerui import pokerinterface
from poker.pokerchildren3d import PokerChildXwnc, PokerChildInterface, CHILD_INTERFACE_READY, CHILD_INTERFACE_GONE
    
import sys
class RedirectOutput:
    def start(self, filename):
		self.oldStdOut = sys.stdout
		self.oldStdErr = sys.stderr
		self.file = file(filename, "a", 0)
		sys.stdout = self.file
		sys.stderr = self.file
    def stop(self):
		sys.stderr.flush()
		sys.stdout.flush()
		sys.stderr = self.oldStdErr
		sys.stdout = self.oldStdOut
		self.file.flush()
		self.file.close()
		self.file = None
		self.oldStdErr = None
		self.oldStdout = None
    
def run(argv, datadir, base, upgradesdir, pokernetwork_upgradesdir):

    if platform.system() == "Windows":
        IDLList = shell.SHGetSpecialFolderLocation(0, shellcon.CSIDL_APPDATA)
        user_dir = shell.SHGetPathFromIDList(IDLList) + "/Pok3d"
        settingsfile = len(argv) > 0 and argv[0] or user_dir + "/" + "poker.client.xml"
    else:
        user_dir = expanduser("~/." + base)
        settingsfile = len(argv) > 0 and argv[0] or user_dir + "/" + base + ".xml"

    configfile = len(argv) > 1 and argv[1] or "client.xml"

    Config.upgrades_repository = upgradesdir or datadir + "/upgrades"
    Config.pokernetwork_upgrades_repository = pokernetwork_upgradesdir or "../../../poker-network/upgrades/poker.client"

    if platform.system() == "Windows":
        redirect = RedirectOutput()
        pathToLogFile = user_dir + "/" + "output.log"
        IDLList = shell.SHGetSpecialFolderLocation(0, shellcon.CSIDL_APPDATA)
        localData = shell.SHGetPathFromIDList(IDLList) + "\Pok3d"
        pathToLogFile = localData + "\output.log"
        redirect.start(pathToLogFile)

    if platform.system() != "Windows":
        conf_file = user_dir + "/" + base + ".xml"
        default_settingsfile = datadir + "/" + base + ".xml"
        if not exists(conf_file) and exists(default_settingsfile):
            if not exists(user_dir):
                makedirs(user_dir)
            copy(default_settingsfile, user_dir)
    else:
          if os.access(settingsfile, os.F_OK) == False:
            # if not here, we need to import "poker.client.xml" from somewhere.  By order of priority:
            # - in "All Users" directory.  That means the game has been installed from "setup.exe" for "All Users" and it's the first time
            #   we launch the game for this user
            # - in the current game directory.  That means the game has been updated from network (not installed) and we were running an old
            #   version of the game that didn't managed multi-users.  As the old installer didn't created any "Documents And Settings/user/Pok3d"
            #   subdirectory, we need to grab the file in the directory game itself as before
            # - the game is corrupted, throw an error and ask for a re-install

            IDLList = shell.SHGetSpecialFolderLocation(0, shellcon.CSIDL_COMMON_APPDATA)
            source = shell.SHGetPathFromIDList(IDLList) + "/Pok3d/poker.client.xml"
            if os.access(source, os.F_OK) == False:
                source = "../../poker.client.xml"
                if os.access(source, os.F_OK) == False:
                    win32gui.MessageBox(0, "Pok3d is not correctly installed on your system and cannot be launched.\nReinstalling the application may solve the problem.", "Unable to launch Pok3d", 0x10)

            copy(source, user_dir)

            need_to_force_upgrades_to_no = 1

            try:
                userName = win32api.GetUserName()
                info = win32net.NetUserGetInfo(None, userName, 1)

                if info["priv"] == 2:
                    need_to_force_upgrades_to_no = 0

            except:
                print_exc()
                pass

            if need_to_force_upgrades_to_no == 1:
                # we are not admin, so we cannot upgrade the software if required
                doc = libxml2.parseFile(source)
                context = doc.xpathNewContext()
                results = context.xpathEval("/settings/@upgrades")
                results[0].setContent("no");
                doc.saveFile(settingsfile)
                context.xpathFreeContext()
                doc.freeDoc()

    client = Main(configfile, settingsfile)

    if client.configOk():
        reactor.startRunning()
        status = client.run()

    reactor.stop()
    while(reactor.running):
		reactor.iterate()
    del client
    libxml2.cleanupParser()

    if platform.system() == "Windows":
        redirect.stop()
        if status: raise Exception, "poker3d exit with status %i" % status

if __name__ == "__main__":
    run(sys.argv, ".", "poker3d", None, None)

#
# Emacs debug:
# cp /usr/lib/python2.3/pdb.py .
# M-x pdb
# ../../underware pdb.py poker3d.py file:conf/client/mekensleep.xml
#
