/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#ifndef poker_outfit_h
#define poker_outfit_h

#ifndef POKER_USE_VS_PCH
#include <map>
#include <vector>

#include <maf/vision.h>
#include <ugame/animated.h>

#include <osg/MatrixTransform>

#include <osgUtil/RenderBin>

#include <pokerexport.h>
#endif

class MAFVisionModel;
class PokerApplication;

namespace osg {
  class Material;
  class Projection;
}

class OutfitRenderBin : public osgUtil::RenderBin {
public:

	OutfitRenderBin(osgUtil::RenderBin::SortMode mode = SORT_BY_STATE);
	OutfitRenderBin(const OutfitRenderBin &rhs,const osg::CopyOp &copyop = osg::CopyOp::SHALLOW_COPY);

	virtual ~OutfitRenderBin();

	virtual osg::Object* cloneType() const { return new OutfitRenderBin(); }
	virtual osg::Object* clone(const osg::CopyOp& copyop) const { return new OutfitRenderBin(*this, copyop); } // note only implements a clone of type.
	virtual bool isSameKindAs(const osg::Object* obj) const { return dynamic_cast<const OutfitRenderBin*>(obj) != 0L; }
	virtual const char* className() const { return "OutfitRenderBin"; }

	virtual void reset();
	virtual void draw(osg::State &, osgUtil::RenderLeaf *&);

	bool stageDrawnThisFrame_;
};

class PokerOutfitModel : public MAFVisionModel
{
public:

	class Anim {
	public:
		int id;
		float duration;
	};

	class Button {
	public:
		osg::ref_ptr<osg::Texture2D> normalState;
		osg::ref_ptr<osg::Texture2D> rollOverState;
		osg::ref_ptr<osg::Texture2D> pushedState;
		int focusID;
		int x0, y0;
		int w, h;
		osg::ref_ptr<MAF_OSGQuad> quad;
	};

	class StopCallback : public CalAnimationAlt::StopCallback {

	public:
		StopCallback(PokerOutfitModel *model, int maleOrFemale) : model_(model), maleOrFemale_(maleOrFemale) { };
		virtual void process(CalModel* model, CalAnimationAlt* animation);

	protected:
		PokerOutfitModel *model_;
		int maleOrFemale_;
	};

	PokerOutfitModel(MAFApplication* application);

protected:
	virtual ~PokerOutfitModel();


public:
	PokerApplication* mApplication;
	std::map<std::string, osg::ref_ptr<UGAMEAnimatedController> > animated_;

	class EyeBlinkAnimation;
	std::map<std::string, EyeBlinkAnimation* > mEyeAnimation;

	std::string sex_;
	osg::ref_ptr<osg::MatrixTransform> caracMatrix_;
	osg::ref_ptr<osg::MatrixTransform> shadowMatrix_;
	osg::ref_ptr<osg::Projection> projection_;

//	osg::ref_ptr<MAF_OSGQuad> buttonLeftRot_;
	//osg::ref_ptr<MAF_OSGQuad> buttonZoom_;
	//osg::ref_ptr<MAF_OSGQuad> buttonRightRot_;

	osg::ref_ptr<MAFSceneController> sceneController_;

	osg::ref_ptr<osgUtil::SceneView> sceneView_;

	osg::Node *previewSexNode_;

	StopCallback *maleStopCallback_;
	StopCallback *femaleStopCallback_;

	CalAnimationAlt *currentMaleAnim_;
	CalAnimationAlt *currentFemaleAnim_;

	std::vector<Anim> maleAnims_;
	std::vector<Anim> femaleAnims_;

	std::vector<Button> buttons_;

	std::string mLastSlotType;
	std::string mLastSlotName;
	int mLastSlotIndex;

	int mCurrentFocus;
	float mNearFarPosBlend;
	int mSensZoom;
	bool mbZoomInProgress;

	int mLastMalePlayedAnimation;
	int mLastFemalePlayedAnimation;

	int mOldMouseX;
	int mOldMouseY;

	float mWheel;

	osg::Vec3f mCamPos;
	osg::Vec3f mCamRot;

	osg::Vec3f mCaracPos;
	osg::Vec3f mCaracRot;

	float mAltitude;

	float mDeltaMouseX;
	float mDeltaMouseY;

	bool mbLMB;

	bool mbClickOnIcon;
	float mTimeSinceLastIconClick;
	float mRotationPersoX;
	float mOldRotationPersoX;

	bool mbDragViewport;
};

class POKER_EXPORT PokerOutfitController : public MAFVisionController
{
 public:
  PokerOutfitController(MAFApplication* application);

  PokerOutfitModel* GetModel() { return dynamic_cast<PokerOutfitModel*>(MAFVisionController::GetModel()); }

	bool Update(MAFApplication* application);

  void Show();
  void Hide();

  void SetSex(std::string sex);
  void SetSlot(std::string slot_type, std::string slot_name, int slot_index);
  void SetParam(std::string parameter, std::string name, int value);
	void UnSetSlot(std::string _slotType, int _slotIndex);

 protected:
  virtual ~PokerOutfitController();
};


#endif // _poker_h
