/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 * Henry Precheur	<henry at precheur dot org>
 * Cedric Pinson <cpinson@freesheep.org>
 */

#ifndef	_POKERCHIPSSTACK_H_
#define	_POKERCHIPSSTACK_H_

#ifndef POKER_USE_VS_PCH
#include <map>
#include <vector>

#include <ugame/artefact.h>
#include <maf/billboard.h>
#include <osg/MatrixTransform>
#include <ugame/text.h>
#endif

namespace osg {
  class PositionAttitudeTransform;
};

namespace osgchips {
  class ManagedStacks;
};

namespace betslider {
  class BetSlider;
};

class PokerApplication;
class MAFBillBoard;
struct UGAMEBasicText;

class PokerChipsStackModel: public UGAMEArtefactModel
{
  void InitTooltip(PokerApplication* game);
public:
  PokerChipsStackModel(class PokerApplication* game);
  virtual ~PokerChipsStackModel();

  void ShowTooltip(bool state, float fadeTime);
  unsigned int GetChipsAmount() const;

  unsigned int mBetValue;
  osg::ref_ptr<UGAMEShadowedText> mTooltip;
  osg::ref_ptr<betslider::BetSlider> mSlider;
  bool mSliderActive;
	bool mbCanBeDisplay;
  osg::ref_ptr<osg::PositionAttitudeTransform> mSliderPosition;
  osg::ref_ptr<osgchips::ManagedStacks> mStacks;
  osg::ref_ptr<osgchips::ManagedStacks> mShadowStacks;
  std::map<std::string,osg::Vec4> mColors;
  int mX;
  int mY;
  bool mSelected;
	int mPreviousMouseX;
	int mPreviousMouseY;
	float mTooltipAlpha;
	float mTooltipFadeOutDelay;
	bool mTooltipFadeIn;

	MAFBillBoard *mBillBoard;

	osg::ref_ptr<osg::MatrixTransform> mOffset;
	bool mForceToDisplayTooltip;
};

class PokerChipsStackController: public UGAMEArtefactController
{
 public:
  PokerChipsStackController(PokerApplication* game,unsigned int controllerID);
  virtual ~PokerChipsStackController();
  
  PokerChipsStackModel*	GetModel() { return dynamic_cast<PokerChipsStackModel*>(MAFController::GetModel()); }
  const PokerChipsStackModel* GetModel() const { return dynamic_cast<const PokerChipsStackModel*>(MAFController::GetModel()); }

  void Clear() { SetChips(std::vector<int>()); }
  void SetChips(const std::vector<int>& chips);
  void SetChips(const std::map<unsigned int,unsigned int>& chips);
  void AddChips(const std::map<unsigned int,unsigned int>& chips);
  void SubChips(const std::map<unsigned int,unsigned int>& chips);
  std::map<unsigned int,unsigned int> GetChips() const;
  unsigned int GetChipsAmount() const { return GetModel()->GetChipsAmount(); }

  void CreateSlider(PokerApplication* game);
  void InstallSlider(PokerApplication* application);
  void UninstallSlider(PokerApplication* application);
	void MoveSlider(PokerApplication*, float x, float y);

  void SetShadowChips(const std::map<unsigned int,unsigned int>& chips, const std::string& style);
  void ClearShadowChips(PokerApplication* application);
  void CreateShadowStacks(PokerApplication* game);

  bool Update(MAFApplication* application);

  unsigned int GetBetValue(bool& isCall);
  void ResetBetValue() { GetModel()->mBetValue = 0; }

  void SetBetLimits(int min, int max, int step, int call, int allin, int pot);
	void ForceToDisplayTooltip(bool state) { GetModel()->mForceToDisplayTooltip = state;}

	virtual const char* GetControllerName() const { return "PokerChipsStackController"; }
};

#endif /* _POKERCHIPSSTACK_H_ */
