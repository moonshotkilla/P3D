/* -*- c++ -*-
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Johan Euphrosine <johan@mekensleep.org>
 *
 */

#ifndef _pokerinteractor_h
#define _pokerinteractor_h

#ifndef POKER_USE_VS_PCH
#include <vector>

#include <ugame/artefact.h>

#include <maf/textwriter.h>
#endif

class PokerApplication;
class MAFPacket;
class MAFOSGData;

struct PokerInteractorBase : public UGAMEArtefactController
{
  PokerInteractorBase(unsigned int id);
  virtual ~PokerInteractorBase();
  bool Update(MAFApplication *application);

  MAFOSGData *mSeatData;
  bool mClickStatus;
  bool mWasClickedFocused;
  bool mDirtyDisplay;
  float mScale;
  bool mCanBeFocused;
  bool mForceToZoom;
  int mBetValue;
  bool mCanZoom;
  bool mWaitingForValid;
  float mGlowScale;
  bool mbRaise;
  bool mbForceToUnclick;

  float mRScale;
  float mRFac;

  //	osg::ref_ptr<UGAMEShadowedText> mText;
  //osg::ref_ptr<UGAMEDoubleText> mText;
  osg::ref_ptr<MAFTextWriter> mText;
  osg::ref_ptr<osg::MatrixTransform> mTextMatrix;

  osg::Vec3f *mOrgVertices;

  // "_1" means for "in first person view"
  // "_3" means for "in third person view"
  osg::Vec3f mPos_1;
  osg::Vec3f mPos_3;
  osg::Vec3f mPosRoot_1;
  osg::Vec3f mPosRoot_3;
  osg::MatrixTransform *mMT_1;
  osg::MatrixTransform *mMT_3;
  osg::MatrixTransform *mRoot_1;
  osg::MatrixTransform *mRoot_3;

  std::map<std::string, osg::MatrixTransform*> mMT;

  float mMorph; // morph amount between 1th and 3th person view

  void Init(PokerApplication* game, MAFOSGData* seatData, const std::string &urlPrefix);
  void Finit(PokerApplication *game);
  void InitNode(PokerApplication* game, const std::string &nodeUrl);
  void Accept(MAFPacket *packet);
  void UpdateDisplay(bool clickAndFocused);
  void SetNodeDisplayed(const std::string &state, bool displayed);
  bool GetNodeDisplayed(const std::string &state);
  void SetText(const std::string &text);
  std::map<std::string, osg::ref_ptr<osg::Node> > mNodes;  
  std::map<std::string, std::string> mState2Name;
  std::vector<std::string> mNodes2Clear;

  virtual const char* GetControllerName() const { return "PokerInteractorBase"; }
};

struct PokerInteractorFold : public PokerInteractorBase {
public:
  PokerInteractorFold(unsigned int id) : PokerInteractorBase(id) { };
  virtual const char* GetControllerName() const { return "PokerInteractorFold"; }
};

struct PokerInteractorCheck : public PokerInteractorBase {
public:
  PokerInteractorCheck(unsigned int id) : PokerInteractorBase(id) { };
  virtual const char* GetControllerName() const { return "PokerInteractorCheck"; }
};

struct PokerInteractorCall : public PokerInteractorBase {
public:
  PokerInteractorCall(unsigned int id) : PokerInteractorBase(id) { };
  virtual const char* GetControllerName() const { return "PokerInteractorCall"; }
};

struct PokerInteractorRaise : public PokerInteractorBase {
public:
  PokerInteractorRaise(unsigned int id) : PokerInteractorBase(id) { };
  virtual const char* GetControllerName() const { return "PokerInteractorRaise"; }  
  bool CanInstallSlider() const;
};

#endif // _pokerinteractor_h
