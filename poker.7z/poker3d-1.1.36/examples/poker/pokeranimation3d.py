#
# Copyright (C) 2004-2006 Mekensleep
#
# Mekensleep
# 24 rue vieille du temple
# 75004 Paris
#       licensing@mekensleep.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
# Authors:
#  Cedric Pinson <cpinson@freesheep.org>
#  Loic Dachary <loic@gnu.org>
#
"""\
Animation manager for poker3d. It handles all animations, except the ones
for which python would be too slow (dynamically generated facial noise
animations for instance).

Can be reloaded dynamically: while running the game, F11 will reload this
file and rebind the relevant python objects to the new code. This mandatory
rebinding is not intuitive but must be done. Part of the code of this file
deal with this issue (stealFrom methods for instance). Most of the time
it should not be an issue. However it MUST be taken in account when adding
new classes or when dealing with any kind of object that might not be
explicitly rebound by the stealFrom functions.

The function registered with setStopCallback won't be re-assigned to the
code reloaded with F11. When their time comes they will execute the code
that existed before F11 was hit. This loophole is considered acceptable
because such callbacks are not currently used to launch animations that
will last forever (or at least for a long time). It should be fixed but
there is not urgency in doing so (2004/10/31).

"""
from pprint import pprint
from random import choice, uniform, randint
from time import time

from twisted.internet import reactor
from twisted.internet import defer

from pokerengine.pokerchips import PokerChips
from pokernetwork.pokernetworkconfig import Config
from pokernetwork.pokerclientpackets import *
from pokerui.pokerchat import PokerChat
from pokerui import pokeranimation

from underware import animated
from underware import lookcardstate

class PokerAnimationPlayer3D(pokeranimation.PokerAnimationPlayer):
    """A poker player seated at a poker table"""
    
    def init(self):
        pokeranimation.PokerAnimationPlayer.init(self)
        self.last_bet_anim=None
        self.animation = None
        self.animationRunning = False
        self.waitIdleAnimation = []
        if self.animations.has_key('idle'):
            self.waitIdleAnimation = self.animations['idle'].getAnimations()
        self.lookingCardsAnimations=[]
        if self.animations.has_key('lookA') and self.animations.has_key('lookB') and self.animations.has_key('lookC'):
            self.lookingCardsAnimations = self.animations['lookA'].getAnimations() + self.animations['lookB'].getAnimations() + self.animations['lookC'].getAnimations()
        self.interactorsAnimations = []
        if self.animations.has_key('bet') and self.animations.has_key('fold') and self.animations.has_key('check'):
            self.interactorsAnimations = self.animations['bet'].getAnimations() + self.animations['fold'].getAnimations() +self.animations['check'].getAnimations()
        self.interactorExcludeList = self.waitIdleAnimation[:]+self.lookingCardsAnimations[:]
        self.schedule_dealer_after_seat_down = None
        self.need_to_call_getpuck =None
        self.look_idle_animation = None
        self.look_start_animation = None
        self.look_end_animation = None
        self.card_look_state = None
        self.schedule_lookcard = None
        self.check_animation = None
        self.bet_animation = None
        self.in_first_person = False
        self.received_pot2player = None
        
    def enable(self):
        self.animation = animated.Animated(self.animation_renderer, self.serial)
        self.chips_animations = animated.Animated(self.animation_renderer, str(self.serial) + "/" + self.animation_bet['anchor'] )
        if self.verbose: print "animation dealer anchor %s"%self.animation_dealer['anchor']
        self.dealer_animations = animated.Animated(self.animation_renderer, str(self.serial) + "/" + self.animation_dealer['anchor'] )
        pokeranimation.PokerAnimationPlayer.enable(self)
        if self.myself:
            self.card_look_state = lookcardstate.CardStateAnimated(self.animation_renderer, self.serial)
            self.card_look_state.unsetLookingCards()

    def initStateAnimation(self):
        self.has_bet=False
        self.changing_dealer=False
        self.looking_card=False
        self.get_pot=False
        self.get_puck=False
        self.freeze_waitidle = False
        self.schedule_dealer = None
        self.need_to_call_getpuck =None
        pokeranimation.PokerAnimationPlayer.initStateAnimation(self)

    def disable(self):
        if self.animation == None:
            return
        self.animation.destroy()
        self.animation = None
        pokeranimation.PokerAnimationPlayer.disable(self)
        
    def destroy(self):
        #print "python destroy player %s" % self.serial
        pokeranimation.PokerAnimationPlayer.destroy(self)
        self.animation.destroy()
        del self.animation

    def resume(self):
        pokeranimation.PokerAnimationPlayer.resume(self)
        self.stopAll()
        if self.sitin_flag:
            self.waitSit(0)
        else:
#            self.waitStand(0)
            self.waitUp(0)

    def stopAll(self):
        """Stop the currently running animations and the scheduled animations.
        """
        if self.animation == None:
            return
        self.animation.stop(animated.ALL)
        pokeranimation.PokerAnimationPlayer.stopAll(self)
        self.stopNoises()

    def stopAnimationList(self,animations,fade):
        """Stop all animation in the specified list
        """
        if self.animation == None:
            return
        for anim in animations:
            self.animation.stop(anim,fade_out=fade)

    def isPlayingAnimationList(self,animations):
        if self.animation == None:
            return
        for anim in animations:
            if self.animation.isAnimationActive(anim):
#                print "found animation %s"%anim
                return True
        return False

    def freezeWaitIdle(self,fade):
        if self.freeze_waitidle is True:
            return
        self.stopAnimationList(self.waitIdleAnimation,fade)
        self.freeze_waitidle = True

    def unfreezeWaitIdle(self):
        self.freeze_waitidle = False

    def scheduleWaitIdle(self, delay):
        min_random = float(self.config.headerGet("/sequence/animation/player/@min_random"))
        max_random = float(self.config.headerGet("/sequence/animation/player/@max_random"))
        when = uniform(min_random + delay, max_random + delay)
        self.callLater(when, self.waitIdle)

    def stopNoises(self):
        self.table.animation_renderer.PythonAccept(PacketPokerAnimationPlayerNoise(serial=self.serial,action="stop"))

    def playNoises(self):
        if not hasattr(self, 'table'): return
        self.table.animation_renderer.PythonAccept(PacketPokerAnimationPlayerNoise(serial=self.serial,action="start"))

    def waitIdle(self):
#        print "Wait idle"
        if self.animation == None:
            return

        if not self.sitin_flag:
            return

        if self.table.stream and self.freeze_waitidle == False:
            # do not play idle animation if an animtion in the list conflict with but
            # but we want to be called later
            excludeList=self.interactorExcludeList + self.interactorsAnimations + ["lookat"] 
            if self.animations.has_key('win'):
                excludeList.extend(self.animations['win'].getAnimations())
            if self.animations.has_key('getPot'):
                excludeList.extend(self.animations['getPot'].getAnimations())

            if self.isPlayingAnimationList(excludeList) == False and self.has_bet == False and self.looking_card == False and self.changing_dealer == False and self.get_pot==False and self.get_puck == False:
                self.stopNoises()
                if self.animations.has_key('idle'):
                    animationSelected=self.animations['idle'].getAnimation().name #choice(self.waitIdleAnimation)
                    timeOfIdle=self.animation.getDuration(animationSelected)
                    self.animation.run(animationSelected,
                                       fade_in = 0.3,
                                       fade_out = 0.3)
                    self.callLater(timeOfIdle, self.playNoises)

        self.scheduleWaitIdle(0)

    def timeoutWarning(self):
        """ Now there is no playIdle so play a wait idle instead
        """
        pass
            
    # todo, insert condition to not conflict with waitIdle, interaction animation, and win
    def isValidToLookCard(self):
        if self.animation == None:
            return
        excludeList = self.interactorsAnimations[:] 
        if self.animations.has_key('win'):
            excludeList.extend(self.animations['win'].getAnimations())
        if self.animations.has_key('loose'):
            excludeList.extend(self.animations['loose'].getAnimations())
        return not self.isPlayingAnimationList(excludeList)

    def isValidToScheduleLookCard(self):
        if self.animation == None:
            return
        checkList = []
        if self.animations.has_key('bet') and self.animations.has_key('check'):
            checkList = self.animations['bet'].getAnimations() + self.animations['check'].getAnimations()
        return self.isPlayingAnimationList(checkList)
        
    def lookCards(self, packet):

        # discard packet LOOK_CARD if player is me because in this case the
        # packet come from the local client and he is looking its cards yet
        # The LOOK_CARD packet is send to inform other player that me is
        # looking its cards
        if packet is not None and self.myself:
            return

        if self.animation == None:
            return

        if self.looking_card is True:
            return
        
        # check if it's not a problem to play LookCard
        if self.isValidToLookCard() is False:
            return

        if self.animations.has_key('lookA') is False:
            return

        self.looking_card = True
        if self.card_look_state is not None:
            self.card_look_state.setStartLookingCards()
            
        # stop all and play fix, it avoids to stop each animation
        # it's a mistake because stopAll removes callback and can
        # broke the send of packet to the client
        #        self.stopAll()
        #        self.waitSit(0)

        if not self.myself:
            self.freezeWaitIdle(0.1)

        anim = self.animations['lookA'].getAnimation()
        self.currentLookFamily = anim.family
        ID = self.animation.run(anim.name,channel = animated.FOREGROUND)
        self.look_start_animation = ID
        self.animation.setStopCallback(ID,self.idleLookCards)

    def idleLookCards(self):
        if self.animation == None:
            return

        if self.looking_card is False:
            return

        # check if it's not a problem to play LookCard
        if self.animations.has_key('lookB') is False:
            return

        if self.isValidToLookCard() is False:
            return

        anim = self.animations['lookB'].getAnimation(family = self.currentLookFamily)
        self.look_idle_animation = self.animation.run(anim.name,
                                                      channel = animated.FOREGROUND,
                                                      length = animated.FOREVER)
        if self.card_look_state is not None:
            self.card_look_state.setLookingCards()
        self.look_start_animation = None
        if not self.myself:
            self.callLater(3, self.stopLookCards)

    def endLookCardCallback(self):

        # special case for other players, because
        # wait idle animation are managed by the state
        # if we are or not in first person
        if not self.myself:
            self.unfreezeWaitIdle()
            
        self.looking_card = False
        self.look_end_animation = None
        if self.card_look_state is not None:
            self.card_look_state.unsetLookingCards()

    def stopLookCards(self):
        if not hasattr(self, 'table'): return
        if self.animation == None:
            return

        if self.looking_card is False:
            if self.verbose:
                print "pokeranimation3d:stopLookCards try to stop look card, but the player is not seeing its cards (looking_card is false)"
            return

        if self.animations.has_key('lookC') is False:
            return

        # check if it's not a problem to play LookCard
        if self.isValidToLookCard() is False:
            return

        if self.look_start_animation is not None:
            self.animation.unsetStopCallback(self.look_start_animation)
            self.animation.stop(self.look_start_animation,
                                fade_out = 0.2)

        if self.look_idle_animation is not None:
            self.animation.stop(self.look_idle_animation,
                                fade_out = 0.2)
        
        anim = self.animations['lookC'].getAnimation(family=self.currentLookFamily)
        self.look_end_animation = self.animation.run(anim.name,
                                channel = animated.FOREGROUND,
                                fade_in = 0.2)
        self.animation.setStopCallback(self.look_end_animation, self.endLookCardCallback)
        self.look_idle_animation = None
        self.look_start_animation = None

    def resetLookCardsState(self):
        if not hasattr(self, 'table'): return
        if self.animation == None:
            return

        # for state stop
        if self.look_start_animation is not None:
            self.animation.unsetStopCallback(self.look_start_animation)
        self.endLookCardCallback()

        # for state idle
        self.look_idle_animation = None
        self.look_start_animation = None

        # init state from lookcard
        self.looking_card = False

    def resetScheduledLookCards(self):
        # remove potential sceduled lookcard
        if self.bet_animation is not None:
            self.animation.unsetStopCallback(self.bet_animation)
        if self.check_animation is not None:
            self.animation.unsetStopCallback(self.check_animation)
        self.schedule_lookcard = None
        
    def sitoutAction(self):
        if not hasattr(self, 'table'): return
        # check if we need to deley the sitin
        # it works for fold but not for the win sequence
        candidate_animation = self.animations['win'].getAnimations()
        candidate_animation.extend(self.animations['fold'].getAnimations())
        if self.isPlayingAnimationList(candidate_animation) == True:
            self.callLater(0.5,self.sitoutAction)
            return

        if len(self.sitin_stack) > 0:
            if self.sitin_stack[-1]!="sitout":
                if len(self.sitin_stack) > 1:
                    self.sitin_stack.pop()
                else:
                    self.sitin_stack.append("sitout")
        else:
            self.sitin_stack.append("sitout")
            self.sitin_stack.append("sitout")
            self.manageSitinSitout()

    def sitoutCallback(self):
        #print "sitoutCallback"
        self.animation_renderer.PythonAccept(PacketPokerSitOut(game_id = self.table.game.id, serial = self.serial))

    def sitoutEndCallback(self):
        if (self.sitin_flag == False):
            self.animation_renderer.PythonAccept(PacketPokerDisplayNode(game_id = self.table.game.id, name = "sitoutEnd", state = self.serial, style = "", selection = ""))

    def sitout(self):

        if self.animation == None:
            return 0
        
        self.stopAll()
        result=0
        if self.table.stream:
            #
            # The player is siting up because he was previously seated
            #
            if self.animations.has_key('seatUp'):
                anim = self.animations['seatUp'].getAnimation().name
                result = self.animation.run(anim)
                delay = self.animation.getDuration(anim)
                #self.setPlayerDelay(delay)
                #print "seatUp"
                self.sitoutCallback()
                #self.setAnimationCallback(result, self.sitoutEndCallback)

                # notify when the sitout animation ends
                self.callLater(delay, self.sitoutEndCallback)                
                #self.animation.setStopCallback(result, self.sitoutEndCallback)
        else:
            #
            # The player was already standing up when we arrived at the table
            #
            delay = 0
#        self.waitStand(0)
        self.waitUp(0)
        return result

    def setAnimationCallback(self, animation, callback):
        self.animation.setStopCallback(animation, callback)

    def sitinCallback(self):
        #print "sitinCallback"
        self.animation_renderer.PythonAccept(PacketPokerSit(game_id = self.table.game.id, serial = self.serial))

    def checkActionAfterSitin(self):
        if not hasattr(self, 'table'): return
        if self.animation == None: return
        # manage dealing while the player he is siting
        if self.schedule_dealer != None:
            (size, player, game_id) = self.schedule_dealer
            self.schedule_dealer = None
            self.changeDealer(size, player, game_id)

        if self.need_to_call_getpuck != None:
            (min_duration, game_id, player_dealt) = self.need_to_call_getpuck
            self.need_to_call_getpuck = None
            self.callLater(min_duration, self.getPuck, game_id, player_dealt)
            self.setPlayerDelay(min_duration)
        
    def sitin(self):

        if self.animation == None:
            return 0
        #
        # Here we should take in account the case when the
        # player is in the middle of the sitout animation as
        # a result of the PokerAnimationPlayer::UpdateSittingOut interaction.
        #
        result=0
        # self.stopAll()

        if self.table.stream:
            #
            # The player is siting down because he was previously standing
            #
            anim = self.animations['seatDown'].getAnimation().name
            result = self.animation.run(anim,fade_in=0.2)
            duration = self.animation.getDuration(anim)
            delay = duration - 0.3
            self.sitinCallback()
            #self.setPlayerDelay(duration)
            
            #self.setAnimationCallback(result, self.sitinCallback)
            self.callLater(delay, self.checkActionAfterSitin)
                
            tostop=[]
            if self.animations.has_key('upIdle'):
                tostop=tostop + self.animations["upIdle"].getAnimations()
            if self.animations.has_key('fixUp'):
                tostop=tostop + self.animations['fixUp'].getAnimations()
            if self.animations.has_key('idle'):
                tostop=tostop + self.animations['idle'].getAnimations()

            self.stopAnimationList(tostop,0.2)
        else:
            #
            # The player was already seated when we arrived at the table
            #
            self.stopAll()
            delay = 0
        self.waitSit(delay)
        return result

    def waitSit(self, delay):
        if self.animation == None:
            return
        if self.animations.has_key('fix'):
            anim = self.animations['fix'].getAnimation().name
            self.animation.run(anim,
                               channel = animated.BACKGROUND,
                               length = animated.FOREVER,
                               delay = delay)

        if self.animations.has_key('breath'):
            anim = self.animations['breath'].getAnimation().name
            self.animation.run(anim,
                               channel = animated.BACKGROUND,
                                length = animated.FOREVER,
                               fade_in = 0.3,
                               fade_out = 0.3)
        self.scheduleWaitIdle(delay)
        self.playNoises()

    def waitUp(self, delay):
        if self.animation == None:
            return
        if self.animations.has_key('fixUp'):
            anim = self.animations['fixUp'].getAnimation().name
            self.animation.run(anim,
                               channel = animated.BACKGROUND,
                               length = animated.FOREVER,
                               delay = delay)
        self.stopNoises()
        self.scheduleStandIdle(delay)
        
    def check(self):
        if self.animation == None:
            return
        self.last_bet_anim = None
        self.resetLookCardsState()
        self.stopAnimationList(self.interactorExcludeList,0.2)
        if self.animations.has_key('check'):
            anim = self.animations['check'].getAnimation().name
            self.check_animation = self.animation.run(anim,
                                                      fade_in = 0.2,
                                                      fade_out = 0.3)
            if self.schedule_lookcard is not None:
                self.animation.setStopCallback(self.check_animation, self.playerMeLookCards, self.schedule_lookcard[0], self.schedule_lookcard[1])

            
    def normalize(self, value):
        chips_values = self.table.scheduler.chips_values
        game = self.table.game
        if game.unit in chips_values:
            chips_values = chips_values[chips_values.index(game.unit):]
        else:
            chips_values = []
        return PokerChips(chips_values, value).tolist()
        
    def betCallback(self, name, chips):
        if not hasattr(self, 'table'): return
        if self.animation == None: return
        if not self.table.stream: return
        self.has_bet = False
        self.bet_animation = None
        packet = PacketPokerAnimationPlayerChips(game_id = self.table.game.id,
                                                 serial = self.serial,
                                                 animation = name,
                                                 state = "hide",
                                                 chips = self.normalize(self.player_bet_stack))
        self.animation_renderer.PythonAccept(packet)
        

    def bet(self, game_id, chips):
        if self.animation == None:
            return
        if not self.table.stream: return
        self.resetLookCardsState()
        self.stopAnimationList(self.interactorExcludeList,0.2)
        if self.animations.has_key('bet'):
            anim = self.animations['bet'].getAnimation().name
            if len(chips) < 4:
                anim = "bet"
            elif len(chips) < 6:
                anim = "betMore"
            else:
                anim = "betAllIn"
            self.last_bet_anim = anim
            self.has_bet = True
            self.bet_animation = self.animation.run(anim,
                                                    fade_in = 0.2,
                                                    fade_out = 0.3,
                                                    weight = 10000)

            anim_name = self.animation_bet[anim]
            packet = PacketPokerAnimationPlayerChips(game_id = game_id,
                                                     serial = self.serial,
                                                     animation = anim,
                                                     state = "show",
                                                     chips = chips)
            self.animation_renderer.PythonAccept(packet)
            duration = self.chips_animations.getDuration(str(anim_name))
            if self.verbose:
                print "pokeranimation3d:bet Duration of animation %s %d" % (anim,duration)
            self.chips_animations.run(anim_name)
            self.callLater(duration, self.betCallback, anim, self.normalize(self.player_bet_stack))
            if self.schedule_lookcard is not None:
                self.animation.setStopCallback(self.bet_animation, self.playerMeLookCards, self.schedule_lookcard[0], self.schedule_lookcard[1])
                

    def fold(self, game_id):
        if not hasattr(self, 'table'): return
        if not self.table.stream: return
        self.has_bet = False
        self.last_bet_anim = None
        self.resetLookCardsState()
        self.resetScheduledLookCards()
        self.stopAnimationList(self.interactorExcludeList+["lookat"],0.1)
        if self.animations.has_key('fold'):
            anim=self.animations['fold'].getAnimation().name
            packet = PacketPokerAnimationPlayerFold(game_id = game_id,
                                                    serial = self.serial,
                                                    animation=anim)
            self.animation_renderer.PythonAccept(packet)
            delay = self.animation.getDuration(anim)
            self.callLater(delay + 0.5, lambda: pokeranimation.PokerAnimationPlayer.fold(self, game_id))
        else:
            pokeranimation.PokerAnimationPlayer.fold(self, game_id)            
        
    def foldEndCallback(self, game_id):
        if self.animation == None:
            return
        self.animation.run("",
                           channel = animated.FOREGROUND,
                           length = animated.ONCE,
                           fade_in = 0.1,
                           fade_out = 0.8)

        #
        # WATCH OUT : this function may be run after the animation_renderer
        # is stopped or after the table for which the serial was valid
        # is gone. Make sure the functions called are properly dealing
        # with these border cases.
        #
        packet = PacketPokerDisplayCard(game_id = game_id,
                                        serial = self.serial,
                                        index = [0,1,2,3],
                                        display = 0)
        self.animation_renderer.PythonAccept(packet)


    def showdownDelta(self, delta, is_delta_max, is_delta_min, chips):
        # print "player %s delta %s chips %s" %(self.serial, delta, chips)
        if delta < 0:
            #self.lose()
            self.scheduleEndGameAction("lose", delta, chips)
        elif delta >= 0:
            #self.scheduleWin(delta)
            self.scheduleEndGameAction("win", delta, chips)

    def lose(self, is_get_chips):
        if self.animation == None:
            return
        if not self.table.stream: return
        #check before to stop animation that could be conflict with win animation
        exclude=self.interactorsAnimations + self.interactorExcludeList
        self.stopAnimationList(exclude,0.1)
        if self.animations.has_key('lose'):
            anim = self.animations['lose'].getAnimation().name
            id = self.animation.run(anim,
                                    channel = animated.FOREGROUND,
                                    length = animated.ONCE,
                                    fade_in = 0.1,
                                    fade_out = 0.8)


    def scheduleEndGameAction(self, animation_key, delta, chips):
        diff = time()-self.last_end_round
        base_time = 2
        limit_time = base_time
        if self.last_bet_anim is not None:
            limit_time = limit_time + self.animation.getDuration(self.last_bet_anim) / 2

        if self.animations.has_key(animation_key):
            anim = self.animations[animation_key].getAnimation().name
            anim_time = self.animation.getDuration(anim)
            min_time = limit_time-anim_time
            # print "%s diff time %f limit_time %f min time %f anim time %f"%(str(self),diff,limit_time,min_time,anim_time)
            if min_time > 0 :
                self.callLater(min_time, self.endGameAction, delta, anim, chips)
            else:
                self.endGameAction(chips, anim, chips)


    def endGameAction(self, delta, anim, chips):
        if not hasattr(self, 'table'): return
        if self.animation == None: return
        if not self.table.stream: return

        animation_standup = self.animations['fixUp'].getAnimations()
        if self.isPlayingAnimationList(animation_standup):
            return
        
        #check before to stop animation that could be conflict with win animation
        self.resetLookCardsState()
        self.resetScheduledLookCards()
        exclude = self.interactorsAnimations + self.interactorExcludeList + self.lookingCardsAnimations
        self.stopAnimationList(exclude, 0.1)
        id = self.animation.run(anim,
                                channel = animated.FOREGROUND,
                                length = animated.ONCE,
                                fade_in = 0.1,
                                fade_out = 0.8)
        self.animation.setStopCallback(id, self.endGameActionCallback, delta, chips)

    def endGameActionCallback(self, delta, chips):
        if (chips <= 0):
            return
        if self.animation == None:
            return
        if not self.table.stream: return
        self.getPot(chips)
        if self.animations.has_key('getPot'):
            anim = self.animations['getPot'].getAnimation().name
            self.animation.run(anim,fade_in = 0.1)

    def getPotCallback(self):
        if not hasattr(self, 'table'): return
        if self.animation == None: return
        if not self.table.stream: return
        packet = PacketPokerAnimationPlayerChips(game_id=self.table.game.id,
                                               serial=self.serial,
                                               animation="getPot",
                                               state="hide",
                                               chips=[])

        self.animation_renderer.PythonAccept(packet)
        self.get_pot = False

        # manage dealing while the player he is siting
        if self.schedule_dealer != None:
            (size, player, game_id) = self.schedule_dealer
            self.schedule_dealer = None
            self.changeDealer(size, player, game_id)
        

    def getPot(self,chips):
        if not self.table.stream: return
        exclude = self.interactorsAnimations + self.interactorExcludeList #self.waitIdleAnimation
        self.stopAnimationList(exclude,0.1)
        anim_name = 'getPot'
        game = self.table.game
        if type(chips) is IntType or type(chips) is LongType:
            chips = self.normalize(chips)
        packet = PacketPokerAnimationPlayerChips(game_id=self.table.game.id,
                                               serial=self.serial,
                                               animation=anim_name,
                                               state="show",
                                               chips = chips)
        osg_name = self.animation_bet[anim_name]
        self.animation_renderer.PythonAccept(packet)
        duration = self.chips_animations.getDuration(osg_name)
        anim = self.chips_animations.run(osg_name)
        self.callLater(duration, self.getPotCallback)
        self.get_pot = True

    def waitStand(self):
        if not hasattr(self, 'table'): return
        if self.animation == None: return
        if self.sitin_flag:
            return

        excludeList = []
        if self.animations.has_key("sitDown"):
            excludeList = self.animations["sitDown"].getAnimations()
        if self.animations.has_key("upIdle"):
            excludeList = excludeList + self.animations["upIdle"].getAnimations()

        if self.isPlayingAnimationList(excludeList) == False:
            if self.animations.has_key('upIdle'):
                anim = self.animations['upIdle'].getAnimation().name
                self.animation.run(anim,
                                   fade_in = 0.3,
                                   fade_out = 0.3)
        self.stopNoises()
        self.scheduleStandIdle(0)

    def scheduleStandIdle(self, delay):
        min_random = float(self.config.headerGet("/sequence/animation/player/@min_random"))
        max_random = float(self.config.headerGet("/sequence/animation/player/@max_random"))
        when = uniform(min_random + delay, max_random + delay)
        self.callLater(when, self.waitStand)

    def chat(self, packet):
        emoteAnimation = packet.word
        if self.animations.has_key(emoteAnimation):
            if (self.isPlayingAnimationList(self.lookingCardsAnimations) == False
                and self.isPlayingAnimationList(self.interactorsAnimations) == False):
                self.stopAnimationList(self.waitIdleAnimation, 0.2)
                anim = self.animations[emoteAnimation].getAnimation().name
                result = self.animation.run(anim, 0.2)
                if self.verbose: print "%s played: %s" % (emoteAnimation, str(result))
            else:
                if self.verbose: print "%s not played" % emoteAnimation
        else:
            if self.verbose: print "%s not found" % emoteAnimation


    def getPuck(self, game_id, from_player):
        if self.verbose: print "DEALER: get puck"
        if not hasattr(self, 'table'): return
        if self.animation == None: return
        if not self.table.stream: return

        self.stopAnimationList(self.interactorExcludeList,0.2)
        self.get_puck = True
        if self.animations.has_key('puckGet'):
            packet_button=PacketPokerAnimationDealerButton(game_id=game_id,
                                                          serial=self.serial,
                                                          state="show")
            self.animation_renderer.PythonAccept(packet_button)
            packet_button_from_player=PacketPokerAnimationDealerButton(game_id=game_id,
                                                                       serial=from_player.serial,
                                                                       state="hide")
            self.animation_renderer.PythonAccept(packet_button_from_player)
            from_player.changing_dealer = False
            anim=self.animations['puckGet'].getAnimation().name
            id=self.animation.run(anim,
                                  fade_in = 0.2,
                                  fade_out = 0.2)
            self.animation.setStopCallback(id, self.changeDealerCallback,game_id)
            anim_name = self.animation_dealer['buttonGet']
            self.dealer_animations.run(anim_name)
            anim_duration = self.animation.getDuration(anim)
            self.setPlayerDelay(anim_duration)
        

    def changeDealerCallback(self,game_id):
        packet = PacketPokerAnimationDealerChange(game_id=game_id,
                                                serial=self.serial,
                                                state="show")
        self.animation_renderer.PythonAccept(packet)
        packet_button = PacketPokerAnimationDealerButton(game_id=game_id,
                                                       serial=self.serial,
                                                       state="hide")
        self.animation_renderer.PythonAccept(packet_button)
        self.get_puck = False

    def changeDealer(self, size, player, game_id):
        if self.verbose: print "DEALER: change dealer"
        if self.animation == None:
            return
        # invalid case
        if size == 0:
            return
        
        if not self.table.stream: return
        self.stopAnimationList(self.interactorExcludeList,0.2)
        self.changing_dealer=True
        anim=""
        if size==1:
            if self.animations.has_key('puckPassNear'):
                anim=self.animations['puckPassNear'].getAnimation().name
        elif size > 1:
            if self.animations.has_key('puckPassFar'):
                anim=self.animations['puckPassFar'].getAnimation().name

        name = "buttonPass%d"%size
        anim_name = self.animation_dealer[name]
        if self.verbose: print "DEBUG ANIM BUTTON %s" % anim_name
        packet_button = PacketPokerAnimationDealerButton(game_id = game_id,
                                                         serial = self.serial,
                                                         state="show")
        self.animation_renderer.PythonAccept(packet_button)

        packet = PacketPokerAnimationDealerChange(game_id = game_id,
                                                  serial = self.serial,
                                                  state = "hide")
        self.animation_renderer.PythonAccept(packet)
        duration = self.dealer_animations.getDuration(str(anim_name))
        id = self.animation.run(anim,fade_in = 0.2,fade_out = 0.2,weight = 10000)
        self.dealer_animations.run(anim_name)

        player_seatdown = player.isPlayingAnimationList([player.animations['seatDown'].getAnimation().name])
        player.need_to_call_getpuck = None
        if player_seatdown == True:
            if self.verbose: print "DEALER: change dealer says schedule getPuck after sitin"
            player.need_to_call_getpuck = (duration, game_id, self)
        else:
            if self.verbose: print "DEALER: change dealer says getPuck"
            self.callLater(duration, player.getPuck, game_id, self)

        # block packet when dealing
        anim_duration = self.animation.getDuration(anim)
        self.setPlayerDelay(anim_duration)

        
    def scheduleChangeDealer(self, size, player, game_id):
        player_seatdown = self.isPlayingAnimationList([self.animations['seatDown'].getAnimation().name])
        get_pot = self.isPlayingAnimationList([self.animations['getPot'].getAnimation().name])
        self.schedule_dealer = None
        if player_seatdown == True or get_pot == True:
            if self.verbose: print "DEALER: scheduleChangeDealer says schedule change dealer"
            self.schedule_dealer = (size, player, game_id)
        else:
            if self.verbose: print "DEALER: scheduleChangeDealer says change dealer"
            self.changeDealer(size, player, game_id)

    def playerMeLookCards(self, packet, protocol):
        if self.verbose:
            print "playerMeLookCards"
        self.schedule_lookcard = None
        self.lookCards(None)
        protocol.sendPacket(packet)
        self.bet_animation = None
        self.check_animation = None
        
    def schedulePlayerMeLookCards(self, packet, protocol):
        if self.check_animation is not None:
            self.animation.setStopCallback(self.check_animation, self.playerMeLookCards, packet, protocol)
        elif self.bet_animation is not None:
            self.animation.setStopCallback(self.bet_animation, self.playerMeLookCards, packet, protocol)
        self.schedule_lookcard = (packet,protocol)

    def setInFirstPerson(self, state):
        self.in_first_person = state
        if state == True:
            self.freezeWaitIdle(0.2)
        else:
            self.unfreezeWaitIdle()
            self.resetScheduledLookCards()


    def pot2player(self, packet):
        self.received_pot2player = packet
    


class PokerAnimationTable3D(pokeranimation.PokerAnimationTable):

    def __init__(self, *args, **kwargs):
        pokeranimation.PokerAnimationTable.__init__(self, *args, **kwargs)
        self.dealer = None
        self.PokerAnimationPlayerType = PokerAnimationPlayer3D
        self.can_look_card = False
        self.game_canceled = False

    def createPlayer(self, protocol, packet):
        if not self.scheduler.cacheAnimationFiles.has_key(packet.url):
            datadir = self.settings.headerGet("/settings/data/@path")
            config = Config([datadir])
            file2load = packet.url + "/animations.xml"
            config.load(file2load)
            if not config.doc:
                print "PokerAnimationScheduler::playerArrive CRITICAL file %s not found"%file2load
            cfg=readAnimationFile(config)
            self.scheduler.cacheAnimationFiles[packet.url]=cfg
        animations=self.scheduler.cacheAnimationFiles[packet.url]

        anchor=self.config.headerGet("/sequence/seat/animationBetPlayer[@skinUrl=\"%s\"]/@anchor"%packet.url)
        if anchor is None:
            print "Error anchor not found for animationBetPlayer for skin %s"%packet.url
        
        mapNameList=self.config.headerGetList("/sequence/seat/animationBetPlayer[@skinUrl=\"%s\"]/animation/@map"%packet.url)
        mapAnimationNameList=self.config.headerGetList("/sequence/seat/animationBetPlayer[@skinUrl=\"%s\"]/animation/@name"%packet.url)
        if len(mapNameList) == 0 or len(mapAnimationNameList) == 0:
            print "No animation bet/getPot found for skin %s in config file"%packet.url

        if len(mapNameList) != len(mapAnimationNameList) :
            print "Error in xml file number of tag @map is not equal to @name"

        bet_animations={}
        for i in range(len(mapNameList)):
            bet_animations[mapNameList[i]]=mapAnimationNameList[i]
        bet_animations['anchor']=anchor


        anchor=self.config.headerGet("/sequence/seat/animationChangeDealer[@skinUrl=\"%s\"]/@anchor"%packet.url)
        if anchor is None:
            print "Error anchor not found for animationChangeDealer for skin %s"%packet.url
        
        mapNameList=self.config.headerGetList("/sequence/seat/animationChangeDealer[@skinUrl=\"%s\"]/animation/@map"%packet.url)
        mapAnimationNameList=self.config.headerGetList("/sequence/seat/animationChangeDealer[@skinUrl=\"%s\"]/animation/@name"%packet.url)
        if len(mapNameList) == 0 or len(mapAnimationNameList) == 0:
            print "No animation changeDealer/getPuck found for skin %s in config file"%packet.url

        if len(mapNameList) != len(mapAnimationNameList) :
            print "Error in xml file number of tag @map is not equal to @name"

        dealer_animations={}
        for i in range(len(mapNameList)):
            dealer_animations[mapNameList[i]]=mapAnimationNameList[i]
        dealer_animations['anchor']=anchor
        
        player = pokeranimation.PokerAnimationTable.createPlayer(self, protocol, packet)
        player.animations = animations
        player.animation_bet = bet_animations
        player.animation_dealer = dealer_animations
        return player

    def gameCanceled(self, protocol, packet):
        # call if the player with the big blind refuse to pay it (the game is canceled)
         self.game_canceled = True

    def endRoundLast(self, protocol, packet):
        if self.game_canceled is True:
            for (serial, player) in self.serial2player.iteritems():
                if player.sitin_flag:
                    if player.received_pot2player is not None:
                        player.showdownDelta(0, None, None, player.received_pot2player.chips)
                player.received_pot2player = None
        self.game_canceled = False

    def tableDealer(self,protocol,packet):
        prev_dealer = packet.previous_dealer
        dealer = packet.dealer
        print "dealer %d next dealer %d " % (prev_dealer,dealer)

        if prev_dealer == -1:
            if self.verbose: print "DEALER: return prev_dealer = -1"
            return

        seat = self.seats[prev_dealer]
        if not self.serial2player.has_key(seat):
            if self.verbose: print "DEALER: return because the previous dealer is not yet here"
            return
        
        nb_seats = len(self.seats)
        size = ((dealer-prev_dealer)+2*nb_seats)%nb_seats
        player_dealer_change = self.serial2player[seat]
        dealer_seat = self.seats[dealer]
        player = self.serial2player[dealer_seat]

        # i added animation seatup check to avoid dealer change wile seatup
        anim_seatup = player_dealer_change.animations['seatUp'].getAnimation().name
        player_situp = player_dealer_change.isPlayingAnimationList([anim_seatup])
        if player_dealer_change.sitin_flag == False:
            if self.verbose: print "DEALER: return because the dealer is not yet seated"
            return

        if player_situp == True:
            if self.verbose: print "DEALER: return because the dealer % is playing situp" % player_dealer_change.serial
            return

        #player_dealer_change.changeDealer(size,player,packet.game_id)
        player_dealer_change.scheduleChangeDealer(size, player, packet.game_id)

    def maybeMeLookCards(self, protocol, packet):
        for (serial, player) in self.serial2player.iteritems():
            if player.myself is True:
                if self.verbose: print "packet maybe look card %s %s" % (packet.state,packet.when)
                if packet.when == "scheduled":
                    if packet.state == "start":
                        mypacket = PacketPokerLookCards(game_id = packet.game_id, serial = serial)
                        player.schedulePlayerMeLookCards(mypacket, protocol)
                        if self.verbose: print "packet look card %s scheduled" % packet.state
                    else:
                        if self.verbose: print "CRITICAL PokerAnimationTable3D::maybeMeLookCards inconsistent state to stop look cards in scheduled mode !!!!"
                elif player.isValidToLookCard() is True:
                    if packet.state == "start":
                        mypacket = PacketPokerLookCards(game_id = packet.game_id, serial = serial)
                        player.playerMeLookCards(mypacket, protocol)
                        if self.verbose: print "packet look card %s" % packet.state
                    elif packet.state == "stop":
                        if player.look_end_animation is None: # if already ending look card
                            player.stopLookCards()
                            if self.verbose: print "packet look card %s" % packet.state
                        else:
                            if self.verbose: print "CRITICAL PokerAnimationTable3D::maybeMeLookCards already stoping endlookcard, check if it this state is consistent state %s" % packet.state
                    else:
                        print "CRITICAL PokerAnimationTable3D::maybeMeLookCards packet has unkown state %s" % packet.state
                # can't look card now we delay it after interaction
                elif packet.state == "start":
                    mypacket = PacketPokerLookCards(game_id = packet.game_id, serial = serial)
                    player.schedulePlayerMeLookCards(mypacket, protocol)
                    if self.verbose: print "packet look card %s scheduled" % packet.state
                elif  packet.state == "stop":
                    # it means there was a sceduled startLookCard the player is betting or checking and want to pass in third
                    # person. So we cancel the scheduled startLookCard
                    player.resetScheduledLookCards()
                    if self.verbose: print "reset scheduled look card"
                break
                
                    
    def executePythonAnimationAction(self, protocol, packet):
        animation_name = packet.animation
        player = self.serial2player[packet.serial]
        if self.verbose: print "PYTHON_ANIMATION %s" % animation_name
        if animation_name == "stopWaitIdle":
            if self.verbose: print "stopWaitIdleProcess"
            player.freezeWaitIdle(0)
        elif animation_name == "startWaitIdle":
            if player.in_first_person is True:
                if self.verbose: print "CRITICAL PokerAnimationTable3D::executePythonAnimationAction inconsistent state, in first person and want to enable waitidle !!!!"
                return
            player.unfreezeWaitIdle()
            
    def setInFirstPerson(self, protocol, packet):
        for (serial, player) in self.serial2player.iteritems():
            if player.myself is True:
                state = packet.state
                if self.verbose: print "PYTHON_SET_IN_FIRST_PERSON %s" % state
                player.setInFirstPerson(state == "true")

        
class PokerAnimationScheduler3D(pokeranimation.PokerAnimationScheduler):
    def __init__(self, *args, **kwargs):
        pokeranimation.PokerAnimationScheduler.__init__(self, *args, **kwargs)
        self.received2function[PACKET_POKER_DEALER] = self.tableDealer
        self.received2function[PACKET_POKER_PYTHON_ANIMATION] = self.executePythonAnimationAction
        self.received2function[PACKET_POKER_PLAYER_ME_LOOK_CARDS] = self.maybeMeLookCards
        self.received2function[PACKET_POKER_PLAYER_ME_IN_FIRST_PERSON] = self.setInFirstPerson
        self.received2function[PACKET_POKER_CANCELED] = self.gameCanceled
        self.received2function[PACKET_POKER_END_ROUND_LAST] = self.endRoundLast
        self.animation_renderer.SetPyScheduler(self)
        self.cacheAnimationFiles = {}
        self.PokerAnimationPlayerType = PokerAnimationPlayer3D
        self.PokerAnimationTableType = PokerAnimationTable3D

    def endRoundLast(self, protocol, packet):
        if not self.id2table.has_key(packet.game_id):
            print "PokerAnimationScheduler::endRoundLast unknown game id (%d) " % packet.game_id
        self.id2table[packet.game_id].endRoundLast(protocol, packet)

    def gameCanceled(self, protocol, packet):
        if not self.id2table.has_key(packet.game_id):
            print "PokerAnimationScheduler::gameCanceled unknown game id (%d) " % packet.game_id
        self.id2table[packet.game_id].gameCanceled(protocol, packet)

    def tableDealer(self, protocol, packet):
        if not self.id2table.has_key(packet.game_id):
            print "PokerAnimationScheduler::tableDealder unknown game id (%d) " % packet.game_id
        self.id2table[packet.game_id].tableDealer(protocol, packet)

    def executePythonAnimationAction(self, protocol, packet):
        if not self.id2table.has_key(packet.game_id):
            print "PokerAnimationScheduler::executePythonAnimationAction unknown game id (%d) " % packet.game_id
        self.id2table[packet.game_id].executePythonAnimationAction(protocol, packet)

    def maybeMeLookCards(self, protocol, packet):
        if not self.id2table.has_key(packet.game_id):
            print "PokerAnimationScheduler::maybeMeLookCards unknown game id (%d) " % packet.game_id
        self.id2table[packet.game_id].maybeMeLookCards(protocol, packet)

    def setInFirstPerson(self, protocol, packet):
        if not self.id2table.has_key(packet.game_id):
            print "PokerAnimationScheduler::setInFirstPerson unknown game id (%d) " % packet.game_id
        self.id2table[packet.game_id].setInFirstPerson(protocol, packet)

def create(animation_renderer, config, settings):
    return PokerAnimationScheduler3D(animation_renderer = animation_renderer,
                                     config = config,
                                     settings = settings)

class AnimationActionEntry:
    def __init__(self,animation,family,freq):
        self.name = animation
        self.family=family
        self.start_freq=0
        self.freq=freq

    
class AnimationAction:
    def __init__(self):
        self.family_entries = {}
        self.max_weight = 0
        
    def generateList(self,animations):
        # build a list that follow proba
        self.family_entries[0]=[]
        nbElements=len(animations)
        start_freq=0
        for i in range(nbElements):
            if animations[i].family is not 0:
                if self.family_entries.has_key(animations[i].family) is False:
                    self.family_entries[animations[i].family]=[]
                self.family_entries[animations[i].family].append(animations[i])
            animations[i].start_freq=start_freq
            start_freq=start_freq+animations[i].freq
            self.family_entries[0].append(animations[i])
        # test to result
        if nbElements > 0:
            if start_freq != 100:
                print "WARNING sum of weight does not make 100\%"
        else:
            print "no entry for this action"
        self.max_weight=start_freq-1    
        
    def getAnimations(self):
        res=[]
        for i in self.family_entries[0]:
            res.append(i.name)
        return res

    def getAnimation(self, *args, **kwargs):
        family=kwargs.get('family', 0)
        if family == 0:
            res=randint(0, self.max_weight)
            for i in self.family_entries[0]:
                if (i.start_freq < res) and ((i.start_freq+i.freq) > res ) :
                    return i

        return choice(self.family_entries[family])

def readAnimationFile(config):
   actions={}
   action_list=config.headerGetList("/actions/action/@name")
   for i in action_list:
       if len(i) > 1:
           items_name=config.headerGetList("/actions/action[@name='" + i + "']/item/@name")
           items_freq=config.headerGetList("/actions/action[@name='" + i + "']/item/@weight")

           if len(items_name) > 0:
               if len(items_freq) == len(items_name) :
                   # get all items for an action
                   list_entries=[]
                   for name in range(len(items_name)):
                       family=config.headerGet("/actions/action[@name='" + i + "']/item[@name='" + items_name[name] + "']/@family")
                       if len(family) > 0 :
                           family=int(family)
                       else:
                           family=0
                       list_entries.append(AnimationActionEntry(items_name[name],family,int(items_freq[name])))

                   # dummy animation
                   action=AnimationAction()
                   #print "Generate animations list for action %s"%(i)
                   action.generateList(list_entries)
                   actions[i]=action
               else:
                   print "*CRITICAL* there is a syntax error in config file %s,skipping action %s"%(file,str(i))
           else:
               print "Warning generate animations list: entry %s empty so skiped"%(str(i))

       else:
           print "Warning entry %s skipped"%(str(i))

   return actions
       
