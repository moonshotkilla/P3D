#include <sstream>
#include <osg/Array>
#include <osg/Vec4>
#include <osg/Geometry>
#include "PokerApplication.h"

struct PokerDebug2D
{

	struct Text : osg::PositionAttitudeTransform
	{
		osg::ref_ptr<osg::Geode> mGeode;
		osg::ref_ptr<osgText::Text> mText;
		Text()
		{
			mGeode = new osg::Geode;
			mText = new osgText::Text;
			addChild(mGeode.get());
			mGeode->addDrawable(mText.get());


      osg::ref_ptr<osgDB::ReaderWriter::Options> options = new osgDB::ReaderWriter::Options;
      osgText::Font* font = dynamic_cast<osgText::Font*> (osgDB::readObjectFile("FreeSans.ttf", options.get()));      
      mText->setFont(font);			
      mText->setCharacterSize(1);
      mText->setPosition(osg::Vec3(0.0f, 0.0f, 0.0f));
      mText->setAlignment(osgText::Text::CENTER_CENTER);
      mText->setColor(osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f));

			osg::StateSet* stateset = getOrCreateStateSet();
			osg::Material* material = new osg::Material;
			material->setColorMode(osg::Material::EMISSION);
			material->setEmission(osg::Material::FRONT_AND_BACK, osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f));
			stateset->setAttributeAndModes(material);
			stateset->setMode(GL_LIGHTING, osg::StateAttribute::ON);

			setScale(osg::Vec3(0.05f, 0.05f, 0.05f));
			setNodeMask(0);
		}
		void setText(const std::string& text)
		{
			setNodeMask(0xffffffff);
			mText->setText(text);
		}
		void setColor(const osg::Vec4& color)
		{
			mText->setColor(color);
		}
	};

  enum 
    {
      NumberOfLine = 100,
      NumberOfPoint = NumberOfLine * 2
    };
  osg::ref_ptr<osg::Vec4Array> mColor;
  osg::ref_ptr<osg::Vec3Array> mVertice;
  osg::ref_ptr<osg::Geometry> mGeom;
	std::vector< osg::ref_ptr<Text> > mTexts;
	int mTextsIndex;
  bool mInited;
  int mIndex;
  PokerDebug2D() : mInited(false), mIndex(0)
  {
  }
  void DrawBox(const osg::Vec3& in, const osg::Vec3& out, const osg::Vec4& color = osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f))
  {
    DrawLine(osg::Vec3(in), osg::Vec3(out.x(), in.y(), 0.0f), color);
    DrawLine(osg::Vec3(in), osg::Vec3(in.x(), out.y(), 0.0f), color);
    DrawLine(osg::Vec3(in.x(), out.y(), 0.0f), osg::Vec3(out), color);
    DrawLine(osg::Vec3(out.x(), in.y(), 0.0f), osg::Vec3(out), color);
  }
  void DrawLine(const osg::Vec3& in, const osg::Vec3& out, const osg::Vec4& color = osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f))
  {
    SetPoint(mIndex, in, color);
    SetPoint(mIndex + 1, out, color);
    mIndex += 2;
    mIndex %= NumberOfPoint;
    mGeom->setVertexArray(mVertice.get());
    mGeom->setColorArray(mColor.get());
  }
	void DrawPoint(const osg::Vec3& in, const osg::Vec4& color = osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f))
	{
		float width = 0.05f;
		DrawLine(in+osg::Vec3(width, width, 0.0f), in+osg::Vec3(-width, -width, 0.0f));
		DrawLine(in+osg::Vec3(-width, +width, 0.0f), in+osg::Vec3(+width, -width, 0.0f));		
	}
	template<typename T>
	void DrawInText(const T& arg, const osg::Vec3& pos, const osg::Vec4& color = osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f))
	{
		std::ostringstream oss;
		oss << arg;
		DrawText(oss.str(), pos, color);
	}
	void DrawText(const std::string& text, const osg::Vec3& pos, const osg::Vec4& color = osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f))
	{
		mTexts[mTextsIndex]->setText(text);
		mTexts[mTextsIndex]->setPosition(pos);
		mTexts[mTextsIndex]->setColor(color);
		mTextsIndex++;
		mTextsIndex %= mTexts.size();
	}
  void SetPoint(int i, const osg::Vec3& point, const osg::Vec4& color = osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f))
  {
    (*mVertice)[i] = point;
    (*mColor)[i] = color;
  }
  void Init(PokerApplication* game)
  {
    if (mInited == true)
			return;
		mInited = true;
		osg::Geometry *geometry = new osg::Geometry;
		{
			// setVec3Array
			osg::Vec3Array *array = new osg::Vec3Array(NumberOfPoint);
			geometry->setVertexArray(array);
			mVertice = array;
		}
		{
			//setVec4Array
			osg::Vec4Array *array = new osg::Vec4Array(NumberOfPoint);
			geometry->setColorArray(array);
			geometry->setColorBinding(osg::Geometry::BIND_PER_VERTEX);
			mColor = array;
		}	
		osg::StateSet *ss = new osg::StateSet;
		ss->setMode(GL_CULL_FACE, osg::StateAttribute::OFF);
		ss->setMode(GL_LIGHTING,  osg::StateAttribute::OFF);
		geometry->setStateSet(ss);
		
		geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::LINES, 0, NumberOfPoint));
		osg::Geode *geode = new osg::Geode;
		geode->addDrawable(geometry);    
		osg::MatrixTransform* mt = new osg::MatrixTransform;
		mt->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
		mt->setMatrix(osg::Matrix::identity());
		mt->addChild(geode);    
		osg::Projection* pj = new osg::Projection;
		pj->addChild(mt);
		game->GetScene()->GetModel()->mGroup->addChild(pj);
		mGeom = geometry;

		int size = 50;
		for (int i = 0; i < size; i++)
			{
				mTexts.push_back(new Text());
				mt->addChild(mTexts.back().get());
			}
  }
};

static PokerDebug2D g_debug2d;

struct Helper
{
  static osg::Vec3 Node2ScreenPos(osg::Node *node, PokerApplication *game)
  {
    osg::Matrix toworld = MAFComputeLocalToWorld(node);
    osg::Vec3 worldPos = osg::Vec3(0.0f, 0.0f, 0.0f) * toworld;
    return World2ScreenPos(worldPos, game);
  }
  static osg::Vec3 World2ScreenPos(const osg::Vec3 &worldPos, PokerApplication *game)
  {
    const osg::Matrix &v = game->GetScene()->GetModel()->mScene->getViewMatrix();
    const osg::Matrix &p = game->GetScene()->GetModel()->mScene->getProjectionMatrix();
    osg::Matrix mvp = v * p;    
    return worldPos * mvp;
  }
};

