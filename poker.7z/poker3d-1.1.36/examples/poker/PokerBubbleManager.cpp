/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* HAVE_CONFIG_H */

#include "pokerStdAfx.h"
#include <PokerEvent.h>
#ifndef POKER_USE_VS_PCH

#ifdef USE_NPROFILE
#include <nprofile/profile.h>
#else  //USE_NPROFILE
#define NPROFILE_SAMPLE(a)
#endif //USE_NPROFILE

#include <sstream>
#include <vector>
#include <iostream>
#include <algorithm>
#include <cmath>

#include <osg/Version>
#include <osg/Vec3>
#include <osg/Vec2>
#if OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1
#else // OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1
#include <osg/io_utils>
#endif // OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1
#include <maf/window.h>
#include <maf/interpolator.h>
#include <maf/bezier.h>

#include "PokerBubbleManager.h"
#include "PokerApplication.h"
//#include "PokerDebug2D.h"
#include "PokerPlayer.h"
#include "PokerBubble.h"
#include <varseditor/varseditor.h>
#include "PokerBody.h"
#include "PokerPlayerCamera.h"
#endif


template <>
void PokerBubbleManager::GameAccept<PokerEventStartFirstPerson>(const PokerEventStartFirstPerson& event)
{
  SetVisible(false);
}

template <>
void PokerBubbleManager::GameAccept<PokerEventEndLeaveFirstPerson>(const PokerEventEndLeaveFirstPerson& event)
{
  SetVisible(true);
}



template<typename T>
bool collisionBox2D(const T& A0, const T& A1, const T& B0, const T& B1)
{
	if ((A0.x() > B1.x()) || (A1.x() < B0.x()))
		return false;
	if ((A0.y() < B1.y()) || (A1.y() > B0.y()))
		return false;
	return true;
}

struct collision
{
	static bool box(const osg::Vec2& inA, const osg::Vec2& outA, const osg::Vec2& inB, const osg::Vec2& outB)
	{
		if ((inA.x() > outB.x()) || (outA.x() < inB.x()))
			return false;
		if ((inA.y() > outB.y()) || (outA.y() < inB.y()))
			return false;
		return true;
	}
};


struct Math
{
  template<typename T>
  static T abs(const T& in)
  {
  }
  template<typename T>
  static T min(const T& in1, const T& in2)
  {
    return std::min(in1, in2);
  }
  template<typename T>
  static T max(const T& in1, const T& in2)
  {
    return std::max(in1, in2);
  }
  template<typename T>
  static T minmax(const T& in, const T& rangeIn, const T& rangeOut)
  {
    return std::min(std::max(in, rangeIn), rangeOut);
  }
  template<typename T, typename U>
  static void assign(T& out, const U& in)
  {
    out = in;
  }
  template<typename T, typename U>
  static T convert(const U& in)
  {
    return in;
  }
};


template<>
osg::Vec2 Math::convert<osg::Vec2, osg::Vec3>(const osg::Vec3& in)
{
  return osg::Vec2(in.x(), in.y());
}

template<>
osg::Vec3 Math::convert<osg::Vec3, osg::Vec2>(const osg::Vec2& in)
{
  return osg::Vec3(in.x(), in.y(), 0.0f);
}

template<>
osg::Vec3 Math::abs<osg::Vec3>(const osg::Vec3& in)
{
  return osg::Vec3(std::abs(in.x()),
		   std::abs(in.y()),
		   std::abs(in.z()));
}

template<>
osg::Vec2 Math::abs<osg::Vec2>(const osg::Vec2& in)
{
  return osg::Vec2(std::abs(in.x()),
		   std::abs(in.y()));
}

template<>
osg::Vec3 Math::min<osg::Vec3>(const osg::Vec3& in1, const osg::Vec3& in2)
{
  return osg::Vec3(Math::min(in1.x(), in2.x()),
		   Math::min(in1.y(), in2.y()),
		   Math::min(in1.z(), in2.z()));
}

template<>
osg::Vec3 Math::max<osg::Vec3>(const osg::Vec3& in1, const osg::Vec3& in2)
{
  return osg::Vec3(Math::max(in1.x(), in2.x()),
		   Math::max(in1.y(), in2.y()),
		   Math::max(in1.z(), in2.z()));
}

template<>
osg::Vec3 Math::minmax<osg::Vec3>(const osg::Vec3& in, const osg::Vec3& rangeIn, const osg::Vec3& rangeOut)
{
  return osg::Vec3(Math::minmax(in.x(), rangeIn.x(), rangeOut.x()),
		   Math::minmax(in.y(), rangeIn.y(), rangeOut.y()),
		   Math::minmax(in.z(), rangeIn.z(), rangeOut.z()));
}
template<>
osg::Vec2 Math::minmax<osg::Vec2>(const osg::Vec2& in, const osg::Vec2& rangeIn, const osg::Vec2& rangeOut)
{
  return osg::Vec2(Math::minmax(in.x(), rangeIn.x(), rangeOut.x()),
		   Math::minmax(in.y(), rangeIn.y(), rangeOut.y()));
}

template<>
void Math::assign<osg::Vec3, osg::Vec2>(osg::Vec3& out, const osg::Vec2& in)
{
  out.x() = in.x();
  out.y() = in.y();
  out.z() = out.z();
}

template<>
void Math::assign<osg::Vec2, osg::Vec3>(osg::Vec2& out, const osg::Vec3& in)
{
  out.x() = in.x();
  out.y() = in.y();
}

template<>
void Math::assign<osg::Vec2, float>(osg::Vec2& out, const float& in)
{
  out.x() = in;
  out.y() = in;
}

template<>
void Math::assign<osg::Vec3, float>(osg::Vec3& out, const float& in)
{
  out.x() = in;
  out.y() = in;
  out.z() = in;
}

struct Convert
{
	static osg::Vec2 Vec3ToVec2(const osg::Vec3& vec3)
	{
		osg::Vec2 vec2(vec3.x(), vec3.y());
		return vec2;
	}
	static osg::Vec3 Vec2ToVec3(const osg::Vec2& vec2)
	{
		osg::Vec3 vec3(vec2.x(), vec2.y(), 0.0f);
		return vec3;
	}
};

struct BubbleHelper
{
  static osg::Vec3 World2ScreenPos(const osg::Vec3 &worldPos, PokerApplication *game)
  {
    MAFWindow* pWin = game->GetWindow(true);
    MAFSceneView* scene = game->GetScene()->GetView();
    MAFCameraModel* camera = scene->GetModel()->mCamera->GetModel();
    osg::BoundingSphere bs = scene->GetModel()->mScene->getSceneData()->getBound();
    
    osg::Matrix v;
    v.makeLookAt(camera->GetPosition(),
		 camera->GetTarget(),
		 camera->GetUp());
    osg::Matrix p;
    p.makePerspective(camera->GetFov(),
		      (((float)pWin->GetWidth())/pWin->GetHeight()),
		      1.0f, // Be carefull when setting zNear: some cards/drivers (nVidia for instance) do not like when zNear is below 1
		      bs.radius()*2.0f);    
    osg::Matrix mvp = v * p;    
    osg::Vec3 screenPos = worldPos * mvp;
    return screenPos;
  }
};


struct verlet
{
	//todo template me
	static 
	void doit(osg::Vec2& pos, osg::Vec2& prevPos, float delta = 0.1f, float friction = 0.9f, const osg::Vec2& force = osg::Vec2(0.0f, 0.0f))
	{
		osg::Vec2 deltaForce = force * delta * delta;
		osg::Vec2 deltaPos = (pos - prevPos) * friction;
		osg::Vec2 newPos = pos + deltaPos + deltaForce;
		prevPos = pos;
		pos = newPos;
	}
};

void PokerBubbleManager::Init(PokerApplication *game)
{
	osg::Vec4 colors[10] = {
	  osg::Vec4(112,	135,	143, 1.0f),
	  osg::Vec4(81,	124,	140, 1.0f),
	  osg::Vec4(100,	124,	89, 1.0f),
	  osg::Vec4(61,	93,	47, 1.0f),
	  osg::Vec4(137,	122,	69, 1.0f),
	  osg::Vec4(118,	88,	45, 1.0f),
	  osg::Vec4(122,	78,	71, 1.0f),
	  osg::Vec4(96,	56,	50, 1.0f),
	  osg::Vec4(124,	83,	119, 1.0f),
	  osg::Vec4(98,	50,	93, 1.0f)
	};
	//setPokerEditor(&PokerEditor::Instance());
  mGame=game;
	MAFController::Init();
	mGroup = new osg::Group();

	const int maxPlayerCount = 10;
  mAnchors.resize(maxPlayerCount);
	for (int i = 0; i < maxPlayerCount; i++)
		{
			char tmp[128];
			sprintf(tmp, "transform_seat%02d", i + 1);
			osg::Node* seatNode = game->mSetData->GetAnchor(tmp);
      mAnchors[i] = seatNode;
			const osg::Matrix& seatToWorld = MAFComputeLocalToWorld(seatNode);

			osg::Node* bubbleNode = dynamic_cast<MAFOSGData*>(game->mDatas->GetVision("seat.escn"))->GetAnchor("transform_bubble");
			const osg::Matrix& bubbleToSeat = MAFComputeLocalToWorld(bubbleNode);			
			mBubbleAnchorWorldPos.push_back(osg::Vec3(0.0f, 0.0f, 0.0f) *  bubbleToSeat * seatToWorld + osg::Vec3(0.0f, 30.0f, 0.0f));

			mControllers.push_back(new PokerBubbleController(game,GetID()));
			mControllers.back()->Anchor(mGroup.get());
			game->AddController(mControllers.back().get());
			mControllers.back()->mBubble->SetColor(colors[i]);
			mBubbles.push_back(PokerBubble());
			mCollisions.push_back(PokerBubble());
		}

		osg::MatrixTransform* mt = new osg::MatrixTransform;
		mt->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
		mt->setMatrix(osg::Matrix::identity());
		osg::Projection* pj = new osg::Projection;
		pj->addChild(mt);
		mt->addChild(mGroup.get());	
		game->mSetData->GetGroup()->addChild(pj);
		SetVisible(true);
		LoadColorSet();
		SwitchColorSet();
}

void PokerBubbleManager::Finit()
{
  int end=(int) mControllers.size();
  for (int i=0;i<end;i++) {
    mControllers[i]->Anchor(0);
    mGame->RemoveController(mControllers[i].get());
    mControllers[i]=0;
  }
  mControllers.clear();
	mBubbleAnchorWorldPos.clear();

	//todo remove nodes from mSetData
}

bool PokerBubbleManager::Update(MAFApplication *application)
{
  NPROFILE_SAMPLE("PokerBubbleManager::Update");
	PokerApplication* game = static_cast<PokerApplication*>(application);
	if (game->GetLastEvent(this))
		return true;
	_Update(game);
	return true;
}

struct SortByDepth
{
	const std::vector<float>& mPositions;
	SortByDepth(const std::vector<float>& positions) : mPositions(positions)
	{
	}
	bool operator()(int a, int b)
	{
		return mPositions[a] < mPositions[b];
	}
};


void PokerBubbleManager::LoadColorSet()
{
  return;
  std::vector<std::vector<osg::Vec4> >& sets = mColorSet;
  std::ifstream fs("bubble-colors.txt");
  std::string s;
  unsigned int setCount = 4;
  sets.resize(setCount);
  for (unsigned int i = 0; i < setCount; i++)
    {
      char buf[256];      
      fs.getline(buf, sizeof(buf));
      g_debug("loading:%s", buf);
      fs.getline(buf, sizeof(buf));
      unsigned int colorCount = 10;
      sets[i].resize(colorCount);
      for (unsigned int j = 0; j < colorCount; j++)
	{	  
	  fs.getline(buf, sizeof(buf));
	  std::istringstream iss(buf);
	  osg::Vec4 v;
	  iss >> v.x();
	  iss >> v.y();
	  iss >> v.z();
	  v.w() = 1.0f;
	  sets[i][j] = v;
	  g_debug("%f %f %f\n", v.x(), v.y(), v.z());
	}
    }
  fs.close();
}

void PokerBubbleManager::SwitchColorSet()
{
  return;
  static int currentSet = 0;
  for (unsigned int i = 0; i < 10; i++)
    {      
      mControllers[i]->mBubble->SetColor(mColorSet[currentSet][i]);
      //mControllers[i]->mBubble->SetColor(osg::Vec4(0.0f, 0.0f, 0.0f, 1.0f));
    }
  currentSet++;
  if (currentSet >= 4)
    {
      currentSet = 0;
    }
}

void PokerBubbleManager::_Update(PokerApplication* game)
{	
	float bubbleHeight2D = 0.125f;
	VarsEditor::Instance().Get("PBM_BubbleHeight2D",bubbleHeight2D);

	float collisionWidth = 0.2f;
	VarsEditor::Instance().Get("PBM_CollisionWidth",collisionWidth);

	float collisionHeight = 0.2f;
	VarsEditor::Instance().Get("PBM_CollisionHeight",collisionHeight);

	bool drawDebug = false;
	VarsEditor::Instance().Get("PBM_DrawDebug",drawDebug);

	//g_debug2d.Init(game);
	for (unsigned int i = 0; i < mBubbleAnchorWorldPos.size(); i++)
	{
		//g_debug2d.DrawPoint(BubbleHelper::World2ScreenPos(mBubbleAnchorWorldPos[i], game));
	}


	std::vector<osg::Vec3> headBonePos;
	headBonePos.resize(mBubbles.size());

	std::vector<osg::ref_ptr<PokerPlayer> >& players = game->GetPoker()->GetModel()->mSeat2Player;
	{
		NPROFILE_SAMPLE("PlayerLoop");
		for (unsigned int i = 0; i < players.size(); i++)
		{
			PokerPlayer* player = players[i].get();
			if (player)
			{
				CalBone* bone;
				CalVector calHeadPos;
				osg::Vec3 headPos;
				char tmp[128];
				osg::Node* seatNode;
				osg::Matrix seatToWorld;
				osg::Vec3 bubblePos;
				osg::Vec3 playerHeadPos;
				osg::Vec3 playerTailPos;
				{
					NPROFILE_SAMPLE("GetBone");
					/*CalBone**/ bone = player->GetBody()->GetModel()->GetBone("Bip01 Spine1");
				}
				{
					NPROFILE_SAMPLE("getTranslationAbsolute");
					/*const CalVector&*/ calHeadPos = bone->getTranslationAbsolute();
				}
				{
					NPROFILE_SAMPLE("stuff");
					/*osg::Vec3 */ headPos = osg::Vec3(calHeadPos.x, calHeadPos.y, calHeadPos.z);
					// 		    EDITABLE(float, playerSpine2Head, 100.0f);
					// 		    EDITABLE(float, playerSpine2Tail, 100.0f);
					// 		    playerHeadPos = headPos + osg::Vec3(0.0f, +playerSpine2Head, 0.0f);
					// 		    playerTailPos = headPos + osg::Vec3(0.0f, -playerSpine2Tail, 0.0f);	    

					float tailXOffset = 0;
					VarsEditor::Instance().Get("PBM_TailXOffset",tailXOffset);
					float tailYOffset = 65;
					VarsEditor::Instance().Get("PBM_TailYOffset",tailYOffset);
					float tailZOffset = 5;
					VarsEditor::Instance().Get("PBM_TailZOffset",tailZOffset);
					headPos = headPos + osg::Vec3(tailXOffset, tailYOffset, tailZOffset);
					/*char tmp[128];*/
					sprintf(tmp, "transform_seat%02d", i + 1);
				}
				{
					NPROFILE_SAMPLE("GetAnchor");
					/*osg::Node* */seatNode = mAnchors[i];//game->mSetData->GetAnchor(tmp);
				}
				{
					NPROFILE_SAMPLE("MAFComputeLocalToWorld");
					/*const osg::Matrix& */seatToWorld = MAFComputeLocalToWorld(seatNode);
				}
				{
					NPROFILE_SAMPLE("stuff29");
					float bubbleXOffset = 0;
					VarsEditor::Instance().Get("PBM_BubbleXOffset",bubbleXOffset);
					float bubbleYOffset = 0;
					VarsEditor::Instance().Get("PBM_BubbleYOffset",bubbleYOffset);
					float bubbleZOffset = 0;
					VarsEditor::Instance().Get("PBM_BubbleZOffset",bubbleZOffset);
					/*osg::Vec3 */bubblePos = (headPos + osg::Vec3(bubbleXOffset, bubbleYOffset, bubbleZOffset)) * seatToWorld;
					mBubbleAnchorWorldPos[i] = bubblePos;
				}

				{
					NPROFILE_SAMPLE("World2ScreenPos");


					MAFSceneView* scene = game->GetScene()->GetView();
					MAFCameraModel* camera = scene->GetModel()->mCamera->GetModel();
					osg::Vec3 cameraPos = camera->GetPosition();
					osg::Vec3 cameraTarget = camera->GetTarget();
					osg::Vec3 cameraUp = camera->GetUp();
					osg::Vec3 cameraAt = cameraTarget - cameraPos;
					cameraAt.normalize();
					osg::Vec3 cameraRight = cameraAt ^ cameraUp;
					cameraRight.normalize();

					headBonePos[i] = BubbleHelper::World2ScreenPos(headPos * seatToWorld, game);

					float headBoxWidth = 50;
					VarsEditor::Instance().Get("PBM_HeadBoxWidth",headBoxWidth);
					float headBoxHeight = 50;
					VarsEditor::Instance().Get("PBM_HeadBoxHeight",headBoxHeight);

					float headPosDeltaX = 0;
					VarsEditor::Instance().Get("PBM_HeadPosDeltaX",headPosDeltaX);
					float headPosDeltaY = -20;
					VarsEditor::Instance().Get("PBM_HeadPosDeltaY",headPosDeltaY);
					float headPosDeltaZ = -10;
					VarsEditor::Instance().Get("PBM_HeadPosDeltaZ",headPosDeltaZ);

					float headPos1DeltaX = 0;
					VarsEditor::Instance().Get("PBM_HeadPos1DeltaX",headPos1DeltaX);
					float headPos1DeltaY = 0;
					VarsEditor::Instance().Get("PBM_HeadPos1DeltaY",headPos1DeltaY);
					float headPos1DeltaZ = 0;
					VarsEditor::Instance().Get("PBM_HeadPos1DeltaZ",headPos1DeltaZ);

					float headPos2DeltaX = 0;
					VarsEditor::Instance().Get("PBM_HeadPos2DeltaX",headPos2DeltaX);
					float headPos2DeltaY = 0;
					VarsEditor::Instance().Get("PBM_HeadPos2DeltaY",headPos2DeltaY);
					float headPos2DeltaZ = 0;
					VarsEditor::Instance().Get("PBM_HeadPos2DeltaZ",headPos2DeltaZ);

					float headBoxLength = 20;
					VarsEditor::Instance().Get("PBM_HeadBoxLength",headBoxLength);

					osg::Vec3 headPosWorld = (headPos + osg::Vec3(headPosDeltaX, headPosDeltaY, headPosDeltaZ)) * seatToWorld;
					osg::Vec3 headBoxRight = cameraRight*headBoxLength;
					osg::Vec3 headBoxUp = cameraUp*headBoxLength;
					osg::Vec3 headBox1 = headPosWorld + headBoxRight + headBoxUp;
					osg::Vec3 headBox2 = headPosWorld - headBoxRight - headBoxUp;
					osg::Vec3 headBox2d1 = BubbleHelper::World2ScreenPos(headBox1, game);
					osg::Vec3 headBox2d2 = BubbleHelper::World2ScreenPos(headBox2, game);
					//osg::Vec3 headBox2d = math::max(headBox2d1, headBox2d2);
					//float headBoxWidth1 = headBox2d1.x();
					//float headBoxHeight1 = headBox2d2.y();
					osg::Vec3 headPos1 = headBox2d1;
					//headBonePos[i] - osg::Vec3(headBoxWidth1, headBoxHeight1, 0.0f);
					//BubbleHelper::World2ScreenPos((headPos + osg::Vec3(headPos1DeltaX, headPos1DeltaY, headPos1DeltaZ)) * seatToWorld, game);
					osg::Vec3 headPos2 = headBox2d2;
					//headBonePos[i] + osg::Vec3(headBoxWidth1, headBoxHeight1, 0.0f);
					//BubbleHelper::World2ScreenPos((headPos + osg::Vec3(headPos2DeltaX, headPos2DeltaY, headPos2DeltaZ)) * seatToWorld, game);

					// 		    g_debug2d.DrawBox(headPos1,
					// 				      headPos2, osg::Vec4(1.0f, 0.0f, 0.0f, 1.0f));
					// 		    g_debug2d.DrawPoint(headPos1, osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f));
					// 		    g_debug2d.DrawPoint(headPos2, osg::Vec4(1.0f, 0.0f, 0.0f, 1.0f));
					//mCollisions[i].InitInOut(math::convert<osg::Vec2>(headPos1), math::convert<osg::Vec2>(headPos2));
					mCollisions[i].Init(Math::convert<osg::Vec2>((headPos1 + headPos2) * 0.5f), Math::convert<osg::Vec2>(Math::abs(headPos2 - headPos1)));
// 					if (drawDebug)
// 						g_debug2d.DrawBox(Math::convert<osg::Vec3>(mCollisions[i].mInPos), Math::convert<osg::Vec3>(mCollisions[i].mOutPos), osg::Vec4(0.0f, 1.0f, 0.0f, 1.0f)); 
					//}

					//{
					// 		    osg::Vec3 playerHeadPos2d;
					// 		    osg::Vec3 playerTailPos2d;
					// 		    playerHeadPos2d = BubbleHelper::World2ScreenPos(playerHeadPos * seatToWorld, game);
					// 		    playerTailPos2d = BubbleHelper::World2ScreenPos(playerTailPos * seatToWorld, game);
					// 		    g_debug2d.DrawLine(playerHeadPos2d, playerTailPos, osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f));
					//}

					std::string message;
					if (mControllers[i]->mState == PokerBubbleController::NONE)
					{
						NPROFILE_SAMPLE("PlayerLoop2");
						if (player->PopTextMessage(message))
						{	
						  if (mVisible)
						    {	
						      mControllers[i]->SetTextMessage(message);
						      osg::Vec2 size = mControllers[i]->mBubble->GetSize();

									float heightRatio = 0.1;
									VarsEditor::Instance().Get("PBM_HeightRatio",heightRatio);
									float widthRatio = 0.1;
									VarsEditor::Instance().Get("PBM_WidthRatio",widthRatio);

						      size.y() += heightRatio;
						      size.x() += widthRatio;
						      osg::Vec2 bubblePos;
						      Math::assign(bubblePos, BubbleHelper::World2ScreenPos(mBubbleAnchorWorldPos[i], game));
						      //osg::Vec2 bubblePos = mCollisions[i].GetCenterPos();
						      
						      //EDITABLE(float, bubbleHeight2D, 0.2f);
						      bubblePos += osg::Vec2(0.0f, bubbleHeight2D);
						      bubblePos = Math::minmax(bubblePos, osg::Vec2(-1.0f, -1.0f), osg::Vec2(1.0f, 1.0f));
						      mBubbles[i].Init(bubblePos, size);
						      mControllers[i]->mBubble->SetTailPosition(headBonePos[i]);
						      mControllers[i]->mBubble->UpdateTailPosition();
						      //mBubbles[i].Init(Convert::Vec3ToVec2(BubbleHelper::World2ScreenPos(mBubbleAnchorWorldPos[i], game)), size);
						    }
						  else
						    {
						      //hacky
						      mControllers[i]->SetTextMessage(message);
						      mControllers[i]->GetModel()->GetPAT()->setNodeMask(0); // hacky
						    }
						}
						else
						{
							mBubbles[i].mActive = false;
						}
					}
					else if (mControllers[i]->mState == PokerBubbleController::SHOW)
					{
						if (player->mMessages.size())
						{	
							//if (mControllers[i]->mTimeout > 2000.f)
							//{
							//	mControllers[i]->mTimeout = 1000.f;
							//}
							//else
							//{
							//buggy
							if (mControllers[i]->mTimeout  > 1000.f)
							{
								mControllers[i]->mTimeout = 1000.0f;
							}
							//}
						}
					}
				}
			}
			else				
			{					
				mBubbles[i].mActive = false;
				mControllers[i]->Hide();
			}
		}
	}

	{
		// 	  NPROFILE_SAMPLE("BubbleLoop");
		// 	  for (unsigned int i = 0; i < mCollisions.size(); i++)
		// 	    {
		// 	      osg::Vec2 bubblePos;
		// 	      Math::assign(bubblePos, BubbleHelper::World2ScreenPos(mBubbleAnchorWorldPos[i], game));
		// 	      mCollisions[i].Init(bubblePos, osg::Vec2(collisionWidth, collisionHeight));
		// 	    }

		if (mVisible)
		{
			for (unsigned int i = 0; i < mBubbles.size(); i++)
				if (mBubbles[i].mActive)					
				{
					//mBubbles[i].Update(game->GetDeltaFrame());
					mBubbles[i].Verlet(game->GetDeltaFrame());
					mBubbles[i].mCollide = false;
				}

			unsigned int nbIteration = 4;
			VarsEditor::Instance().Get("PBM_NbIteration",nbIteration);

				for (unsigned int i = 0; i < nbIteration; i++)
				{
					for (unsigned int i = 0; i < mBubbles.size(); i++)
					{
						if (mBubbles[i].mActive)
						{
							for (unsigned int j = i+1; j < mBubbles.size(); j++)
								if (mBubbles[j].mActive)
								{
									mBubbles[i].CollisionConstraint(mBubbles[j]);
								}
// 								if (drawDebug)
// 								{
// 									g_debug2d.DrawBox(Math::convert<osg::Vec3>(mBubbles[i].mInPos), Math::convert<osg::Vec3>(mBubbles[i].mOutPos), osg::Vec4(1.0f, 0.0f, 0.0f, 1.0f)); 
// 									g_debug2d.DrawBox(Math::convert<osg::Vec3>(mCollisions[i].mInPos), Math::convert<osg::Vec3>(mCollisions[i].mOutPos));
// 								}
								//mBubbles[i].CollisionConstraint(mCollisions[i], 1.0f, 0.0f);
						}
					}

					for (unsigned int i = 0; i < mBubbles.size(); i++)
						if (mBubbles[i].mActive)
						{
							mBubbles[i].SizeContraint();

							osg::Vec2 bubblePos;
							Math::assign(bubblePos, BubbleHelper::World2ScreenPos(mBubbleAnchorWorldPos[i], game));
							bubblePos += osg::Vec2(0.0f, bubbleHeight2D);
							bubblePos = Math::minmax(bubblePos, osg::Vec2(-1.0f, -1.0f), osg::Vec2(1.0f, 1.0f));		
// 							if (drawDebug)
// 								g_debug2d.DrawPoint(Math::convert<osg::Vec3>(bubblePos));
							mBubbles[i].CenterPosConstraint(bubblePos);//Convert::Vec3ToVec2(BubbleHelper::World2ScreenPos(mBubbleAnchorWorldPos[i], game)));

							bool screenConstraint = true;
							VarsEditor::Instance().Get("PBM_ScreenConstraint",screenConstraint);
							if (screenConstraint)
								mBubbles[i].ScreenConstraint();					
						}
				}	
				for (unsigned int i = 0; i < mControllers.size(); i++)
					if (mBubbles[i].mActive)					
					{							
						float fontSize = 0.04;
						VarsEditor::Instance().Get("PBM_FontSize",fontSize);

						mControllers[i]->mBubble->SetFontSize(fontSize);
						osg::Vec3 pos = Convert::Vec2ToVec3(mBubbles[i].GetCenterPos());
						//pos.z() = mBubbleAnchorWorldPos[i].z();
						mControllers[i]->mBubble->SetBubblePosition(pos);//BubbleHelper::World2ScreenPos(mBubbleAnchorWorldPos[i], game));
						mControllers[i]->mBubble->UpdateBubblePosition();
						mControllers[i]->mBubble->SetTailPosition(headBonePos[i]);
// 						if (drawDebug)
// 							g_debug2d.DrawPoint(headBonePos[i], osg::Vec4(1.0f, 1.0f, 0.0f, 1.0f));
						mControllers[i]->mBubble->UpdateTailPosition();//2
						// 			if (mBubbles[i].mCollide)
						bool enableDebug = false;
						VarsEditor::Instance().Get("PBM_EnableDebug",enableDebug);
// 						if (enableDebug)
// 							g_debug2d.DrawBox(Convert::Vec2ToVec3(mBubbles[i].mInPos), Convert::Vec2ToVec3(mBubbles[i].mOutPos), osg::Vec4(1.0f, 0.0f, 0.0f, 1.0f));
						// 			else
						// 				g_debug2d.DrawBox(Convert::Vec2ToVec3(mBubbles[i].mInPos), Convert::Vec2ToVec3(mBubbles[i].mOutPos), osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f));
					}

					//{
					//	std::vector<unsigned int> sorted;
					//	sorted.resize(mBubbles.size());
					//	for (unsigned int i = 0; i < mBubbles.size(); i++)
					//	{
					//		sorted[i] = i;
					//	}
					//	std::vector<float> depth;
					//	depth.resize(mBubbles.size());
					//	for (unsigned int i = 0; i < mBubbles.size(); i++)
					//	{
					//		depth[i] = mControllers[i]->mTimeout;
					//	}
					//	std::sort(sorted.begin(), sorted.end(), SortByDepth(depth));
					//	for (unsigned int i = 0; i < mBubbles.size(); i++)
					//	{
					//		mControllers[depth[i]]->mBubble->SetRenderBinOffset(i*3);
					//	}
					//}
		}
	}
}

void PokerBubbleManager::SetVisible(bool value)
{
	mGroup->setNodeMask(value ? MAF_VISIBLE_MASK : 0);
	mVisible = value;
}

PokerBubble::PokerBubble()
{
	mActive = false;
}
void PokerBubble::Init(const osg::Vec2& pos, const osg::Vec2& size)
{
  mSize = size;
  osg::Vec2 halfSize = size/2.0f;
  mInPos = pos - halfSize;
  mInPrevPos = mInPos;
  mOutPos = pos + halfSize;
  mOutPrevPos = mOutPos;
  mActive = true;
}

void PokerBubble::InitInOut(const osg::Vec2& in, const osg::Vec2& out)
{
  mInPos = mInPrevPos = Math::min(in, out);
  mOutPos = mOutPrevPos = Math::max(in, out);
  mSize = mOutPos - mInPos;
  mActive = true;
}

osg::Vec2 PokerBubble::GetCenterPos()
{
	return (mInPos + mOutPos) * 0.5f;
}

void PokerBubble::Update(float delta)
{
// 	Verlet(delta);
// 	EDITABLE(unsigned int, nbIteration, 4);
// 	for (unsigned int i = 0; i < nbIteration; i++)
// 		{
// 			SizeContraint();
// 			CenterPosConstraint();
// 			ScreenConstraint();
// 		}	
}

void PokerBubble::Verlet(float delta)
{
	float friction = 0.8;
	VarsEditor::Instance().Get("PBM_Friction",friction);

	verlet::doit(mInPos, mInPrevPos, delta, friction);
	verlet::doit(mOutPos, mOutPrevPos, delta, friction);
}

void PokerBubble::SizeContraint()
{
	osg::Vec2 center = GetCenterPos();
	osg::Vec2 halfSize = mSize/2.0f;
	osg::Vec2 newInPos = center - halfSize;
	osg::Vec2 newOutPos = center + halfSize;

	float resizeFactor = 1.0;
	VarsEditor::Instance().Get("PBM_ResizeFactor",resizeFactor);
	mInPos += (newInPos - mInPos) * resizeFactor;
	mOutPos += (newOutPos - mOutPos) * resizeFactor;
}

void PokerBubble::CenterPosConstraint(const osg::Vec2& centerWantedPos)
{
	osg::Vec2 center = GetCenterPos();
	osg::Vec2 centerWantedPosInScreen = Math::minmax(centerWantedPos, osg::Vec2(-1.0f, -1.0f), osg::Vec2(1.0f, 1.0f));

	osg::Vec2 delta = centerWantedPosInScreen - center;

	float attractionRatioWhenCollide = 0.15;
	VarsEditor::Instance().Get("PBM_AttractionRatioWhenCollide",attractionRatioWhenCollide);

	float attractionRatioWhenNotCollide = 0.30;
	VarsEditor::Instance().Get("PBM_AttractionRatioWhenNotCollide",attractionRatioWhenNotCollide);

	float attraction = mCollide ? attractionRatioWhenCollide : attractionRatioWhenNotCollide;
	mInPos += delta * attraction;
	mOutPos += delta * attraction;
}

void PokerBubble::ScreenConstraint()
{
	float screenYMAX = 0.9;
	VarsEditor::Instance().Get("PBM_ScreenYMAX",screenYMAX);
	mInPos = Math::minmax(mInPos, osg::Vec2(-1.0f, -1.0f), osg::Vec2(1.0f, screenYMAX));
  mOutPos = Math::minmax(mOutPos, osg::Vec2(-1.0f, -1.0f), osg::Vec2(1.0f, screenYMAX));
}

void PokerBubble::CollisionConstraint(PokerBubble& left, float ratioA, float ratioB)
{
	osg::Vec2& inA = mInPos;
	osg::Vec2& outA = mOutPos;
	osg::Vec2& inB = left.mInPos;
	osg::Vec2& outB = left.mOutPos;
	
	if (collision::box(inA, outA, inB, outB))											
		{
			float overlapX1 = outB.x() - inA.x();
			float overlapX2 = outA.x() - inB.x();
			float overlapY1 = outB.y() - inA.y();
			float overlapY2 = outA.y() - inB.y();
			assert(overlapX1 >= 0.0f);
			assert(overlapX2 >= 0.0f);
			assert(overlapY1 >= 0.0f);
			assert(overlapY2 >= 0.0f);
			float overlapMin = std::min(overlapX1, std::min(overlapX2,  std::min(overlapY1, overlapY2)));

			float collisionFactor = 1;
			VarsEditor::Instance().Get("PBM_CollisionFactor",collisionFactor);

			float delta = overlapMin * collisionFactor;
			float deltaA = delta * ratioA;
			float deltaB = delta * ratioB;
			if (overlapMin == overlapX1)
			  {
			    outB.x() -= deltaB;
			    inA.x() += deltaA;
			  }
			else if (overlapMin == overlapX2)
			  {
			    outA.x() -= deltaA;
			    inB.x() += deltaB;
			  }
			else if (overlapMin == overlapY1)
			  {
			    outB.y() -= deltaB;
			    inA.y() += deltaA;
			  }
			else if (overlapMin == overlapY2)
			  {
			    outA.y() -= deltaA;
			    inB.y() += deltaB;	
			  }
			mCollide = true;
			left.mCollide = true;
		}
}
