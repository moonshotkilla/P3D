/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Johan Euphrosine <johan@mekensleep.com>
*
*/

#include "pokerStdAfx.h"

#ifndef POKER_USE_VS_PCH

// MAF INCLUDES
#include <maf/assert.h>
#include <maf/utils.h>

// POKER INCLUDES
#include "PokerApplication.h"
#include "PokerSelectable.h"

#endif

PokerSelectableController::PokerSelectableController(unsigned int id) : UGAMEArtefactController(id)
{
  mX = 0;
  mY = 0;
  mMouseButtonState = 9;
  mXSelected = 0;
  mYSelected = 0;
  mSelected = false;
  mMouseButtonDownEvent = false;
  mMouseButtonUpEvent = false;
  mFocused = false;
  mClickedAndFocused = false;
  mUpdateCount = 0;
}

PokerSelectableController::~PokerSelectableController()
{
}

void PokerSelectableController::Init(PokerApplication* game)
{
  UGAMEArtefactController::Init();
  SetSelectable(true);
  mGame = game;
}

void PokerSelectableController::SetNodeSelectable(osg::Node* node)
{
  osg::NodePath pathToAddCollisionMask;
  MAFCreateNodePath(node, pathToAddCollisionMask);
  for (osg::NodePath::iterator it = pathToAddCollisionMask.begin(); it != pathToAddCollisionMask.end(); it++) {
    unsigned int mask = (*it)->getNodeMask();
    mask =  mask | MAF_COLLISION_MASK;
    (*it)->setNodeMask(mask);
  }
}

bool PokerSelectableController::Update(MAFApplication* application)
{
  UGAMEArtefactController::Update(mGame);
  if (mUpdateCount == 0)
    BeginUpdateEvent();
  SDL_Event* hasEvent = mGame->GetLastEventIgnoreLocking();
  mLastEvent = mGame->GetLastEvent(this);
  if (hasEvent)
    {
      if (mLastEvent)
	UpdateEvent();
      mUpdateCount++;
    }
  else
    {
      EndUpdateEvent();
      mUpdateCount = 0;
    }
  return true;
}

void PokerSelectableController::BeginUpdateEvent()
{
  mMouseButtonDownEvent = false;
  mMouseButtonUpEvent = false;
}

void PokerSelectableController::UpdateEvent()
{
  SDL_Event* event = mLastEvent;
  MAF_ASSERT(event);
  switch(event->type)
    {
    case SDL_MOUSEMOTION:
      {
	mX = event->motion.x;
	mY = event->motion.y;
      }
      break;
    case SDL_MOUSEBUTTONDOWN:
      {
	if (event->button.button == SDL_BUTTON_LEFT)
	  {
	    mMouseButtonState = 1;
	    mMouseButtonDownEvent = true;
	  }
      }
      break;
    case SDL_MOUSEBUTTONUP:
      {
	if (event->button.button == SDL_BUTTON_LEFT)
	  {
	    mMouseButtonState = 0;
	    mMouseButtonUpEvent = true;
	  }
      }
      break;
    }
}

void PokerSelectableController::EndUpdateEvent()
{
  mFocused = mGame->GetFocus() == dynamic_cast<MAFController*>(this);
  if (mFocused && mMouseButtonDownEvent)
    {
      mClickedAndFocused = true;
      mReleasedAndFocused = false;
    }
  if ((mFocused == false) && mMouseButtonDownEvent)
    {
      mClickedAndFocused = false;
    }
  if (mFocused && mMouseButtonUpEvent)
    {
      mReleasedAndFocused = true;
    }
  if ((mFocused == false) && mMouseButtonUpEvent)
    {
      mReleasedAndFocused = false;
    }
  if (mClickedAndFocused && mReleasedAndFocused)
    {
      mSelected = true;
      mClickedAndFocused = false;
      mReleasedAndFocused = false;
    }
}
