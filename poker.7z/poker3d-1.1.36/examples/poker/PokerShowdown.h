/*
 *
 * Copyright (C) 2007 Loic Dachary <loic@dachary.org>
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef _pokershowdown_h
#define _pokershowdown_h

#ifndef POKER_USE_VS_PCH
#include <vector>

#include <ugame/artefact.h>
#include <osg/Version>
#include <osg/Group>
#include <osg/Geometry>
#include <osg/Version>
#endif

namespace osg { class TexMat; class Material; class AutoTransform; }

class PokerCardController;
class PokerPlayer;


class CardsGroup 
{
public:
  void  AddCards(PokerApplication* pGame, MAFOSGData* pData, unsigned int controllerID, int CardsCount, const std::string& strModelURL , const std::string& strAnchorTemplate, char cAnchorSide);
  void  SetValues(const std::vector<int>& vCardValues);
  void  Clear();
  void  SetColor(const osg::Vec4& Color);
  void  SetAlpha(const float& rAlpha);
  const osg::Vec4& GetColor() const { return m_Color; }
  void  AddGlow(MAFOSGData* pSeatData, const std::string& strGlowTemplate, char AnchorSide);
  inline int CardsCount() const { return m_nCardsCount; }
  inline int KnownCardsCount() const { return m_nKnownCardsCount; }
  PokerCardController* GetCard(int nCardIndex) { return m_Cards.at(nCardIndex).get(); }
  void  ShowCards(bool bShow);
	CardsGroup() { m_nCardsCount = 0; m_nKnownCardsCount = 0;}

private:

  void ApplyColor(const osg::Vec4& Color);

  int m_nCardsCount;
  int m_nKnownCardsCount;
  typedef std::vector<osg::ref_ptr<PokerCardController> >                 Cards_t;
  typedef std::vector<osg::ref_ptr<PokerCardController> >::iterator       Cards_it;
  typedef std::vector<osg::ref_ptr<PokerCardController> >::const_iterator Cards_cit;

  Cards_t m_Cards;
  osg::ref_ptr<osg::Node> m_Glow;
  osg::Vec4 m_Color;
};


class PokerShowdownBBoxBiasedGeom : public osg::Geometry
{
public:
  PokerShowdownBBoxBiasedGeom(const osg::Geometry& Source):osg::Geometry(Source), m_vBBoxOffset(0.0f, 0.0f, 0.0f){}
  PokerShowdownBBoxBiasedGeom():m_vBBoxOffset(0.0f, 0.0f, 0.0f){}
  void SetOffset(const osg::Vec3& vOffset) { m_vBBoxOffset = vOffset; }

protected:
  osg::Vec3 m_vBBoxOffset;

#if OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
  bool computeBound() const
  {
    bool bRet = osg::Geometry::computeBound();
    OffsetBBox(m_vBBoxOffset);

    return bRet;
  }
#else // OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
  virtual osg::BoundingBox computeBound() const
  {
    osg::BoundingBox bb = osg::Geometry::computeBound();
    OffsetBBox(m_vBBoxOffset);

    return bb;
  }
#endif // OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2

  void OffsetBBox(const osg::Vec3& vOffset) const
  {
#if OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
    osg::BoundingBox& bbox = _bbox;
#else // OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
    osg::BoundingBox& bbox = _boundingBox;
#endif // OSG_VERSION_RELEASE != 9 && OSG_VERSION_MAJOR != 1 && OSG_VERSION_MAJOR != 2
    bbox.xMin() += vOffset.x();
    bbox.xMax() += vOffset.x();

    bbox.yMin() += vOffset.y();
    bbox.yMax() += vOffset.y();

    bbox.zMin() += vOffset.z();
    bbox.zMax() += vOffset.z();
  }
  
};

class PokerShowdownModel : public UGAMEArtefactModel
{
public:
  PokerShowdownModel(PokerApplication* game, MAFOSGData* data,unsigned int controllerID);
  virtual ~PokerShowdownModel();

  virtual void Init(void);

  enum Side 
  { 
    HIGH        = 0,
    LOW         = 1,
    CARDS_SIZE  = 2
  };

  void SwapCardGroups();
  void SetScale(float fScale);

  PokerApplication* mGame;
  osg::ref_ptr<osgText::Text> mHandValue;
  osg::Vec4   mColors[CARDS_SIZE];
  CardsGroup  mCardsGroup[CARDS_SIZE];
  osg::Vec4   mShowdownCardColor;
  osg::MatrixTransform* mScaleTransform;

  static osg::Vec4 GetColorFromConfigFile(PokerApplication* game, const std::string& strXMLurl);
};


class PokerShowdownController : public UGAMEArtefactController 
{
protected:
  virtual ~PokerShowdownController();

public:
  PokerShowdownController(PokerApplication* game, MAFOSGData* data,unsigned int controllerID=0);

  PokerShowdownModel* GetModel() { return dynamic_cast<PokerShowdownModel*>(UGAMEArtefactController::GetModel()); }

	virtual const char* GetControllerName() const { return "PokerShowdownController"; }

  virtual bool Update(MAFApplication* application);

  void  SetFocus(bool bFocused) { m_bFocused = bFocused; }
  bool  Focused() const { return m_bFocused; }

  /// TurnProjectorOn/Off functions trigger projector scale/fade animation
  void  TurnProjectorOn();
  void  TurnProjectorOff();

  void  SetCards(const std::string& side, std::vector<int> values);
  void  SetWinner(const std::string& handval);
  void  ResetWinner();

  void  Reset(void);
	void  ResetText();

  static void  SetColor(osg::Node* node, const osg::Vec4& color);

  class LightRayGeometry : public osg::Geometry {
  public:

	  LightRayGeometry(const osg::Geometry &_geom, int _index, PokerShowdownController *_showdown, osg::MatrixTransform *_attachedTo, const osg::CopyOp &_copyop = osg::CopyOp::SHALLOW_COPY)
		  : osg::Geometry(_geom, _copyop)
	  {
		  m_rayIndex = _index;
		  m_showdown = _showdown;
		  m_attachedTo = _attachedTo;
		  m_cardGroupToProject = NULL;
	  }

	  int m_rayIndex;
	  PokerShowdownController *m_showdown;
	  osg::MatrixTransform *m_attachedTo;
	  osg::Matrix m_invAttachedTo;

    osg::Vec3f m_cardsHull[4];

	  //PokerShowdownController::CardsGroup *m_cardGroupToProject;
	  //int m_iCardToProject;
    PokerCardController *m_cardGroupToProject;
	  osg::Vec3f m_anchorPos;

#if OSG_VERSION_MAJOR != 2
	  virtual void drawImplementation(osg::State &) const;
#else // OSG_VERSION_MAJOR != 2
	  virtual void drawImplementation(osg::RenderInfo &) const;
#endif  // OSG_VERSION_MAJOR != 2
  };

protected:

	PokerApplication*   m_game;
	PokerPlayer*        m_showDownPlayer;
  osg::AutoTransform* m_auto;
	osg::Geode*         m_lightRay[2];
	osg::TexMat*        m_lightRayProjMat[2][2];
	osg::Material*      m_lightRayMaterial[2];
  LightRayGeometry*   m_lrgeom[2];
  osg::Vec3f          m_cardsHull[4];
	MAFOSGData*         m_seatData;

  bool                m_bFocused;
  bool                m_bWinner;
  bool                m_bProjectorActive;
  bool                m_bExpandProjector;

  osg::Vec4           m_CurrentColor;
  osg::Vec4           m_TargetColor;
  float               m_CurrentScale;
  float               m_TargetScale;

  // static config parameters
  static float      s_alphaFadeInFactor;
  static float      s_alphaStayDuration;
  static float      s_alphaFadeOutFactor;
  static float      s_ScaleWon;
  static float      s_ScaleLost;
  static float      s_ExpandSpeedFactor;
  static osg::Vec4  s_ProjectorColorWon;
  static osg::Vec4  s_ProjectorColorLost;

  static void ReadStaticParametersFromConfigFile(PokerApplication *_game);

private:  
  bool  HasCards();
  bool  HasKnownCards();
  bool  HasHighAndLowCards();
  void  ShowCards(bool bShow);
  void  BypassFade();
  void  UpdateScale(float dt);
  void  UpdateColor(float dt);
  void  UpdateLightRayGeom();
  void  UpdateLightRayBoundaries(PokerShowdownModel::Side side);  
  void  SetLightRayColor(const osg::Vec4& Color);

  void TEST_SinalWave(float dt);

 public:
  bool	m_bProjectorEnabled;
  void	EnableProjector();
  void	DisableProjector();
};


#endif // _pokershowdown_h
