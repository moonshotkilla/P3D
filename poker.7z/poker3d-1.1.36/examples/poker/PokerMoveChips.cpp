/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include "pokerStdAfx.h"
#include <PokerEvent.h>

#ifndef POKER_USE_VS_PCH
#include "CustomAssert/CustomAssert.h"
#include "PokerMoveChips.h"
#include "PokerPot.h"
#include "PokerApplication.h"
#include "PokerPot.h"
#include "PokerError.h"
#include <osg/Geode>
#include <osg/ShapeDrawable>
#include "PokerPlayer.h"
#include "PokerBody.h"
#include <cal3d/scheduler.h>
#endif

template<>
void PokerMoveChips::GameAccept<PokerEventPotChips>(const PokerEventPotChips& event)
{
  PokerPotChips(event.mIndex, event.mAmounts);
}

template<>
void PokerMoveChips::GameAccept<PokerEventPlayerLeave>(const PokerEventPlayerLeave& event)
{
  PlayerLeave(event.mSerial);
}

template<>
void PokerMoveChips::GameAccept<PokerEventPlayerFold>(const PokerEventPlayerFold& event)
{
  PlayerFold(event.mSerial);
}

template<>
void PokerMoveChips::GameAccept<PokerEventSwitchToExistingTable>(const PokerEventSwitchToExistingTable& event)
{
  SwitchToExistingLevel();
}

template<>
void PokerMoveChips::GameAccept<PokerEventGameStart>(const PokerEventGameStart& event)
{
  GameStart();
}

template<>
void PokerMoveChips::GameAccept<PokerEventEndRound>(const PokerEventEndRound& event)
{
  EndRound();
}


template<>
void PokerMoveChips::GameAccept<PokerEventChipsBet2Pot>(const PokerEventChipsBet2Pot& event)
{
  if (event.mBatchMode)
    return;

  if(mSerial2Player.find(event.mSerial) == mSerial2Player.end()) {
    g_error("PokerMoveChips::GameAccept<PokerEventChipsBet2Pot> serial %d not matching any player", event.mSerial);
  } else {
    PokerPlayer* player = mSerial2Player[event.mSerial].get();
    if (!player)
      g_error("Player with serial %d does not exist",event.mSerial);
    else {
      PokerChipsBet2Pot(event.mSerial, event.mPot, event.mAmounts);
    }
  }
}


template<>
void PokerMoveChips::GameAccept<PokerEventChipsPot2Player>(const PokerEventChipsPot2Player& event)
{
  if (event.mBatchMode)
    return;

  if(mSerial2Player.find(event.mSerial) == mSerial2Player.end()) {
    g_error("PokerMoveChips::GameAccept<PokerEventChipsPot2Player> serial %d not matching any player", event.mSerial);
  } else {
    PokerPlayer* player = mSerial2Player[event.mSerial].get();
    if (!player)
      g_error("Player with serial %d does not exist",event.mSerial);
    else {
      mPot2PlayerCommand.push_back(PokerMoveChipsCommand(event.mSerial,event.mAmounts,event.mPot));
    }
    mLastPacketPotChip.clear(); // clear unused last packet POKER_POT_CHIPS when paying players
    mPacketPot2PlayerReceived=true; // when i receive a POT2PLAYER I suppose it's the end of game so i will reset betstack of player after animations
  }
}


void PokerMoveChips::PokerPotChips(int index, const std::vector<int>& amounts)
{
  mLastPacketPotChip[index]=amounts;
}

void PokerMoveChips::PokerChipsBet2Pot(int serial, int pot, const std::vector<int>& amounts)
{
  mBet2PotCommand.push_back(PokerMoveChipsCommand(serial,amounts,pot));
}


void PokerMoveChips::GameStart() 
{
  mPacketPot2PlayerReceived = false;
  // clear possible pot2player animation that will not be resumed
  // it does not work
  mBet2PotCommand.clear();
  mActiveBet2Pot->ClearAllEntries();
}


void PokerMoveChips::PlayerLeave(int serial)
{
  // clear active move chips that concern the player
  mActivePot2Player->ClearEntries(serial);
  mActiveBet2Pot->ClearEntries(serial);
}


void PokerMoveChips::EndRound() 
{
  SortStack(mBet2PotCommand,false);
  SortStack(mPot2PlayerCommand,true);
}


void PokerMoveChips::PlayerFold(int serial) 
{
  typedef std::vector<PokerMoveChipsCommand>::iterator PMCCIt;
  std::vector<PMCCIt> toremove;
  PMCCIt it = mBet2PotCommand.begin();
  for (;it != mBet2PotCommand.end();) {
    if (it->mSerial==serial)
      it = mBet2PotCommand.erase(it);
    else
      it++;
  }
}

void PokerMoveChips::SwitchToExistingLevel() 
{
  mBet2PotCommand.clear();
  mPot2PlayerCommand.clear();
}

void PokerMoveChips::Update(PokerApplication* game,
                            PokerPotController* potcenter)
{

  bool allPlayerBetAnimationFinished = IsValidToRunAnimationBet2Pot();

	// chips animation
	bool isBet2PotChips=IsAnyChipsToMoveToPot();
	bool isPot2PlayerChips = IsAnyChipsToMoveToPlayer();
	bool isfreezed = potcenter->IsFreezed();
	bool isStoped = potcenter->IsStopped();

  if (IsAnimationsBet2PotFinished(isfreezed, isStoped)) {

		potcenter->UnFreezeCenter();
		mEventRunAnimationProcess=false;

		// animation is finished so renormalize pot chips;
		for (std::map<int,std::vector<int> >::iterator i=mLastPacketPotChip.begin(); i != mLastPacketPotChip.end();i++)
			potcenter->SetPotValue(i->second,i->first);
		mLastPacketPotChip.clear();

		if (mPacketPot2PlayerReceived && !isPot2PlayerChips) {
			// end of turn and animations are finished so clear player chips (betStack)
			for (PokerModel::Serial2Player::iterator it = mSerial2Player.begin(); it != mSerial2Player.end();it++)
				if (it->second.get())
					it->second->GetBetStack()->Clear();

			mPacketPot2PlayerReceived=false;
		}
	}


	if (isBet2PotChips) {
		if (!potcenter->IsFreezed()) {
			potcenter->FreezeCenter();
		} else if (potcenter->IsStopped()) {
			g_debug("B2P:Center is stoped and there is bet2pot chips");
			if (allPlayerBetAnimationFinished) {
				g_debug("B2P:Run Animations Bet2Pot");

        RunAnimationsBet2PotForPlayerFinishToBet(potcenter);
			} else {
				g_debug("B2P: all player have not finished to bet");
        ReportPlayersHaveBet2PotAndHaveNotFinishToBet();
      }
		}
	}


	if (!mActiveBet2Pot->HasAnimation() && !IsAnyChipsToMoveToPot()) { // don't play winner chips if there are Bet2Pot Animation active or if packets Bet2Pot need to be animated
		if (isPot2PlayerChips) {
			if (!potcenter->IsFreezed()) {
				potcenter->FreezeCenter();
			} else if (potcenter->IsStopped()) {
        RunAnimationsPot2Players(potcenter);
			}
		}
	}

  
	// update track of animation
	mActivePot2Player->RemoveFinishedEntry();
	mActiveBet2Pot->RemoveFinishedEntry();
}


bool PokerMoveChips::IsAnimationsBet2PotFinished(bool potCenterIsFrozen, bool potCenterIsStoped)
{
 	if (mEventRunAnimationProcess && !mActivePot2Player->HasAnimation() && !mActiveBet2Pot->HasAnimation() && potCenterIsFrozen && potCenterIsStoped)
    return true;
  return false;
}


void PokerMoveChips::RunAnimationsBet2PotForPlayerFinishToBet(PokerPotController* potcenter)
{
  RunChipsAnimationBet2Pot(potcenter);
  mBet2PotCommand.clear();
  mEventRunAnimationProcess=true;
}


void PokerMoveChips::RunAnimationsPot2Players(PokerPotController* potcenter)
{
  mEventRunAnimationProcess=true;
  RunChipsAnimationPot2Player(potcenter);
  mPot2PlayerCommand.clear();
}

void PokerMoveChips::ReportPlayersHaveBet2PotAndHaveNotFinishToBet()
{
  for (std::vector<PokerMoveChips::PokerMoveChipsCommand>::iterator it = mBet2PotCommand.begin(); it != mBet2PotCommand.end();it++) {
    PokerModel::Serial2Player::iterator itfound = mSerial2Player.find(it->mSerial);
    if (itfound != mSerial2Player.end()) {
      PokerPlayer* p = mSerial2Player[it->mSerial].get();
      // now it's python that says if an animation hasrunanimationbet(false) throw packer POKER_ANIMATION_CHIPS with state hide and an animation bet
      // so the condition could be ( p && p->HasRunAnimationBet())
      if (p && p->HasRunAnimationBet() /* && !p->IsAnimationBetFinished()*/) {
        g_debug("B2P: serial %d has not finished to bet",it->mSerial);
      }
    }
  }
}

bool PokerMoveChips::IsValidToRunAnimationBet2Pot()
{
	// manage chips player 2 bet
	bool allPlayerBetAnimationFinished=true;
	for (std::vector<PokerMoveChips::PokerMoveChipsCommand>::iterator it = mBet2PotCommand.begin() ; it != mBet2PotCommand.end();it++) {
		std::map<guint,osg::ref_ptr<PokerPlayer> >::iterator itfound = mSerial2Player.find(it->mSerial);
		if (itfound != mSerial2Player.end()) {
			PokerPlayer* p = mSerial2Player[it->mSerial].get();
			// now it's python that says if an animation hasrunanimationbet(false) throw packer POKER_ANIMATION_CHIPS with state hide and an animation bet
			// so the condition could be ( p && p->HasRunAnimationBet())
			if (p && p->HasRunAnimationBet() /* && !p->IsAnimationBetFinished()*/) {
				allPlayerBetAnimationFinished=false;
				break;
			}
		}
	}
  return allPlayerBetAnimationFinished;
}

PokerMoveChips::PokerMoveChips(std::map<guint,osg::ref_ptr<PokerPlayer> >& serial) : mSerial2Player(serial)
{
  mActiveBet2Pot = new PokerTrackActiveMoveChips(serial);
  mActivePot2Player = new PokerTrackActiveMoveChips(serial);
  mEventRunAnimationProcess = false;
}


bool PokerMoveChips::PokerTrackActiveMoveChips::HasAnimation() 
{
  return mActives.size()!=0;
}

void PokerMoveChips::PokerTrackActiveMoveChips::RemoveFinishedEntry() 
{
  for (std::vector<EntryElement>::iterator i=mActives.begin();i!=mActives.end();) {
    if (mSerial2Player.find((*i).mSerial)==mSerial2Player.end()) {// test first if the player is already here
      i=mActives.erase(i);
    } else if ((*i).mAnimation->mFinished) {
      PokerPlayer* player=mSerial2Player[(*i).mSerial].get();
      i->mAnimation->ExecuteAtEnd(player);
      i=mActives.erase(i);
    } else
      i++;
  }
}

void PokerMoveChips::PokerTrackActiveMoveChips::ClearEntries(guint serial) 
{
  for (std::vector<EntryElement>::iterator i=mActives.begin();i!=mActives.end();) {
    if (mSerial2Player.find((*i).mSerial)==mSerial2Player.end()) {// test first if the player is already here
      i=mActives.erase(i);
    } else if ((*i).mSerial == serial) {
      i=mActives.erase(i);
		} else
			i++;
	}
}


void PokerMoveChips::PokerTrackActiveMoveChips::ClearAllEntries() 
{
	mActives.clear();
}


void PokerMoveChips::SortStack(std::vector<PokerMoveChipsCommand>& stackToSort,bool toPlayer)
{
  for (std::vector<PokerMoveChipsCommand>::iterator i=stackToSort.begin();i!=stackToSort.end();)
    if ((*i).IsEmpty() || mSerial2Player.find((*i).mSerial) == mSerial2Player.end() )
      i=stackToSort.erase(i);
    else
      i++;
}

bool PokerMoveChips::IsAnyChipsToMoveToPotFromPlayer(int serial)
{
  int e=(int)mBet2PotCommand.size();
  for (int i=0;i<e;i++)
    if (!mBet2PotCommand[i].IsEmpty())
      if (mBet2PotCommand[i].mSerial==serial)
        return true;
  return false;
}

bool PokerMoveChips::IsAnyChipsToMoveToPot()
{
  int e=(int)mBet2PotCommand.size();
  for (int i=0;i<e;i++)
    if (!mBet2PotCommand[i].IsEmpty())
      return true;
  return false;
}

bool PokerMoveChips::IsAnyChipsToMoveToPlayer()
{
  int e=(int)mPot2PlayerCommand.size();
  for (int i=0;i<e;i++)
    if (!mPot2PlayerCommand[i].IsEmpty())
      return true;
  return false;
}

float PokerMoveChips::RunChipsAnimationBet2Pot(PokerPotController* potcenter)
{
  std::vector<int> betNull;
  float res=0;
  int e=(int)mBet2PotCommand.size();
  for (int i=0;i<e;i++) {
    if (mSerial2Player.find(mBet2PotCommand[i].mSerial)!=mSerial2Player.end()) {
      PokerPlayer* p=mSerial2Player[mBet2PotCommand[i].mSerial].get();
			CUSTOM_ASSERT(p);
			if (!p)
				continue;
      PokerMoveChipsBet2PotController* a=p->GetFreeAnimationBet2Pot();
      if (a) {
        potcenter->BuildAnimationBetToPot(a,mBet2PotCommand[i].mIndex);
        a->mChips->SetChips(mBet2PotCommand[i].mChips);
        a->StartAnimation();
        a->SetTargetChipsStack(potcenter->GetPotChipsStack(mBet2PotCommand[i].mIndex));
        mActiveBet2Pot->AddEntry(PokerTrackActiveMoveChips::EntryElement(mBet2PotCommand[i].mSerial,a));
        p->SetBet(betNull);
      }
    }
  }
  return res;
}
float PokerMoveChips::RunChipsAnimationPot2Player(PokerPotController* potcenter)
{
  float res=0;
  int e=(int)mPot2PlayerCommand.size();
  for (int i=0;i<e;i++) {
    if (mSerial2Player.find(mPot2PlayerCommand[i].mSerial)!=mSerial2Player.end()) {
      PokerPlayer* p=mSerial2Player[mPot2PlayerCommand[i].mSerial].get();
      PokerMoveChipsPot2PlayerController* a=p->GetFreeAnimationPot2Player();

      p->GetBetStack()->Clear();

			p->GetPot2PlayerChipStack()->Clear();
			p->DisplayPot2PlayerChipStack(true);

      if (a) {
        potcenter->BuildAnimationPotToPlayer(a,mPot2PlayerCommand[i].mIndex);
        osg::Matrix res=MAFComputeLocalToWorld(p->GetBetStack()->GetModel()->GetNode());
        a->SetDestination(res.getTrans());
        a->mChips->SetChips(mPot2PlayerCommand[i].mChips);
        
        a->SetAmount(mPot2PlayerCommand[i].mChips);
        a->SetTargetChipsStack(p->GetPot2PlayerChipStack());
        a->StartAnimation();
        mActivePot2Player->AddEntry(PokerTrackActiveMoveChips::EntryElement(mPot2PlayerCommand[i].mSerial,a));
      }
    }
  }
  potcenter->ResetPots();
  return res;
}





















PokerMoveChipsBase::PokerMoveChipsBase(PokerApplication* game,unsigned int controllerID):MAFController(controllerID)
{
  mChips=new PokerChipsStackController(game,controllerID);

  mFinished=true;
  mTransform=new osg::MatrixTransform;
  mTransform->setMatrix(osg::Matrix::identity());
}

void PokerMoveChipsBase::UpdateTarget() 
{
  if (mTargetChips.get()) {
    mTargetChips->AddChips(mChips->GetChips());
    mTargetChips=0;
  }
  mChips->Clear();
}

void PokerMoveChipsBase::Display(bool state)
{
  if (state)
    mTransform->setNodeMask(MAF_VISIBLE_MASK);
  else
    mTransform->setNodeMask(0);
}

bool PokerMoveChipsBase::IsFinished()
{
  return mFinished;
}

PokerMoveChipsBase::~PokerMoveChipsBase()
{
  //	g_debug("PokerMoveChipsBase::~PokerMoveChipsBase");
  mTransform=0;
  mTargetChips=0;
  mChips=0;
}




PokerMoveChipsBet2PotController::PokerMoveChipsBet2PotController(PokerApplication* game,osg::Node* source,unsigned int controllerID):PokerMoveChipsBase(game,controllerID)
{
  mNode=source;
  mTransform->addChild(mChips->GetModel()->GetArtefact());
  PokerMoveChipsBase::Display(false);
}


PokerMoveChipsBet2PotController::~PokerMoveChipsBet2PotController()
{
  RecursiveClearUserData(mTransform.get());
  mTransform->removeChild(mChips->GetModel()->GetArtefact());
  osg::NodeVisitor* leakNodes = RecursiveLeakCollect(mTransform.get());
  RecursiveLeakCheck(leakNodes);
  mNode=0;
}

void PokerMoveChipsBet2PotController::StartAnimation()
{
  mFinished=false;
  PokerMoveChipsBase::Display(true);

  // init the position of stacks
  osg::Matrix rot;
  rot.makeIdentity();
  rot.makeRotate(0,osg::Vec3(0,1,0));
  osg::Vec3 dir=osg::Vec3(0,1,mDistanceFromCenter-mDistanceToInterpolate);
  osg::Matrix tran=osg::Matrix::translate(dir);
  osg::Vec3 out=(tran*rot*mBaseMatrix).getTrans();
  mTransform->setMatrix(osg::Matrix::translate(out));
}


void PokerMoveChipsBet2PotController::InitAnimation()
{
  const float mTimeDurationScale = 1.0/osg::PI;
  const float mParamAngleInterpolation=15.0*osg::PI/180.0;

  mInternalTimer=0;
  float timeOfEndPart=mParamAngleInterpolation*mTimeDurationScale;
  float timeOfAnimation=fabs(mAngleToInterpolate*mTimeDurationScale);
  mTimeDuration=timeOfAnimation;
  if (mTimeDuration<timeOfEndPart)
    mTimeDuration=timeOfEndPart;
  mTimeToOffset=mTimeDuration-timeOfEndPart;
}


bool PokerMoveChipsBet2PotController::Update(MAFApplication* application)
{
  PokerApplication* game = dynamic_cast<PokerApplication*>(application);
  if(game->HasEvent())
    return true;

  if (mFinished)
    return true;

  float delta=GetDeltaFrame()*1.0/1000.0;
  osg::Vec3 out;

  mInternalTimer+=delta;

  float timeRatio=mInternalTimer/mTimeDuration;
  float res=mAngleToInterpolate*timeRatio;
  float offset=0;

  if (mInternalTimer>mTimeToOffset) {
    offset=-mDistanceToInterpolate*(mInternalTimer-mTimeToOffset)/(mTimeDuration-mTimeToOffset);
  }


  osg::Matrix rot;
  rot.makeIdentity();
  rot.makeRotate(res,osg::Vec3(0,1,0));
  osg::Vec3 dir=osg::Vec3(0,1,mDistanceFromCenter+offset);
  osg::Matrix tran=osg::Matrix::translate(dir);
  out=(tran*rot*mBaseMatrix).getTrans();

  if (mInternalTimer>mTimeDuration) {
    mFinished=true;
    PokerMoveChipsBase::Display(false);
    UpdateTarget();
  }

  mTransform->setMatrix(osg::Matrix::translate(out));
  return true;
}


void PokerMoveChipsPot2PlayerController::InitAnimation()
{
  const float mTimeDurationScale = 1.0/osg::PI;
  const float mParamAngleInterpolation=15.0*osg::PI/180.0;

  mInternalTimer=0.0001;
  float timeOfEndPart=mParamAngleInterpolation*mTimeDurationScale;
  float timeOfAnimation=fabs(mAngleToInterpolate*mTimeDurationScale);
  mTimeDuration=timeOfAnimation;
  if (mTimeDuration<timeOfEndPart)
    mTimeDuration=timeOfEndPart;
  mTimeToOffset=mTimeDuration-timeOfEndPart;
}

bool PokerMoveChipsPot2PlayerController::Update(MAFApplication* application)
{
  PokerApplication* game = dynamic_cast<PokerApplication*>(application);
  if(game->HasEvent())
    return true;

  if (mFinished)
    return true;

  float delta=GetDeltaFrame()*1.0/1000.0;
  osg::Vec3 out;

  mInternalTimer+=delta;

  float timeRatio=mInternalTimer/mTimeDuration;
  float res=mAngleToInterpolate*timeRatio;
  float offset=0;

  if (mInternalTimer<mTimeToOffset) {
    offset=-mDistanceToInterpolate*(mTimeToOffset-mInternalTimer)/(mTimeToOffset);
  }

  osg::Matrix rot;
  rot.makeIdentity();
  rot.makeRotate(res,osg::Vec3(0,1,0));
  osg::Vec3 dir=osg::Vec3(0,1,mDistanceFromCenter+offset);
  osg::Matrix tran=osg::Matrix::translate(dir);
  out=(tran*rot*mBaseMatrix).getTrans();

  if (mInternalTimer>mTimeDuration) {
    mFinished=true;
    out=mDestination;
		PokerMoveChipsBase::Display(false);
		UpdateTarget();
  }

  mTransform->setMatrix(osg::Matrix::translate(out));
  return true;
}


void PokerMoveChipsBet2PotController::ExecuteAtEnd(PokerPlayer* player)
{
}


void PokerMoveChipsPot2PlayerController::ExecuteAtEnd(PokerPlayer* player)
{
}


PokerMoveChipsPot2PlayerController::~PokerMoveChipsPot2PlayerController()
{
}
