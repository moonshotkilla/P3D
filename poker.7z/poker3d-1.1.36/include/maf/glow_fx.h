/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@tsarevitch.org>
*
*/

#ifndef MAF_GLOW_FX
#define MAF_GLOW_FX

#ifndef MAF_USE_VS_PCH
#include <osg/Node>
#endif

class MAFPBuffer;

class MAFGlowFX {
public:

	MAF_EXPORT static void init(int textureSize, bool bUsePBuffer = true, MAFPBuffer *pbuffer = NULL, int pbufferSize = 0);
	MAF_EXPORT static void uninit();

	MAF_EXPORT static void markNodeAsGlowing(osg::Node *, bool bDefineRBin, int rbin = 1);

	MAF_EXPORT static void captureBackBufferToGlowTexture(int backBufferWidth, int backBufferHeight);
	MAF_EXPORT static void workOnGlowTexture();

	MAF_EXPORT static void drawGlowTexture();

	MAF_EXPORT static float getGlowTextureOpacity();
	MAF_EXPORT static void setGlowTextureOpacity(float opa);

	MAF_EXPORT static MAFPBuffer* getPBuffer();
	MAF_EXPORT static bool isUsePBuffer();

	MAF_EXPORT static void calculMatrixConvolution(float r);
};

#endif
