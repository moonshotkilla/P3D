/*
 *
 * Copyright (C) 2007 Loic Dachary <loic@dachary.org>
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Igor kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef maf_data_h 
#define maf_data_h

#ifndef MAF_USE_VS_PCH

#include <string>
#include <vector>

#include <glib.h>
#include <cal3d/tinyxml.h>

#include <osg/ref_ptr>
#include <osg/Matrix>
#include <osg/LightSource>
#include <osgDB/ReaderWriter>

#include <libxml/tree.h>
#include <libxml/xpath.h>

#include <AL/al.h>
#if OSGAL_VERSION < 0X000600
#include <openalpp/alpp.h>
#else // OSGAL_VERSION < 0X000600
#include <openalpp/SoundData>
#endif // OSGAL_VERSION < 0X000600

#include <maf/mafexport.h>

#endif

#include <maf/utils.h>
#include <maf/camera.h>

#include <maf/anchor.h>

std::string EvalPath(const std::string& path);


namespace osgText { class Font; }

class MAFMonitor;

#if CAL3D_VERSION >= 11
namespace cal3d {
  class TiXmlElement;
}
using cal3d::TiXmlElement;
#else
class TiXmlElement;
#endif

class MAF_EXPORT MAFData {
public:
  MAFData() { }
  virtual ~MAFData() {}

  virtual bool Load(const std::string& path, osgDB::ReaderWriter::Options* options) = 0;
  virtual MAFData* Clone(unsigned int cloneFlag=0xFFFFFFFF) { abort(); }
	virtual bool ReLoad() { return false;}
};

class MAF_EXPORT MAFVisionData : public MAFData {
public:
  MAFVisionData() {}
  virtual ~MAFVisionData() {}

  MAFAnchor* GetAnchor(const std::string& __name) { return 0; }

  MAFCameraController* GetCamera(const std::string& name);
  MAFCameraController* getFirstCamera();

  std::vector<osg::ref_ptr<osg::LightSource> >& GetLights() { return mLights; }

  osg::ref_ptr<osg::LightSource>		getLightByIndex(int) const;
  
  std::vector<osg::ref_ptr<osg::LightSource> > mLights;
  std::map<std::string, osg::ref_ptr<MAFCameraController> > mCameras;
};

class MAF_EXPORT MAFOSGData : public MAFVisionData {
public:
  MAFOSGData() {}
  virtual ~MAFOSGData() {}

  virtual bool Load(const std::string& path, osgDB::ReaderWriter::Options* options);
  virtual MAFData* Clone(unsigned int cloneFlag=0xFFFFFFFF);

  void SetDescription(const std::string& name);
  MAFAnchor* GetAnchor(const std::string& name);
  void GroupAnchors(osg::Group* group, const std::vector<std::string>& names);
  osg::BoundingBox GetBound();
  osg::Node* GetNode(const std::string& name);

  osg::Group* GetGroup(void) { return mGroup.get(); }

protected:
  osg::ref_ptr<osg::Group> mGroup;
};

class MAF_EXPORT MAFESCNData : public MAFOSGData
{
public:

	explicit		MAFESCNData		(void);
	virtual			~MAFESCNData	(void);

	bool			Load(const std::string &path,
								const std::string &dir,
								const std::string &file,
								osgDB::ReaderWriter::Options *options,
								MAFMonitor *mon = NULL);

	osg::Node *		Convert(TiXmlElement *pElt,
											osg::Group *parent,
											const std::string &parentPath,
											osgDB::ReaderWriter::Options *options,
											MAFMonitor *mon = NULL);
	bool			ParseAnimation	(TiXmlElement * pElt, osg::Group* parent);
	void			getAttribute	(TiXmlElement * pElt, const std::string & strName, osg::Matrixf & m);
	void			getAttribute	(TiXmlElement * pElt, const std::string & strName, osg::Vec4f & v);

	osg::Vec4f	getAmbientColor() const { return mAmbientColor; }
	osg::Vec4f	getBackGroundColor() const { return mBackGroundColor; }
	osg::Vec4f	getFogColor() const { return mFogColor; }
	bool			isUseFog() const { return mbUseFog; }

	// set the global states set of the scene
	// it includes ambient, lights, fog, etc.
	void			setupRootStateSet(osg::StateSet *);

private:

	std::string		mPath;
	std::string		mDir;
	std::string		mFile;
	int				mCurrentLight;
	osg::Vec4f	mAmbientColor;
	osg::Vec4f	mBackGroundColor;
	osg::Vec4f	mFogColor;
	bool			mbUseFog;

	//osg::Tex
};


class MAF_EXPORT MAFAudioData : public MAFData {
 public:
  MAFAudioData():mSoundData(0) {}
  virtual ~MAFAudioData();
  
  virtual bool Load(const std::string& path, osgDB::ReaderWriter::Options* options) { mPath = path; return LoadAudio(path,options);}
	virtual bool LoadAudio(const std::string& path, osgDB::ReaderWriter::Options* options) = 0;
  openalpp::SoundData* GetSoundData() { return mSoundData.get();}

	bool Reload();
	
 protected:
	std::string mPath;
  void Error(const openalpp::Error& error);

  osg::ref_ptr<openalpp::SoundData> mSoundData;
};

class MAF_EXPORT MAFAudioDataWAV : public MAFAudioData {
 public:
  MAFAudioDataWAV(){}
  virtual ~MAFAudioDataWAV(){}
  
  virtual bool LoadAudio(const std::string& path, osgDB::ReaderWriter::Options* options = 0);
};


class MAF_EXPORT MAFAudioDataOGG : public MAFAudioData {
 public:
  MAFAudioDataOGG() {}
  virtual ~MAFAudioDataOGG() {}
  
  virtual bool LoadAudio(const std::string& path, osgDB::ReaderWriter::Options* options = 0);
};

class MAF_EXPORT MAFXmlData : public MAFData {
 public:
  MAFXmlData();
  virtual ~MAFXmlData();
  virtual bool Load(const std::string &path, osgDB::ReaderWriter::Options* options);


  std::string Get(const std::string& path);
  std::list<std::string> GetList(const std::string& path);
 private:
  xmlDocPtr mDocument;
};


class MAF_EXPORT MAFCursorData : public MAFData {
 public:
  MAFCursorData();
  virtual ~MAFCursorData();
  virtual bool Load(const std::string &path, osgDB::ReaderWriter::Options* options);
  
  SDL_Cursor *GetCursor();
  SDL_Cursor *CreateCursor();
  SDL_Cursor *GetOrCreateCursor();
 private:  
  SDL_Cursor *mCursor;
	static const int CURSOR_W = 32;
	static const int CURSOR_H = 32;
	static const int CURSOR_SIZE = CURSOR_W * CURSOR_H * 2 / 8;	
  Uint8 mData[CURSOR_SIZE];
};

class XwncDesktop;

class MAF_EXPORT MAFRepositoryData {
  static std::string mLevel;
  static std::string mDirectoryBase;
public:
  MAFRepositoryData()
    : mDesktop(0),mParent(0)
  {
	
  }
  ~MAFRepositoryData();

//   void Load(const std::string& dir);

  MAFVisionData* GetVision(const std::string& name, MAFMonitor *mon=NULL);
  MAFAudioData* GetAudio(const std::string& name, MAFMonitor *mon=NULL);
  MAFXmlData* GetXml(const std::string &name);
  MAFCursorData *GetCursor(const std::string &name);

//   MAFRepositoryData *GetDirectory(const std::string &name);
//   void LoadDirectory(const std::string &dirname,const std::string& registerName);
//   void UnLoadDirectory(const std::string &name);

  void SetLevel(const std::string& level) { mLevel=level;}
	const std::string& GetLevel() const { return mLevel;}
  void SetBaseDirectory(const std::string& dir) { mDirectoryBase=dir;}

  void ReloadAudio();
  
  XwncDesktop*	GetDesktop() const
  {
    return mDesktop;
  }

  void XwncConnect(const std::string& url);

private:  

  std::map<std::string, MAFVisionData*> mVisionMap;
  std::map<std::string, MAFAudioData*> mAudioMap;
  std::map<std::string, MAFXmlData*> mXmlMap;
  std::map<std::string, MAFCursorData*> mCursorMap;
  std::map<std::string, MAFRepositoryData*> mRepositoryMap;
  std::map<std::string, std::string> mLinks;
  XwncDesktop* mDesktop;
  MAFRepositoryData* mParent;

  std::string GetItem(const std::string& item);
  bool LoadItem(const std::string& item, MAFMonitor *mon = NULL);

};

MAF_EXPORT osgText::Font* MAFLoadFont(const std::string &font_file);
MAF_EXPORT osg::Image* MAFLoadImage(const std::string &image_file);

#endif // maf_data_h
