/*
*
* Copyright (C) 2007 Loic Dachary <loic@dachary.org>
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@obraz.net>
*
*/

#ifndef MAF_RENDERPBUFFER_H
#define MAF_RENDERPBUFFER_H

#ifndef MAF_USE_VS_PCH
#include <osg/Version>
#include <osg/Texture2D>
#include <osgUtil/RenderStage>
#endif

class MAFPBuffer;

class RenderPBuffer : public osgUtil::RenderStage {
public:
	RenderPBuffer();

	virtual osg::Object* cloneType() const { return new RenderPBuffer(); }
	virtual osg::Object* clone(const osg::CopyOp&) const { return new RenderPBuffer(); } // note only implements a clone of type.
	virtual bool isSameKindAs(const osg::Object* obj) const { return dynamic_cast<const RenderPBuffer*>(obj)!=0L; }
	virtual const char* libraryName() const { return "libmaf"; }
	virtual const char* className() const { return "RenderPBuffer"; }

	virtual void reset();

	void setTexture(osg::Texture2D* texture) { _texture = texture; }
	osg::Texture2D* getTexture() { return _texture.get(); }

	void setImage(osg::Image* image) { _image = image; }
	osg::Image* getImage() { return _image.get(); }

#if OSG_VERSION_MAJOR != 2
	virtual void draw(osg::State& state, osgUtil::RenderLeaf*& previous);
#else // OSG_VERSION_MAJOR != 2
	virtual void draw(osg::RenderInfo& state, osgUtil::RenderLeaf*& previous);
#endif  // OSG_VERSION_MAJOR != 2

protected:

	virtual ~RenderPBuffer();

	MAFPBuffer *pbuffer_;
	osg::ref_ptr<osg::Texture2D> _texture;
	osg::ref_ptr<osg::Image> _image;

};

#endif
