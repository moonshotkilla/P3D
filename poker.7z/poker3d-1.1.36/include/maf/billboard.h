/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@ozos.net>
 *
 */

#ifndef MAF_BILLBOARD_H
#define MAF_BILLBOARD_H

#ifndef MAF_USE_VS_PCH
#include <maf/mafexport.h>

#include <osg/Transform>
#endif

class MAF_EXPORT MAFBillBoard : public osg::Transform
{
public :
	MAFBillBoard();

	MAFBillBoard(const MAFBillBoard &pat, const osg::CopyOp &copyop = osg::CopyOp::SHALLOW_COPY);            

	virtual osg::Object* cloneType() const { return new MAFBillBoard(); }
	virtual osg::Object* clone(const osg::CopyOp& copyop) const { return new MAFBillBoard (*this,copyop); }
	virtual bool isSameKindAs(const osg::Object* obj) const { return dynamic_cast<const MAFBillBoard *>(obj)!=NULL; }
	virtual const char* className() const { return "MAFBillBoard"; }
	virtual const char* libraryName() const { return "maf"; }

	virtual void accept(osg::NodeVisitor &);

	virtual MAFBillBoard* asMAFBillBoard() { return this; }
	virtual const MAFBillBoard* asMAFBillBoard() const { return this; }

	virtual bool computeLocalToWorldMatrix(osg::Matrix &, osg::NodeVisitor *) const;
	virtual bool computeWorldToLocalMatrix(osg::Matrix &, osg::NodeVisitor *) const;

	bool isActive() const { return _bActive; }
	void setActive(bool bActive) { _bActive = bActive; }

protected :

	virtual ~MAFBillBoard() {}

	bool _bActive;

	void computeMatrix() const;

	mutable bool        _matrixDirty;
	mutable osg::Matrix _cachedMatrix;
};

#endif

