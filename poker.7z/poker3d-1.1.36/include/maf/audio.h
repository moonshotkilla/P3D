/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *  Vincent Caron <zerodeux@gnu.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 */

#ifndef maf_audio_h 
#define maf_audio_h

#ifndef MAF_USE_VS_PCH
#include <osg/Node>
#include <osgAL/SoundNode>
#include <osgAL/SoundState>
#endif

#include <maf/data.h>

#include <maf/model.h>
#include <maf/view.h>
#include <maf/controller.h>

#define MAF_AUDIO_NB_CHANNELS 16

class MAF_EXPORT MAFAudioDevice
{
	bool mSoundEnabled;
	bool mSoundDeviceHaveTried;

	void InitializeDevice();

public:
	MAFAudioDevice();
	~MAFAudioDevice();
	void DeInitializeDevice();
	bool SetSoundEnabled(bool enable);
	bool IsSoundEnabled() const { return mSoundEnabled;}
	bool IsSoundDeviceValid() const;

	static MAFAudioDevice *GetInstance();
};


class MAF_EXPORT MAFAudioModel : public MAFModel
{
public:

  struct MAFAudioParameter
  {
    MAFAudioParameter():mReferenceDistance(40),mRolloff(1),mPriority(0),mGain(1),mData(0),mName("noname"),mAmbient(false){}
    float mReferenceDistance;
    float mRolloff;
    int mPriority;
    float mGain;
    MAFAudioData* mData;
    std::string mName;
    bool mAmbient;
  };

public:
  MAFAudioModel();
  virtual ~MAFAudioModel();

  void SetData(MAFAudioData* data);

  const std::string& GetName();
  void SetName(const std::string& name);

  ALfloat GetGain();
  void SetGain(ALfloat gain);

  bool GetPlaying();
  void SetPlaying( bool playing );

  void SetPriority(int pri);
  int GetPriority();

  osg::Node* GetNode() { return mNode.get();}

  void SetStatePlaying(bool b);

  void SetStopMethod(openalpp::SourceState stop);

  bool PlayEvent(int priority=-1);

  osgAL::SoundState* GetState() { return mSoundState.get();}
  void SetReferenceDistance(float d);

  void SetRolloff(float d);
  float GetRolloff();
  float GetReferenceDistance();

  void SetAmbient(bool a);
  void DumpState();

  void SetSource(openalpp::Source* source);
  void SetSoundEvent(bool state) { mEventSound=state;}
  bool GetSoundEvent() const { return mEventSound;}

  void Init();

  void SetParameter(const MAFAudioParameter& param) { mParameters=param;}
  MAFAudioParameter& GetParameter() { return mParameters;}
  const MAFAudioParameter& GetParameter() const { return mParameters;}
  void ApplyParameter();
  
  static void CheckError(const std::string& message);

protected:
  osg::ref_ptr<osgAL::SoundState> mSoundState;
  osg::ref_ptr<osgAL::SoundNode> mNode;
  bool mEventSound;
  MAFAudioParameter mParameters;  
};


typedef MAFView MAFAudioView;

class MAFSceneController;

class MAF_EXPORT MAFAudioController : public MAFController
{
public:
  MAFAudioController() {}
  virtual ~MAFAudioController() {}

  MAFAudioModel* GetModel() { return dynamic_cast<MAFAudioModel*>(MAFController::GetModel()); }
  MAFAudioView* GetView() { return dynamic_cast<MAFAudioView*>(MAFController::GetView()); }

  virtual void Init( void );

  void BindToScene(MAFSceneController* scene);
  void AttachTo( osg::Group* group );
  void Play( void );
  void PlayEvent( void );
  void Stop( void );

};



typedef MAFView MAFAudioSourceView;
class MAF_EXPORT MAFAudioSourceModel : public MAFModel
{

public:

  typedef std::map<std::string,MAFAudioModel::MAFAudioParameter> SoundMap;

  MAFAudioSourceModel();

  void Play(const std::string& name);
  void Stop();

  SoundMap mSounds;
  osg::ref_ptr<MAFAudioController> mSound;
  
};


class MAF_EXPORT MAFAudioSourceController : public MAFController
{
protected:
  virtual ~MAFAudioSourceController() {}

public:
  MAFAudioSourceController() { SetModel(new MAFAudioSourceModel); }

  MAFAudioSourceModel* GetModel() { return dynamic_cast<MAFAudioSourceModel*>(MAFController::GetModel()); }
  MAFAudioView* GetView() { return dynamic_cast<MAFAudioSourceView*>(MAFController::GetView()); }

  virtual void Init();

  void BindToScene(MAFSceneController* scene);
  void AttachTo( osg::Group* group );
  void Play(const std::string& sound) { GetModel()->Play(sound); }
  void Stop() { GetModel()->Stop();}
  void Enable();
  void Disable();
};

#endif // maf_audio_h
