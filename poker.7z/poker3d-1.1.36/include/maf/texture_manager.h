/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#ifndef	_texture_manager_h
#define	_texture_manager_h

#ifndef MAF_USE_VS_PCH
#include <maf/maferror.h>

#include <sys/types.h>
#include <sys/stat.h>

#ifndef WIN32
#include <unistd.h>
#endif

#include <map>
#include <string>
#endif

#include <osgDB/Registry>
#include <osgDB/ReadFile>
#include <osgDB/WriteFile>

#include <osg/Texture2D>


class TextureInformation : public osg::Referenced
{
	std::string _name;
	int _width,_height;
	time_t _lastModificationTime;

protected:
	~TextureInformation() {}

public:
	TextureInformation(const std::string& name,int s,int t):_name(name),_width(s),_height(t), _lastModificationTime(0) {}
	const std::string& getName() const { return _name;}
	void setName(const std::string& name) { _name=name;}
	int getWidth() const { return _width;}
	int getHeight() const { return _height;}
	time_t getLastModificationTime()
	  {
	    return _lastModificationTime;
	  }
	void resetLastModificationTime()
	  {
	    struct stat ss;
	    int statResult = stat(_name.c_str(), &ss);
	    if (statResult == 0)
	      _lastModificationTime = ss.st_mtime;
	  }
	bool hasChanged()
	  {
	    time_t previousModificationTime = _lastModificationTime;
	    resetLastModificationTime();
	    return (_lastModificationTime != previousModificationTime);
	  }
};

class TextureManager
{
  typedef std::map<std::string,osg::ref_ptr<osg::Texture2D> > ContainerTexture;
  typedef std::map<osg::ref_ptr<osg::Texture2D>,std::string > ContainerTexture2Name;
  ContainerTexture mTextures;
  ContainerTexture2Name mTextures2Name;
  unsigned int mTextureSize;
  osg::ref_ptr<osgDB::ReaderWriter::Options> mOptions;
	bool mUseTrilinear;

public:

  MAF_EXPORT TextureManager();
  MAF_EXPORT ~TextureManager();
  MAF_EXPORT bool GetNameFromTexture2D(osg::Texture2D *, std::string &);
  MAF_EXPORT osg::Texture2D* GetTexture2D(const std::string& _name, osgDB::ReaderWriter::Options* _options = NULL);
  MAF_EXPORT void Statistics();
  MAF_EXPORT void Flush();
  MAF_EXPORT void Reload();
	MAF_EXPORT void SetUseTrilinear(bool);
	MAF_EXPORT bool IsUseTrilinear() const;
};

#endif
