/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@obraz.net>
*
*/

#ifndef IMGLAYERS_FLATTEN_H
#define IMGLAYERS_FLATTEN_H

#ifndef MAF_USE_VS_PCH
#include <maf/mafexport.h>

#include <osg/ref_ptr>

#include <vector>
#endif

namespace osg { class Texture2D; class Image; }

class MAFImageLayersFlatten {
public:

	enum PIXELOP {
		// terminology are taken from Photoshop
		PIXELOP_NORMAL,
		PIXELOP_OVERLAY,
		PIXELOP_LINEARDODGE,
		PIXELOP_MULTIPLY,
	};

	class Layer {
	public:

		MAF_EXPORT Layer() : img_(NULL), opacity_(1.0f) { };

		osg::Image *img_;
		PIXELOP pixelOp_;
		float opacity_;
	};

	MAF_EXPORT MAFImageLayersFlatten(int width, int height);
	virtual ~MAFImageLayersFlatten();

	MAF_EXPORT inline void addLayer(Layer &_layer) { layers_.push_back(_layer); }
	MAF_EXPORT inline void removeLayerByIndex(int _index) { layers_.erase(&layers_[_index]); }
	MAF_EXPORT inline const Layer& getLayerByIndex(int _index) const { return layers_[_index]; }
	MAF_EXPORT inline int getNbLayers() const { return layers_.size(); }

	MAF_EXPORT inline osg::Texture2D* getTexture() { return texture_.get(); }

	MAF_EXPORT void updateTexture();

	MAF_EXPORT void writeFinalImageToDisk(const char *fileName);

protected:

	void applyNormalMode(unsigned char *A, unsigned char *B, Layer &);
	void applyOverlayMode(unsigned char *A, unsigned char *B, Layer &);
	void applyLinearDodgeMode(unsigned char *A, unsigned char *B, Layer &);
	void applyMultiplyMode(unsigned char *A, unsigned char *B, Layer &);

	std::vector<Layer> layers_;

	osg::ref_ptr<osg::Texture2D> texture_;
	osg::ref_ptr<osg::Image> finalImage_;
	unsigned char *imgData_;

	int width_, height_;
};

#endif
