/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Loic Dachary <loic@gnu.org>
 *
 */

#ifndef _maf_split_h
#define _maf_split_h

#ifndef MAF_USE_VS_PCH
#include <string>
#include <vector>
#include <maf/mafexport.h>
#endif

#if 1
namespace std
{
  inline vector<string> split(const string& str, const string& delims, unsigned int maxSplits);
}
#endif

inline std::vector<std::string> std::split(const std::string& str, const std::string& delims, unsigned int maxSplits)
{
  // static unsigned dl;
  std::vector<std::string> ret;
  unsigned int numSplits = 0;

  // Use STL methods 
  size_t start, pos;
  start = 0;
  do 
    {
      pos = str.find_first_of(delims, start);
      if (pos == start)
	{
	  // Do nothing
	  start = pos + 1;
	}
      else if (pos == std::string::npos || (maxSplits && numSplits == maxSplits))
	{
	  // Copy the rest of the string
	  ret.push_back( str.substr(start) );
	  break;
	}
      else
	{
	  // Copy up to delimiter
	  ret.push_back( str.substr(start, pos - start) );
	  start = pos + 1;
	}
      // parse up to next real data
      start = str.find_first_not_of(delims, start);
      ++numSplits;

    } while (pos != std::string::npos);

  return ret;
}

#endif // _maf_split_h
