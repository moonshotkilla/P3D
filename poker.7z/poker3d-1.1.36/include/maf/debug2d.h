#include <osg/Array>
#include <osg/Vec4>
#include <osg/Geometry>
#include "application.h"

struct MAFDebug2D
{
  enum 
    {
      NumberOfLine = 100,
      NumberOfPoint = NumberOfLine * 2
    };
  osg::ref_ptr<osg::Vec4Array> mColor;
  osg::ref_ptr<osg::Vec3Array> mVertice;
  osg::ref_ptr<osg::Geometry> mGeom;
  bool mInited;
  int mIndex;
  MAFDebug2D() : mInited(false), mIndex(0)
  {
  }
  void DrawBox(const osg::Vec3& in, const osg::Vec3& out, const osg::Vec4& color = osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f))
  {
    DrawLine(osg::Vec3(in), osg::Vec3(out.x(), in.y(), 0.0f), color);
    DrawLine(osg::Vec3(in), osg::Vec3(in.x(), out.y(), 0.0f), color);
    DrawLine(osg::Vec3(in.x(), out.y(), 0.0f), osg::Vec3(out), color);
    DrawLine(osg::Vec3(out.x(), in.y(), 0.0f), osg::Vec3(out), color);
  }
  void DrawLine(const osg::Vec3& in, const osg::Vec3& out, const osg::Vec4& color = osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f))
  {
    SetPoint(mIndex, in, color);
    SetPoint(mIndex + 1, out, color);
    mIndex += 2;
    mIndex %= NumberOfPoint;
    mGeom->setVertexArray(mVertice.get());
    mGeom->setColorArray(mColor.get());
  }
	void DrawPoint(const osg::Vec3& in, const osg::Vec4& color = osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f), float width = 0.01f)
	{
		DrawLine(in+osg::Vec3(width, width, 0.0f), in+osg::Vec3(-width, -width, 0.0f));
		DrawLine(in+osg::Vec3(-width, +width, 0.0f), in+osg::Vec3(+width, -width, 0.0f));		
	}
  void SetPoint(int i, const osg::Vec3& point, const osg::Vec4& color = osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f))
  {
    (*mVertice)[i] = point;
    (*mColor)[i] = color;
  }
  void Init(MAFApplication* game)
  {
    if (mInited == true)
			return;
		mInited = true;
		osg::Geometry* geometry = new osg::Geometry;
		{
			// setVec3Array
			osg::Vec3Array* array = new osg::Vec3Array(NumberOfPoint);
			geometry->setVertexArray(array);
			mVertice = array;
		}
		{
			//setVec4Array
			osg::Vec4Array* array = new osg::Vec4Array(NumberOfPoint);
			geometry->setColorArray(array);
			geometry->setColorBinding(osg::Geometry::BIND_PER_VERTEX);
			mColor = array;
		}	
		osg::StateSet* ss = new osg::StateSet;
		ss->setMode(GL_CULL_FACE, osg::StateAttribute::OFF);
		ss->setMode(GL_LIGHTING,  osg::StateAttribute::OFF);
		geometry->setStateSet(ss);
		
		geometry->addPrimitiveSet(new osg::DrawArrays(osg::PrimitiveSet::LINES, 0, NumberOfPoint));
		osg::Geode* geode = new osg::Geode;
		geode->addDrawable(geometry);    
		osg::MatrixTransform* mt = new osg::MatrixTransform;
		mt->setReferenceFrame(osg::Transform::ABSOLUTE_RF);
		mt->setMatrix(osg::Matrix::identity());
		mt->addChild(geode);    
		osg::Projection* pj = new osg::Projection;
		pj->addChild(mt);
		game->GetScene()->GetModel()->mGroup->addChild(pj);
		mGeom = geometry;
  }
};

static MAFDebug2D g_debug2d;
