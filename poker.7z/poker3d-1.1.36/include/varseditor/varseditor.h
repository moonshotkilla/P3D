/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *  Cedric Pinson <cpinson@freesheep.org>
 */

#ifndef __VARS_EDITOR__
#define __VARS_EDITOR__
#include <string>
#include <map>
#include <sstream>
#include <iostream>
#include <libxml/tree.h>


#if defined(_MSC_VER) || defined(__CYGWIN__) || defined(__MINGW32__) || defined( __BCPLUSPLUS__) || defined( __MWERKS__)
	#  ifdef VARSEDITOR_LIBRARY
	#    define VARSEDITOR_EXPORT   __declspec(dllexport)
	#  else
	#    define VARSEDITOR_EXPORT   __declspec(dllimport)
	#  endif /* VARSEDITOR_LIBRARY*/
#else
	#  define VARSEDITOR_EXPORT
#endif

#ifdef UNITTEST
#undef VARSEDITOR_EXPORT
#define VARSEDITOR_EXPORT
#endif

template<typename T>
struct Singleton
{
	static T& Instance()
	{
		static T instance;
		return instance;
	}
};


class VarsEditor : public Singleton<VarsEditor>
{
public:

	
	struct CacheBase
	{
	};

	template<typename T> struct Cache : public CacheBase
	{
		T _cached;
		Cache(const T& val): _cached(val) {}
		const T& Get() const { return _cached;}
	};


	class Entry {
		std::string _value;
		CacheBase* _cached;

		template <typename T> void CreateCache() {
			if (_cached)
				delete _cached;
			T val;
			std::istringstream iss(_value);
			iss >> val;
			_cached = new Cache<T>(val);
		}

	public:
		Entry():_cached(0) {}

		const std::string& GetString() const { return _value;} 
		void SetString(const std::string& str) { _value = str;} 
		template <typename T> CacheBase* GetOrCreateCache() {
			if (!_cached)
				CreateCache<T>();
			return _cached;
		}
		void ClearCache() {
			if (_cached)
				delete _cached;
			_cached = 0;
		}
		template<typename T>
		  static CacheBase* GetOrCreateCache(Entry& entry)
		  {
		    return entry.GetOrCreateCache<T>();
		  }
	};
	

	typedef std::map<std::string, Entry> VarsString;

private:

	VarsString _varsString;
	VarsEditor(){}

	void ClearCache() {
		for (VarsString::iterator it = _varsString.begin(); it != _varsString.end(); it++)
			it->second.ClearCache();
	}

public:

	friend struct Singleton<VarsEditor>;

	VARSEDITOR_EXPORT ~VarsEditor();

	VARSEDITOR_EXPORT bool Read(const std::string& path);
	VARSEDITOR_EXPORT bool Read(struct _xmlDoc* doc, const std::string& xpath);

	template<typename T> bool Get(const std::string& key,T& result)
	{
		if (_varsString.find(key) == _varsString.end()) {
			//std::cout << "VarsEditor key " << key << " not found\n";
			return false;
		}
		//Cache<T>* cache = static_cast<Cache<T>*>(_varsString[key].GetOrCreateCache<T>());
		typedef Cache<T> CachedType;
		Entry& entry = _varsString[key];
		CacheBase* base = Entry::GetOrCreateCache<T>(entry);
		CachedType* cache = static_cast<CachedType*>(base);
		result = cache->Get();
		return true;
	}

	void Dump() {
		for (VarsString::iterator it = _varsString.begin(); it != _varsString.end(); it++) {
			std::cout << "var " << it->first << " value " <<  it->second.GetString() << std::endl;
		}
	}

};

#endif
