/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#pragma once

#include <osg/Group>
#include <osg/MatrixTransform>
#include <osg/Vec4>
#include <osg/Referenced>

struct UGAMEBasicText;
struct osgQuad;
struct osgSprite;
struct _xmlDoc;

class PokerHUD : public osg::Group
{
public:
  static const unsigned int PLAYER_COUNT = 10;
  static const unsigned int DEFAULT_WIDTH = 1024;
  static const unsigned int DEFAULT_HEIGHT = 768;
  struct Panel : osg::Group
  {
    struct Text : osg::MatrixTransform
    {
      osg::ref_ptr<UGAMEBasicText> mText;
      osg::ref_ptr<osg::MatrixTransform> mTransform;
      osg::ref_ptr<osgQuad> mQuad;
      osg::ref_ptr<osgSprite> mLeft;
      osg::ref_ptr<osgSprite> mCenter;
      osg::ref_ptr<osgSprite> mRight;
      bool mBackgroundEnabled;
      bool mFramedBackgroundEnabled;
      float mBackgroundWidth;
      osg::Vec3 mTranslate;
      osg::Vec4 mBackgroundColor;
      Text();
      Text(const std::string& text, const std::string& font, unsigned int size, const std::string& align = "CENTER_CENTER");
      void Create(const std::string& text, const std::string& font, unsigned int size, const std::string& align = "CENTER_CENTER");
      void Load(const std::string& file, const std::string& path, const std::string& dataDir = "");
      void Load(_xmlDoc* doc, const std::string& path, const std::string& dataDir = "");
      UGAMEBasicText* getText();
      static unsigned int lineCount(const std::string& chat);
      void SetText(const std::string& text);
      void EnableBackround(const osg::Vec4& color, float width);
      void LoadFramedBackground(_xmlDoc* file, const std::string &leftImage, const std::string &centerImage, const std::string &rightImage, const std::string& dataDir);
      void resizeBackground();
    };
    osg::ref_ptr<osg::MatrixTransform> mTransform;
    osg::Vec3 mPosition;
    osg::ref_ptr<osgSprite> mActionSprite;
    osg::ref_ptr<osgSprite> mDealerSprite;
    osg::ref_ptr<osgSprite> mHeaderSprite;
    osg::ref_ptr<Text> mChipsText;
    osg::ref_ptr<Text> mNameText;
    osg::ref_ptr<Text> mActionText;
    osg::ref_ptr<Text> mActionTextIt;
    osg::ref_ptr<Text> mChatText;
    std::vector< osg::ref_ptr<osgSprite> > mCardsSprite;
    
    std::string mAction;
    std::string mName;
    std::string mChat;
    bool mPlayed;
    bool mInPosition;
    bool mDealer;
    unsigned int mChipAmount;
    unsigned int mWidth;
    unsigned int mHeight;
    float mChatCurrentTime;
    float mChatTotalTime;
    float mChatCurrentShowedTime;
    float mChatTotalShowedTime;
    osg::Vec3 mChatBeginPos;
    osg::Vec3 mChatEndPos;
    osg::Vec4 mChatBeginColor;
    osg::Vec4 mChatEndColor;
    osg::Vec4 mChatTextBeginColor;
    osg::Vec4 mChatTextEndColor;
    
    Panel(const std::string& file, const std::string& path, unsigned int width = DEFAULT_WIDTH, unsigned int height = DEFAULT_HEIGHT, const std::string& dataDir = "");
    Panel(_xmlDoc* doc, const std::string& path, unsigned int width = DEFAULT_WIDTH, unsigned int height = DEFAULT_HEIGHT, const std::string& dataDir = "");
    void Load(_xmlDoc* doc, const std::string& path, unsigned int width = DEFAULT_WIDTH, unsigned int height = DEFAULT_HEIGHT, const std::string& dataDir = "");
    void SetPosition(const osg::Vec3& pos, const osg::Vec3& align = osg::Vec3(0.0f, 0.0f, 0.0f));
    void SetName(const std::string& name);
    void SetAction(const std::string& action, unsigned int amount = 0);
    void SetInPosition(bool inPosition);
    void SetChipAmount(unsigned int chipAmount);
    static std::string FormatChipAmount(unsigned int chipAmount);
    void SetDealer(bool dealer);
		void SetPlayed(bool played);
    void SetChat(const std::string& chat);
    void SetCards(const std::vector<std::string>& cards);
    void Update(float delta);
  };
  std::vector<osg::ref_ptr<Panel> > mPanels;
  std::vector<osg::Vec3> mPositionFrom;
  std::vector<osg::Vec3> mPositionTo;
  float mT;
  bool mMoving;  
  float mWay;
  float mTimeToInterpolate;
  PokerHUD();
  PokerHUD(const std::string& file, const std::string& path, unsigned int width = DEFAULT_WIDTH, unsigned int height = DEFAULT_HEIGHT, const std::string& dataDir = "");
  PokerHUD(const std::vector<osg::Vec3>& positionFrom, const std::vector<osg::Vec3>& positionTo, float timeToInterpolate, const std::string& file, const std::string& path, unsigned int width = DEFAULT_WIDTH, unsigned int height = DEFAULT_HEIGHT, const std::string& dataDir = "");
  void Create(const std::vector<osg::Vec3>& positionFrom, const std::vector<osg::Vec3>& positionTo, float timeToInterpolate, const std::string& file, const std::string& path, unsigned int width = DEFAULT_WIDTH, unsigned int height = DEFAULT_HEIGHT, const std::string& dataDir = "");
  void Create(const std::vector<osg::Vec3>& positionFrom, const std::vector<osg::Vec3>& positionTo, float timeToInterpolate, _xmlDoc* doc, const std::string& path, unsigned int width = DEFAULT_WIDTH, unsigned int height = DEFAULT_HEIGHT, const std::string& dataDir = "");
  void Load(const std::string& file, const std::string& path, unsigned int width = DEFAULT_WIDTH, unsigned int height = DEFAULT_HEIGHT, const std::string& dataDir = "");
  void Load(_xmlDoc* doc, const std::string& path, unsigned int width = DEFAULT_WIDTH, unsigned int height = DEFAULT_HEIGHT, const std::string& dataDir = "");
  void EnablePanel(unsigned int index);
  void DisablePanel(unsigned int index); 
  bool IsPanelEnabled(unsigned int index) const;
  void Show(unsigned int meIndex);
  void UpdatePosition(float delta, unsigned int meIndex);
  void Hide(unsigned int meIndex);
  void DealerChangeToSeat(unsigned int seat);
	void DisableDealer();
  void PositionChangeToSeat(unsigned int seat);
  void PlayerArrive(unsigned int seat, const std::string& name);
  void PlayerLeave(unsigned int seat);
  void PlayerAction(unsigned int seat, const std::string& action, unsigned int amount = 0);
  void PlayerInPosition(unsigned int seat);
  void PlayerPlayed(unsigned int seat, bool played);
  void PlayerChipAmountChanged(unsigned int seat, unsigned int amount);
  void PlayerSetCards(unsigned int seat, std::vector<std::string>& cards);
  void PlayerChat(unsigned int seat, const std::string& chat);
  void NewTurn();
  void NewRound();
  static unsigned int seatToPositionIndex(unsigned int seatIndex, unsigned int meIndex);
};

class MAFPacket;

class PokerHUDController : public osg::Referenced
{
public:
  osg::ref_ptr<PokerHUD> mHUD;
  PokerHUDController();
  PokerHUDController(PokerHUD* hud);
  ~PokerHUDController();
  void Create(PokerHUD* hud);
  void PythonAccept(const MAFPacket& packet, const std::map<int, unsigned int>& serial2seat);
};
