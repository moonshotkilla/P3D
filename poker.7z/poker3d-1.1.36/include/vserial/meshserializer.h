/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_MESHSERIALIZER_H
#define UNDERWARE_VSERIAL_MESHSERIALIZER_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>
#include <vector>
#include <string>
#include <map>
#endif

ENTER_NAMESPACE_UNDERWARE

class DataIn;
class DataOut;
class Material;
class Mesh;
class MeshLayer;
class MeshPrimitivesPacket;
class Vec3f;
class Vertex;
class VertexMap;

class MeshSerializer {
public:

	class SaveOptions {
	public:
		bool bDontSaveMaterials;
	};

	UW_VSERIAL_API static bool load(const char *fileName, const char *basePath, Mesh **res = NULL);
	UW_VSERIAL_API static bool load(DataIn &data, const char *basePath, Mesh **res = NULL);

	UW_VSERIAL_API static bool save(Mesh &mesh, const char *fileName, SaveOptions *options = NULL);
	UW_VSERIAL_API static bool save(Mesh &mesh, DataOut &data, SaveOptions *options = NULL);

protected:

	DataIn *in_;
	DataOut *out_;
	Mesh *mesh_;
	const char *path_;
	std::vector<Material*> materials_;
	std::map<MeshPrimitivesPacket*, std::string> mpp2mat_;
	SaveOptions *saveOptions_;

	bool load();
	void save();

	// read functions
	bool readMLAYchunk(MeshLayer &meshLayer, int chunkSize);
	bool readPCKTchunk(MeshPrimitivesPacket &packet, int chunkSize);
	bool readPNTSchunk(std::vector<Vec3f> &pnts, int chunkSize);
	bool readVMAPchunk(MeshLayer &meshLayer, int chunkSize);
	bool readVERTchunk(std::vector<Vertex> &vertices, int &vertex_format, int chunkSize);
	bool readPRIMchunk(std::vector<short> &prim, char &type, int chunkSize);

	// write functions
	void writeNAMEchunk(const char *);
	void writePCKTchunk(const MeshPrimitivesPacket &);
	void writeMLAYchunk(const MeshLayer &);
	void writeVMAPchunk(const VertexMap &);
};

LEAVE_NAMESPACE

#endif // UNDERWARE_VSERIAL_MESHSERIALIZER_H
