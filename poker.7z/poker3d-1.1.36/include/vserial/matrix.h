/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_MATRIX_H
#define UNDERWARE_VSERIAL_MATRIX_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>
#endif

#include <vserial/vec3f.h>

ENTER_NAMESPACE_UNDERWARE

class Matrix {
public:

	UW_VSERIAL_API Matrix() { };
	UW_VSERIAL_API Matrix(const float *);
	UW_VSERIAL_API Matrix(const double *);
	UW_VSERIAL_API Matrix(const Matrix &);

	UW_VSERIAL_API void identity();
	UW_VSERIAL_API void rotateX(float angle);
	UW_VSERIAL_API void rotateY(float angle);
	UW_VSERIAL_API void rotateZ(float angle);

	UW_VSERIAL_API Matrix mul(const Matrix &) const;
	UW_VSERIAL_API Vec3f mul(const Vec3f &) const;
	UW_VSERIAL_API Vec3f mulNT(const Vec3f &) const;
	UW_VSERIAL_API void transpose();
	UW_VSERIAL_API void invert();

	UW_VSERIAL_API inline Vec3f getTranslation() const { return Vec3f(v_[0][3], v_[1][3], v_[2][3]); }
	UW_VSERIAL_API inline void setTranslation(const Vec3f &trans) { v_[0][3] = trans.x; v_[1][3] = trans.y; v_[2][3] = trans.z; }

	UW_VSERIAL_API Matrix operator * (const Matrix &) const;
	UW_VSERIAL_API Vec3f operator * (const Vec3f &) const;

	float v_[4][4];
};

LEAVE_NAMESPACE

#endif
