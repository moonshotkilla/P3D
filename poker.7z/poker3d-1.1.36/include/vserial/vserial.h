/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_H
#define UNDERWARE_VSERIAL_H

#ifdef WIN32

  #ifdef UNDERWARE_VSERIAL_DLLEXPORT
    #define UW_VSERIAL_API __declspec(dllexport)
	  #pragma message("Underware Vector Serializer - DLL Export")
  #elif UNDERWARE_VSERIAL_DLLIMPORT
    #define UW_VSERIAL_API __declspec(dllimport)
	  #pragma message("Underware Vector Serializer - DLL Import")
  #elif UNDERWARE_VSERIAL_STATIC
    #define UW_VSERIAL_API
	  #pragma message("Underware Vector Serializer - Static Library")
  #else
	  #error("Underware Vector Serializer - Please define Static Library or DLL")
  #endif

#else

  #define UW_VSERIAL_API

#endif // WIN32

//#ifdef WIN32
 #define FPU_IEEE754
//#endif

// Big/Little Endian MakeID
#define BI_MID(a,b,c,d)	( ((a)<<24) + ((b)<<16) + ((c)<<8) + (d) )
#define LI_MID(a,b,c,d)	( ((d)<<24) + ((b)<<16) + ((c)<<8) + (a) )
#define MID							LI_MID

#define ENTER_NAMESPACE_UNDERWARE namespace underware {
#define LEAVE_NAMESPACE }

ENTER_NAMESPACE_UNDERWARE
static const float INV_255 = 1.0f / 255;
LEAVE_NAMESPACE

#endif // UNDERWARE_VSERIAL_H
