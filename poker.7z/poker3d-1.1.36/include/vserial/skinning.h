/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_SKINNING_H
#define UNDERWARE_VSERIAL_SKINNING_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <map>
#include <string>
#include <vector>

#include <vserial/vserial.h>
#endif

ENTER_NAMESPACE_UNDERWARE

class SceneBone;
class FloatMap;

class Skinning {

public:

	UW_VSERIAL_API Skinning(const std::string &name = "");
	UW_VSERIAL_API virtual ~Skinning();

	UW_VSERIAL_API inline const std::string& getName() const { return name_; }
	UW_VSERIAL_API inline void setName(const std::string &name) { name_ = name; }

	UW_VSERIAL_API int getIndexOfBone(SceneBone *) const;
	UW_VSERIAL_API bool hasBone(SceneBone *) const;

	UW_VSERIAL_API inline int getNbBones() const { return bones2FloatMap_.size(); }
	UW_VSERIAL_API void setBone(SceneBone *bone, FloatMap *fmap);
	UW_VSERIAL_API std::vector<SceneBone*> getBonesList() const;
	UW_VSERIAL_API FloatMap* getWeightMapByBone(SceneBone *bone);
	UW_VSERIAL_API void removeBone(SceneBone *bone);

protected:
	std::string name_;
	std::map<SceneBone*, FloatMap*> bones2FloatMap_;
};

LEAVE_NAMESPACE

#endif
