/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_DATAIO_H
#define UNDERWARE_VSERIAL_DATAIO_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <string>

#include <vserial/vserial.h>
#endif

ENTER_NAMESPACE_UNDERWARE

class DataIn {

public:

	enum SOURCE_TYPE {
		SOURCE_DISK,
		SOURCE_MEMORY
	};

	UW_VSERIAL_API DataIn();
	UW_VSERIAL_API virtual ~DataIn();

	// Open for read from disk
	UW_VSERIAL_API bool open(const std::string &fileName);

	// Open for read from memory
	UW_VSERIAL_API void open(void *mem, int size);

	UW_VSERIAL_API SOURCE_TYPE getSourceType() const;

	// Close the current opened file
	UW_VSERIAL_API bool close();

	UW_VSERIAL_API bool isOpen() const;

	UW_VSERIAL_API bool eof() const;
	UW_VSERIAL_API bool error() const;

	UW_VSERIAL_API const std::string& getFileName() const;
	UW_VSERIAL_API bool advance(int n);
	UW_VSERIAL_API bool seek(int n);
	UW_VSERIAL_API int tell() const;
	UW_VSERIAL_API int getSize() const;

	UW_VSERIAL_API int read(void *dest, int nbBytes);
	UW_VSERIAL_API int readStrZ(char *dest);
	UW_VSERIAL_API char readByte();
	UW_VSERIAL_API short readWord();
	UW_VSERIAL_API int readDword();
	UW_VSERIAL_API float readFloat();

private:
	SOURCE_TYPE	input_;
	FILE			*fileHandle_;
	char			*mem_;
	int				memSize_;
	int				byteOff_;
	std::string fileName_;
};

class DataOut {

public:

	UW_VSERIAL_API DataOut();
	UW_VSERIAL_API virtual ~DataOut();

	UW_VSERIAL_API bool open(const std::string &fileName);

	UW_VSERIAL_API bool close();

	UW_VSERIAL_API bool isOpen() const;

	UW_VSERIAL_API bool eof() const;

	UW_VSERIAL_API const std::string& getFileName() const;
	UW_VSERIAL_API bool advance(int n);
	UW_VSERIAL_API bool seek(int n);
	UW_VSERIAL_API int tell() const;

	UW_VSERIAL_API int write(const void *src, int nbBytes);
	UW_VSERIAL_API int writeStr(const char *);
	UW_VSERIAL_API int writeStrZ(const char *);

	UW_VSERIAL_API int writeByte(char);
	UW_VSERIAL_API int writeWord(short);
	UW_VSERIAL_API int writeDword(int);
	UW_VSERIAL_API int writeFloat(float);

private:
	FILE			*fileHandle_;
	int				memSize_;
	std::string fileName_;
};

LEAVE_NAMESPACE

#endif // UNDERWARE_VSERIAL_DATAIO_H
