/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_TEXTURELAYER_H
#define UNDERWARE_VSERIAL_TEXTURELAYER_H

//#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vector>

#include <vserial/vserial.h>
//#endif

ENTER_NAMESPACE_UNDERWARE

class Texture;

enum TMAP_TYPE {
	TMAP_UV = 0,
	TMAP_FRONT = 1,
	TMAP_REFLECTION = 2,
	TMAP_NORMAL = 3,
};

enum TMAP_TILE_TYPE {
	TILE_REPEAT = 0,
	TILE_MIRROR = 1,
	TILE_CLAMP = 2,
};

class TextureLayer {
	TextureLayer();
public:
	~TextureLayer();

	UW_VSERIAL_API inline Texture* getTexture() const { return texture_; }
	UW_VSERIAL_API inline void setTexture(Texture *texture) { texture_ = texture; }

	UW_VSERIAL_API inline int getUVIndex() const { return uvIndex_; }
	UW_VSERIAL_API inline void setUVIndex(int _index) { uvIndex_ = _index; }

	UW_VSERIAL_API inline TMAP_TYPE getMapType() const { return mapType_; }
	UW_VSERIAL_API inline void setMapType(TMAP_TYPE type) { mapType_ =  type; }

	UW_VSERIAL_API inline TMAP_TILE_TYPE getMapTileU() const { return mapTileU_; }
	UW_VSERIAL_API inline void setMapTileU(TMAP_TILE_TYPE tile) { mapTileU_ = tile; }

	UW_VSERIAL_API inline TMAP_TILE_TYPE getMapTileV() const { return mapTileV_; }
	UW_VSERIAL_API inline void setMapTileV(TMAP_TILE_TYPE tile) { mapTileV_ = tile; }

protected:
	int uvIndex_;
	TMAP_TYPE mapType_;
	TMAP_TILE_TYPE mapTileU_;
	TMAP_TILE_TYPE mapTileV_;
	Texture *texture_;

	friend class std::vector<TextureLayer>;
};

LEAVE_NAMESPACE

#endif // UNDERWARE_VSERIAL_TEXTURELAYER_H
