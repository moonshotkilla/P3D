/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_TEXTURE_H
#define UNDERWARE_VSERIAL_TEXTURE_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <string>
#include <cassert>

#include <vserial/vserial.h>
#endif

ENTER_NAMESPACE_UNDERWARE

class Texture {
public:

	enum MigrateOptions {
		MIGRATE_AND_RENAME,
		ONLY_MIGRATE,
		ONLY_RENAME,
	};

	UW_VSERIAL_API static int getNb();
	UW_VSERIAL_API static Texture* getByIndex(int _i);
	UW_VSERIAL_API static Texture* getByName(const std::string &name);

	UW_VSERIAL_API Texture();
	UW_VSERIAL_API virtual ~Texture();

	UW_VSERIAL_API inline const std::string& getFileName() const { return name_; }
	UW_VSERIAL_API inline void setFileName(const std::string &name) { name_ = name; }

	UW_VSERIAL_API void migrate(const std::string &destPath, const std::string &basePath, MigrateOptions options);

protected:
	std::string name_;
};

LEAVE_NAMESPACE

#endif // UNDERWARE_VSERIAL_TEXTURE_H
