/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_MATERIAL_H
#define UNDERWARE_VSERIAL_MATERIAL_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vector>

#include <vserial/vserial.h>
#include <vserial/flagable.h>
#include <string>
#endif

ENTER_NAMESPACE_UNDERWARE

class Technique;

class Material : public Flagable {
public:

	static const int FLAG_MULTISTREAMCANDIDATE = 0x4;

	UW_VSERIAL_API static int getNb();
	UW_VSERIAL_API static Material* getByIndex(int i);
	UW_VSERIAL_API static Material* getByName(const std::string &name);

	UW_VSERIAL_API Material();
	UW_VSERIAL_API virtual ~Material();

	UW_VSERIAL_API inline const std::string& getFileName() const { return fname_; }
	UW_VSERIAL_API inline void setFileName(const std::string &fname) { fname_ = fname; }

	UW_VSERIAL_API Technique* addTechnique(const char *_techniqueName = NULL);
	UW_VSERIAL_API inline int getNbTechniques() const { return techniques_.size(); }
	UW_VSERIAL_API inline Technique* getTechniqueByIndex(int i) const { return techniques_[i]; }

protected:
	std::string fname_;
	std::vector<Technique*> techniques_;
};

LEAVE_NAMESPACE

#endif // UNDERWARE_VSERIAL_MATERIAL_H
