/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_STDAFX_H
#define UNDERWARE_VSERIAL_STDAFX_H

#ifdef UNDERWARE_VSERIAL_USE_PCH

#include <iostream>
#include <map>
#include <string>
#include <vector>

#include <assert.h>
#include <float.h>
#include <math.h>
#include <memory.h>

#include <glib.h>

#pragma warning( disable : 4101 ) // disable unreferenced local variable warning

#include <vserial/vserial.h>
#include <vserial/ref_ptr.h>
#include <vserial/referenced.h>

#include <vserial/dataio.h>
#include <vserial/col4f.h>
#include <vserial/envelope.h>
#include <vserial/flagable.h>
#include <vserial/floatmap.h>
#include <vserial/keyframe.h>
#include <vserial/gpuprogram.h>
#include <vserial/material.h>
#include <vserial/materialserializer.h>
#include <vserial/matrix.h>
#include <vserial/mesh.h>
#include <vserial/meshlayer.h>
#include <vserial/meshprimitivespacket.h>
#include <vserial/meshserializer.h>
#include <vserial/motion.h>
#include <vserial/motionserializer.h>
#include <vserial/pass.h>
#include <vserial/quat.h>
#include <vserial/scene.h>
#include <vserial/scenebone.h>
#include <vserial/scenecamera.h>
#include <vserial/sceneitem.h>
#include <vserial/scenelight.h>
#include <vserial/scenemesh.h>
#include <vserial/scenenullobject.h>
#include <vserial/skinning.h>
#include <vserial/technique.h>
#include <vserial/texturelayer.h>
#include <vserial/texturelayerbind.h>
#include <vserial/vec2f.h>
#include <vserial/vec3f.h>
#include <vserial/rle.h>
#include <vserial/scene.h>
#include <vserial/sceneserializer.h>
#include <vserial/string.h>
#include <vserial/texture.h>
#include <vserial/vector3map.h>
#include <vserial/vertexmap.h>

#endif // UNDERWARE_VSERIAL_USE_PCH

#endif // UNDERWARE_VSERIAL_H
