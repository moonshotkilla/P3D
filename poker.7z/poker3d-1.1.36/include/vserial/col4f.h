/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_COL4F_H
#define UNDERWARE_VSERIAL_COL4F_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>
#endif

ENTER_NAMESPACE_UNDERWARE

class Col4f {
public:

	Col4f() { }
	Col4f(float _r, float _g, float _b, float _a) : r(_r), g(_g), b(_b), a(_a) { }

	int toDword() const
	{
		return	(int(a * 255) << 24 ) |
						(int(r * 255) << 16) |
						(int(g * 255) << 8) |
						(int(b * 255));
	}

	void fromDword(int argb)
	{
		a = ((argb >> 24) & 0xff) * INV_255;
		r = ((argb >> 16) & 0xff) * INV_255;
		g = ((argb >> 8) & 0xff) * INV_255;
		b = (argb & 0xff) * INV_255;
	}

	float r, g, b, a;
};

LEAVE_NAMESPACE

#endif // UNDERWARE_VSERIAL_COL4F_H
