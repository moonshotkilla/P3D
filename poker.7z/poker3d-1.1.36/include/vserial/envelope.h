/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_ENVELOPE_H
#define UNDERWARE_VSERIAL_ENVELOPE_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>
#include <vector>
#endif

ENTER_NAMESPACE_UNDERWARE

class DataOut;
class KeyBase;
class KeyFloat;
class KeyQuaternion;

class EnvelopeBase {

protected:
	UW_VSERIAL_API EnvelopeBase();

public:

	UW_VSERIAL_API virtual ~EnvelopeBase();

	enum VALUE_TYPE {
		TYPE_FLOAT = 0,
		TYPE_QUATERNION,
	};

	enum BEHAVIOR {
		BEH_RESET = 0,
		BEH_CONSTANT,
		BEH_REPEAT,
		BEH_OSCILLATE,
		BEH_OFFSETREPEAT,
		BEH_LINEAR
	};

	UW_VSERIAL_API BEHAVIOR	getPreBehavior() const { return behaviors_[0]; }
	UW_VSERIAL_API void			setPreBehavior(BEHAVIOR beh) { behaviors_[0] = beh; }
	UW_VSERIAL_API BEHAVIOR	getPostBehavior() const { return behaviors_[1]; }
	UW_VSERIAL_API void			setPostBehavior(BEHAVIOR beh) { behaviors_[1] = beh; }

	UW_VSERIAL_API inline VALUE_TYPE getValueType() const { return valueType_; }
	UW_VSERIAL_API inline void addKey(KeyBase *key) { keyFrames_.push_back(key); }
	UW_VSERIAL_API inline int getNbKeys() const { return keyFrames_.size(); }
	UW_VSERIAL_API inline KeyBase* getKey(int i) { return keyFrames_[i]; }

	UW_VSERIAL_API float getDuration() const;

	virtual void write(DataOut &) const;

public:
	BEHAVIOR behaviors_[2];
	VALUE_TYPE valueType_;
	std::vector<KeyBase*> keyFrames_;
};

class EnvelopeFloat : public EnvelopeBase {
public:
	UW_VSERIAL_API EnvelopeFloat() { valueType_ = TYPE_FLOAT; }
	void write(DataOut &) const;
};

class EnvelopeQuaternion : public EnvelopeBase {
public:
	UW_VSERIAL_API EnvelopeQuaternion() { valueType_ = TYPE_QUATERNION; }
	void write(DataOut &) const;
};

LEAVE_NAMESPACE

#endif
