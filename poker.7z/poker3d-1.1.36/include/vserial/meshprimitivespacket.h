/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#ifndef UNDERWARE_VSERIAL_MESHPRIMITIVESPACKET_H
#define UNDERWARE_VSERIAL_MESHPRIMITIVESPACKET_H

#ifndef UNDERWARE_VSERIAL_USE_PCH
#include <vserial/vserial.h>
#endif

#include <vserial/vec2f.h>
#include <vserial/vec3f.h>

ENTER_NAMESPACE_UNDERWARE

class Material;
class MeshLayer;

enum MESHPRIM_PACKET_TYPE {
	MESHPRIM_NGONS = 0,
	MESHPRIM_TRIANGLES = 1,
	MESHPRIM_LINES = 2,
	MESHPRIM_POINTS = 3,
	MESHPRIM_STRIP = 4,
};

class Vertex {
public:
	static const int MAXNB_UVS = 6;

	static const int FMT_GEOBIND = 1 << 0;
	static const int FMT_NORMAL = 1 << 1;
	static const int FMT_COLOR1 = 1 << 2;
	static const int FMT_COLOR2 = 1 << 3;

	static const int UVSHIFT = 5;
	static const int FMT_UV1 = 1 << UVSHIFT;
	static const int FMT_UV2 = 2 << UVSHIFT;
	static const int FMT_UV3 = 3 << UVSHIFT;
	static const int FMT_UV4 = 4 << UVSHIFT;
	static const int FMT_UV5 = 5 << UVSHIFT;
	static const int FMT_UV6 = 6 << UVSHIFT;
	static const int UVMASK = 15 << UVSHIFT;

	int geoBind;

	// some explanations here:
	// normalx is quantized to 16 bits signed integer
	// normaly is quantized to 15 bits signed integer MSB, the first bit is the sign of normalz
	// normalz is then deducted from normalx and normaly since normal is normalized
	// that makes a normal to cost only 4 bytes instead of 12 with a neglectible loss of precision
	short normalx, normaly;

	int color1, color2;
	Vec2f uvs[ MAXNB_UVS ];

	UW_VSERIAL_API bool isSameVertex(const Vertex &_vertex, int _format, float _threshold = 0.001f);
	UW_VSERIAL_API static int getNbUVs(int _format);
	UW_VSERIAL_API static int getSize(int _format);
	UW_VSERIAL_API static Vec3f unpackNormal(short normalx, short normaly);
	UW_VSERIAL_API static void packNormal(const Vec3f &normal, short &normalx, short &normaly);
};

class MeshPrimitivesPacket {

	MeshPrimitivesPacket(MeshLayer &, MESHPRIM_PACKET_TYPE);
	MeshPrimitivesPacket(MeshLayer &);
	~MeshPrimitivesPacket();

public:

	UW_VSERIAL_API inline Material* getMaterial() const { return material_; }
	UW_VSERIAL_API inline void setMaterial(Material *_material) { material_ = _material; }

	UW_VSERIAL_API inline MESHPRIM_PACKET_TYPE getType() const { return type_; }
	UW_VSERIAL_API inline void setType(MESHPRIM_PACKET_TYPE _type) { type_ = _type; }
	UW_VSERIAL_API int getNbPrimitives() const;

	UW_VSERIAL_API inline unsigned short* getIndexBuffer() const { return indexBuffer_; }
	UW_VSERIAL_API inline int getNbIndices() const { return nbIndices_; }
	UW_VSERIAL_API void setIndexBuffer(unsigned short *_indices, int _nbIndices);

	UW_VSERIAL_API void setPrimitiveBuffer(short *_indices, int _nbIndices, MESHPRIM_PACKET_TYPE _primitive_type);

	UW_VSERIAL_API inline Vertex* getVertexBuffer() const { return vertices_; }
	UW_VSERIAL_API inline int getNbVertices() const { return nbVertices_; }
	UW_VSERIAL_API void setVertexBuffer(Vertex *_vertices, int _size, int _vertexFormat);

	UW_VSERIAL_API inline int getVertexFormat() const { return vertexFormat_; }
	UW_VSERIAL_API inline int getNbUVs() const { return Vertex::getNbUVs(vertexFormat_); }

protected:
	MeshLayer *owner_;
	MESHPRIM_PACKET_TYPE type_;
	Material *material_;

	unsigned short *indexBuffer_;
	int nbIndices_;
	Vertex *vertices_;
	int nbVertices_;
	int vertexFormat_;

	friend class MeshLayer;
	friend class MeshSerializer;
};

LEAVE_NAMESPACE

#endif // UNDERWARE_VSERIAL_MESHPRIMITVESPACKET_H
