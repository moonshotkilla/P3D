/*
 *
 * Copyright (C) 2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#ifndef _RLE_H
#define _RLE_H

class RLE {
public:

	// format of compressed buffer:
	// if byte != key, this is just a normal byte
	// if byte == key, next byte is the value to be repeated and next word is the number of occurences of that value
	// key is choosen to be the byte with the minimum occurence (0 if possible)

	class EncodeRes {
	public:
		EncodeRes(void *buffer, int size, char key) : buffer(buffer), size(size), key(key) { };
		void *buffer; // allocated by malloc()
		int size; // size in byte of that buffer
		char key; // RLE key
	};

	class DecodeRes {
	public:
		DecodeRes(void *buffer, int size) : buffer(buffer), size(size) { };
		void *buffer; // allocated by malloc()
		int size; // size in byte of that buffer
	};

	static EncodeRes encode(void *mem, int size);
	static DecodeRes decode(void *mem, int size, char key);
	static DecodeRes decode(void *mem, int size, char key, int orgSize);
};

#endif
