/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <UnitTest++.h>
#include <maf/texture_manager.h>

#include <osgDB/ReadFile>

static std::string g_srcDir = "./";

typedef unsigned long DWORD;
typedef unsigned short WORD;

#define DDPF_ALPHAPIXELS	0x00000001l
#define DDPF_FOURCC				0x00000004l

#ifndef MAKEFOURCC
#define MAKEFOURCC(ch0, ch1, ch2, ch3)                              \
    ((unsigned long)(char)(ch0) | ((unsigned long)(char)(ch1) << 8) |   \
    ((unsigned long)(char)(ch2) << 16) | ((unsigned long)(char)(ch3) << 24 ))
#endif

#define FOURCC_DXT1	(MAKEFOURCC('D','X','T','1'))

struct  DDCOLORKEY
{
    DDCOLORKEY():
        dwColorSpaceLowValue(0),
        dwColorSpaceHighValue(0) {}
        
    unsigned long    dwColorSpaceLowValue;
    unsigned long    dwColorSpaceHighValue;
};

struct DDPIXELFORMAT
{

    DDPIXELFORMAT():
        dwSize(0),
        dwFlags(0),
        dwFourCC(0),
        dwRGBBitCount(0),
        dwRBitMask(0),
        dwGBitMask(0),
        dwBBitMask(0),
        dwRGBAlphaBitMask(0) {}
        

    unsigned long    dwSize;
    unsigned long    dwFlags;
    unsigned long    dwFourCC;
    union
    {
        unsigned long    dwRGBBitCount;
        unsigned long    dwYUVBitCount;
        unsigned long    dwZBufferBitDepth;
        unsigned long    dwAlphaBitDepth;
    };
    union
    {
        unsigned long    dwRBitMask;
        unsigned long    dwYBitMask;
    };
    union
    {
        unsigned long    dwGBitMask;
        unsigned long    dwUBitMask;
    };
    union
    {
        unsigned long    dwBBitMask;
        unsigned long    dwVBitMask;
    };
    union
    {
        unsigned long    dwRGBAlphaBitMask;
        unsigned long    dwYUVAlphaBitMask;
        unsigned long    dwRGBZBitMask;
        unsigned long    dwYUVZBitMask;
    };
};

struct  DDSCAPS2
{
     DDSCAPS2():
        dwCaps(0),
        dwCaps2(0),
        dwCaps3(0),
        dwCaps4(0) {}

    unsigned long       dwCaps;
    unsigned long       dwCaps2;
    unsigned long       dwCaps3;
    union
    {
        unsigned long       dwCaps4;
        unsigned long       dwVolumeDepth;
    };
};

struct DDSURFACEDESC2
{
    DDSURFACEDESC2():
        dwSize(0),
        dwFlags(0),
        dwHeight(0),
        dwWidth(0), 
        lPitch(0),
        dwBackBufferCount(0),
        dwMipMapCount(0),
        dwAlphaBitDepth(0),
        dwReserved(0),     
        lpSurface(0),      
        dwTextureStage(0) {}      
        

    unsigned long         dwSize;
    unsigned long         dwFlags;
    unsigned long         dwHeight;
    unsigned long         dwWidth; 
    union                          
    {
        long              lPitch;
        unsigned long     dwLinearSize;
    };
    union
    {
        unsigned long      dwBackBufferCount;
        unsigned long      dwDepth;      
    };
    union
    {
        unsigned long     dwMipMapCount;
        unsigned long     dwRefreshRate;
    };
    unsigned long         dwAlphaBitDepth;
    unsigned long         dwReserved;     
    unsigned long*        lpSurface;      
    DDCOLORKEY    ddckCKDestOverlay;      
    DDCOLORKEY    ddckCKDestBlt;           
    DDCOLORKEY    ddckCKSrcOverlay;        
    DDCOLORKEY    ddckCKSrcBlt;            
    DDPIXELFORMAT ddpfPixelFormat;         
    DDSCAPS2      ddsCaps;                 
    unsigned long dwTextureStage;          
}; 

bool isGotAlpha(const std::string &fname)
{
	FILE *file = fopen(fname.c_str(), "rb");
	if (!file)
		return false;

	DWORD magicValue;
	fread(&magicValue, 1, 4, file);
	DDSURFACEDESC2 ddsd;
	fread(&ddsd, 1, sizeof(DDSURFACEDESC2), file);

	if (! ( (ddsd.ddpfPixelFormat.dwFlags & DDPF_FOURCC) && (ddsd.ddpfPixelFormat.dwFourCC == FOURCC_DXT1) )) {
		return false;
	}

	int nbBlocks = (ddsd.dwWidth * ddsd.dwHeight) >> 2;
	bool bGotAlpha = false;
	for (int i = 0; i < nbBlocks; i++) {
		WORD color_0;
		WORD color_1;
		fread(&color_0, 1, 2, file);
		fread(&color_1, 1, 2, file);
		char block[4];
		fread(block, 1, 4, file);

		if (color_0 <= color_1) {
			for (int j = 0; j < 4; j++) {
				int bits0 = block[j] & 0x3;
				int bits1 = (block[j] >> 2) & 0x3;
				int bits2 = (block[j] >> 4) & 0x3;
				int bits3 = (block[j] >> 6) & 0x3;
				if (bits0 == 3 || bits1 == 3 || bits2 == 3 || bits3 == 3) {
					bGotAlpha = true;
					break;
				}
			}
		}
		if (bGotAlpha)
			break;
	}
	fclose(file);
	return bGotAlpha;
}

TEST(TestSameFile)
{
	FILE *f1 = fopen((g_srcDir + "test.dds").c_str(), "rb");
	CHECK(f1);
	FILE *f2 = fopen((g_srcDir + "test_a.dds").c_str(), "rb");
	CHECK(f2);

	fseek(f1, 0, SEEK_END);
	fseek(f2, 0, SEEK_END);
	int fsize1 = ftell(f1);
	int fsize2 = ftell(f2);
	CHECK_EQUAL(fsize1, fsize2);

	fclose(f1);
	fclose(f2);
}

TEST(FailedBecauseOfBadFormat)
{
	const std::string &file = g_srcDir + "test.dds";
	bool bGotAlpha = isGotAlpha(file);

	TextureManager tm;
	osg::Texture2D *texture = tm.GetTexture2D(file);
	CHECK(texture);
	GLint format = texture->getInternalFormat();
	CHECK_EQUAL(true, bGotAlpha && format == GL_COMPRESSED_RGB_S3TC_DXT1_EXT);
}

TEST(SuccessBecauseOfFormatCorrection)
{
	const std::string &file = g_srcDir + "test_a.dds";
	bool bGotAlpha = isGotAlpha(file);

	TextureManager tm;
	osg::Texture2D *texture = tm.GetTexture2D(file);
	CHECK(texture);
	GLint format = texture->getInternalFormat();
	CHECK_EQUAL(true, bGotAlpha && format == GL_COMPRESSED_RGBA_S3TC_DXT1_EXT);
}

#ifndef WIN32
void fetchsrcdir()
{
	char* srcdirPtr = getenv("srcdir");
	if (srcdirPtr)
	{
		//beware "." is always first in PathList
		osgDB::Registry::instance()->getDataFilePathList().push_front(srcdirPtr);
		g_srcDir = std::string(srcdirPtr) + "/";
		if (g_srcDir == "./")
			g_srcDir = "";
	}
};
#endif

int main(int argc, char *argv[])
{
#ifndef WIN32
  fetchsrcdir();
#endif
	return UnitTest::RunAllTests();
}

/*
Index: underware/src/maf/texture_manager.cpp
===================================================================
RCS file: /cvs/underware/underware/src/maf/texture_manager.cpp,v
retrieving revision 1.10
diff -u -r1.10 texture_manager.cpp
--- underware/src/maf/texture_manager.cpp	12 Sep 2006 15:08:03 -0000	1.10
+++ underware/src/maf/texture_manager.cpp	19 Oct 2006 15:02:18 -0000
@@ -103,6 +103,10 @@
 
 		texture->setFilter(osg::Texture2D::MAG_FILTER, osg::Texture2D::LINEAR);
 
+		if (texture->getInternalFormat() == GL_COMPRESSED_RGB_S3TC_DXT1_EXT && _name.rfind("_a.dds") != std::string::npos) {
+			texture->setInternalFormat(GL_COMPRESSED_RGBA_S3TC_DXT1_EXT);
+		}
+
 	}
 	return mTextures[_name].get();
 }
 */
