class MAFApplication:
    def SetHeaders(self, settings, config):
	pass
    def SetLogPolicy(self):
	pass
    def SetReactor(self, policy):
	pass
    def Init(self):
	pass
    def ShowSplashScreen(self):
	pass
    def UpdateSplashScreen(self, ratio, message):
	pass
    def SetPyScheduler(self, scheduler):
	pass
    def Stop(self):
	pass
    def PythonAccept(self, packet):
	pass
