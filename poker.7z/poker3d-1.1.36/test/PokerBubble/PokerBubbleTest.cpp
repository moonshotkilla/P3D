/* (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#include <UnitTest++.h>
#include <osg/MatrixTransform>
#include <osg/Matrix>
#include <SDL.h>
#include <PokerEvent.h>
#include "PokerBubbleManager.h"
#include "PokerPlayerCamera.h"

class MAFAudioController : public osg::Referenced
{
};

void MAFCameraController::Init()
{
}

struct PokerApplication
{
  PokerApplication()
  {
  }
};

PokerCameraController::PokerCameraController(PokerApplication* game, unsigned int id)
{
  mGame = new PokerApplication();
}

PokerCameraController::~PokerCameraController()
{
}

void PokerCameraController::Init()
{
}

bool PokerCameraController::Update(MAFApplication* application)
{
  return false;
}

void PokerCameraController::ConsumeMode()
{
}

void PokerCameraController::SetMode(PokerCameraModel::Mode mode)
{
}

bool PokerCameraController::ModeChanged() const
{
  return false;
}

bool PokerCameraModel::GetIsMoving()
{
  return false;
}

void PokerCameraModel::StartInterpolation(float)
{
}

void PokerCameraController::MoveToPrevious(float)
{
}

void PokerCameraController::MoveTo(const osg::Vec3 &position, const osg::Vec3 &target, float fov, float timeout)
{
}

PokerCameraModel::Mode PokerCameraController::GetMode() const
{
  return PokerCameraModel::CAMERA_ENTER_MODE;
}

PokerCameraModel::PokerCameraModel()
{
}

PokerCameraModel::~PokerCameraModel()
{
}

osgText::Font* MAFLoadFont(const std::string &font_file)
{
  return NULL;
}

std::string MAFformat_amount(unsigned int value, bool bAdvancedFormat)
{
  return "";
}

class PokerModel
{
public:
  PokerModel();
  virtual ~PokerModel();
};
PokerModel::PokerModel()
{
}
PokerModel::~PokerModel()
{
}

MAFCameraModel::MAFCameraModel()
{
}
MAFCameraModel::~MAFCameraModel()
{
}

class VarsEditor
{
public:
  VarsEditor();
  ~VarsEditor();
};
VarsEditor::VarsEditor()
{
}
VarsEditor::~VarsEditor()
{
}
MAFController::~MAFController()
{
}
void MAFController::Init()
{
}

namespace osg
{
  class StateSet;
  class Group;
};
class MAFRenderBin
{
public:
  MAFRenderBin& Instance();
  bool SetupRenderBin(const std::string &_entityName, osg::StateSet *_ss) const;
};
MAFRenderBin& MAFRenderBin::Instance()
{
  return *((MAFRenderBin*)0);
}
bool MAFRenderBin::SetupRenderBin(const std::string &_entityName, osg::StateSet *_ss) const
{
  return false;
}

UGAMEArtefactModel::UGAMEArtefactModel()
{
}
void UGAMEArtefactModel::Init()
{
}
void UGAMEArtefactModel::SetArtefact(osg::Node* artefact)
{
}
osg::Node* UGAMEArtefactModel::GetArtefact(void)
{
  return NULL;
}

UGAMEArtefactController::~UGAMEArtefactController()
{
}
void UGAMEArtefactController::Init()
{
}
void UGAMEArtefactController::SetSelectable(bool selectable)
{
}
void UGAMEArtefactController::SetSelected(bool selected)
{
}
void UGAMEArtefactController::Anchor(osg::Group* anchor)
{
}
bool UGAMEArtefactController::Update(MAFApplication* application)
{
  return false;
}

class CalBone;
namespace osgCal
{
  class Model;
};
class UGAMEAnimatedModel
{
public:
  UGAMEAnimatedModel();
  ~UGAMEAnimatedModel();
  CalBone* GetBone(const std::string& name);
  osgCal::Model* GetOsgCalModel();
};
UGAMEAnimatedModel::UGAMEAnimatedModel()
{
}
UGAMEAnimatedModel::~UGAMEAnimatedModel()
{
}
CalBone* UGAMEAnimatedModel::GetBone(const std::string& name)
{
  return NULL;
}
osgCal::Model* UGAMEAnimatedModel::GetOsgCalModel()
{
  return NULL;
}

osg::Matrix MAFComputeLocalToWorld(osg::Node *_src, int _parentValidMask, int _nodeMaskExclude, int _nodeMaskStop)
{
  return osg::Matrix();
}

osg::Node* GetNode(osg::Node* node, const std::string& name)
{
  return NULL;
}

class PokerPlayer
{
  PokerPlayer();
  ~PokerPlayer();
  bool PopTextMessage(std::string &message);
};
PokerPlayer::PokerPlayer()
{
}
PokerPlayer::~PokerPlayer()
{
}
bool PokerPlayer::PopTextMessage(std::string &message)
{
  return false;
}

class TextureManager
{
public:
  osg::Texture2D* GetTexture2D(const std::string& _name, osgDB::ReaderWriter::Options* _options);
};

osg::Texture2D* TextureManager::GetTexture2D(const std::string& _name, osgDB::ReaderWriter::Options* _options)
{
  return NULL;
}

class MAFWindow;
class MAFApplication
{
  MAFApplication();
  ~MAFApplication();
  SDL_Event* GetLastEvent(MAFController* controller) const;
  void AddController(MAFController* controller);
  void RemoveController(MAFController* controller);
  MAFWindow* GetWindow(bool opengl);
  std::string HeaderGet(const std::string& name, const std::string& path);
  std::list<std::string> HeaderGetList(const std::string& name, const std::string& path);
  static TextureManager* GetTextureManager();
};
MAFApplication::MAFApplication()
{
}
MAFApplication::~MAFApplication()
{
}
SDL_Event* MAFApplication::GetLastEvent(MAFController* controller) const
{
  return NULL;
}
void MAFApplication::AddController(MAFController* controller)
{
}
void MAFApplication::RemoveController(MAFController* controller)
{
}
MAFWindow* MAFApplication::GetWindow(bool opengl)
{
  return NULL;
}
std::string MAFApplication::HeaderGet(const std::string& name, const std::string& path)
{
  return "";
}

std::list<std::string> MAFApplication::HeaderGetList(const std::string& name, const std::string& path)
{
  return std::list<std::string>();
}

TextureManager* MAFApplication::GetTextureManager()
{
  return NULL;
}

bool MAFOSGData::Load(const std::string& path, osgDB::ReaderWriter::Options* options)
{
  return false;
}
MAFData* MAFOSGData::Clone(unsigned int cloneFlag)
{
  return NULL;
}
osg::Group* MAFOSGData::GetAnchor(const std::string& __name)
{
  return NULL;
}

class MAFVisionData;
class MAFMonitor;
MAFRepositoryData::~MAFRepositoryData()
{
}
MAFVisionData* MAFRepositoryData::GetVision(const std::string& name, MAFMonitor *mon)
{
  return NULL;
}


struct PokerBubbleManagerMockup : PokerBubbleManager
{
  PokerBubbleManagerMockup() : PokerBubbleManager(0)
  {
    mGroup = new osg::Group();
    mVisible = true;
  }
};

PokerBubbleManagerMockup* gBubbleManager = NULL;

class PokerController
{
  template <typename T> void GameAccept(const T&);
};

template <>
void PokerController::GameAccept<PokerEventEndLeaveFirstPerson>(const PokerEventEndLeaveFirstPerson& event)
{
  gBubbleManager->GameAccept(event);
}

template <>
void PokerController::GameAccept<PokerEventEndFirstPerson>(const PokerEventEndFirstPerson& event)
{
  // gBubbleManager->GameAccept(event);
}

template <>
void PokerController::GameAccept<PokerEventStartFirstPerson>(const PokerEventStartFirstPerson& event)
{
  gBubbleManager->GameAccept(event);
}




struct PokerPlayerCameraMockup : PokerPlayerCamera
{
  PokerPlayerCameraMockup()
  {
    mCamera = new PokerCameraController(NULL, 0);
  }
  void BeginDirectMode()
  {
    PokerPlayerCamera::BeginDirectMode();
  }
  void EndLeaveMode()
  {
    PokerPlayerCamera::EndLeaveMode();
  }
};



TEST(PokerBubbleGameAccept)
{
  gBubbleManager = new PokerBubbleManagerMockup();
  PokerPlayerCameraMockup camera;
  camera.BeginDirectMode();
  CHECK_EQUAL(false, gBubbleManager->mVisible);
  camera.EndLeaveMode();
  CHECK_EQUAL(true, gBubbleManager->mVisible);
}

int	main()
{
  return UnitTest::RunAllTests();
}
