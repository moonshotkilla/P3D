
import sys
sys.path.insert(0, "../../python")

import platform
if platform.system() != "Windows":
    print "python-modules: Fix me it does not work on GNU/linux"
    sys.exit(0)
    
import base
import underware.mafapplication
import underware.outfit
import underware.animated
import underware.lookcardstate
