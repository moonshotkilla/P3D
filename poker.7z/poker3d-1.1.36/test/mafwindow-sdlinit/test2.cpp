/* (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <UnitTest++.h>
#include <maf/window.h>
#include <vector>
#include <string>
#include <iostream>

#ifdef WIN32
#undef main
#endif

#include <iostream>
struct MAFError {
  MAFError(int,const char*, ...);
  virtual ~MAFError(){}
  GQuark mDomain;
  gint mCode;
  gchar* mMessage;
};

MAFError::MAFError(int,const char*, ...) {;}

struct MAFApplication {
  static int mbAgain,mbVisible;

};
int MAFApplication::mbAgain = 0;
int MAFApplication::mbVisible = 0;

SDL_Rect gRect0;
SDL_Rect gRect1;
SDL_Rect* gSDL_Rect[3] = {
    &gRect0,&gRect1,0
};
SDL_Rect** return_SDL_ListModes;

std::vector<std::string> gLogMessage;
bool call_g_log;

void g_log (const gchar   *log_domain,
            GLogLevelFlags log_level,
            const gchar   *format,
            ...)
{
  char buffer[512];
  va_list args;
  
  va_start (args, format);
  vsnprintf(buffer, 511, format,args);
  //  g_logv (log_domain, log_level, format, args);
  va_end (args);

  call_g_log = true;
  gLogMessage.push_back(std::string(buffer));
  //  std::cout << gLogMessage.back() << std::endl;
}

int main(int argc, char *argv[])
{
	return UnitTest::RunAllTests();
}


bool call_SDL_init;
bool call_SDL_EnableUNICODE;
bool call_SDL_EnableKeyRepeat;
bool call_SDL_GetVideoInfo;
bool call_SDL_ListModes;
bool call_SDL_WM_SetIcon;
bool call_SDL_SetVideoMode;
bool call_SDL_GL_GetAttribute;
bool call_SDL_GL_SetAttribute;
bool call_SDL_GetError;
bool call_SDL_WM_SetCaption;
bool call_SDL_GL_SwapBuffers;
bool call_SDL_Flip;
bool call_SDL_Quit;

SDL_Surface* return_SDL_SetVideoMode;
int return_SDL_init;

SDL_VideoInfo* return_SDL_GetVideoInfo;
static SDL_VideoInfo gSDL_VideoInfo;
static SDL_PixelFormat gVfmt;

std::map<SDL_GLattr,int> gSDL_GL_SetAttribute;

int SDL_Init(unsigned int) {call_SDL_init = true; return return_SDL_init;}
char* SDL_GetError() {call_SDL_GetError=true; return "SDL_GetError_Mockup";}
int SDL_EnableUNICODE(int) { call_SDL_EnableUNICODE = true; return 0;}
int SDL_EnableKeyRepeat(int , int) { call_SDL_EnableKeyRepeat = true; return 0;}
const SDL_VideoInfo* SDL_GetVideoInfo() { call_SDL_GetVideoInfo = true; return return_SDL_GetVideoInfo;}

int SDL_GL_SetAttribute(SDL_GLattr attr, int value) { 
  call_SDL_GL_SetAttribute=true; 
  gSDL_GL_SetAttribute[attr] = value;
  return 0;
}

std::map<GLenum,bool> gglGetString;
char* return_glGetString;
const GLubyte* glGetString(GLenum id) 
{
  if (id == GL_VERSION) {
    gglGetString[id] = true;
    return (const GLubyte*)return_glGetString;
  }
  return (const GLubyte*)"nop";
}


SDL_Surface gValideSurface;

SDL_Rect ** SDL_ListModes(SDL_PixelFormat *format, Uint32 flags) {call_SDL_ListModes=true; return return_SDL_ListModes;}
SDL_Surface* SDL_SetVideoMode(int width, int height, int bpp, Uint32 flags) { call_SDL_SetVideoMode=true ;return return_SDL_SetVideoMode;}
void SDL_WM_SetIcon(SDL_Surface *icon, Uint8 *mask) { call_SDL_WM_SetIcon = true; }
int SDL_GL_GetAttribute(SDL_GLattr attr, int* value) {call_SDL_GL_GetAttribute=true; return 0; }
void SDL_WM_SetCaption(const char *title, const char *icon) { call_SDL_WM_SetCaption=true;}
void SDL_GL_SwapBuffers() { call_SDL_GL_SwapBuffers=true;}
int SDL_Flip(SDL_Surface *screen) {call_SDL_Flip=true; return 0;}
void SDL_Quit() { call_SDL_Quit=true;}

struct MAFWindowMockup : public MAFWindow
{
  MAFWindowMockup() {
    call_SDL_init = false;
    call_SDL_EnableUNICODE = false;
    call_SDL_EnableKeyRepeat = false;
    call_SDL_GetVideoInfo = false;
    call_SDL_init = false;
    call_SDL_EnableUNICODE = false;
    call_SDL_EnableKeyRepeat = false;
    call_SDL_GetVideoInfo = false;
    call_SDL_ListModes = false;
    call_SDL_WM_SetIcon = false;
    call_SDL_SetVideoMode = false;
    call_SDL_GL_GetAttribute = false;
    call_SDL_GL_SetAttribute = false;
    call_SDL_GetError = false;
    return_SDL_init = 0;
    return_SDL_GetVideoInfo = 0;
    return_SDL_GetVideoInfo = &gSDL_VideoInfo; 
    gSDL_VideoInfo.vfmt = &gVfmt;
    gVfmt.BitsPerPixel = 24;
    call_g_log = false;
    gLogMessage.clear();
    gSDL_GL_SetAttribute.clear();

    return_SDL_SetVideoMode = 0;
    return_glGetString = "1.4.0";
    gglGetString.clear();

    gValideSurface.w = 1024;
    gValideSurface.w = 768;

    gRect0.w = 640;
    gRect0.h = 480;

    gRect1.w = 1024;
    gRect1.h = 768;

    return_SDL_ListModes = 0;

    SetWidth(0);
    SetHeight(0);
    SetOpenGL(true);
    SetFullScreen(true);

  }

  ~MAFWindowMockup() {}

};  

struct Fixture {
  MAFWindowMockup* window;
  Fixture() {
    window = new MAFWindowMockup();
  }

  ~Fixture() {
    delete window;
  }
};

TEST_FIXTURE(Fixture,SDL_Init_failed)
{
  return_SDL_init = 1;
  CHECK_EQUAL(window->mSurface, (SDL_Surface*)0);
  CHECK_THROW(window->Init(), MAFError*);
  CHECK_EQUAL(call_SDL_init, true);
  CHECK_EQUAL(call_SDL_EnableUNICODE, false);
}

TEST_FIXTURE(Fixture,SDL_GetVideoInfo_null)
{
  return_SDL_GetVideoInfo = 0;
  CHECK_EQUAL(window->mSurface, (SDL_Surface*)0);
  CHECK_THROW(window->Init(), MAFError*);
  CHECK_EQUAL(call_SDL_init, true);
  CHECK_EQUAL(call_SDL_EnableUNICODE, true);
  CHECK_EQUAL(call_SDL_EnableKeyRepeat, true);
  CHECK_EQUAL(call_SDL_GetVideoInfo, true);
}

TEST_FIXTURE(Fixture,FailedToFindMode)
{
  CHECK_EQUAL(window->mSurface, (SDL_Surface*)0);
  CHECK_THROW(window->Init((SDL_Surface*)1), MAFError*);
  CHECK_EQUAL(true, call_SDL_init);
  CHECK_EQUAL(true, call_SDL_EnableUNICODE);
  CHECK_EQUAL(true, call_SDL_EnableKeyRepeat);
  CHECK_EQUAL(true, call_SDL_GetVideoInfo);
  CHECK_EQUAL(true, call_SDL_ListModes);
  CHECK_EQUAL(true, call_g_log);
  CHECK_EQUAL(std::string("width or height equal to zero, revert to default 1024x768"),gLogMessage[0]);
  CHECK_EQUAL(true, call_SDL_GL_SetAttribute);
  CHECK_EQUAL(16, gSDL_GL_SetAttribute[SDL_GL_DEPTH_SIZE]);
  CHECK_EQUAL(8, gSDL_GL_SetAttribute[SDL_GL_STENCIL_SIZE]);
  CHECK_EQUAL(1, gSDL_GL_SetAttribute[SDL_GL_DOUBLEBUFFER]);
  CHECK_EQUAL(8, gSDL_GL_SetAttribute[SDL_GL_ALPHA_SIZE]);
  CHECK_EQUAL(std::string("desired video mode 1024x768 not available, revert to 0x0"),gLogMessage[1]);
  CHECK_EQUAL(std::string("Video with 24 bpp not available, revert to 16 bpp"),gLogMessage[2]);
  CHECK_EQUAL(true, call_SDL_WM_SetIcon);
  CHECK_EQUAL(true, call_SDL_SetVideoMode);
}

TEST_FIXTURE(Fixture,SuccessSurface)
{
  return_SDL_SetVideoMode = &gValideSurface;
  CHECK_EQUAL(window->mSurface, (SDL_Surface*)0);
  CHECK_EQUAL(true, window->Init());
}

TEST_FIXTURE(Fixture,BadOpenGL_version)
{
  return_SDL_SetVideoMode = &gValideSurface;
  return_glGetString = "1.3.1.1";  
  // in comment to not break test in futur this test should be enabled
  //CHECK_THROW(window->Init((SDL_Surface*)0), MAFError*);
  window->Init((SDL_Surface*)0);
  CHECK_EQUAL(true, gglGetString[GL_VERSION] );
  std::cout << "BadOpenGL_version This test passed and it should not!!!!!!\n";
}

TEST_FIXTURE(Fixture,BadOpenGL_version2)
{
  return_SDL_SetVideoMode = &gValideSurface;
  return_glGetString = "1"  ;
  CHECK_THROW(window->Init((SDL_Surface*)0), MAFError*);
  CHECK_EQUAL(true, gglGetString[GL_VERSION] );
}

TEST_FIXTURE(Fixture,BadOpenGL_version3)
{
  return_SDL_SetVideoMode = &gValideSurface;
  return_glGetString = "1.3a";  
  // in comment to not break test in futur this test should be enabled
  //CHECK_THROW(window->Init((SDL_Surface*)0), MAFError*);
  window->Init((SDL_Surface*)0);
  CHECK_EQUAL(true, gglGetString[GL_VERSION] );
  std::cout << "BadOpenGL_version3 This test passed and it should not!!!!!!\n";
}

TEST_FIXTURE(Fixture,GoodOpenGL_version)
{
  return_SDL_SetVideoMode = &gValideSurface;
  return_glGetString = "1.3";  
  CHECK_EQUAL(true, window->Init((SDL_Surface*)0));
  CHECK_EQUAL(true, gglGetString[GL_VERSION] );
}

TEST_FIXTURE(Fixture,GoodOpenGL_version2)
{
  return_SDL_SetVideoMode = &gValideSurface;
  return_glGetString = "1.1.1";  
  CHECK_EQUAL(true, window->Init((SDL_Surface*)0));
  CHECK_EQUAL(true, gglGetString[GL_VERSION] );
}

TEST_FIXTURE(Fixture,CoverageModeAvailable)
{
  return_SDL_SetVideoMode = &gValideSurface;
  return_SDL_ListModes = gSDL_Rect;
  return_glGetString = "1.4.1";  
  CHECK_EQUAL(true, window->Init((SDL_Surface*)0));
  CHECK_EQUAL(true, gglGetString[GL_VERSION] );
}


std::string getOpenGLErrorString();
TEST(OpenGLError)
{
  std::string error = getOpenGLErrorString();
  std::cout << error << std::endl;
  CHECK(std::string::npos != error.find("Pok3d"));
}
