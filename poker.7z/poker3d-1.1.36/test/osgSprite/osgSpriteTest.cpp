/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#include "osgSprite/osgSprite.h"
#include "CustomAssert/CustomAssert.h"
#include <UnitTest++.h>
#include <ReportAssert.h>
#include <osg/Version>
#if OSG_VERSION_MAJOR == 1
#include <osg/io_utils>
#endif // OSG_VERSION_MAJOR == 1
#include <osg/Image>
#include <osg/Material>
#include <osg/Geode>
#include <osg/Geometry>
#include <osg/BoundingBox>
#include <osgDB/ReadFile>
#include <iostream>
#include "osgViewer.h"

#include <libxml/tree.h>
#include <libxml/parser.h>
#include <libxml/xpath.h>
#include <libxml/xpathInternals.h>
#include <libxml/xmlsave.h>

static std::string spritexml;
static std::string srcdir;
void fetchsrcdir()
{
  char* srcdirPtr = getenv("srcdir");
  if (srcdirPtr)
    {
      //beware "." is always first in PathList
      osgDB::Registry::instance()->getDataFilePathList().push_front(srcdirPtr);
      srcdir = std::string(srcdirPtr) + "/";
      if (srcdir == "./")
	srcdir = "";
    }
  spritexml = srcdir + "sprite.xml";
}

TEST(osgSprite)
{
  osgSprite sprite;
  sprite.addFrame("timer/01.tga");
  CHECK_ASSERT(sprite.setCurrentFrame(1));
  sprite.addFrame("timer/02.tga");
  CHECK_EQUAL(sprite._frames.size(), (size_t)2);
  CHECK_EQUAL((int)sprite.getNumChildren(), 0);
  sprite.setCurrentFrame(0);
  CHECK_EQUAL((int)sprite.getNumChildren(), 1);
  CHECK_EQUAL(sprite._frames[0].get(), sprite.getChild(0));
  sprite.setCurrentFrame(1);
  CHECK_EQUAL((int)sprite.getNumChildren(), 1);
  CHECK_EQUAL(sprite._frames[1].get(), sprite.getChild(0));
}

TEST(osgSpriteAddFrames)
{
  osgSprite sprite;
  sprite.addFrames("timer/", 10);
  CHECK_EQUAL(sprite._frames.size(), (size_t)10);
}

TEST(osgSpriteAnimation)
{  
  osgSprite sprite;
  sprite.addFrames("timer/", 10);
  CHECK_ASSERT(sprite.addTime(1.0f));
  sprite.setTotalTime(10.0f);
  CHECK_EQUAL(sprite.getTotalTime(), 10.0f);
  sprite.addTime(1.0f);
  CHECK_EQUAL(sprite._frames[1].get(), sprite.getChild(0));
  sprite.setCurrentTime(10.0f);
  CHECK_EQUAL(sprite.getCurrentTime(), 10.0f);
  CHECK_EQUAL(sprite._frames[9].get(), sprite.getChild(0));
  sprite.subTime(2.0f);
  CHECK_EQUAL(sprite.getCurrentTime(), 8.0f);
  CHECK_EQUAL(sprite._frames[8].get(), sprite.getChild(0));
  sprite.subTime(10.0f);
  CHECK_EQUAL(sprite.getCurrentTime(), 0.0f);
  CHECK_EQUAL(sprite._frames[0].get(), sprite.getChild(0));
}

TEST(osgSpriteCurrentFrame)
{
  osgSprite sprite;
  sprite.addFrames("timer/", 10);
  CHECK_ASSERT(sprite.getCurrentFrameImage());
  sprite.setCurrentFrame(0);
  CHECK_EQUAL(sprite.getCurrentFrameImage()->getFileName(), srcdir + "timer/01.tga");
  sprite.setCurrentFrame(1);
  CHECK_EQUAL(sprite.getCurrentFrameImage()->getFileName(), srcdir + "timer/02.tga");
  sprite.setCurrentFrame(9);
  CHECK_EQUAL(sprite.getCurrentFrameImage()->getFileName(), srcdir + "timer/10.tga");
  sprite.setCurrentFrame(5);
  sprite.setCurrentFrame(5);
  CHECK_EQUAL(sprite.getCurrentFrameImage()->getFileName(), srcdir + "timer/06.tga");
  CHECK_ASSERT(sprite.setCurrentFrame(10));
}

TEST(osgSpriteRemoveCurrentFrame)
{
  osgSprite sprite;
  sprite.addFrames("timer/", 10);
  CHECK_ASSERT(sprite.removeCurrentFrame());
  sprite.setCurrentFrame(0);
  CHECK_EQUAL(sprite.getCurrentFrameImage()->getFileName(), srcdir + "timer/01.tga");
  sprite.removeCurrentFrame();
  CHECK_ASSERT(sprite.getCurrentFrameImage());
  CHECK_ASSERT(sprite.removeCurrentFrame());
}

TEST(osgQuadTest)
{
  osg::Vec4 color = osg::Vec4(1.0f, 0.0f, 1.0f, 1.0f);
  osg::Vec4 color2 = osg::Vec4(1.0f, 0.0f, 0.0f, 0.0f);
  osgQuad quad(10, 10, color);
  osg::StateSet* state = quad.getStateSet();
  CUSTOM_ASSERT(state);
  osg::Material* mat = dynamic_cast<osg::Material*>(state->getAttribute(osg::StateAttribute::MATERIAL));
  CUSTOM_ASSERT(mat);
  CHECK_EQUAL(mat->getDiffuse(osg::Material::FRONT_AND_BACK), color); 
  quad.setColor(color2);
  CHECK_EQUAL(mat->getDiffuse(osg::Material::FRONT_AND_BACK), color2); 

  osg::Geode* geode = dynamic_cast<osg::Geode*>(quad.getChild(0));
  CUSTOM_ASSERT(geode);
  osg::Geometry* geom = dynamic_cast<osg::Geometry*>(geode->getDrawable(0));
  CUSTOM_ASSERT(geom);
  const osg::BoundingBox& bbox = geom->getBound();
  CHECK_EQUAL(bbox.yMax() - bbox.yMin(), 10);
  CHECK_EQUAL(bbox.xMax() - bbox.xMin(), 10);

  quad.resize(20, 30);
  const osg::BoundingBox& bbox2 = geom->getBound();
  CHECK_EQUAL(bbox2.yMax() - bbox2.yMin(), 30);
  CHECK_EQUAL(bbox2.xMax() - bbox2.xMin(), 20);
  CHECK_EQUAL(20u, quad._w);
  CHECK_EQUAL(30u, quad._h);

  quad.setImage("hud/fold.tga");
  CHECK_EQUAL(256u, quad._w);
  CHECK_EQUAL(32u, quad._h);
  CHECK_EQUAL(137u, quad._iw);
  CHECK_EQUAL(26u, quad._ih);
  CHECK_EQUAL(quad.getImage()->getFileName(), srcdir + "hud/fold.tga");
}

TEST(osgSpriteNamedFrame)
{
  osgSprite sprite;
  sprite.addFrames("timer/", 10);
  CHECK_EQUAL(sprite._frames.size(), (size_t)10);
  CHECK_EQUAL(sprite._name2index.size(), (size_t)10);
  sprite.setCurrentFrame("timer/05.tga");
  CHECK_EQUAL(sprite.getCurrentFrameImage()->getFileName(), srcdir + "timer/05.tga");
  sprite.addFrame("timer/01.tga", "Test");
  sprite.setCurrentFrame("Test");
  CHECK_EQUAL(sprite.getCurrentFrameImage()->getFileName(), srcdir + "timer/01.tga");
  CHECK_ASSERT(sprite.setCurrentFrame("Failed"));
  CHECK_ASSERT(sprite.addFrame("timer/02.tga", "Test"));
}

TEST(osgSpritegetFrameCount)
{
  osgSprite sprite;
  sprite.addFrames("timer/", 10);
  CHECK_EQUAL(sprite.getFrameCount(), (size_t)10);
}

TEST(osgSpriteSerializeLoad)
{
  {
    osgSprite sprite;
    sprite.load(spritexml, "/test/sprite");
    CHECK_EQUAL((size_t)30, sprite._frames.size());
    CHECK_EQUAL((size_t)30, sprite._name2index.size());
    CHECK_EQUAL(30.0f, sprite._currentTime);
    CHECK_EQUAL(30.0f, sprite._totalTime);
  }
  {
    osgSprite sprite;
    CHECK_ASSERT(sprite.load(spritexml, "/test/spriteFail1"));
  }
  {
    osgSprite sprite;
    CHECK_ASSERT(sprite.load(spritexml, "/test/spriteFail2"));
  }
  {
    osgSprite sprite;
    CHECK_ASSERT(sprite.load(spritexml, "/test/spriteFail3"));
  }
  {
    osgSprite sprite;
    CHECK_ASSERT(sprite.load(spritexml, "/test/spriteFail4"));
  }
  {
    osgSprite sprite;
    CHECK_ASSERT(sprite.load(spritexml, "/test/spriteFail5"));
  }
  {
    osgSprite sprite;
    CHECK_ASSERT(sprite.load(spritexml, "/test/spriteFail41"));
  }
  {
    osgSprite sprite;
    CHECK_ASSERT(sprite.load(spritexml, "/test/spriteFail6"));
  }
  {
    osgSprite sprite;
    CHECK_ASSERT(sprite.load(spritexml, "/test/spriteFail7"));
  }
  {
    osgSprite sprite;
    CHECK_ASSERT(sprite.load(spritexml, "/test/spriteFail8"));
  }
  {
    osgSprite sprite;
    CHECK_ASSERT(sprite.load(spritexml, "/test/spriteFail9"));
  }
  {
    osgSprite sprite;
    CHECK_ASSERT(sprite.load(spritexml, "/test/spriteFail10"));
  }
  {
    osgSprite sprite;
    sprite.load(spritexml, "/test/spriteOk");
    CHECK_EQUAL(sprite.getCurrentFrameImage()->getFileName(), srcdir + "timer/02.tga");
    sprite.setCurrentFrame("toto");
    CHECK_EQUAL(sprite.getCurrentFrameImage()->getFileName(), srcdir + "timer/01.tga");
    sprite.setCurrentFrame("titi");
    CHECK_EQUAL(sprite.getCurrentFrameImage()->getFileName(), srcdir + "timer/02.tga");
  }
  {
    osgSprite sprite;
    sprite.load(spritexml, "/test/spriteOk1");
    CHECK_EQUAL(sprite.getCurrentFrameImage()->getFileName(), srcdir + "timer/02.tga");
    sprite.setCurrentFrame("toto");
    CHECK_EQUAL(sprite.getCurrentFrameImage()->getFileName(), srcdir + "timer/01.tga");
    sprite.setCurrentFrame("titi");
    CHECK_EQUAL(sprite.getCurrentFrameImage()->getFileName(), srcdir + "timer/02.tga");
  }
  {
    osgSprite sprite;
    sprite.load(spritexml, "/test/spriteOk2");
    CHECK_EQUAL((int)sprite.getNumChildren(), 0);
    sprite.setCurrentFrame("toto");
    CHECK_EQUAL(sprite.getCurrentFrameImage()->getFileName(), srcdir + "timer/01.tga");
    sprite.setCurrentFrame("titi");
    CHECK_EQUAL(sprite.getCurrentFrameImage()->getFileName(), srcdir + "timer/02.tga");
  }
  {
    osgSprite sprite;
    sprite.load(spritexml, "/test/spriteOk3");
    CHECK_EQUAL(sprite._frames.size(), (size_t)1);
    CHECK_EQUAL(sprite.getMatrix().getTrans(), osg::Vec3(1.0f, 2.0f, -3.0f));
  }
  {
    osgSprite sprite;
    sprite.load(spritexml, "/test/spriteOk4");
    CHECK_EQUAL(sprite._frames.size(), (size_t)1);
    sprite.setCurrentFrame("toto");
    CHECK_EQUAL(sprite.getCurrentFrameImage()->getFileName(), srcdir + "timer/01.tga");
  }
}

TEST(PowerOfTwoTest)
{
  CHECK_EQUAL(osgSprite::isPowerOfTwo(32), true);
  CHECK_EQUAL(osgSprite::isPowerOfTwo(31), false);
  CHECK_EQUAL(osgSprite::nextPowerOfTwo(31), (size_t)32);
  CHECK_EQUAL(osgSprite::nextPowerOfTwo(32), (size_t)32);
  osg::ref_ptr<osg::Image> image = osgDB::readImageFile("hud/fold.tga");
  CUSTOM_ASSERT(image.get());
  CUSTOM_ASSERT(osgSprite::isPowerOfTwo(image->s() == false));
  CUSTOM_ASSERT(osgSprite::isPowerOfTwo(image->t() == false));
  osg::ref_ptr<osg::Image> imagePowerOfTwo = osgSprite::copySubImagePowerOfTwo(image.get());
  CUSTOM_ASSERT(imagePowerOfTwo.get());
  CHECK_EQUAL(osgSprite::isPowerOfTwo(imagePowerOfTwo->s()), true);
  CHECK_EQUAL(osgSprite::isPowerOfTwo(imagePowerOfTwo->t()), true);
}

TEST(dataDir)
{
  {
    std::string spritexml = srcdir + "sprite.xml";
    osgSprite sprite;
    sprite.load(spritexml, "/test/spriteOk4", "data/");
    CHECK_EQUAL(sprite._frames.size(), (size_t)1);
    sprite.setCurrentFrame("toto");
    CHECK_EQUAL(sprite.getCurrentFrameImage()->getFileName(), srcdir + "data/timer/01.tga");
  }
}

extern _xmlDoc* g_doc;
void reportCustomAssert()
{
  if (g_doc)
    {
      xmlFreeDoc(g_doc);
      g_doc = NULL;
    }
  std::string description = CustomAssert::Instance().GetDescription();
  std::string function = CustomAssert::Instance().GetFunction();
  std::string file = CustomAssert::Instance().GetFile();
  int line  = CustomAssert::Instance().GetLine();
  UnitTest::ReportAssert(description.c_str(), (function+" "+file).c_str(), line);
}

int main()
{
  fetchsrcdir();
  CustomAssert::Instance().SetHandler(reportCustomAssert);
  return UnitTest::RunAllTests();
}
