
sys.path.insert(0, "..")
sys.path.insert(0, "../../../envwin32/python")
sys.path.insert(0, "../../../envwin32/python/Lib")
sys.path.insert(0, "../../../envwin32/python/Lib/site-packages")
sys.path.insert(0, "../../../envwin32/python/Lib/site-packages/win32")
sys.path.insert(0, "../../../envwin32/python/Lib/site-packages/win32/lib")
sys.path.insert(0, "../../../envwin32/python/Lib/site-packages/twisted")
sys.path.insert(0, "../../../envwin32/python/Lib/site-packages/libxmlmods")
sys.path.insert(0, "../../../envwin32/python/DLLs")
sys.path.insert(0, "../../../envwin32/python/Lib/xml")

sys.path.insert(0, "../../../../pokersource/poker-network")
sys.path.insert(0, "../../../../pokersource/poker-engine")
sys.path.insert(0, "../../../underware/python")
sys.path.insert(0, "../../../../underware/underware/python")
sys.path.insert(0, "../../../../underware/underware/examples")

os.environ["path"] += ";..\\..\\...\\envwin32\\python"
os.environ["path"] += ";..\\..\\...\\envwin32\\python\\Lib"
os.environ["path"] += ";..\\..\\...\\envwin32\\python\\Lib\\site-packages"
os.environ["path"] += ";..\\..\\...\\envwin32\\python\\Lib\\site-packages\\win32"
os.environ["path"] += ";..\\..\\...\\envwin32\\python\\Lib\\site-packages\\win32\\lib"
os.environ["path"] += ";..\\..\\...\\envwin32\\python\\Lib\\site-packages\\pywin32_system32"
os.environ["path"] += ";..\\..\\...\\envwin32\\python\\Lib\\site-packages\\twisted"
os.environ["path"] += ";..\\..\\...\\envwin32\\python\\Lib\\site-packages\\underware"
os.environ["path"] += ";..\\..\\...\\envwin32\\python\\Lib\\site-packages\\libxmlmods"
os.environ["path"] += ";..\\..\\...\\envwin32\\python\DLLs"
os.environ["path"] += ";..\\..\\...\\envwin32\\python\Lib\\xml"

import os, signal
import sys
import unittest

from twisted.internet import win32eventreactor
win32eventreactor.install()

from twisted.internet import reactor
from twisted.internet.protocol import ProcessProtocol
from twisted.internet import error
from pokernetwork import dispatch
from pokerengine.pokerengineconfig import Config

CHILD_DONE = "//event/pokernetwork/pokerchildren/child_done"
from string import split, replace
from os.path import exists
def expand(url, command, substitute):
    args = []
    for arg in split(command):
        for (original, destination) in substitute.iteritems():
            arg = replace(arg, original, destination)
        args.append(arg)
    if not exists(args[0]):
        raise Exception, "ERROR: %s, as found in %s at line %s is not an existing file." % ( args[0], url, command )
    return args


from twisted.internet.protocol import Factory, Protocol

class LobbyProtocol(Protocol):
	def connectionMade(self):
		print "LobbyProtocol.connectionMade"

class LobbyFactory(Factory):
	protocol = LobbyProtocol

CHILD_XWNC_STARTED = "//event/poker3d/pokerchildren/xwncstarted"
CHILD_XWNC_STOPPED = "//event/poker3d/pokerchildren/xwncstopped"

class PokerChildXwnc(ProcessProtocol, dispatch.EventDispatcher):

    def __init__(self, settings):
        dispatch.EventDispatcher.__init__(self)
        self.settings = settings
        self.verbose = settings.headerGetInt("/settings/@verbose")
        self.display = None
        self.ready = self.configure()

    def configure(self):
        settings = self.settings
        screen = self.settings.headerGetProperties("/settings/screen")[0]
        datadir = settings.headerGet("/settings/data/@path")
        self.display = settings.headerGet("/settings/metisse/@display")
        substitutions = {}
        substitutions["%width%"] = screen["width"]
        substitutions["%height%"] = screen["height"]
        substitutions["%display%"] = self.display

        if not settings.headerGetList("/settings/metisse/xwnc"):
            print "no <xwnc> found in config file (ignored)"
            return False
        self.spawnInDir = replace(settings.headerGet("/settings/metisse/xwnc/@chdir"), "%datadir%", datadir)
        self.commandLine = expand(self.settings.path, settings.headerGet("/settings/metisse/xwnc"), substitutions)
        self.commandName = split(self.commandLine[0],"/").pop()
        if self.verbose:
            print "command name of xwnc : " + self.commandName
        return True

    def spawn(self):
        proc = reactor.spawnProcess(self, self.commandLine[0], self.commandLine, path = "../../bin-cygwin")

    def kill(self):
        from underware import python_mywin32   
        python_mywin32.killProcessByName(self.commandName)

    def connectionMade(self):
        print "<%s>: connectionMade" % self.commandName
        if self.callbacks.has_key(CHILD_XWNC_STARTED):
			self.publishEvent(CHILD_XWNC_STARTED)

    def outReceived(self, data):
        print "<%s>: %s" % (self.commandName, data)

    def errReceived(self, data):
        print "<%s>: %s" % (self.commandName, data)
        
    def processEnded(self, status_object):
        print "<%s>: exits with status %d" % (self.commandName, status_object.value.exitCode)
        if self.callbacks.has_key(CHILD_XWNC_STOPPED):
			self.publishEvent(CHILD_XWNC_STOPPED)

CHILD_INTERFACE_READY = "//event/poker3d/pokerchildren/lobbyready"
CHILD_INTERFACE_GONE = "//event/poker3d/pokerchildren/lobbygone"
CHILD_INTERFACE_STARTED = "//event/poker3d/pokerchildren/lobbystarted"
CHILD_INTERFACE_STOPPED = "//event/poker3d/pokerchildren/lobbystopped"

class PokerChildInterface(ProcessProtocol, dispatch.EventDispatcher):

    def __init__(self, settings):
        dispatch.EventDispatcher.__init__(self)
        self.settings = settings
        self.verbose = settings.headerGetInt("/settings/@verbose")
        print self.verbose
        self.port = settings.headerGetInt("/settings/metisse/lobby/@port")
        print self.port
        self.ready = ( settings.headerGetList("/settings/metisse/lobby") and
                       self.configure() )
        
    def configure(self):
        settings = self.settings

        display = settings.headerGet("/settings/metisse/@display")
        datadir = settings.headerGet("/settings/data/@path")
        substitutions = {}
        substitutions["%port%"] = str(self.port)
        substitutions["%display%"] = display
        substitutions["%verbose%"] = str(self.verbose)
        substitutions["%datadir%"] = datadir

        if not settings.headerGetList("/settings/metisse/lobby"):
            print "no <lobby> found in config file (ignored)"
            return False
        self.spawnInDir = replace(settings.headerGet("/settings/metisse/lobby/@chdir"), "%datadir%", datadir)
        self.commandLine = expand(self.settings.path, settings.headerGet("/settings/metisse/lobby"), substitutions)
        self.commandName = split(self.commandLine[0],"/").pop()
        if self.verbose:
            print "command name of lobby : " + self.commandName
        return True        

    def lobbyReady(self, lobby, lobbyFactory):
		pass
        #self.publishEvent(CHILD_INTERFACE_READY, self, lobby, lobbyFactory)

    def lobbyGone(self, lobby, lobbyFactory):
		pass
        #self.publishEvent(CHILD_INTERFACE_GONE, self, lobby, lobbyFactory)
        
    def spawn(self):
        proc = reactor.spawnProcess(self, self.commandLine[0], self.commandLine, path = "../../bin-cygwin")
        #lobby = pokerinterface.PokerInterfaceFactory(verbose = self.verbose)
        #lobby.registerHandler(pokerinterface.INTERFACE_READY, self.lobbyReady)
        #lobby.registerHandler(pokerinterface.INTERFACE_GONE, self.lobbyGone)
        reactor.listenTCP(self.port, LobbyFactory())

    def kill(self):
        from underware import python_mywin32   
        python_mywin32.killProcessByName(self.commandName)

    def connectionMade(self):
        print "<%s>: connectionMade" % self.commandName
        if self.callbacks.has_key(CHILD_INTERFACE_STARTED):
			self.publishEvent(CHILD_INTERFACE_STARTED)

    def outReceived(self, data):
        print "<%s>: %s" % (self.commandName, data)

    def errReceived(self, data):
        print "<%s>: %s" % (self.commandName, data)
        
    def processEnded(self, status_object):
        print "<%s>: exits with status %d" % (self.commandName, status_object.value.exitCode)
        if self.callbacks.has_key(CHILD_INTERFACE_STOPPED):
			self.publishEvent(CHILD_INTERFACE_STOPPED)

#settings = Config("../../")
#settings.load("../../poker.client.xml")
#xwnc = PokerChildXwnc(settings)
#interface = PokerChildInterface(settings)
#class EventReceiver:
#	def xwncReady(self):
#		interface.registerHandler(CHILD_INTERFACE_STARTED, recv.interfaceReady)
#		interface.registerHandler(CHILD_INTERFACE_STOPPED, recv.interfaceDone)
#		interface.spawn()
#	def xwncDone(self):
#		print "CHILD_INTERFACE_STOPPED"
#	def interfaceReady(self):	
#		print "CHILD_INTERFACE_STARTED"
#		reactor.callLater(3, lambda: xwnc.kill())
#	def interfaceDone(self):
#		print "CHILD_INTERFACE_STOPPED"
#		reactor.stop()
#recv = EventReceiver()
#xwnc.registerHandler(CHILD_XWNC_STARTED, recv.xwncReady)
#xwnc.registerHandler(CHILD_XWNC_STOPPED, recv.xwncDone)
#xwnc.spawn()
#reactor.run()
#print "finished"
		
class TestChildren(unittest.TestCase):
	def setUp(self):
		self.settings = Config("../../")
		self.settings.load("../../poker.client.xml")
	def tearDown(self):
		pass
	def test_SpawnChildren(self):
		reactor.startRunning()
		self.xwnc = PokerChildXwnc(self.settings)
		self.xwnc.registerHandler(CHILD_XWNC_STARTED, self.callbackXwncStarted)
		self.xwnc.registerHandler(CHILD_XWNC_STOPPED, self.callbackXwncStopped)
		self.xwnc.spawn()
		self.Run = True
		while self.Run:
			reactor.iterate()		
		self.interface.kill()	
		self.xwnc.kill()
		reactor.run()
					
	def callbackXwncStarted(self):
		print "callbackXwncStarted"	
		self.interface = PokerChildInterface(self.settings)
		self.interface.registerHandler(CHILD_INTERFACE_STARTED, self.callbackInterfaceStarted)
		self.interface.registerHandler(CHILD_INTERFACE_STOPPED, self.callbackInterfaceStopped)
		self.interface.spawn()

	def callbackXwncStopped(self):
		print "callbackXwncStopped"
		self.Run = False
		reactor.stop()
		#reactor.runUntilCurrent()		
		
	def stop(self):
		print "stop"
		self.Run = False

	def callbackInterfaceStarted(self):
		print "callbackInterfaceStarted"
		reactor.callLater(3, self.stop)

	def callbackInterfaceStopped(self):
		print "callbackInterfaceStopped"
		self.Run = False

def run():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestChildren))
    verbosity = int(os.environ.get('VERBOSE_T', 2))
    return unittest.TextTestRunner(verbosity=verbosity).run(suite)
    
if __name__ == '__main__':
    if run().wasSuccessful():
        sys.exit(0)
    else:
        sys.exit(1)
