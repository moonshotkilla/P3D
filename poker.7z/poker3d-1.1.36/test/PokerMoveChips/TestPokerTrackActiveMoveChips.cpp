/* (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include <UnitTest++.h>
#include <ReportAssert.h>
#include <CustomAssert/CustomAssert.h>
#include <PokerMoveChips.h>
#include <osg/Referenced>
#include <osg/Matrix>

MAFController::~MAFController() {}
void MAFController::Init() {}

struct PokerPlayer : public osg::Referenced
{
  bool mHasRunAnimationBet;
  PokerMoveChipsBet2PotController* GetFreeAnimationBet2Pot();
  PokerMoveChipsPot2PlayerController* GetFreeAnimationPot2Player();
  void SetBet(const std::vector<int>&);
  bool HasRunAnimationBet() const;
};
bool PokerPlayer::HasRunAnimationBet() const { return mHasRunAnimationBet;}
void PokerPlayer::SetBet(const std::vector<int>& v) {}
PokerMoveChipsBet2PotController* PokerPlayer::GetFreeAnimationBet2Pot() { return 0;}
PokerMoveChipsPot2PlayerController* PokerPlayer::GetFreeAnimationPot2Player() { return 0;}

void RecursiveClearUserData(osg::Node*) {}
osg::NodeVisitor* RecursiveLeakCollect(osg::Node*) {return 0;}
osg::Node* UGAMEArtefactModel::GetArtefact() { return 0;}
void RecursiveLeakCheck(osg::NodeVisitor*) {}
void PokerChipsStackController::AddChips(const std::map<unsigned int, unsigned int>& ) {}
std::map<unsigned int,unsigned int> PokerChipsStackController::GetChips() const { return std::map<unsigned int,unsigned int>();}

namespace betslider {
struct BetSlider : public osg::Referenced {};
}

namespace osgchips {
struct ManagedStacks : public osg::Referenced {};
}

PokerChipsStackModel::~PokerChipsStackModel() {}

PokerChipsStackController::~PokerChipsStackController() {}
UGAMEArtefactController::~UGAMEArtefactController() {}
void UGAMEArtefactModel::Init(void) {}
void UGAMEArtefactController::Init(){}
bool UGAMEArtefactController::Update(MAFApplication*){ return true;}
void UGAMEArtefactController::SetSelectable(bool) {}
void UGAMEArtefactController::SetSelected(bool) {}
void UGAMEArtefactController::Anchor(osg::Group*) {}
bool PokerChipsStackController::Update(MAFApplication*) { return true;}

struct PokerPotController : public osg::Referenced
{
  bool mCallResetPots;
  void BuildAnimationPotToPlayer(PokerMoveChipsPot2PlayerController*, int);
  void BuildAnimationBetToPot(PokerMoveChipsBet2PotController*, int);
  void ResetPots();
  PokerPotController();
  void UnFreezeCenter();
  void FreezeCenter();
  void SetPotValue(const std::vector<int>& pot, int sidepot);
};
PokerPotController::PokerPotController() {mCallResetPots = false;}
void PokerPotController::BuildAnimationPotToPlayer(PokerMoveChipsPot2PlayerController*, int) {}
void PokerPotController::ResetPots() {mCallResetPots=true;}
void PokerPotController::BuildAnimationBetToPot(PokerMoveChipsBet2PotController*, int) {}
void PokerPotController::UnFreezeCenter() {}
void PokerPotController::FreezeCenter() {}
void PokerPotController::SetPotValue(const std::vector<int>& pot, int sidepot) {}

osg::Matrix MAFComputeLocalToWorld(osg::Node* src, int parentValidMask, int nodeMaskExclude, int nodeMaskStop) { return osg::Matrix();}

void PokerChipsStackController::SetChips(const std::vector<int>& chips) {}


struct MAFApplication
{
  virtual ~MAFApplication();
  bool HasEvent() const ;
};
MAFApplication::~MAFApplication() {}
bool MAFApplication::HasEvent() const { return false;}

struct PokerApplication : public MAFApplication
{
  virtual ~PokerApplication();
};
PokerApplication::~PokerApplication() {}

PokerChipsStackController::PokerChipsStackController(PokerApplication*, unsigned int) {}



//======================================================================================


std::map<guint,osg::ref_ptr<PokerPlayer> > serial2player;

struct MyFixture : public PokerMoveChips::PokerTrackActiveMoveChips
{
  MyFixture():PokerTrackActiveMoveChips(serial2player) {
    serial2player.clear();
  }
  ~MyFixture() {}
};


TEST_FIXTURE(MyFixture, testClearAllEntries)
{
  PokerMoveChipsBase* pc = new PokerMoveChipsBase(0,0);
  serial2player[0] = 0;
  serial2player[2] = 0;
  AddEntry(EntryElement(0,pc));
  AddEntry(EntryElement(2,pc));
  AddEntry(EntryElement(1,pc));

  CHECK_EQUAL(3, mActives.size());
  ClearAllEntries();
  CHECK_EQUAL(true, mActives.empty());
}

TEST_FIXTURE(MyFixture, testHasAnimation)
{
  CHECK_EQUAL(false, HasAnimation());
  AddEntry(EntryElement(0,0));
  CHECK_EQUAL(true, HasAnimation());
}


TEST_FIXTURE(MyFixture, testClearEntries)
{
  PokerMoveChipsBase* pc = new PokerMoveChipsBase(0,0);
  serial2player[0] = 0;
  serial2player[2] = 0;
  AddEntry(EntryElement(0,pc));
  AddEntry(EntryElement(2,pc));
  AddEntry(EntryElement(1,pc));

  CHECK_EQUAL(3, mActives.size());
  ClearEntries(0);
  CHECK_EQUAL(1, mActives.size());
  CHECK_EQUAL(2, mActives[0].mSerial);
}

TEST_FIXTURE(MyFixture, testRemoveFinishedEntry)
{
  PokerMoveChipsBase* pc = new PokerMoveChipsBase(0,0);
  PokerMoveChipsBase* pc2 = new PokerMoveChipsBase(0,0);
  serial2player[0] = 0;
  serial2player[2] = 0;
  pc2->mFinished = false;
  pc->mFinished = true;
  AddEntry(EntryElement(0,pc));
  AddEntry(EntryElement(2,pc2));
  AddEntry(EntryElement(1,pc));

  CHECK_EQUAL(3, mActives.size());
  RemoveFinishedEntry();
  CHECK_EQUAL(1, mActives.size());
  CHECK_EQUAL(2, mActives[0].mSerial);
}


void reportCustomAssert()
{
  std::string description = CustomAssert::Instance().GetDescription();
  std::string message = CustomAssert::Instance().GetMessage();
  std::string function = CustomAssert::Instance().GetFunction();
  std::string file = CustomAssert::Instance().GetFile();
  int line  = CustomAssert::Instance().GetLine();
  UnitTest::ReportAssert((description+" "+message).c_str(), (function+" "+file).c_str(), line);
}

int	main()
{
  CustomAssert::Instance().SetHandler(reportCustomAssert);
  return UnitTest::RunAllTests();
}
