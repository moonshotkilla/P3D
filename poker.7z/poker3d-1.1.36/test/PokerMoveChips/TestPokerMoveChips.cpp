/* (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include <UnitTest++.h>
#include <ReportAssert.h>
#include <CustomAssert/CustomAssert.h>
#include <PokerEvent.h>
#include <PokerMoveChips.h>
#include <osg/Referenced>
#include <osg/Matrix>

MAFController::~MAFController() {}
void MAFController::Init() {}

struct PokerPlayer : public osg::Referenced
{
  bool mHasRunAnimationBet;
  PokerMoveChipsBet2PotController* GetFreeAnimationBet2Pot();
  PokerMoveChipsPot2PlayerController* GetFreeAnimationPot2Player();
  void SetBet(const std::vector<int>&);
  bool HasRunAnimationBet() const;
};
bool PokerPlayer::HasRunAnimationBet() const { return mHasRunAnimationBet;}
void PokerPlayer::SetBet(const std::vector<int>& v) {}
PokerMoveChipsBet2PotController* PokerPlayer::GetFreeAnimationBet2Pot() { return 0;}
PokerMoveChipsPot2PlayerController* PokerPlayer::GetFreeAnimationPot2Player() { return 0;}

void RecursiveClearUserData(osg::Node*) {}
osg::NodeVisitor* RecursiveLeakCollect(osg::Node*) {return 0;}
osg::Node* UGAMEArtefactModel::GetArtefact() { return 0;}
void RecursiveLeakCheck(osg::NodeVisitor*) {}
void PokerChipsStackController::AddChips(const std::map<unsigned int, unsigned int>& ) {}
std::map<unsigned int,unsigned int> PokerChipsStackController::GetChips() const { return std::map<unsigned int,unsigned int>();}

namespace betslider {
struct BetSlider : public osg::Referenced {};
}

namespace osgchips {
struct ManagedStacks : public osg::Referenced {};
}

PokerChipsStackModel::~PokerChipsStackModel() {}

PokerChipsStackController::~PokerChipsStackController() {}
UGAMEArtefactController::~UGAMEArtefactController() {}
void UGAMEArtefactModel::Init(void) {}
void UGAMEArtefactController::Init(){}
bool UGAMEArtefactController::Update(MAFApplication*){ return true;}
void UGAMEArtefactController::SetSelectable(bool) {}
void UGAMEArtefactController::SetSelected(bool) {}
void UGAMEArtefactController::Anchor(osg::Group*) {}
bool PokerChipsStackController::Update(MAFApplication*) { return true;}

struct PokerPotController : public osg::Referenced
{
  bool mCallResetPots;
  void BuildAnimationPotToPlayer(PokerMoveChipsPot2PlayerController*, int);
  void BuildAnimationBetToPot(PokerMoveChipsBet2PotController*, int);
  void ResetPots();
  PokerPotController();
  void UnFreezeCenter();
  void FreezeCenter();
  void SetPotValue(const std::vector<int>& pot, int sidepot);
};
PokerPotController::PokerPotController() {mCallResetPots = false;}
void PokerPotController::BuildAnimationPotToPlayer(PokerMoveChipsPot2PlayerController*, int) {}
void PokerPotController::ResetPots() {mCallResetPots=true;}
void PokerPotController::BuildAnimationBetToPot(PokerMoveChipsBet2PotController*, int) {}
void PokerPotController::UnFreezeCenter() {}
void PokerPotController::FreezeCenter() {}
void PokerPotController::SetPotValue(const std::vector<int>& pot, int sidepot) {}

osg::Matrix MAFComputeLocalToWorld(osg::Node* src, int parentValidMask, int nodeMaskExclude, int nodeMaskStop) { return osg::Matrix();}

void PokerChipsStackController::SetChips(const std::vector<int>& chips) {}


struct MAFApplication
{
  virtual ~MAFApplication();
  bool HasEvent() const ;
};
MAFApplication::~MAFApplication() {}
bool MAFApplication::HasEvent() const { return false;}

struct PokerApplication : public MAFApplication
{
  virtual ~PokerApplication();
};
PokerApplication::~PokerApplication() {}

PokerChipsStackController::PokerChipsStackController(PokerApplication*, unsigned int) {}



//======================================================================================


std::map<guint,osg::ref_ptr<PokerPlayer> > serial2player;

struct MyFixture : public PokerMoveChips
{
  PokerPotController* mPotCenterMuckup;
  MyFixture():PokerMoveChips(serial2player) {
    serial2player.clear();
    mPotCenterMuckup = new PokerPotController;
  }
  ~MyFixture() { delete mPotCenterMuckup;}
};



#if 0
TEST_FIXTURE(MyFixture, testPokerEventChipsPot2PlayerGoodCaseError1)
{
  bool batch = false;
  mSerial2Player.clear();
  std::vector<int> amount;
  PokerEventChipsPot2Player event(batch,0,amount,0);
  GameAccept<PokerEventChipsPot2Player>(event);
//   CHECK_EQUAL(false, mPot2PlayerCommand.empty());
//   CHECK_EQUAL(true, mLastPacketPotChip.empty());
//   CHECK_EQUAL(true, mPacketPot2PlayerReceived);
}
#endif

TEST_FIXTURE(MyFixture, testPokerEventChipsPot2PlayerGoodCase)
{
  bool batch = false;
  mPacketPot2PlayerReceived = false;
  mSerial2Player[0] = new PokerPlayer;
  std::vector<int> amount;
  mLastPacketPotChip[0] = amount;
  PokerEventChipsPot2Player event(batch,0,amount,0);
  GameAccept<PokerEventChipsPot2Player>(event);
  CHECK_EQUAL(false, mPot2PlayerCommand.empty());
  CHECK_EQUAL(true, mLastPacketPotChip.empty());
  CHECK_EQUAL(true, mPacketPot2PlayerReceived);
}

TEST_FIXTURE(MyFixture, testPokerEventChipsPot2PlayerIfBatchMode)
{
  bool batch = true;
  mSerial2Player[0] = new PokerPlayer;
  std::vector<int> amount;
  PokerEventChipsPot2Player event(batch,0,amount,0);
  GameAccept<PokerEventChipsPot2Player>(event);
  CHECK_EQUAL(true, mPot2PlayerCommand.empty());
}


TEST_FIXTURE(MyFixture, testPlayerLeave)
{
  mSerial2Player[0] = new PokerPlayer;
  mSerial2Player[3] = new PokerPlayer;
  mActiveBet2Pot->AddEntry(PokerTrackActiveMoveChips::EntryElement(0,0));
  mActiveBet2Pot->AddEntry(PokerTrackActiveMoveChips::EntryElement(3,0));
  mActivePot2Player->AddEntry(PokerTrackActiveMoveChips::EntryElement(0,0));
  mActivePot2Player->AddEntry(PokerTrackActiveMoveChips::EntryElement(3,0));
  PlayerLeave(0);
  CHECK_EQUAL(1, mActiveBet2Pot->mActives.size());
  CHECK_EQUAL(1, mActivePot2Player->mActives.size());
}

TEST_FIXTURE(MyFixture, testPlayerFold)
{
  mBet2PotCommand.push_back(PokerMoveChipsCommand(0,std::vector<int>(),0));
  mBet2PotCommand.push_back(PokerMoveChipsCommand(4,std::vector<int>(),0));
  PlayerFold(0);
  CHECK_EQUAL(1, mBet2PotCommand.size());
}

TEST_FIXTURE(MyFixture, testGameStart)
{
  mBet2PotCommand.push_back(PokerMoveChipsCommand(0,std::vector<int>(),0));
  mPacketPot2PlayerReceived = true;
  mActiveBet2Pot->AddEntry(PokerTrackActiveMoveChips::EntryElement(0,0));

  GameStart();
  CHECK_EQUAL(true, mBet2PotCommand.empty());
  CHECK_EQUAL(true, mActiveBet2Pot->mActives.empty());
  CHECK_EQUAL(false, mPacketPot2PlayerReceived);
}

TEST_FIXTURE(MyFixture, testSwitchToExistingLevel)
{
  mPot2PlayerCommand.push_back(PokerMoveChipsCommand(0,std::vector<int>(),0));
  mBet2PotCommand.push_back(PokerMoveChipsCommand(0,std::vector<int>(),0));
  SwitchToExistingLevel();
  CHECK_EQUAL(true, mBet2PotCommand.empty());
  CHECK_EQUAL(true, mPot2PlayerCommand.empty());
}

TEST_FIXTURE(MyFixture, testRunAnimationsPot2Players)
{
  mPot2PlayerCommand.push_back(PokerMoveChipsCommand(0,std::vector<int>(),0));
  CHECK_EQUAL(false, mPotCenterMuckup->mCallResetPots);
  RunAnimationsPot2Players(mPotCenterMuckup);
  CHECK_EQUAL(true, mPotCenterMuckup->mCallResetPots);
  CHECK_EQUAL(true, mEventRunAnimationProcess);
  CHECK_EQUAL(true, mPot2PlayerCommand.empty());
}

TEST_FIXTURE(MyFixture, testSortStack)
{
  serial2player[0] = 0;
  std::vector<int> chips;
  chips.push_back(1);
  mBet2PotCommand.push_back(PokerMoveChipsCommand(0,std::vector<int>(),0));
  mBet2PotCommand.push_back(PokerMoveChipsCommand(0,chips,0));
  mBet2PotCommand.push_back(PokerMoveChipsCommand(1,chips,0));
  SortStack(mBet2PotCommand, true);
  CHECK_EQUAL(1, mBet2PotCommand.size());
  CHECK_EQUAL(0, mBet2PotCommand[0].mSerial);
  CHECK_EQUAL(1, mBet2PotCommand[0].mChips.size());
}


TEST_FIXTURE(MyFixture, testIsAnyChipsToMoveToPotFromPlayer)
{
  mBet2PotCommand.push_back(PokerMoveChipsCommand(0,std::vector<int>(),0));
  mBet2PotCommand[0].mChips.push_back(1);
  CHECK_EQUAL(true,IsAnyChipsToMoveToPotFromPlayer(0));
  CHECK_EQUAL(false,IsAnyChipsToMoveToPotFromPlayer(1));
  mBet2PotCommand[0].mChips.clear();
  CHECK_EQUAL(false,IsAnyChipsToMoveToPotFromPlayer(0));
}


TEST_FIXTURE(MyFixture, testIsAnyChipsToMoveToPot)
{
  mBet2PotCommand.push_back(PokerMoveChipsCommand(0,std::vector<int>(),0));
  mBet2PotCommand[0].mChips.push_back(1);
  CHECK_EQUAL(true,IsAnyChipsToMoveToPot());
  mBet2PotCommand[0].mChips.clear();
  CHECK_EQUAL(false,IsAnyChipsToMoveToPot());
}


TEST_FIXTURE(MyFixture, testRunAnimationsBet2PotForPlayerFinishToBet)
{
  mBet2PotCommand.push_back(PokerMoveChipsCommand(0,std::vector<int>(),0));
  RunAnimationsBet2PotForPlayerFinishToBet(0);
  CHECK_EQUAL(true, mBet2PotCommand.empty());
  CHECK_EQUAL(true, mEventRunAnimationProcess);
}

TEST_FIXTURE(MyFixture, testIsAnimationsBet2PotFinished)
{
  mEventRunAnimationProcess = true;
  CHECK_EQUAL(true, IsAnimationsBet2PotFinished(true,true));
  CHECK_EQUAL(false, IsAnimationsBet2PotFinished(false,true));
  CHECK_EQUAL(false, IsAnimationsBet2PotFinished(false,false));
  mActivePot2Player->AddEntry(PokerTrackActiveMoveChips::EntryElement(0,0));
  mActiveBet2Pot->AddEntry(PokerTrackActiveMoveChips::EntryElement(0,0));
  CHECK_EQUAL(false, IsAnimationsBet2PotFinished(true,true));
}

TEST_FIXTURE(MyFixture, testIsPlayersWhoHaveBet2PotHaveFinishedToBet)
{
  CHECK_EQUAL(true, IsValidToRunAnimationBet2Pot());
  
  mBet2PotCommand.push_back(PokerMoveChipsCommand(0,std::vector<int>(),0));
  CHECK_EQUAL(true, IsValidToRunAnimationBet2Pot());
  serial2player[0] = new PokerPlayer;
  serial2player[0]->mHasRunAnimationBet = false;
  CHECK_EQUAL(true, IsValidToRunAnimationBet2Pot());
  serial2player[0]->mHasRunAnimationBet = true;
  CHECK_EQUAL(false, IsValidToRunAnimationBet2Pot());
}


void reportCustomAssert()
{
  std::string description = CustomAssert::Instance().GetDescription();
  std::string message = CustomAssert::Instance().GetMessage();
  std::string function = CustomAssert::Instance().GetFunction();
  std::string file = CustomAssert::Instance().GetFile();
  int line  = CustomAssert::Instance().GetLine();
  UnitTest::ReportAssert((description+" "+message).c_str(), (function+" "+file).c_str(), line);
}

int	main()
{
  CustomAssert::Instance().SetHandler(reportCustomAssert);
  return UnitTest::RunAllTests();
}
