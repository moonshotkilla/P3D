/* (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <sstream>
#include <vector>
#include <iostream>
#include "CustomAssert/CustomAssert.h"

#include <maf/packets.h>

class PacketEx {
public:
	std::map<std::string, std::string> str2str;
};

static std::map<const MAFPacket*, PacketEx> g_mafpacket2ex;

MAFPacket::MAFPacket(MAFPacketsModule* module, PyObject* object)
{
}

MAFPacket::~MAFPacket()
{
}

void MAFPacket::SetMember(const std::string &name, const std::string &value)
{
	g_mafpacket2ex[this].str2str[name] = value;
}

void MAFPacket::GetMember(const std::string& name, std::string& value) const
{
	value = g_mafpacket2ex[this].str2str[name];
}
