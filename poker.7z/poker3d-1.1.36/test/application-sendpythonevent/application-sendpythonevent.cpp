/* (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *  Cedric Pinson <cpinson@freesheep.org>
 */

#include <UnitTest++.h>
#include <Python.h>

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <map>
#include <typeinfo>
#include <iostream>
#include "maf/application.h"
#include <ReportAssert.h>
#include "CustomAssert/CustomAssert.h"

class MAFApplicationMockup : public MAFApplication
{
  std::string mLog;
public:
  void Init() {}
  const std::string& SetLogPolicy() { return mLog;}
  void Crash() {}
  bool SetSoundEnabled(bool) { return false;}
  bool IsSoundEnabled() { return false;}
  void OnExit(int) {}
  //  void SendPythonEvent(const std::string& event, const std::map<std::string,std::string>& map);
  //  void SendPythonEvent(const std::string& event) { std::map<std::string,std::string> empty; SendPythonEvent(event, empty);}
  bool GetMClient() { return mClient;}
};

void TextureManager::Flush() {}
TextureManager::TextureManager() {}
TextureManager::~TextureManager() {}

MAFError::MAFError(int,char const*, ...) {}
MAFError::~MAFError() {}

void MAFCursorController::ReleaseCursor(){}
void MAFCursorController::InitCursor(){}

struct SDL_Surface;

struct MAFWindow 
{
  MAFWindow();
  void Init(SDL_Surface*);
  void Render();
};

bool MAFController::DoUpdate(MAFApplication*) {}

MAFWindow::MAFWindow() {}
void MAFWindow::Init(SDL_Surface*) {}
void MAFWindow::Render() {}

double GetRealTimeInMS() { return 0;}


void MAFSceneController::DoIntersection(MAFApplication*, int, int) {}

struct MAFPacketsModule
{
  MAFPacketsModule(const std::string&);
  ~MAFPacketsModule();
};
MAFPacketsModule::MAFPacketsModule(const std::string&) {}
MAFPacketsModule::~MAFPacketsModule() {}

class MAFRepositoryData
{
public:
  MAFRepositoryData();
  ~MAFRepositoryData();
};

MAFRepositoryData::MAFRepositoryData(){}
MAFRepositoryData::~MAFRepositoryData(){}


static std::string srcdir;
void fetchsrcdir()
{
  char* srcdirPtr = getenv("srcdir");
#ifdef WIN32
  srcdirPtr = "U:/new_pok3d/underware/underware/test/application-sendpythonevent/";
#endif
  srcdir = std::string(srcdirPtr) + "/";
};

struct Fixture
{
  MAFApplicationMockup* MAF;
  bool _g_criticalIsCalled;

  Fixture(const char* classname) {
    Py_Initialize();
    PySys_SetPath((char*)srcdir.c_str());
    PyObject* module = PyImport_ImportModule("underware.pokerrenderer");
    assert(module && "no module found");
    PyObject* pyclass = PyObject_GetAttrString(module, (char*)classname); 
    assert(pyclass && "class not found");
    PyObject* instance = PyObject_CallFunction(pyclass, "s", "instance_name"); 
    assert(instance && "can't create instance");
    PyErr_Print();
    MAF = new MAFApplicationMockup;
    MAF->SetClient(instance);
    _g_criticalIsCalled = false;

    g_log_set_handler(NULL, (GLogLevelFlags)(G_LOG_LEVEL_CRITICAL), g_criticalHandler, this);
  }

  static void g_criticalHandler(const gchar *log_domain,
                                GLogLevelFlags log_level,
                                const gchar *message,
                                gpointer user_data)
  {
    Fixture* fixture = (Fixture*)user_data;
    fixture->_g_criticalIsCalled = true;
  }

  ~Fixture() {
    delete MAF;
  }
};

struct FixtureGoodModule : public Fixture
{
  FixtureGoodModule():Fixture("PokerRendererMockup") {}
};

struct FixtureBadModule : public Fixture
{
  FixtureBadModule():Fixture("PokerRendererBadMockup") {}
};


TEST_FIXTURE(FixtureGoodModule, testInstance)
{
  MAF->SetClient((PyObject*)0);
  CHECK_EQUAL(MAF->GetMClient() == 0, true);
  MAF->SendPythonEvent("quit");
  CHECK_EQUAL(_g_criticalIsCalled, true);
}

TEST_FIXTURE(FixtureGoodModule, testGoodCase)
{
  std::map<std::string, std::string> myMap;
  myMap["test0"] = "test0";
  myMap["test1"] = "test1";
  CHECK_EQUAL(MAF->GetMClient() != 0, true);
  MAF->SendPythonEvent("quit",myMap);
  CHECK_EQUAL(_g_criticalIsCalled, false);
}

TEST_FIXTURE(FixtureBadModule, testException)
{
  CHECK_EQUAL(MAF->GetMClient() != 0, true);
  CHECK_THROW(MAF->SendPythonEvent("quit"), MAFError*);
}

void reportCustomAssert()
{
  std::string description = CustomAssert::Instance().GetDescription();
  std::string message = CustomAssert::Instance().GetMessage();
  std::string function = CustomAssert::Instance().GetFunction();
  std::string file = CustomAssert::Instance().GetFile();
  int line  = CustomAssert::Instance().GetLine();
  UnitTest::ReportAssert((description+" "+message).c_str(), (function+" "+file).c_str(), line);
}

int	main()
{
  fetchsrcdir();
  CustomAssert::Instance().SetHandler(reportCustomAssert);  
  return UnitTest::RunAllTests();
}
