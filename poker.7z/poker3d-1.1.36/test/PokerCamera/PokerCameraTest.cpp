/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#include <UnitTest++.h>
#include <ReportAssert.h>
#include "PokerCamera.h"
#include <iostream>
#include <maf/window.h>
#include <CustomAssert/CustomAssert.h>

MAFWindow::MAFWindow()
{
}


MAFWindow::~MAFWindow()
{
}

struct MAFController;
struct MAFApplication
{
  std::string HeaderGet(const std::string& name, const std::string& path);
  SDL_Event* GetLastEvent(MAFController* controller) const;
  MAFController* GetFocus(void);
  void LockFocus();
  void UnlockFocus();
  MAFWindow* GetWindow(bool);
  bool HasEvent() const;
};

std::string MAFApplication::HeaderGet(const std::string& name, const std::string& path)
{
  return std::string();
}

SDL_Event* MAFApplication::GetLastEvent(MAFController* controller) const
{
  return NULL;
}

MAFController* MAFApplication::GetFocus(void)
{
  return NULL;
}

void MAFApplication::LockFocus()
{
}

void MAFApplication::UnlockFocus()
{
}

MAFWindow* MAFApplication::GetWindow(bool)
{
  MAFWindow* window = new MAFWindow();
  window->SetWidth(800);
  window->SetHeight(600);
  return window;
}

bool MAFApplication::HasEvent() const
{
  return false;
}

double GetRealTimeInMS()
{
  return 0.0;
}

struct VarsEditor
{
  ~VarsEditor();
};

VarsEditor::~VarsEditor()
{
}

std::list<std::string> MAFXmlData::GetList(const std::string& path)
{
  return std::list<std::string>();
}

struct MAFSceneController;
struct MAFAudioController
{
  MAFAudioController();
  virtual ~MAFAudioController();
  void Play();
};

MAFAudioController::MAFAudioController()
{
}

MAFAudioController::~MAFAudioController()
{
}

void MAFAudioController::Play()
{
}

struct MAFAudioModel
{
  MAFAudioModel();
  void SetName(const std::string&);
  void SetData(MAFAudioData*);
  void SetAmbient(bool);
};

MAFAudioModel::MAFAudioModel()
{
}

void MAFAudioModel::SetName(const std::string&)
{
}

void MAFAudioModel::SetData(MAFAudioData*)
{
}

void MAFAudioModel::SetAmbient(bool)
{
}

struct MAFMonitor;
struct MAFAudioData;
struct MAFXmlData;

MAFAudioData* MAFRepositoryData::GetAudio(const std::string&, MAFMonitor*)
{
  return NULL;
}

MAFXmlData* MAFRepositoryData::GetXml(const std::string &name)
{
  return NULL;
}

struct PokerMoveChipsCommand
{
};

struct PokerPlayer;
class PokerModel : public MAFModel
{
public:
  PokerModel(PokerApplication* game,unsigned int id, MAFMonitor *mon=NULL);
  virtual ~PokerModel();
  PokerPlayer*  GetLocalPlayer();
};


PokerModel::PokerModel(PokerApplication* game,unsigned int id, MAFMonitor *mon)
{
}

PokerModel::~PokerModel()
{
}

PokerPlayer*  PokerModel::GetLocalPlayer()
{
  return NULL;
}

class PokerBodyController
{
 protected:
  virtual ~PokerBodyController();
 public:
  PokerBodyController(MAFApplication* application,MAFOSGData* seat,unsigned int controllerID, bool me);
};

PokerBodyController::~PokerBodyController()
{
}

PokerBodyController::PokerBodyController(MAFApplication* application,MAFOSGData* seat,unsigned int controllerID, bool me)
{
}

struct PokerCameraControllerMockup : PokerCameraController
{
  PokerCameraControllerMockup() : PokerCameraController(NULL, 0)
  {
    GetModel()->mCamAttitude.x() = NAN;
    GetModel()->mCamAttitude.y() = NAN;
    GetModel()->mCamAttitude.z() = NAN;
    GetModel()->mCamAttitude.w() = NAN;
  }
};


TEST(RotateGameModeNanAssert)
{
  PokerCameraControllerMockup controller;
  CHECK_ASSERT(controller.RotateGameMode(0.0, 0.0, 0.0));
}

void reportCustomAssert()
{
  std::string description = CustomAssert::Instance().GetDescription();
  std::string message = CustomAssert::Instance().GetMessage();
  std::string function = CustomAssert::Instance().GetFunction();
  std::string file = CustomAssert::Instance().GetFile();
  int line  = CustomAssert::Instance().GetLine();
  UnitTest::ReportAssert((description+" "+message).c_str(), (function+" "+file).c_str(), line);
}

int main()
{
  CustomAssert::Instance().SetHandler(reportCustomAssert);
  return UnitTest::RunAllTests();
}
