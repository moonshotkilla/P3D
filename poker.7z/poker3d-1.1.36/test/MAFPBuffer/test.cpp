/* (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <UnitTest++.h>

#include <maf/pbuffer.h>
#include <SDL.h>

#ifdef WIN32
#include <GL/GL.h>
#undef main
#endif

int main(int argc, char *argv[])
{
	return UnitTest::RunAllTests();
}

TEST(Create512x512PBufferWithoutContext)
{
	MAFPBuffer *pbuffer = new MAFPBuffer(512, 512);
	CHECK(pbuffer);
	bool res = pbuffer->_create();
	CHECK_EQUAL(res, false);
	delete pbuffer;
}

TEST(Create512x512PBufferWith32bitsContext)
{
  CHECK_EQUAL( SDL_Init(SDL_INIT_VIDEO), 0);
  SDL_Surface *surface = SDL_SetVideoMode(640, 480, 32, SDL_OPENGL);

	MAFPBuffer *pbuffer = new MAFPBuffer(512, 512);
	CHECK(pbuffer);
	bool res = pbuffer->_create();
	CHECK_EQUAL(res, true);
	pbuffer->_destroy();
	delete pbuffer;
	SDL_Quit();
}

TEST(Create512x512PBufferWith32bitsContextAndUseIt)
{
  CHECK_EQUAL( SDL_Init(SDL_INIT_VIDEO), 0);
  SDL_Surface *surface = SDL_SetVideoMode(640, 480, 32, SDL_OPENGL);
	CHECK(surface);
	MAFPBuffer *pbuffer = new MAFPBuffer(512, 512);
	CHECK(pbuffer);
	bool res = pbuffer->_create();
	CHECK_EQUAL(res, true);

	for (int i = 0; i < 1000; i++) {
		pbuffer->use();

		glClearColor(0, 0, 1, 0);
		glClearDepth(1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		glDisable(GL_DEPTH_TEST);

		glViewport(0, 0, 512, 512);

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(-1, 1, -1, 1, -1, 1);

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		glBegin(GL_QUADS);

		glColor3f(0.0f, 0.0f, 0.0f);
		glVertex3f(-1.0f, 1.0f, 1.0f);

		glColor3f(1.0f, 0.0f, 0.0f);
		glVertex3f(i/500.0f-1.0f, 1.0f, 1.0f);

		glColor3f(1.0f, 1.0f, 0.0f);
		glVertex3f(i/500.0f-1.0f, -1.0f, 1.0f);

		glColor3f(0.0f, 1.0f, 1.0f);
		glVertex3f(-1.0f, -1.0f, 1.0f);

		glEnd();

		pbuffer->release();

		SDL_GL_SwapBuffers();
	
		SDL_Event event;
		while ( SDL_PollEvent(&event) ) { };
	}

	pbuffer->_destroy();
	delete pbuffer;
	SDL_Quit();
}

TEST(Create512x512PBufferWith16bitsContextAndUseIt)
{
  CHECK_EQUAL( SDL_Init(SDL_INIT_VIDEO), 0);
  SDL_Surface *surface = SDL_SetVideoMode(640, 480, 16, SDL_OPENGL);
	CHECK(surface);
	MAFPBuffer *pbuffer = new MAFPBuffer(512, 512);
	CHECK(pbuffer);
	bool res = pbuffer->_create();
	CHECK_EQUAL(res, true);

	for (int i = 0; i < 1000; i++) {
		pbuffer->use();

		glClearColor(0, 0, 1, 0);
		glClearDepth(1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		glDisable(GL_DEPTH_TEST);

		glViewport(0, 0, 512, 512);

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(-1, 1, -1, 1, -1, 1);

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		glBegin(GL_QUADS);

		glColor3f(0.0f, 0.0f, 0.0f);
		glVertex3f(-1.0f, 1.0f, 1.0f);

		glColor3f(1.0f, 0.0f, 0.0f);
		glVertex3f(i/500.0f-1.0f, 1.0f, 1.0f);

		glColor3f(1.0f, 1.0f, 0.0f);
		glVertex3f(i/500.0f-1.0f, -1.0f, 1.0f);

		glColor3f(0.0f, 1.0f, 1.0f);
		glVertex3f(-1.0f, -1.0f, 1.0f);

		glEnd();

		pbuffer->release();

		SDL_GL_SwapBuffers();
	
		SDL_Event event;
		while ( SDL_PollEvent(&event) ) { };
	}

	pbuffer->_destroy();
	delete pbuffer;
	SDL_Quit();
}
