/* (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */
#include <UnitTest++.h>
#include <ReportAssert.h>
#include <maf/wnc_desktop.h>
#include <maf/wnc_window.h>

#define Read ReadMockup
#include <maf/renderbin.h>

#include <CustomAssert/CustomAssert.h>
#include <string>


struct URL
{
  void load(const std::string&);
};
void URL::load(const std::string&) {}

MAFError::MAFError(int, char const*, ...) {}
MAFError::~MAFError(){}

struct WncImage
{
    typedef enum {
   OPAQUE=0,      // Reserved for toolkit extensions
	 PREFERRED=1,   // Image source can freely choose the encoding
	 // -------------------------------------------------
	 // "Raw" encodings
	 L=16,          // Luminance (grayscale) images
	 RGB=32,        // These are the
	 ABGR=64,       //    two main encodings we use     
	 RGBA=128,      // Used for OpenGL textures
	 ARGB=256,      // Quicktime "native format" ?
	 YpCbCr420=512, // Y'CbCr 4:2:0 (see www.inforamp.net/~poynton)
	                //    Image is stored with all Y' components,
	                //    then Cb (1/4), then Cr (1/4)
                     //    (is this what they call a "planar" format?)
	 // -------------------------------------------------
	 // "Cooked" encodings
	 JPEG=4096
    } Encoding ;
};

//typedef std::string URL ;

struct wncSource
{
  wncSource(XwncDesktop*, WncImage::Encoding, URL const&);
  ~wncSource();
  bool start();
  void updateRequest(bool);
  void getSize(unsigned int*, unsigned int*);
  void check();
  void keyEvent(unsigned long, bool);
  void pointerEvent(int, int, unsigned long);
  void pointerEvent(unsigned long, int, int, unsigned char);
};
wncSource::wncSource(XwncDesktop*, WncImage::Encoding, URL const&) {}
wncSource::~wncSource() {}
bool wncSource::start() { return true;}
void wncSource::updateRequest(bool)  {}
void wncSource::getSize(unsigned int*, unsigned int*) {}
void wncSource::check(){}
void wncSource::keyEvent(unsigned long, bool) {}
void wncSource::pointerEvent(int, int, unsigned long) {}
void wncSource::pointerEvent(unsigned long, int, int, unsigned char) {}

#if 0
struct MAFRenderBin
{
  bool GetRenderBinIndexOfEntity(const std::string &_entityName, int &_rbinIndex) const;
  MAFRenderBin& Instance();
  bool SetupRenderBin(const std::string &_entityName, osg::StateSet *_ss) const;
};

bool MAFRenderBin::GetRenderBinIndexOfEntity(const std::string &_entityName, int &_rbinIndex) const
{
  return true;
}

MAFRenderBin& MAFRenderBin::Instance()
{
  return *(new MAFRenderBin());
}

bool MAFRenderBin::SetupRenderBin(const std::string &_entityName, osg::StateSet *_ss) const
{
  return true;
}
#endif

void MAFRenderBin::Read(struct _xmlDoc *_doc, const std::string &_xpath)
{
  typedef std::pair<int,std::string> Entry;
  mName2rbin["WNC_yo"] = Entry(10, std::string("RenderBin"));
  mName2rbin["WNC_DEFAULT_RENDER_BIN"] = Entry(5,std::string("RenderBin"));
  mName2rbin["WNC_menu"] = Entry(13,std::string("RenderBin"));
  mName2rbin["WNC_message"] = Entry(0,std::string("RenderBin"));
}


const std::string& XwncWindow::GetTitle() const { return _title;}
XwncWindow::~XwncWindow() {}
void XwncWindow::getSize(float*, float*) const {}
void XwncWindow::updateTexture(WncImage*, int, int, unsigned int, unsigned int) {}
bool XwncWindow::IsMapped() const { return true;}
void XwncWindow::setMapped(bool) {}
osg::MatrixTransform* XwncWindow::staticCopy() { return 0;}
XwncWindow::XwncWindow(std::string name, unsigned long, wncSource*, int, int, unsigned int, unsigned int) { _title = name;}
void XwncWindow::setRootWindow(){}
void XwncWindow::configure(int, int, int, int) {}
void XwncWindow::getSize(int*, int*) const {}
void XwncWindow::getPosition(int*, int*, int) {}
unsigned long XwncWindow::getFrameID() { return 0;}
bool XwncWindow::isRootWindow() { return true;}
void XwncWindow::setStackPriority(int i) { _stackPriority = i;}
int XwncWindow::getStackPriority() const { return _stackPriority;}

struct DesktopMockup : public XwncDesktop
{
  std::vector<XwncWindow*> win;
  DesktopMockup():XwncDesktop("toto","l'asticot") {
    win.push_back(new XwncWindow("bof", 0, 0, 0, 0, 100, 100));
    win.push_back(new XwncWindow("yo", 0, 0, 0, 0, 100, 100));
    win.push_back(new XwncWindow("message", 0, 0, 0, 0, 100, 100));
    win.push_back(new XwncWindow("menu", 0, 0, 0, 0, 100, 100));
    MAFRenderBin::Instance().Read(0,"rien");
  }

};

TEST_FIXTURE(DesktopMockup, TestSetPriorityWindow)
{
  for (int i = 0; i < (int)win.size(); i++)
    setWindowPriority(win[i]);

  CHECK_EQUAL(5,win[0]->getOrCreateStateSet()->getBinNumber());
  CHECK_EQUAL(10,win[1]->getOrCreateStateSet()->getBinNumber());
  CHECK_EQUAL(0,win[2]->getOrCreateStateSet()->getBinNumber());
  CHECK_EQUAL(13,win[3]->getOrCreateStateSet()->getBinNumber());
}

void reportCustomAssert()
{
  std::string description = CustomAssert::Instance().GetDescription();
  std::string message = CustomAssert::Instance().GetMessage();
  std::string function = CustomAssert::Instance().GetFunction();
  std::string file = CustomAssert::Instance().GetFile();
  int line  = CustomAssert::Instance().GetLine();
  UnitTest::ReportAssert((description+" "+message).c_str(), (function+" "+file).c_str(), line);
}

int	main()
{
  CustomAssert::Instance().SetHandler(reportCustomAssert);
  return UnitTest::RunAllTests();
}
