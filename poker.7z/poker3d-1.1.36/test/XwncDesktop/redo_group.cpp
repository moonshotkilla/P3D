/* (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */
#include <UnitTest++.h>
#include <ReportAssert.h>
#include <osg/TexMat>
#include <maf/wnc_desktop.h>
#include <maf/wnc_window.h>
#include <PokerApplication2d.h>
#include <CustomAssert/CustomAssert.h>
#include <string>

MAFError::MAFError(int, char const*, ...) {}
MAFError::~MAFError(){}


struct URL
{
  void load(const std::string&);
};
void URL::load(const std::string&) {}

struct WncImage
{
    typedef enum {
   OPAQUE=0,      // Reserved for toolkit extensions
	 PREFERRED=1,   // Image source can freely choose the encoding
	 // -------------------------------------------------
	 // "Raw" encodings
	 L=16,          // Luminance (grayscale) images
	 RGB=32,        // These are the
	 ABGR=64,       //    two main encodings we use     
	 RGBA=128,      // Used for OpenGL textures
	 ARGB=256,      // Quicktime "native format" ?
	 YpCbCr420=512, // Y'CbCr 4:2:0 (see www.inforamp.net/~poynton)
	                //    Image is stored with all Y' components,
	                //    then Cb (1/4), then Cr (1/4)
                     //    (is this what they call a "planar" format?)
	 // -------------------------------------------------
	 // "Cooked" encodings
	 JPEG=4096
    } Encoding ;
};

struct wncSource
{
  wncSource(XwncDesktop*, WncImage::Encoding, URL const&);
  ~wncSource();
  bool start();
  void updateRequest(bool);
  void getSize(unsigned int*, unsigned int*);
  void check();
  void keyEvent(unsigned long, bool);
  void pointerEvent(int, int, unsigned long);
  void pointerEvent(unsigned long, int, int, unsigned char);
};
wncSource::wncSource(XwncDesktop*, WncImage::Encoding, URL const&) {}
wncSource::~wncSource() {}
bool wncSource::start() { return true;}
void wncSource::updateRequest(bool)  {}
void wncSource::getSize(unsigned int*, unsigned int*) {}
void wncSource::check(){}
void wncSource::keyEvent(unsigned long, bool) {}
void wncSource::pointerEvent(int, int, unsigned long) {}
void wncSource::pointerEvent(unsigned long, int, int, unsigned char) {}

struct _xmlDoc {};

struct MAFRenderBin
{
  bool GetRenderBinIndexOfEntity(const std::string &_entityName, int &_rbinIndex) const;
  MAFRenderBin& Instance();
  bool SetupRenderBin(const std::string &_entityName, osg::StateSet *_ss) const;
  void Read(_xmlDoc*, const std::string&);
};

void MAFRenderBin::Read(_xmlDoc*, const std::string&){}

bool MAFRenderBin::GetRenderBinIndexOfEntity(const std::string &_entityName, int &_rbinIndex) const
{
  return true;
}

MAFRenderBin& MAFRenderBin::Instance()
{
  return *(new MAFRenderBin());
}

bool MAFRenderBin::SetupRenderBin(const std::string &_entityName, osg::StateSet *_ss) const
{
  return true;
}

void XwncWindow::setStackPriority(int i) { _stackPriority = i;}
int XwncWindow::getStackPriority() const { return _stackPriority;}
const std::string& XwncWindow::GetTitle() const { return _title;}
XwncWindow::~XwncWindow() {}
void XwncWindow::getSize(float*, float*) const {}
void XwncWindow::updateTexture(WncImage*, int, int, unsigned int, unsigned int) {}
bool XwncWindow::IsMapped() const { return true;}
void XwncWindow::setMapped(bool) {}
osg::MatrixTransform* XwncWindow::staticCopy() { return 0;}
XwncWindow::XwncWindow(std::string name, unsigned long id, wncSource*, int, int, unsigned int, unsigned int) { _title = name; _frameID = id; }
void XwncWindow::setRootWindow(){}
void XwncWindow::configure(int, int, int, int) {}
void XwncWindow::getSize(int*, int*) const {}
void XwncWindow::getPosition(int*, int*, int) {}
unsigned long XwncWindow::getFrameID() { return _frameID;}
bool XwncWindow::isRootWindow() { return true;}

struct DesktopMockup : public XwncDesktop
{
  std::vector<XwncWindow*> win;
  DesktopMockup():XwncDesktop("toto","l'asticot") {
    win.push_back(new XwncWindow("bof", 1, 0, 0, 0, 100, 100));
    _windows[1] = win[0];
    win.push_back(new XwncWindow("yo", 2, 0, 0, 0, 100, 100));
    _windows[2] = win[1];
    win.push_back(new XwncWindow("message", 3, 0, 0, 0, 100, 100));
    _windows[3] = win[2];
    win.push_back(new XwncWindow("menu", 4, 0, 0, 0, 100, 100));
    _windows[4] = win[3];
  }

};

TEST_FIXTURE(DesktopMockup, TestOriginalCase)
{
  win[0]->setStackPriority(1);
  win[1]->setStackPriority(1);
  win[2]->setStackPriority(1);
  win[3]->setStackPriority(1);
  for (int i = 0; i < (int)win.size(); i++)
    _add(win[i]->getFrameID());

  CHECK_EQUAL(4, mDisplayGroup->getNumChildren());
  CHECK_EQUAL(4, mHitGroup->getNumChildren());

  CHECK_EQUAL(1, dynamic_cast<XwncWindow*>(mDisplayGroup->getChild(0))->getFrameID());
  CHECK_EQUAL(2, dynamic_cast<XwncWindow*>(mDisplayGroup->getChild(1))->getFrameID());
  CHECK_EQUAL(3, dynamic_cast<XwncWindow*>(mDisplayGroup->getChild(2))->getFrameID());
  CHECK_EQUAL(4, dynamic_cast<XwncWindow*>(mDisplayGroup->getChild(3))->getFrameID());

  CHECK_EQUAL(1, dynamic_cast<XwncWindow*>(mHitGroup->getChild(3))->getFrameID());
  CHECK_EQUAL(2, dynamic_cast<XwncWindow*>(mHitGroup->getChild(2))->getFrameID());
  CHECK_EQUAL(3, dynamic_cast<XwncWindow*>(mHitGroup->getChild(1))->getFrameID());
  CHECK_EQUAL(4, dynamic_cast<XwncWindow*>(mHitGroup->getChild(0))->getFrameID());
}

TEST_FIXTURE(DesktopMockup, TestOriginalCaseUp)
{
  win[0]->setStackPriority(1);
  win[1]->setStackPriority(1);
  win[2]->setStackPriority(1);
  win[3]->setStackPriority(1);
  for (int i = 0; i < (int)win.size(); i++)
    _add(win[i]->getFrameID());

  _up(win[1]->getFrameID());

  CHECK_EQUAL(4, mDisplayGroup->getNumChildren());
  CHECK_EQUAL(4, mHitGroup->getNumChildren());

  CHECK_EQUAL(1, dynamic_cast<XwncWindow*>(mDisplayGroup->getChild(0))->getFrameID());
  CHECK_EQUAL(3, dynamic_cast<XwncWindow*>(mDisplayGroup->getChild(1))->getFrameID());
  CHECK_EQUAL(4, dynamic_cast<XwncWindow*>(mDisplayGroup->getChild(2))->getFrameID());
  CHECK_EQUAL(2, dynamic_cast<XwncWindow*>(mDisplayGroup->getChild(3))->getFrameID());

  CHECK_EQUAL(2, dynamic_cast<XwncWindow*>(mHitGroup->getChild(0))->getFrameID());
  CHECK_EQUAL(4, dynamic_cast<XwncWindow*>(mHitGroup->getChild(1))->getFrameID());
  CHECK_EQUAL(3, dynamic_cast<XwncWindow*>(mHitGroup->getChild(2))->getFrameID());
  CHECK_EQUAL(1, dynamic_cast<XwncWindow*>(mHitGroup->getChild(3))->getFrameID());
}


TEST_FIXTURE(DesktopMockup, TestPriorityStack1)
{
  win[0]->setStackPriority(9);
  win[1]->setStackPriority(4);
  win[2]->setStackPriority(1);
  win[3]->setStackPriority(2);
  for (int i = 0; i < (int)win.size(); i++)
    _add(win[i]->getFrameID());

  CHECK_EQUAL(4, mDisplayGroup->getNumChildren());
  CHECK_EQUAL(4, mHitGroup->getNumChildren());
  
  CHECK_EQUAL(3, dynamic_cast<XwncWindow*>(mDisplayGroup->getChild(0))->getFrameID());
  CHECK_EQUAL(4, dynamic_cast<XwncWindow*>(mDisplayGroup->getChild(1))->getFrameID());
  CHECK_EQUAL(2, dynamic_cast<XwncWindow*>(mDisplayGroup->getChild(2))->getFrameID());
  CHECK_EQUAL(1, dynamic_cast<XwncWindow*>(mDisplayGroup->getChild(3))->getFrameID());

  CHECK_EQUAL(3, dynamic_cast<XwncWindow*>(mHitGroup->getChild(3))->getFrameID());
  CHECK_EQUAL(4, dynamic_cast<XwncWindow*>(mHitGroup->getChild(2))->getFrameID());
  CHECK_EQUAL(2, dynamic_cast<XwncWindow*>(mHitGroup->getChild(1))->getFrameID());
  CHECK_EQUAL(1, dynamic_cast<XwncWindow*>(mHitGroup->getChild(0))->getFrameID());
}

TEST_FIXTURE(DesktopMockup, TestPriorityStack1up)
{
  win[0]->setStackPriority(9);
  win[1]->setStackPriority(4);
  win[2]->setStackPriority(1);
  win[3]->setStackPriority(2);
  for (int i = 0; i < (int)win.size(); i++)
    _add(win[i]->getFrameID());
  _up(3);

  CHECK_EQUAL(4, mDisplayGroup->getNumChildren());
  CHECK_EQUAL(4, mHitGroup->getNumChildren());
  
  CHECK_EQUAL(3, dynamic_cast<XwncWindow*>(mDisplayGroup->getChild(0))->getFrameID());
  CHECK_EQUAL(4, dynamic_cast<XwncWindow*>(mDisplayGroup->getChild(1))->getFrameID());
  CHECK_EQUAL(2, dynamic_cast<XwncWindow*>(mDisplayGroup->getChild(2))->getFrameID());
  CHECK_EQUAL(1, dynamic_cast<XwncWindow*>(mDisplayGroup->getChild(3))->getFrameID());

  CHECK_EQUAL(3, dynamic_cast<XwncWindow*>(mHitGroup->getChild(3))->getFrameID());
  CHECK_EQUAL(4, dynamic_cast<XwncWindow*>(mHitGroup->getChild(2))->getFrameID());
  CHECK_EQUAL(2, dynamic_cast<XwncWindow*>(mHitGroup->getChild(1))->getFrameID());
  CHECK_EQUAL(1, dynamic_cast<XwncWindow*>(mHitGroup->getChild(0))->getFrameID());
}


void reportCustomAssert()
{
  std::string description = CustomAssert::Instance().GetDescription();
  std::string message = CustomAssert::Instance().GetMessage();
  std::string function = CustomAssert::Instance().GetFunction();
  std::string file = CustomAssert::Instance().GetFile();
  int line  = CustomAssert::Instance().GetLine();
  UnitTest::ReportAssert((description+" "+message).c_str(), (function+" "+file).c_str(), line);
}

int	main()
{
  CustomAssert::Instance().SetHandler(reportCustomAssert);
  return UnitTest::RunAllTests();
}
