
#include <maf/flyingitem.h>
#include <maf/glow_fx.h>
#include <maf/renderbin.h>
#include <maf/window.h>

#include <osgCal/ImageCache>

#include "PokerApplication.h"
#include <PokerPlayer/PokerPlayer.h>
#include "PokerSceneView.h"
#include "PokerSound.h"

#include <osgchips/Stacks>

#include <SDL.h>

#include "memory_test.h"

#undef main

int main(int argc, char **argv)
{
	SDL_Surface *surface;
	SDL_Init(SDL_INIT_VIDEO);
	SDL_EnableUNICODE(1);
	//SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY, SDL_DEFAULT_REPEAT_INTERVAL);

	int FLAGS = SDL_OPENGL | SDL_DOUBLEBUF;
  //if (fullscreen)
    //FLAGS |= SDL_FULLSCREEN;
	surface = SDL_SetVideoMode(1024, 768, 24, FLAGS);

	xmlDocPtr doc1 = xmlParseFile("U:/new_pok3d/underware/underware/examples/poker/conf/client.xml");
	xmlDocPtr doc2 = xmlParseFile("U:/new_pok3d/underware/envwin32/poker.client.xml");

	PokerApplication *app = new PokerApplication();
	MAFApplication::Headers headers;
	headers["sequence"] = doc1;
	headers["settings"] = doc2;
	app->SetHeaders(headers);

	app->mDatas->SetBaseDirectory("U:/new_pok3d/data.proprio");
	app->mDatas->SetLevel("level00");
	MAFRenderBin::Instance().Read(doc1, "/sequence/renderbin/*/entity");

	const std::string &dataPath = app->HeaderGet("settings", "/settings/data/@path");
  osgDB::Registry::instance()->getDataFilePathList().push_back(dataPath);

	app->SetScene(new MAFSceneController);
	MAFSceneModel *model = new MAFSceneModel;
	app->GetScene()->SetModel(model);
  PokerSceneView *uihelp = new PokerSceneView(app, 1024);
  uihelp->setUseGlow(false);
  app->GetScene()->SetView(uihelp);
  app->GetScene()->Init();
	uihelp->setViewport(0, 0, 1024, 768);
	app->GetWindow(true)->AddView(uihelp);
	uihelp->setup();

	MAFGlowFX::init(256);

  {
		osgchips::ChipBank *instance = osgchips::ChipBank::instance();
    instance->unserialize(app->GetHeaders()["sequence"], "/sequence/osgchips", osgDB::Registry::instance());
  }

	// precaching texture
	std::list<std::string> urls = app->HeaderGetList("sequence", "/sequence/texture_precache/texture/@name");
	for (std::list<std::string>::iterator it = urls.begin(); it != urls.end(); ++it) {
		std::string tex = *it;
    std::string data = app->HeaderGet("settings", "/settings/data/@path");

		std::string path = data + "/" + tex;
		osgCal::ImageCache::getOrLoadBinary(path);
	}

	// load sounds
	{
    std::string maleSounds = "player.male.cal3d/sounds/sounds.xml";
    MAFXmlData *maleData = app->mDatas->GetXml(maleSounds);

    std::string femaleSounds = "player.female.cal3d/sounds/sounds.xml";
    MAFXmlData *femaleData = app->mDatas->GetXml(femaleSounds);

    std::vector<SoundInit> maleParams;
    std::vector<SoundInit> femaleParams;
		LoadSoundSettings(maleParams, maleData);
		LoadSoundSettings(femaleParams, femaleData);

		int nbMaleSounds = maleParams.size();
		int nbFemaleSounds = femaleParams.size();

		for (int i = 0; i < nbMaleSounds; i++) {
			app->mDatas->GetAudio("player.male.cal3d/sounds/" + maleParams[i].mSoundName);
		}

		for (int i = 0; i < nbFemaleSounds; i++) {
			app->mDatas->GetAudio("player.female.cal3d/sounds/" + femaleParams[i].mSoundName);
		}
	}

	MAFOSGData *setData;
  {
    std::string set_name = app->HeaderGet("sequence", "/sequence/set/@url");
    setData = dynamic_cast<MAFOSGData*>(app->mDatas->GetVision(set_name, NULL ));
    app->mSetData = setData;
  }

	app->GetScene()->GetModel()->mGroup->addChild(setData->GetGroup());

	app->GetScene()->GetView()->setSetupVP(false);

	app->GetScene()->GetModel()->mScene->setProjectionMatrixAsPerspective(80,
																								1024.0f / 768.0f,
																								1.0f,
																								10000.0f);


	std::string outfit;
	FILE *f = fopen("c:/outfit0.txt", "rb");
	while(1) {
		int c = fgetc(f);
		if (c == EOF)
			break;
		outfit += char(c);
	}
	fclose(f);

	//PokerSplashScreenModel *monitor = new PokerSplashScreenModel(app);
	PokerPlayerP *player = new PokerPlayerP(app, 0, false, "player.female.cal3d", outfit);

	app->GetScene()->GetModel()->mGroup->addChild( player->GetSeat()->GetModel()->GetArtefact() );

	int mouseX = 0, mouseY = 0;
	bool bLMB = false;
	bool bRMB = false;
	while(1) {

//		osg::Matrixf viewMatrix = osg::Matrix::inverse(g_camMatrix);
	//	app->GetScene()->GetModel()->mScene->setViewMatrix(viewMatrix);

		app->GetWindow(true)->Render();
	}

	return 0;
}
