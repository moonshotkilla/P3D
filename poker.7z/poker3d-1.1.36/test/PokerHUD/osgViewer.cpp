#include "osgViewer.h"

#ifndef WIN32
 #include <sys/time.h>
#endif
#include <ctime>
#include <string>
#include <iostream>
#include <SDL.h>
#include <osgUtil/SceneView>
#include <UnitTest++.h>
#include <ReportAssert.h>
#include <osg/FrameStamp>

class FrameStampExtended : public osg::FrameStamp
{
protected:

	double _deltaFrame;

public:

	void setDeltaFrame(double delta) { _deltaFrame = delta; }
	double getDeltaFrame() const { return _deltaFrame; }

};



void Assert::AssertMsg(bool condition, const std::string& msg, const std::string& function, const std::string& file, int line)
{
  if (condition == false)
    UnitTest::ReportAssert(msg.c_str(), (function+": "+file).c_str(), line);
}

osgViewer::osgViewer() : mRunning(false), mDeltaTime(0.0), mCurrentTime(0.0), mPreviousTime(0.0), mSurface(NULL), mSceneView(NULL), mSceneRoot(NULL)
{
}
osgViewer::~osgViewer()
{
  ASSERT(false == mRunning);
  ASSERT(NULL == mSurface);
  ASSERT(NULL == mSceneView.get());
  ASSERT(NULL == mSceneRoot.get());
}
void osgViewer::Create(int width, int height, int bpp, bool fullscreen)
{
  ASSERT(false == mRunning);
  ASSERT(NULL == mSurface);
  ASSERT(NULL == mSceneView.get());
  ASSERT(NULL == mSceneRoot.get());
  SDL_Init(SDL_INIT_VIDEO);
  int FLAGS = SDL_OPENGL|SDL_DOUBLEBUF;
  if (fullscreen)
    FLAGS |= SDL_FULLSCREEN;
  mSurface = SDL_SetVideoMode(width, height, BPP, FLAGS);
  ASSERT(mSurface && "SDL_SetVideoMode()");
  mSceneView = new osgUtil::SceneView();
  mSceneView->setDefaults();
	mSceneView->setFrameStamp(new FrameStampExtended());
  mSceneRoot = new osg::Group();
  mSceneView->setSceneData(mSceneRoot.get());
  mSceneView->setViewport(0, 0, width, height);
  mRunning = true;
  updateCurrentTime();
  mPreviousTime = mCurrentTime;
  mDeltaTime = 0.0;
}
void osgViewer::Destroy()
{
  ASSERT(NULL != mSurface);
  ASSERT(NULL != mSceneView.get());
  ASSERT(NULL != mSceneRoot.get());    
  mSceneRoot = NULL;
  mSceneView = NULL;
  mSurface = NULL;
  mRunning = false;
  SDL_Quit();
}
void osgViewer::Update()
{
	static unsigned int frameNumer = 0;
  mLastEvent = NULL;
  mPreviousTime = mCurrentTime;
  updateCurrentTime();  
  mDeltaTime = mCurrentTime - mPreviousTime;
  if (SDL_PollEvent(&mEvent)) {
		mLastEvent = &mEvent;
		if (mEvent.type == SDL_KEYDOWN)
			if (mEvent.key.keysym.sym == SDLK_ESCAPE)
				mRunning = false;
	}

	osg::FrameStamp* fss = const_cast<osg::FrameStamp*>(mSceneView->getFrameStamp());
	fss->setReferenceTime(mCurrentTime);
	fss->setFrameNumber(frameNumer);
	FrameStampExtended* fs = dynamic_cast<FrameStampExtended*>(fss);
	fs->setDeltaFrame(mDeltaTime);
	frameNumer++;
}

void osgViewer::updateCurrentTime()
{
  mCurrentTime = SDL_GetTicks()/1000.0f;
}

void osgViewer::Render()
{
	Cull();
	Draw();
	SwapBuffer();
}

void osgViewer::Cull()
{
  mSceneView->setProjectionMatrixAsOrtho(0.f, float(WIDTH),
																				 float(HEIGHT), 0.0f,
																				 -FLT_MAX, FLT_MAX);
  mSceneView->update();
  mSceneView->cull();
}

void osgViewer::Draw()
{
  mSceneView->draw();
}

void osgViewer::SwapBuffer()
{
  SDL_GL_SwapBuffers();   
} 

bool osgViewer::GetRunning() const
{
  return mRunning;
}
osg::Group* osgViewer::GetRoot()
{
  ASSERT(mSceneRoot.get());
  return mSceneRoot.get();
}
const SDL_Event* osgViewer::GetLastEvent() const
{
  return mLastEvent;
}
float osgViewer::GetDeltaTime() const
{
  return mDeltaTime;
}
float osgViewer::GetCurrentTime() const
{
  return mCurrentTime;
}
float osgViewer::GetPreviousTime() const
{
  return mPreviousTime;
}
