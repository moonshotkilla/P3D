/* (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#include <UnitTest++.h>
#include <ReportAssert.h>
#include <osg/Vec2>
#include <osg/MatrixTransform>
#include <osg/Geode>
#include <osg/Version>
#if OSG_VERSION_MAJOR == 1
#include <osg/io_utils>
#endif // OSG_VERSION_MAJOR == 1
#include <osg/Geometry>
#include <osg/Material>
#include <osg/Projection>
#include <osg/BlendFunc>
#include <osgText/Text>
#include <osgText/Font>
#include <osgDB/Registry>
#include <osgDB/WriteFile>
#include <string>
#include <iostream>
#include <sstream>

#include <libxml/parser.h>

// #define USE_NPROFILE
// #include <nprofile/profile.h>

#include "osgSprite/osgSprite.h"
#include "PokerHUD/PokerHUD.h"
#include "ugame/text.h"
#include "CustomAssert/CustomAssert.h"
#include "packets.mock.h"
#include "osgViewer.h"
#include <glib.h>

void reportCustomAssert()
{
  std::string description = CustomAssert::Instance().GetDescription();
  std::string message = CustomAssert::Instance().GetMessage();
  std::string function = CustomAssert::Instance().GetFunction();
  std::string file = CustomAssert::Instance().GetFile();
  int line  = CustomAssert::Instance().GetLine();
  UnitTest::ReportAssert((description+" "+message).c_str(), (function+" "+file).c_str(), line);
}

template<>
void MAFPacket::SetMember<std::string> (const std::string& member, const std::string& in)
{
  mMembers[member] = in;
}
template<>
void MAFPacket::SetMember< std::vector<int> > (const std::string& member, const std::vector<int>& in)
{
  mMembers[member] = "true";
  mInts = in;
}
template<>
void MAFPacket::SetMember< std::vector<unsigned int> > (const std::string& member, const std::vector<unsigned int>& in)
{
  mMembers[member] = "true";
  mUInts = in;
}
template<>
void MAFPacket::SetMember< std::vector<std::string> > (const std::string& member, const std::vector<std::string>& in)
{
  mMembers[member] = "true";
  mStrings = in;
}

static std::string hudxml;
static std::string srcdir;
void fetchsrcdir()
{
  char* srcdirPtr = getenv("srcdir");
#ifdef WIN32
  srcdirPtr = "U:/new_pok3d/underware/underware/test/PokerHUD";
#endif
  if (srcdirPtr)
    {
      //beware "." is always first in PathList
      osgDB::Registry::instance()->getDataFilePathList().push_front(srcdirPtr);
      srcdir = std::string(srcdirPtr) + "/";
      if (srcdir == "./")
	srcdir = "";
    }
  hudxml = srcdir + "hud.xml";
};

TEST(PokerHUDPanelTest)
{
  {
    PokerHUD::Panel panel(hudxml, "/sequence/hud");
    CHECK_EQUAL(panel.mName, "");
    CHECK_EQUAL(panel.mAction, "None");
    CHECK_EQUAL(panel.mPlayed, false);
    CHECK_EQUAL(panel.mInPosition, false);
    CHECK_EQUAL(panel.mDealer, false);
    CHECK_EQUAL(panel.mHeaderSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/band_low_off.tga");
    panel.SetName("toto");
    panel.SetAction("Call");
    panel.SetInPosition(false);
    panel.SetInPosition(true);  
    panel.SetChipAmount(42);
  }
  {
    _xmlDoc* doc = xmlParseFile(hudxml.c_str());
    CUSTOM_ASSERT(doc);
    PokerHUD::Panel panel(doc, "/sequence/hud");
    xmlFreeDoc(doc);
    xmlCleanupParser();
    CHECK_EQUAL(panel.mName, "");
    CHECK_EQUAL(panel.mAction, "None");
    CHECK_EQUAL(panel.mPlayed, false);
    CHECK_EQUAL(panel.mInPosition, false);
    CHECK_EQUAL(panel.mDealer, false);
    CHECK_EQUAL(panel.mHeaderSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/band_low_off.tga");
    panel.SetName("toto");
    panel.SetAction("Call");
    panel.SetInPosition(false);
    panel.SetInPosition(true);  
    panel.SetChipAmount(42);
  }
}

TEST(PokerHUDPanelActionTest)
{
  PokerHUD::Panel panel(hudxml, "/sequence/hud");
  panel.SetPlayed(true);
  CHECK_ASSERT(panel.SetAction("Yeah"));
  panel.SetAction("None");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/none.tga");
  CHECK_EQUAL(panel.mNameText->getText()->getText()->getText().createUTF8EncodedString(), "");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)0);
  panel.SetAction("Call");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/call.tga");
  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Call");
  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Call");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)0);
  panel.SetAction("Fold");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/fold.tga");
  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Fold");
  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Fold");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)0);
  panel.SetAction("Check");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/check.tga");
  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Check");
  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Check");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)0);
  panel.SetAction("Win");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/win.tga");
  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Win");
  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Win");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)MAF_VISIBLE_MASK);
  panel.SetAction("Lose");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/lose.tga");
  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Lose");
  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Lose");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)MAF_VISIBLE_MASK);
  panel.SetAction("Raise");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/raise.tga");
  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Raise");
  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Raise");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)0);
  panel.SetAction("Bet");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/raise.tga");
  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Bet");
  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Bet");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)0);
  panel.SetAction("Blind");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/raise.tga");
  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Blind");
  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Blind");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)0);

  panel.SetPlayed(false);
  CHECK_ASSERT(panel.SetAction("Yeah"));
  panel.SetAction("None");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/none_G.tga");
  CHECK_EQUAL(panel.mNameText->getText()->getText()->getText().createUTF8EncodedString(), "");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)0);
  panel.SetAction("Call");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/call_G.tga");
  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Call");
  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Call");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)0);
  panel.SetAction("Fold");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/fold_G.tga");
  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Fold");
  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Fold");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)0);
  panel.SetAction("Check");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/check_G.tga");
  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Check");
  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Check");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)0);
  panel.SetAction("Win");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/win_G.tga");
  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Win");
  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Win");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)MAF_VISIBLE_MASK);
  panel.SetAction("Lose");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/lose_G.tga");
  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Lose");
  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Lose");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)MAF_VISIBLE_MASK);
  panel.SetAction("Raise");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/raise_G.tga");
  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Raise");
  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Raise");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)0);
  panel.SetAction("Bet");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/raise_G.tga");
  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Bet");
  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Bet");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)0);
  panel.SetAction("Blind");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/raise_G.tga");
  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Blind");
  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Blind");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)0);
}

TEST(PokerHUDPanelDealerTest)
{
  PokerHUD::Panel panel(hudxml, "/sequence/hud");
  panel.SetDealer(true);
  panel.SetDealer(false);

  panel.SetDealer(true);
  CHECK_EQUAL(panel.mDealerSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/dealer.tga");
  panel.SetDealer(false);
  CHECK_ASSERT(panel.mDealerSprite->getCurrentFrameImage());
}

TEST(PokerHUDPanelInPositionTest)
{
  PokerHUD::Panel panel(hudxml, "/sequence/hud");
  panel.SetInPosition(true);
  panel.SetInPosition(false);

  panel.SetInPosition(true);
  CHECK_EQUAL(panel.mHeaderSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/band_low_on.tga");
  CHECK_EQUAL(panel.mChipsText->mLeft->getCurrentFrameImage()->getFileName(), srcdir+"hud/band_top_left_on.tga");
  CHECK_EQUAL(panel.mChipsText->mCenter->getCurrentFrameImage()->getFileName(), srcdir+"hud/band_top_middle_on.tga");
  CHECK_EQUAL(panel.mChipsText->mRight->getCurrentFrameImage()->getFileName(), srcdir+"hud/band_top_right_on.tga");
  CHECK_EQUAL(osg::Vec4(0.0f, 0.0f, 0.0f, 1.0f), panel.mChipsText->mText->getText()->getColor());
  CHECK_EQUAL(osg::Vec4(0.0f, 0.0f, 0.0f, 1.0f), panel.mNameText->mText->getText()->getColor());
  panel.SetInPosition(false);
  CHECK_EQUAL(panel.mHeaderSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/band_low_off.tga");
  CHECK_EQUAL(panel.mChipsText->mLeft->getCurrentFrameImage()->getFileName(), srcdir+"hud/band_top_left_off.tga");
  CHECK_EQUAL(panel.mChipsText->mCenter->getCurrentFrameImage()->getFileName(), srcdir+"hud/band_top_middle_off.tga");
  CHECK_EQUAL(panel.mChipsText->mRight->getCurrentFrameImage()->getFileName(), srcdir+"hud/band_top_right_off.tga");
  CHECK_EQUAL(osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f), panel.mChipsText->mText->getText()->getColor());
  CHECK_EQUAL(osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f), panel.mNameText->mText->getText()->getColor());
}

TEST(TextTest)
{
  PokerHUD::Panel panel(hudxml, "/sequence/hud");
  panel.SetChipAmount(100);
  CHECK_EQUAL(panel.mChipsText->getText()->getText()->getText().createUTF8EncodedString(), "1$");
  panel.SetChipAmount(200);
  CHECK_EQUAL(panel.mChipsText->getText()->getText()->getText().createUTF8EncodedString(), "2$");
  panel.SetName("dummy1");
  CHECK_EQUAL(panel.mNameText->getText()->getText()->getText().createUTF8EncodedString(), "dummy1");
  panel.SetName("dummy2");
  CHECK_EQUAL(panel.mNameText->getText()->getText()->getText().createUTF8EncodedString(), "dummy2");
}

TEST(PokerHUDPanelPlayedTest)
{
  PokerHUD::Panel panel(hudxml, "/sequence/hud");
  panel.SetPlayed(true);
  panel.SetAction("Call");
  panel.SetPlayed(false);
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/call_G.tga");
  CHECK_EQUAL(panel.mActionTextIt->getNodeMask(), (unsigned int)MAF_VISIBLE_MASK);
  CHECK_EQUAL(panel.mActionText->getNodeMask(), (unsigned int)0);
  panel.SetPlayed(true);
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/call.tga");
  CHECK_EQUAL(panel.mActionText->getNodeMask(), (unsigned int)MAF_VISIBLE_MASK);
  CHECK_EQUAL(panel.mActionTextIt->getNodeMask(), (unsigned int)0);
  panel.SetPlayed(false);
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/call_G.tga");
  CHECK_EQUAL(panel.mActionTextIt->getNodeMask(), (unsigned int)MAF_VISIBLE_MASK);
  CHECK_EQUAL(panel.mActionText->getNodeMask(), (unsigned int)0);
  panel.SetPlayed(false);
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/call_G.tga");
  CHECK_EQUAL(panel.mActionTextIt->getNodeMask(), (unsigned int)MAF_VISIBLE_MASK);
  CHECK_EQUAL(panel.mActionText->getNodeMask(), (unsigned int)0);
}

TEST(PokerHUDPanelChatTest)
{
  PokerHUD::Panel panel(hudxml, "/sequence/hud");
  CHECK_EQUAL(0u, panel.mChatText->getNodeMask());
  CHECK_EQUAL(panel.mChatText->lineCount("yeah"), (unsigned int)1);
  CHECK_EQUAL(panel.mChatText->lineCount("yeah\n"), (unsigned int)1);
  CHECK_EQUAL(panel.mChatText->lineCount("yeah\nyeah"), (unsigned int)2);
  CHECK_EQUAL(panel.mChatText->lineCount("yeah\nyeah\n"), (unsigned int)2);

  {
    CUSTOM_ASSERT(panel.mChatText->mQuad.get());
    osg::Geode* geode = dynamic_cast<osg::Geode*>(panel.mChatText->mQuad->getChild(0));
    CUSTOM_ASSERT(geode);
    osg::Geometry* geom = dynamic_cast<osg::Geometry*>(geode->getDrawable(0));
    CUSTOM_ASSERT(geom);
    const osg::BoundingBox& bbox = geom->getBound();
    CHECK_EQUAL(bbox.xMax() - bbox.xMin(), 137.0f);
    CHECK_EQUAL(bbox.yMax() - bbox.yMin(), 0.0f);
  }

  panel.SetChat("yeah");
  CHECK_EQUAL(panel.mChatText->getText()->getText()->getText().createUTF8EncodedString(), "yeah");
  panel.SetChat("yeah yeah yeah yeah yeah yeah yeah y yeah yeah yeah yeah yeah yeah yeah yeah yeah yeah yeah yeah yeah yeah");
  CHECK_EQUAL(panel.mChatText->getText()->getText()->getText().createUTF8EncodedString(), 
	      "yeah yeah yeah yeah yeah yeah yeah y yeah yeah yeah yeah yeah yeah yeah yeah yeah yeah yeah yeah yeah yeah");
 

  panel.SetChat("yeah\nyeah\nyeah\n");  
  CHECK_EQUAL(panel.mChatText->getText()->getText()->getText().createUTF8EncodedString(), 
	      "yeah\nyeah\nyeah\n");
  panel.SetChat("yeah\nyeah\nyeah");  
  CHECK_EQUAL(panel.mChatText->getText()->getText()->getText().createUTF8EncodedString(), 
	      "yeah\nyeah\nyeah");

  osg::Geode* geode = dynamic_cast<osg::Geode*>(panel.mChatText->mQuad->getChild(0));
  CUSTOM_ASSERT(geode);
  osg::Geometry* geom = dynamic_cast<osg::Geometry*>(geode->getDrawable(0));
  CUSTOM_ASSERT(geom);
  const osg::BoundingBox& bbox = geom->getBound();
  const unsigned int hudChatTextFontSize = 12;
  const unsigned int hudChatTextOffsetAndBorder = 8;;
  const float hudWidth = 137.0f;
  CHECK_EQUAL(bbox.xMax() - bbox.xMin(), hudWidth);
  CHECK_EQUAL(bbox.yMax() - bbox.yMin(), hudChatTextFontSize * 3 + hudChatTextOffsetAndBorder);
  panel.SetChat("yeah\nyeah");
  const osg::BoundingBox& bbox1 = geom->getBound();
  CHECK_EQUAL(bbox1.xMax() - bbox1.xMin(), hudWidth);
  CHECK_EQUAL(bbox1.yMax() - bbox1.yMin(), hudChatTextFontSize * 2 + hudChatTextOffsetAndBorder);
  float chatHeight = (hudChatTextFontSize * 2 + hudChatTextOffsetAndBorder);
  float from = panel.mChatText->getMatrix().getTrans().y() - chatHeight;
  float to = panel.mChatText->getMatrix().getTrans().y();

  osg::Material *mat = dynamic_cast<osg::Material*>(panel.mChatText->mQuad->getOrCreateStateSet()->getAttribute(osg::StateAttribute::MATERIAL));  
  CUSTOM_ASSERT(mat);

  CHECK_ASSERT(panel.Update(-1.0f));
  panel.Update(0.0f);
  CHECK_EQUAL(from, panel.mChatText->getMatrix().getTrans().y());
  CHECK_EQUAL(osg::Vec4(0.0f, 0.0f, 0.0f, 0.0f), mat->getDiffuse(osg::Material::FRONT_AND_BACK));
  CHECK_EQUAL(osg::Vec4(1.0f, 1.0f, 1.0f, 0.0f), panel.mChatText->getText()->getText()->getColor());
  panel.Update(1.0f);
  CHECK_EQUAL(to, panel.mChatText->getMatrix().getTrans().y());
  CHECK_EQUAL(osg::Vec4(0.0f, 0.0f, 0.0f, 0.5f), mat->getDiffuse(osg::Material::FRONT_AND_BACK));
  CHECK_EQUAL(osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f), panel.mChatText->getText()->getText()->getColor());
  panel.Update(1.0f);
  CHECK_EQUAL(to, panel.mChatText->getMatrix().getTrans().y());
  CHECK_EQUAL(osg::Vec4(0.0f, 0.0f, 0.0f, 0.5f), mat->getDiffuse(osg::Material::FRONT_AND_BACK));
  CHECK_EQUAL(osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f), panel.mChatText->getText()->getText()->getColor());
  panel.Update(4.0f);
  panel.Update(1.0f);
  CHECK_EQUAL(from, panel.mChatText->getMatrix().getTrans().y());
  CHECK_EQUAL(osg::Vec4(0.0f, 0.0f, 0.0f, 0.0f), mat->getDiffuse(osg::Material::FRONT_AND_BACK));
  CHECK_EQUAL(osg::Vec4(1.0f, 1.0f, 1.0f, 0.0f), panel.mChatText->getText()->getText()->getColor());
  panel.Update(1.0f);
  CHECK_EQUAL(from, panel.mChatText->getMatrix().getTrans().y());
  CHECK_EQUAL(osg::Vec4(0.0f, 0.0f, 0.0f, 0.0f), mat->getDiffuse(osg::Material::FRONT_AND_BACK));
  CHECK_EQUAL(osg::Vec4(1.0f, 1.0f, 1.0f, 0.0f), panel.mChatText->getText()->getText()->getColor());

  panel.SetChat("yeah\nyeah");
  panel.Update(0.0f);
  CHECK_EQUAL(from, panel.mChatText->getMatrix().getTrans().y());
  CHECK_EQUAL(osg::Vec4(0.0f, 0.0f, 0.0f, 0.0f), mat->getDiffuse(osg::Material::FRONT_AND_BACK));
  CHECK_EQUAL(osg::Vec4(1.0f, 1.0f, 1.0f, 0.0f), panel.mChatText->getText()->getText()->getColor());
  panel.Update(1.0f);
  CHECK_EQUAL(to, panel.mChatText->getMatrix().getTrans().y());
  CHECK_EQUAL(osg::Vec4(0.0f, 0.0f, 0.0f, 0.5f), mat->getDiffuse(osg::Material::FRONT_AND_BACK));
  CHECK_EQUAL(osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f), panel.mChatText->getText()->getText()->getColor());
  panel.Update(1.0f);
  CHECK_EQUAL(to, panel.mChatText->getMatrix().getTrans().y());
  CHECK_EQUAL(osg::Vec4(0.0f, 0.0f, 0.0f, 0.5f), mat->getDiffuse(osg::Material::FRONT_AND_BACK));
  CHECK_EQUAL(osg::Vec4(1.0f, 1.0f, 1.0f, 1.0f), panel.mChatText->getText()->getText()->getColor());
  panel.Update(4.0f);
  panel.Update(1.0f);
  CHECK_EQUAL(from, panel.mChatText->getMatrix().getTrans().y());
  CHECK_EQUAL(osg::Vec4(0.0f, 0.0f, 0.0f, 0.0f), mat->getDiffuse(osg::Material::FRONT_AND_BACK));
  CHECK_EQUAL(osg::Vec4(1.0f, 1.0f, 1.0f, 0.0f), panel.mChatText->getText()->getText()->getColor());
  panel.Update(1.0f);
  CHECK_EQUAL(from, panel.mChatText->getMatrix().getTrans().y());
  CHECK_EQUAL(osg::Vec4(0.0f, 0.0f, 0.0f, 0.0f), mat->getDiffuse(osg::Material::FRONT_AND_BACK));
  CHECK_EQUAL(osg::Vec4(1.0f, 1.0f, 1.0f, 0.0f), panel.mChatText->getText()->getText()->getColor());
}

TEST(PokerHUDPanelCardTest)
{
  PokerHUD::Panel panel(hudxml, "/sequence/hud");
  CHECK_EQUAL((unsigned int)2, panel.mCardsSprite.size());
  CHECK_EQUAL((unsigned int)52, panel.mCardsSprite[0]->_frames.size());
  std::vector<std::string> cards;
  cards.push_back("As");
  cards.push_back("Ac");
  panel.SetCards(cards);
  CHECK_EQUAL(panel.mCardsSprite[0]->getCurrentFrameImage()->getFileName(), srcdir+"hud/Aspades.jpg");
  CHECK_EQUAL(panel.mCardsSprite[1]->getCurrentFrameImage()->getFileName(), srcdir+"hud/Aclubs.jpg");
  panel.SetAction("Fold");
  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/fold_G.tga");
  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Fold");
  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Fold");
  CHECK_EQUAL(panel.mCardsSprite[0]->getNodeMask(), (unsigned int)0);
  CHECK_ASSERT(panel.mCardsSprite[0]->getCurrentFrameImage());
}

TEST(TextLoadTest)
{
  {
    PokerHUD::Panel::Text panelText;
    panelText.Load(hudxml, "/sequence/hud/textDummy");
    CHECK_EQUAL(panelText.mTransform->getChild(0), panelText.mText.get());
    CHECK_EQUAL(panelText.getText()->getText()->getText().createUTF8EncodedString(), "dummy");
    CHECK_EQUAL(panelText.getText()->getText()->getFont()->getFileName(), srcdir+"font/FreeSans.ttf");
    CHECK_EQUAL(panelText.getText()->getText()->getCharacterHeight(), 12);
    CHECK_EQUAL(panelText.getText()->getText()->getAlignment(), osgText::Text::RIGHT_BOTTOM);
    CHECK_EQUAL(panelText.getMatrix().getTrans(), osg::Vec3(1.0f, 2.0f, 3.0f));
    CHECK(panelText.mBackgroundEnabled == false);
  }
  {
    PokerHUD::Panel::Text panelText;
    CHECK_ASSERT(panelText.Load(hudxml, "/sequence/hud/textFailure0"));
  }
  {
    PokerHUD::Panel::Text panelText;
    CHECK_ASSERT(panelText.Load(hudxml, "/sequence/hud/textFailure1"));
  }
  {
    PokerHUD::Panel::Text panelText;
    CHECK_ASSERT(panelText.Load(hudxml, "/sequence/hud/textFailure2"));
  }
  {
    PokerHUD::Panel::Text panelText;
    CHECK_ASSERT(panelText.Load(hudxml, "/sequence/hud/textFailure3"));
  }
  {
    PokerHUD::Panel::Text panelText;
    panelText.Load(hudxml, "/sequence/hud/textBackground");
    CHECK_EQUAL(panelText.getText()->getText()->getText().createUTF8EncodedString(), "dummy");
    CHECK_EQUAL(panelText.getText()->getText()->getFont()->getFileName(), srcdir+"font/FreeSans.ttf");
    CHECK_EQUAL(panelText.getText()->getText()->getCharacterHeight(), 12);
    CHECK_EQUAL(panelText.getText()->getText()->getAlignment(), osgText::Text::RIGHT_BOTTOM);
    CHECK_EQUAL(panelText.getMatrix().getTrans(), osg::Vec3(1.0f, 2.0f, 3.0f));
    CHECK(panelText.mBackgroundEnabled);
  }
  {
    PokerHUD::Panel::Text panel;
    panel.Create("dummy", "font/VeraIt.ttf", 10);
    CHECK_ASSERT(panel.Create("dummy", "font/VeraIt.ttf", 10));
    CHECK_ASSERT(panel.Load(hudxml, "/sequence/hud/textBackground"));
  }
  {
    PokerHUD::Panel::Text panel;
    panel.Load(hudxml, "/sequence/hud/textBackground");
    CHECK_ASSERT(panel.Load(hudxml, "/sequence/hud/textBackground"));
    CHECK_ASSERT(panel.Create("dummy", "font/VeraIt.ttf", 10));
  }
  {
    PokerHUD::Panel::Text panel("dummy", "font/VeraIt.ttf", 10);
    CHECK_ASSERT(panel.Load(hudxml, "/sequence/hud/textBackground"));
    CHECK_ASSERT(panel.Create("dummy", "font/VeraIt.ttf", 10));
  }
}

TEST(TextBackgroundTest)
{
  PokerHUD::Panel::Text panelText;
  panelText.Create("dummy", "font/VeraIt.ttf", 10);
  panelText.EnableBackround(osg::Vec4(0.0f, 0.0f, 0.0f, 0.5f), 10.0f);
  CHECK_ASSERT(panelText.EnableBackround(osg::Vec4(0.0f, 0.0f, 0.0f, 0.5f), 10.0f));  
}

TEST(PokerHUDLoadCreate)
{
  PokerHUD hud;
  std::vector<osg::Vec3> empty;
  std::vector<osg::Vec3> playerCount(PokerHUD::PLAYER_COUNT);
  CHECK_ASSERT(hud.Create(empty, playerCount, 1.0f, hudxml, "/sequence/hud"));
  CHECK_ASSERT(hud.Create(playerCount, empty, 1.0f, hudxml, "/sequence/hud"));
  CHECK_ASSERT(hud.Create(playerCount, playerCount, -1.0f, hudxml, "/sequence/hud"));
  hud.Create(playerCount, playerCount, 1.0f, hudxml, "/sequence/hud");
  CHECK_ASSERT(hud.Create(playerCount, playerCount, 1.0f, hudxml, "/sequence/hud"));
  CHECK_ASSERT(hud.Load(hudxml, "/sequence/hud"));
}


TEST(PokerHUDLoadTest)
{
  PokerHUD hud;
  hud.Load(hudxml, "/sequence/hud");
  std::vector<osg::Vec3>& from = hud.mPositionFrom; 
  std::vector<osg::Vec3>& to = hud.mPositionTo;
  CHECK_EQUAL(PokerHUD::PLAYER_COUNT, from.size());
  CHECK_EQUAL(PokerHUD::PLAYER_COUNT, to.size());
  CHECK_EQUAL(10.0f, hud.mTimeToInterpolate);
}


TEST(PokerHUDseatToPositionIndex)
{
    for (unsigned int meIndex = 0; meIndex < PokerHUD::PLAYER_COUNT; ++meIndex)
      {
	for (unsigned int seatIndex = 0; seatIndex < PokerHUD::PLAYER_COUNT; ++seatIndex)
	  {
	    unsigned int rIndex = PokerHUD::seatToPositionIndex(meIndex, seatIndex);
	    int espectedIndex = seatIndex - meIndex;
	    if (espectedIndex < 0)
	      espectedIndex += PokerHUD::PLAYER_COUNT;
	    CHECK_EQUAL((unsigned int)espectedIndex, rIndex);
	  }
      }
}

TEST(PokerHUDTest)
{
  std::vector<osg::Vec3> from(PokerHUD::PLAYER_COUNT); 
  std::vector<osg::Vec3> to(PokerHUD::PLAYER_COUNT); 
  for (unsigned int i = 0; i < PokerHUD::PLAYER_COUNT; ++i)
    {
      from[i] = osg::Vec3(i * 100, 0.0f, 0.0f);
      to[i] = osg::Vec3(i * 100, 100.0f, 0.0f);
    }

  PokerHUD hud(from, to, 1.0f, hudxml, "/sequence/hud"); 
  CUSTOM_ASSERT(hud.mPanels.size() == PokerHUD::PLAYER_COUNT);
  CUSTOM_ASSERT(hud.mPositionFrom.size() == PokerHUD::PLAYER_COUNT);
  CUSTOM_ASSERT(hud.mPositionTo.size() == PokerHUD::PLAYER_COUNT);
  for (unsigned int i = 0; i < PokerHUD::PLAYER_COUNT; ++i)
    CHECK(NULL != hud.mPanels[i].get());
  for (unsigned int i = 0; i < PokerHUD::PLAYER_COUNT; ++i)
    CHECK_EQUAL((unsigned int)0, hud.mPanels[i]->getNodeMask());

  hud.EnablePanel(0);
  CHECK(hud.IsPanelEnabled(0));
  CHECK_EQUAL((unsigned int)MAF_VISIBLE_MASK, hud.mPanels[0]->getNodeMask());
  CHECK_EQUAL((unsigned int)MAF_VISIBLE_MASK, hud.mPanels[0]->getNodeMask());
  hud.DisablePanel(0);
  CHECK(!hud.IsPanelEnabled(0));
  CHECK_EQUAL((unsigned int)0, hud.mPanels[0]->getNodeMask());
  CHECK_EQUAL((unsigned int)0, hud.mPanels[0]->getNodeMask());
  CHECK_ASSERT(hud.EnablePanel(42));
  CHECK_ASSERT(hud.DisablePanel(42));

  CHECK_ASSERT(hud.Show(44));
  CHECK_ASSERT(hud.Hide(44));

  for (unsigned int meIndex = 0; meIndex < PokerHUD::PLAYER_COUNT; ++meIndex)
    {
      hud.Show(meIndex);
      CHECK_EQUAL(true, hud.mMoving);
      for (unsigned int seatIndex = 0; seatIndex < PokerHUD::PLAYER_COUNT; ++seatIndex)
	{
	  CHECK_EQUAL(0u, hud.mPanels[seatIndex]->mChatText->getNodeMask());
	  CHECK_EQUAL(from[PokerHUD::seatToPositionIndex(meIndex, seatIndex)], hud.mPanels[seatIndex]->mPosition);
	}
      for (unsigned int seatIndex = 0; seatIndex < PokerHUD::PLAYER_COUNT; ++seatIndex)
	hud.EnablePanel(seatIndex);
      while(hud.mMoving)
	{
	  for (unsigned int seatIndex = 0; seatIndex < PokerHUD::PLAYER_COUNT; ++seatIndex)
	    hud.DisablePanel(seatIndex);
	  hud.UpdatePosition(0.1f, meIndex);
	  for (unsigned int seatIndex = 0; seatIndex < PokerHUD::PLAYER_COUNT; ++seatIndex)
	    hud.EnablePanel(seatIndex);
	}
      CHECK_EQUAL(false, hud.mMoving);
      for (unsigned int seatIndex = 0; seatIndex < PokerHUD::PLAYER_COUNT; ++seatIndex)
	{
	  CHECK_EQUAL((unsigned int)MAF_VISIBLE_MASK, hud.mPanels[seatIndex]->mChatText->getNodeMask());
	  CHECK_EQUAL(to[PokerHUD::seatToPositionIndex(meIndex, seatIndex)], hud.mPanels[seatIndex]->mPosition);
	}
      hud.Hide(meIndex);
      CHECK_EQUAL(true, hud.mMoving);
      for (unsigned int seatIndex = 0; seatIndex < PokerHUD::PLAYER_COUNT; ++seatIndex)
	{
	  CHECK_EQUAL((unsigned int)MAF_VISIBLE_MASK, hud.mPanels[seatIndex]->mChatText->getNodeMask());
	  CHECK_EQUAL(to[PokerHUD::seatToPositionIndex(meIndex, seatIndex)], hud.mPanels[seatIndex]->mPosition);
	}
      for (unsigned int seatIndex = 0; seatIndex < PokerHUD::PLAYER_COUNT; ++seatIndex)
	hud.DisablePanel(seatIndex);
      while(hud.mMoving)
	{
	  for (unsigned int seatIndex = 0; seatIndex < PokerHUD::PLAYER_COUNT; ++seatIndex)
	    hud.EnablePanel(seatIndex);
	  hud.UpdatePosition(0.1f, meIndex);
	  for (unsigned int seatIndex = 0; seatIndex < PokerHUD::PLAYER_COUNT; ++seatIndex)
	    hud.DisablePanel(seatIndex);
	}
      CHECK_EQUAL(false, hud.mMoving);
      for (unsigned int seatIndex = 0; seatIndex < PokerHUD::PLAYER_COUNT; ++seatIndex)
	{
	  CHECK_EQUAL(0u, hud.mPanels[seatIndex]->mChatText->getNodeMask());
	  CHECK_EQUAL(from[PokerHUD::seatToPositionIndex(meIndex, seatIndex)], hud.mPanels[seatIndex]->mPosition);
	}
      
      for (unsigned int meIndex = 0; meIndex < PokerHUD::PLAYER_COUNT; ++meIndex)
	{      
	  hud.UpdatePosition(0.0f, meIndex);
	  for (unsigned int seatIndex = 0; seatIndex < PokerHUD::PLAYER_COUNT; ++seatIndex)
	    {
	      CHECK_EQUAL(from[PokerHUD::seatToPositionIndex(meIndex, seatIndex)], hud.mPanels[seatIndex]->mPosition);
	    }
	}
    }
}

TEST(PokerHUDDealerChangeToSeat)
{
  PokerHUD hud;
  hud.Load(hudxml, "/sequence/hud");
  for (unsigned int i = 0; i < PokerHUD::PLAYER_COUNT; ++i)
    {
      hud.EnablePanel(i);
    }
  for (unsigned int dealerSeat = 0; dealerSeat < PokerHUD::PLAYER_COUNT; ++dealerSeat)
    {
      {
	hud.DealerChangeToSeat(dealerSeat);
	for (unsigned int seatIndex = 0; seatIndex < PokerHUD::PLAYER_COUNT; ++seatIndex)
	  {
	    unsigned int panelIndex = seatIndex;
	    if (seatIndex == dealerSeat)
	      {
		CHECK_EQUAL(hud.mPanels[panelIndex]->mDealerSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/dealer.tga");
	      }	  
	    else
	      {	      
		CHECK_ASSERT(hud.mPanels[panelIndex]->mDealerSprite->getCurrentFrameImage());
	      }
	  }
      }
    }
}

TEST(PokerHUDPositionChangeToSeat)
{
  PokerHUD hud;
  hud.Load(hudxml, "/sequence/hud");
  for (unsigned int i = 0; i < PokerHUD::PLAYER_COUNT; ++i)
    hud.EnablePanel(i);
  for (unsigned int positionSeat = 0; positionSeat < PokerHUD::PLAYER_COUNT; ++positionSeat)
    {
      hud.PositionChangeToSeat(positionSeat);
      for (unsigned int seatIndex = 0; seatIndex < PokerHUD::PLAYER_COUNT; ++seatIndex)
	{
	  unsigned int panelIndex = seatIndex;
	  if (seatIndex == positionSeat)
	    {
	      CHECK_EQUAL(hud.mPanels[panelIndex]->mHeaderSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/band_low_on.tga");
	    }	  
	  else
	    {
	      CHECK_EQUAL(hud.mPanels[panelIndex]->mHeaderSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/band_low_off.tga");
	    }
	}
    }
}

TEST(PokerHUDPlayerArriveLeave)
{
  PokerHUD hud;
  hud.Load(hudxml, "/sequence/hud");
  CHECK_ASSERT(hud.PlayerArrive(11, "aminche"));
  CHECK_ASSERT(hud.PlayerLeave(11));
  for (unsigned int i = 0; i < PokerHUD::PLAYER_COUNT; ++i)
    {
      std::ostringstream oss;
      oss << "player" << i;
      hud.PlayerArrive(i, oss.str());
      
      unsigned int panelIndex = i;
      CHECK_EQUAL((unsigned int)MAF_VISIBLE_MASK, hud.mPanels[panelIndex]->getNodeMask());
      CHECK_EQUAL(oss.str(), hud.mPanels[panelIndex]->mNameText->getText()->getText()->getText().createUTF8EncodedString());
      hud.PlayerLeave(i);
      CHECK_EQUAL("", hud.mPanels[panelIndex]->mNameText->getText()->getText()->getText().createUTF8EncodedString());
    }
}

TEST(PokerHUDPlayerAction)
{
  PokerHUD hud;
  hud.Load(hudxml, "/sequence/hud");
  CHECK_ASSERT(hud.PlayerAction(0, "Fold"));
  CHECK_ASSERT(hud.PlayerAction(11, "Fold"));
  for (unsigned int i = 0; i < PokerHUD::PLAYER_COUNT; ++i)
    {
      hud.PlayerArrive(i, "ActionMan");
      hud.PlayerAction(i, "Fold");
      hud.PlayerPlayed(i, true);
      unsigned int panelIndex = i;
      
      CHECK_EQUAL(true, hud.mPanels[panelIndex]->mPlayed);
      CHECK_EQUAL("Fold", hud.mPanels[panelIndex]->mAction);
      CHECK_EQUAL(hud.mPanels[panelIndex]->mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/fold.tga");
      CHECK_EQUAL(hud.mPanels[panelIndex]->mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Fold");
      CHECK_EQUAL(hud.mPanels[panelIndex]->mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Fold");
      CHECK_EQUAL(hud.mPanels[panelIndex]->mCardsSprite[0]->getNodeMask(), (unsigned int)0);
      hud.PlayerPlayed(i, false);      
      CHECK_EQUAL(false, hud.mPanels[panelIndex]->mPlayed);
      CHECK_EQUAL(hud.mPanels[panelIndex]->mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/fold_G.tga");
      
      hud.PlayerAction(i, "Check");
      CHECK_EQUAL("Check", hud.mPanels[panelIndex]->mAction);
      hud.PlayerAction(i, "Call");
      CHECK_EQUAL("Call", hud.mPanels[panelIndex]->mAction);
      hud.PlayerAction(i, "Win");
      CHECK_EQUAL("Win", hud.mPanels[panelIndex]->mAction);
      hud.PlayerAction(i, "Lose");
      CHECK_EQUAL("Lose", hud.mPanels[panelIndex]->mAction);
      CHECK_ASSERT(hud.PlayerAction(i, "Yeah"));
    }
}

TEST(PokerHUDChipAmountChanged)
{
  PokerHUD hud;
  hud.Load(hudxml, "/sequence/hud");
  CHECK_ASSERT(hud.PlayerChipAmountChanged(0, 1));
  CHECK_ASSERT(hud.PlayerChipAmountChanged(11, 1));
  for (unsigned int i = 0; i < PokerHUD::PLAYER_COUNT; ++i)
    {
      hud.PlayerArrive(i, "ChipMan");
      hud.PlayerChipAmountChanged(i, 1);
      unsigned int panelIndex = i;
      CHECK_EQUAL((unsigned int)1, hud.mPanels[panelIndex]->mChipAmount);
      CHECK_EQUAL(hud.mPanels[panelIndex]->mChipsText->getText()->getText()->getText().createUTF8EncodedString(), "0.01$");
    }
}

TEST(PokerHUDSetCards)
{
  PokerHUD hud;
  hud.Load(hudxml, "/sequence/hud");
  std::vector<std::string> cards;
  cards.push_back("As");
  cards.push_back("Ac");
  CHECK_ASSERT(hud.PlayerSetCards(0, cards));
  CHECK_ASSERT(hud.PlayerSetCards(11, cards));
  for (unsigned int i = 0; i < PokerHUD::PLAYER_COUNT; ++i)
    {
      hud.PlayerArrive(i, "CardMan");
      hud.PlayerSetCards(i, cards);
      unsigned int panelIndex = i;
      CHECK_EQUAL(hud.mPanels[panelIndex]->mCardsSprite[0]->getCurrentFrameImage()->getFileName(), srcdir+"hud/Aspades.jpg");
      CHECK_EQUAL(hud.mPanels[panelIndex]->mCardsSprite[1]->getCurrentFrameImage()->getFileName(), srcdir+"hud/Aclubs.jpg"); 
    }
}

TEST(PokerHUDPlayerChat)
{
  PokerHUD hud;
  hud.Load(hudxml, "/sequence/hud");
  CHECK_ASSERT(hud.PlayerChat(0, "salut les aminches"));
  CHECK_ASSERT(hud.PlayerChat(11, "salut les aminches"));
  for (unsigned int i = 0; i < PokerHUD::PLAYER_COUNT; ++i)
    {
      hud.PlayerArrive(i, "ChatMan");
      hud.PlayerChat(i, "salut les aminches");
      unsigned int panelIndex = i;
      CHECK_EQUAL(hud.mPanels[panelIndex]->mChatText->getText()->getText()->getText().createUTF8EncodedString(), "salut les aminches");
    }
}

TEST(PokerHUDNewTurn)
{
  PokerHUD hud;
  hud.Load(hudxml, "/sequence/hud");
  for (unsigned int i = 0; i < PokerHUD::PLAYER_COUNT; ++i)
    {
      hud.PlayerArrive(i, "Folder");
      hud.PlayerAction(i, "Fold");
      hud.PlayerPlayed(i, true);
    }
  hud.NewTurn();
  for (unsigned int i = 0; i < PokerHUD::PLAYER_COUNT; ++i)
    {
      unsigned int panelIndex = i;
      CHECK_EQUAL(false, hud.mPanels[panelIndex]->mPlayed);
    }
}

TEST(PokerHUDLazyInstanciation)
{
  {
    PokerHUD hud1(hudxml, "/sequence/hud");
    PokerHUD hud2;
    hud2.Load(hudxml, "/sequence/hud");
    CHECK_EQUAL(hud1.mT, hud2.mT);
    CHECK_EQUAL(hud1.mMoving, hud2.mMoving);
    CHECK_EQUAL(hud1.mWay, hud2.mWay);
    CHECK_EQUAL(hud1.mTimeToInterpolate, hud2.mTimeToInterpolate);
    CHECK_EQUAL(hud1.mPositionFrom.size(), hud2.mPositionFrom.size());
    for (unsigned int i = 0; i < hud1.mPositionFrom.size(); ++i)
      CHECK_EQUAL(hud1.mPositionFrom[i], hud2.mPositionFrom[i]);
    CHECK_EQUAL(hud1.mPositionTo.size(), hud2.mPositionTo.size());
    for (unsigned int i = 0; i < hud1.mPositionTo.size(); ++i)
      CHECK_EQUAL(hud1.mPositionTo[i], hud2.mPositionTo[i]);
    CHECK_EQUAL(hud1.mPanels.size(), hud2.mPanels.size());
  }
}


TEST(PokerHUDDataDir)
{
  {
    PokerHUD hud;
    hud.Load(hudxml, "/sequence/hud", PokerHUD::DEFAULT_WIDTH, PokerHUD::DEFAULT_HEIGHT, "data/");
    CHECK_EQUAL(srcdir+"data/hud/band_low_off.tga", hud.mPanels[0]->mHeaderSprite->getCurrentFrameImage()->getFileName());
  }
  {
    PokerHUD::Panel panel(hudxml, "/sequence/hud", PokerHUD::DEFAULT_WIDTH, PokerHUD::DEFAULT_HEIGHT, "data/");
    CHECK_EQUAL(srcdir+"data/hud/band_low_off.tga", panel.mHeaderSprite->getCurrentFrameImage()->getFileName());
  }
  {
    PokerHUD::Panel::Text text;
    text.Load(hudxml, "/sequence/hud/textChips", "data/");
    CHECK_EQUAL(text.getText()->getText()->getFont()->getFileName(), srcdir+"data/font/FreeSans.ttf");
  }
}


bool gPokerHUDDestructorCalled = false;
struct PokerHUDMockup : PokerHUD
{
  ~PokerHUDMockup()
  {
    gPokerHUDDestructorCalled = true;
  }
};
TEST(PokerHUDPacketControllerCreation)
{
  CHECK_EQUAL(false, gPokerHUDDestructorCalled);
  {
    PokerHUD* hud = new PokerHUDMockup();
    PokerHUDController controller(hud);
    CHECK_EQUAL(hud, controller.mHUD.get());
    PokerHUDController controller2;
    CHECK(NULL == controller2.mHUD.get());
    controller2.Create(hud);
    CHECK_EQUAL(controller.mHUD.get(), controller2.mHUD.get());
    CHECK_ASSERT(controller2.Create(hud));
    CHECK_ASSERT(PokerHUDController controller3(NULL));
  }
  CHECK(gPokerHUDDestructorCalled);
}

TEST(MAFPacketTest)
{
  MAFPacket packet;
  CHECK_EQUAL("", packet.GetType());
  CHECK_EQUAL(0u, packet.mMembers.size());
  int i;
  CHECK_ASSERT(packet.GetMember("salut", i));
  std::string type("MY_TYPE");
  packet.SetType(type);
  CHECK_EQUAL(type, packet.GetType());
  std::string member("my_member");
  int value = 42;
  packet.SetMember(member, value);
  int resultGetMember = -1;
  packet.GetMember(member, resultGetMember);
  CHECK(-1 != resultGetMember);
  CHECK_EQUAL(value, resultGetMember);
}

TEST(PacketPlayerArriveLeave)
{  
  std::map<int, unsigned int> serial2seat;
  PokerHUD* hud = new PokerHUD();
  hud->Load(hudxml, "/sequence/hud");  
  unsigned int me = 42;
  PokerHUDController controller(hud);

  MAFPacket playerArrive;
  playerArrive.SetType("POKER_PLAYER_ARRIVE");
  for (unsigned int seat = 0; seat < 4; ++seat)
  {
    playerArrive.SetMember("serial", me + seat);
    std::ostringstream oss;
    oss << "player" << seat;
    std::string name(oss.str());
    playerArrive.SetMember("name", name);
    playerArrive.SetMember("seat", seat);
    controller.PythonAccept(playerArrive, serial2seat);
  }
  
  CHECK(hud->IsPanelEnabled(1));
  CHECK(hud->IsPanelEnabled(2));
  CHECK(hud->IsPanelEnabled(3));
  CHECK(!hud->IsPanelEnabled(4));
  CHECK_EQUAL("player0", hud->mPanels[0]->mNameText->getText()->getText()->getText().createUTF8EncodedString());
  CHECK_EQUAL("player1", hud->mPanels[1]->mNameText->getText()->getText()->getText().createUTF8EncodedString());
  CHECK_EQUAL("player2", hud->mPanels[2]->mNameText->getText()->getText()->getText().createUTF8EncodedString());
  CHECK_EQUAL("player3", hud->mPanels[3]->mNameText->getText()->getText()->getText().createUTF8EncodedString());

  
  MAFPacket playerLeave;
  playerLeave.SetType("POKER_PLAYER_LEAVE");
  playerLeave.SetMember("serial", 43);
  playerLeave.SetMember("seat", 1);
  controller.PythonAccept(playerLeave, serial2seat);
  CHECK(!hud->IsPanelEnabled(1));
  playerLeave.SetType("POKER_PLAYER_LEAVE");
  playerLeave.SetMember("serial", 42);
  playerLeave.SetMember("seat", 0);
  controller.PythonAccept(playerLeave, serial2seat);
}

TEST(PacketDealer)
{
  std::map<int, unsigned int> serial2seat;
  PokerHUD* hud = new PokerHUD();
  hud->Load(hudxml, "/sequence/hud");  
  unsigned int me = 42;
  PokerHUDController controller(hud);

  MAFPacket playerArrive;
  playerArrive.SetType("POKER_PLAYER_ARRIVE");
  for (unsigned int seat = 0; seat < 4; ++seat)
  {
    int serial = me + seat;
    serial2seat[serial] = seat;
    playerArrive.SetMember("serial", serial);
    std::ostringstream oss;
    oss << "player" << seat;
    std::string name(oss.str());
    playerArrive.SetMember("name", name);
    playerArrive.SetMember("seat", seat);
    controller.PythonAccept(playerArrive, serial2seat);
  }

  MAFPacket packetDealer;
  unsigned int dealerSeat = 0;
  packetDealer.SetType("POKER_DEALER");
  packetDealer.SetMember("dealer", dealerSeat);
  controller.PythonAccept(packetDealer, serial2seat);
  for (unsigned int panelIndex = 0; panelIndex < PokerHUD::PLAYER_COUNT; ++panelIndex)
    {
      if (panelIndex == dealerSeat)
	{
	  CHECK_EQUAL(hud->mPanels[panelIndex]->mDealerSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/dealer.tga");
	}
      else
	{
	  CHECK_ASSERT(hud->mPanels[panelIndex]->mDealerSprite->getCurrentFrameImage());
	}
    }
  ++dealerSeat;
  packetDealer.SetMember("dealer", dealerSeat);
  controller.PythonAccept(packetDealer, serial2seat);
  for (unsigned int panelIndex = 0; panelIndex < PokerHUD::PLAYER_COUNT; ++panelIndex)
    {
      if (panelIndex == dealerSeat)
	{
	  CHECK_EQUAL(hud->mPanels[panelIndex]->mDealerSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/dealer.tga");
	}
      else
	{
	  CHECK_ASSERT(hud->mPanels[panelIndex]->mDealerSprite->getCurrentFrameImage());
	}
    }
}

TEST(PokerActionPacket)
{
  std::map<int, unsigned int> serial2seat;
  PokerHUD* hud = new PokerHUD();
  hud->Load(hudxml, "/sequence/hud");  
  unsigned int me = 42;
  PokerHUDController controller(hud);

  MAFPacket playerArrive;
  playerArrive.SetType("POKER_PLAYER_ARRIVE");
  for (unsigned int seat = 0; seat < 4; ++seat)
  {
    int serial = me + seat;
    serial2seat[serial] = seat;
    playerArrive.SetMember("serial", serial);
    std::ostringstream oss;
    oss << "player" << seat;
    std::string name(oss.str());
    playerArrive.SetMember("name", name);
    playerArrive.SetMember("seat", seat);
    controller.PythonAccept(playerArrive, serial2seat);
  }

  MAFPacket action;
  bool betIsARaise = false;
  for (unsigned int seat = 0; seat < 4; ++seat)
    {
      hud->PlayerPlayed(seat, true);
      //       action.SetMember("serial", 66);
      //       action.SetType("POKER_FOLD");
      //       CHECK_ASSERT(controller.PythonAccept(action, serial2seat));      
      
      action.SetMember("serial", me + seat);
      PokerHUD::Panel& panel = *(hud->mPanels[seat].get());

      action.SetType("POKER_FOLD");
      controller.PythonAccept(action, serial2seat);
      CHECK_EQUAL(panel.mAction, "Fold");
      CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/fold.tga");
      CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Fold");
      CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Fold");

      action.SetType("POKER_CHECK");
      controller.PythonAccept(action, serial2seat);
      CHECK_EQUAL(panel.mAction, "Check");
      CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/check.tga");
      CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Check");
      CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Check");

      action.SetType("POKER_RAISE");
      action.SetMember("amount", 101);
      controller.PythonAccept(action, serial2seat);
      if (betIsARaise)
	{
	  CHECK_EQUAL(panel.mAction, "Raise");
	  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/raise.tga");
	  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Raise 1.01$");
	  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Raise 1.01$");
	}
      else
	{
	  CHECK_EQUAL(panel.mAction, "Bet");
	  CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/raise.tga");
	  CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Bet 1.01$");
	  CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Bet 1.01$");
	}
      betIsARaise = true;

      action.SetType("POKER_CALL");
      action.SetMember("amount", 100);
      controller.PythonAccept(action, serial2seat);
      CHECK_EQUAL(panel.mAction, "Call");
      CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/call.tga");
      CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Call");
      CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Call");
	
      action.SetType("POKER_BLIND");
      action.SetMember("amount", 102);
      controller.PythonAccept(action, serial2seat);
      CHECK_EQUAL(panel.mAction, "Blind");
      CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/raise.tga");
      CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Blind 1.02$");
      CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Blind 1.02$");


      //action.SetType("POKER_RAISE");
      //controller.PythonAccept(action, serial2seat);

    }
}

TEST(PokerPositionPacket)
{
  std::map<int, unsigned int> serial2seat;
  PokerHUD* hud = new PokerHUD();
  hud->Load(hudxml, "/sequence/hud");  
  unsigned int me = 42;
  PokerHUDController controller(hud);
  MAFPacket playerArrive;
  playerArrive.SetType("POKER_PLAYER_ARRIVE");
  for (unsigned int seat = 0; seat < 4; ++seat)
  {
    int serial = me + seat;
    serial2seat[serial] = seat;
    playerArrive.SetMember("serial", serial);
    std::ostringstream oss;
    oss << "player" << seat;
    std::string name(oss.str());
    playerArrive.SetMember("name", name);
    playerArrive.SetMember("seat", seat);
    controller.PythonAccept(playerArrive, serial2seat);
  }

  for (unsigned int seatInPosition = 0; seatInPosition < 4; ++seatInPosition)
    {
      MAFPacket packet;  
      packet.SetType("POKER_POSITION");
      int serial = me + seatInPosition;
      packet.SetMember("serial", serial);
      controller.PythonAccept(packet, serial2seat);
      
      for (unsigned int i = 0; i < 4; ++i)
	{
	  PokerHUD::Panel& panel = *(hud->mPanels[i].get());
	  if (i == seatInPosition)
	    {
	      CHECK_EQUAL(panel.mHeaderSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/band_low_on.tga");
	    }
	  else
	    {
	      CHECK_EQUAL(panel.mHeaderSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/band_low_off.tga");
	    }
	}
    }
}

TEST(PokerPlayedPacket)
{
  std::map<int, unsigned int> serial2seat;
  PokerHUD* hud = new PokerHUD();
  hud->Load(hudxml, "/sequence/hud");  
  unsigned int me = 42;
  PokerHUDController controller(hud);
  MAFPacket playerArrive;
  playerArrive.SetType("POKER_PLAYER_ARRIVE");
  for (unsigned int seat = 0; seat < 4; ++seat)
  {
    int serial = me + seat;
    serial2seat[serial] = seat;
    playerArrive.SetMember("serial", serial);
    std::ostringstream oss;
    oss << "player" << seat;
    std::string name(oss.str());
    playerArrive.SetMember("name", name);
    playerArrive.SetMember("seat", seat);
    controller.PythonAccept(playerArrive, serial2seat);
  }

  MAFPacket packet;
  for (unsigned int seat = 0; seat < 4; ++seat)    
    {
      int serial = me + seat;
      packet.SetMember("serial", serial);
      packet.SetType("POKER_FOLD");
      controller.PythonAccept(packet, serial2seat);
    }

  packet.SetType("POKER_END_ROUND");
  controller.PythonAccept(packet, serial2seat);
  
  for (unsigned int seat = 0; seat < 4; ++seat)    
    {
      PokerHUD::Panel& panel = *(hud->mPanels[seat].get());
      CHECK_EQUAL(false, panel.mPlayed);
      CHECK_EQUAL(srcdir+"hud/fold_G.tga", panel.mActionSprite->getCurrentFrameImage()->getFileName());
    }

  for (unsigned int seatInPosition = 0; seatInPosition < 4; ++seatInPosition)
    {
      MAFPacket packet;  
      packet.SetType("POKER_POSITION");
      int serial = me + seatInPosition;
      packet.SetMember("serial", serial);
      controller.PythonAccept(packet, serial2seat);      
      for (unsigned int i = 0; i < 4; ++i)
	{
	  PokerHUD::Panel& panel = *(hud->mPanels[i].get());
	  if (i == seatInPosition)
	    {
	      CHECK_EQUAL(true, panel.mPlayed);
	      CHECK_EQUAL(srcdir+"hud/none.tga", panel.mActionSprite->getCurrentFrameImage()->getFileName());
	    }	  
	  else if (i > seatInPosition)
	    {
	      CHECK_EQUAL(false, panel.mPlayed);
	      CHECK_EQUAL(srcdir+"hud/fold_G.tga", panel.mActionSprite->getCurrentFrameImage()->getFileName());
	    }
	  else if (i < seatInPosition)
	    {
	      CHECK_EQUAL(true, panel.mPlayed);
	      CHECK_EQUAL(srcdir+"hud/check.tga", panel.mActionSprite->getCurrentFrameImage()->getFileName());
	    }
	}
      packet.SetType("POKER_CHECK");
      controller.PythonAccept(packet, serial2seat);
    }

  {
    MAFPacket packet;
    packet.SetType("POKER_START");
    controller.PythonAccept(packet, serial2seat);
    for (unsigned int seat = 0; seat < 4; ++seat)    
      {
	PokerHUD::Panel& panel = *(hud->mPanels[seat].get());
	CHECK_EQUAL(false, panel.mPlayed);
	CHECK_EQUAL(srcdir+"hud/none_G.tga", panel.mActionSprite->getCurrentFrameImage()->getFileName());
    }    
  }
}

TEST(PokerPlayerChipsPacket)
{
  std::map<int, unsigned int> serial2seat;
  PokerHUD* hud = new PokerHUD();
  hud->Load(hudxml, "/sequence/hud");  
  unsigned int me = 42;
  PokerHUDController controller(hud);
  MAFPacket playerArrive;
  playerArrive.SetType("POKER_PLAYER_ARRIVE");
  for (unsigned int seat = 0; seat < 4; ++seat)
  {
    int serial = me + seat;
    serial2seat[serial] = seat;
    playerArrive.SetMember("serial", serial);
    std::ostringstream oss;
    oss << "player" << seat;
    std::string name(oss.str());
    playerArrive.SetMember("name", name);
    playerArrive.SetMember("seat", seat);
    controller.PythonAccept(playerArrive, serial2seat);
  }

  for (unsigned int seat = 0; seat < 4; ++seat)
  {  
    MAFPacket packet;
    int serial = me + seat;
    packet.SetMember("serial", serial);
    unsigned int money = seat * 100;
    packet.SetMember("money", seat*100);
    packet.SetMember("bet", std::vector<int>(0));
    packet.SetType("POKER_PLAYER_CHIPS");
    controller.PythonAccept(packet, serial2seat);
    PokerHUD::Panel& panel = *(hud->mPanels[seat].get());
    std::ostringstream oss;
    oss << float(money/100) << "$";
    CHECK_EQUAL(oss.str(), panel.mChipsText->getText()->getText()->getText().createUTF8EncodedString());
  }
}

TEST(PokerPlayerWinCardsPacket)
{
  std::map<int, unsigned int> serial2seat;
  PokerHUD* hud = new PokerHUD();
  hud->Load(hudxml, "/sequence/hud");  
  unsigned int me = 42;
  PokerHUDController controller(hud);

  MAFPacket playerArrive;
  playerArrive.SetType("POKER_PLAYER_ARRIVE");
  for (unsigned int seat = 0; seat < 4; ++seat)
  {
    int serial = me + seat;
    serial2seat[serial] = seat;
    playerArrive.SetMember("serial", serial);
    std::ostringstream oss;
    oss << "player" << seat;
    std::string name(oss.str());
    playerArrive.SetMember("name", name);
    playerArrive.SetMember("seat", seat);
    controller.PythonAccept(playerArrive, serial2seat);
  }
  
  MAFPacket action;
  action.SetMember("serial", me + 3);
  action.SetType("POKER_FOLD");
  controller.PythonAccept(action, serial2seat);


  MAFPacket packet;
  std::vector<int> serials;
  for (unsigned int seat = 0; seat < 2; ++seat)
    {
      int serial = me + seat;
      serials.push_back(serial);
    }

  packet.SetMember("serials", serials);
  packet.SetType("POKER_WIN");
  controller.PythonAccept(packet, serial2seat);  

  for (unsigned int seat = 0; seat < 4; ++seat)
    hud->PlayerPlayed(seat, true);


  for (unsigned int seat = 0; seat < 2; ++seat)
    {
      PokerHUD::Panel& panel = *(hud->mPanels[seat].get());
      CHECK_EQUAL(panel.mAction, "Win");
      CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/win.tga");
      CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Win");
      CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Win");
      CHECK_ASSERT(panel.mCardsSprite[0]->getCurrentFrameImage());
      CHECK_ASSERT(panel.mCardsSprite[1]->getCurrentFrameImage());

    }

    {
      unsigned int seat = 2;
      PokerHUD::Panel& panel = *(hud->mPanels[seat].get());
      CHECK_EQUAL(panel.mAction, "Lose");
      CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/lose.tga");
      CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Lose");
      CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Lose");
      CHECK_ASSERT(panel.mCardsSprite[0]->getCurrentFrameImage());
      CHECK_ASSERT(panel.mCardsSprite[1]->getCurrentFrameImage());
    }


    {
      unsigned int seat = 3;
      PokerHUD::Panel& panel = *(hud->mPanels[seat].get());
      CHECK_EQUAL(panel.mAction, "Fold");
      CHECK_EQUAL(panel.mActionSprite->getCurrentFrameImage()->getFileName(), srcdir+"hud/fold.tga");
      CHECK_EQUAL(panel.mActionText->getText()->getText()->getText().createUTF8EncodedString(), "Fold");
      CHECK_EQUAL(panel.mActionTextIt->getText()->getText()->getText().createUTF8EncodedString(), "Fold");
      CHECK_ASSERT(panel.mCardsSprite[0]->getCurrentFrameImage());
      CHECK_ASSERT(panel.mCardsSprite[1]->getCurrentFrameImage());
    }



  for (unsigned int seat = 0; seat < 4; ++seat)
    {
//       char* number2card[] =
// 	{
// 	  "2h","3h","4h","5h","6h","7h","8h","9h","Th","Jh","Qh","Kh","Ah",
// 	  "2d","3d","4d","5d","6d","7d","8d","9d","Td","Jd","Qd","Kd","Ad",
// 	  "2c","3c","4c","5c","6c","7c","8c","9c","Tc","Jc","Qc","Kc","Ac",
// 	  "2s","3s","4s","5s","6s","7s","8s","9s","Ts","Js","Qs","Ks","As",
// 	};
      packet.SetType("POKER_PLAYER_CARDS");
      std::vector<int> cards;
      cards.push_back(seat);
      cards.push_back(seat+13);
      packet.SetMember("cards", cards);
      int serial = me + seat;
      packet.SetMember("serial", serial);
      controller.PythonAccept(packet, serial2seat);
      PokerHUD::Panel& panel = *(hud->mPanels[seat].get());
      std::ostringstream card0;
      std::ostringstream card1;
      card0 << seat + 2 << "hearts.jpg";
      card1 << seat + 2 << "diamonds.jpg";
      CHECK_EQUAL(srcdir + "hud/" + card0.str(), panel.mCardsSprite[0]->getCurrentFrameImage()->getFileName());
      CHECK_EQUAL(srcdir + "hud/" + card1.str(), panel.mCardsSprite[1]->getCurrentFrameImage()->getFileName());
    }
}

TEST(PokerChatPacket)
{
  std::map<int, unsigned int> serial2seat;
  PokerHUD* hud = new PokerHUD();
  hud->Load(hudxml, "/sequence/hud");  
  unsigned int me = 42;
  PokerHUDController controller(hud);

  MAFPacket playerArrive;
  playerArrive.SetType("POKER_PLAYER_ARRIVE");
  for (unsigned int seat = 0; seat < 4; ++seat)
  {
    int serial = me + seat;
    serial2seat[serial] = seat;
    playerArrive.SetMember("serial", serial);
    std::ostringstream oss;
    oss << "player" << seat;
    std::string name(oss.str());
    playerArrive.SetMember("name", name);
    playerArrive.SetMember("seat", seat);
    controller.PythonAccept(playerArrive, serial2seat);
  }

  for (unsigned int seat = 0; seat < 4; ++seat)
  {  
    MAFPacket packet;
    int serial = me + seat;
    packet.SetMember("serial", serial);
    std::ostringstream oss;
    oss << "hi!\nI'm player " << serial;
    packet.SetMember("money", seat*100);
    packet.SetMember("message", oss.str());
    packet.SetType("POKER_CHAT");
    controller.PythonAccept(packet, serial2seat);
    PokerHUD::Panel& panel = *(hud->mPanels[seat].get());
    CHECK_EQUAL(oss.str(), panel.mChatText->getText()->getText()->getText().createUTF8EncodedString());
  }
}

TEST(PokerHUDTextBackground)
{
  {
    PokerHUD::Panel::Text text;
    text.Load(hudxml, "/sequence/hud/textChips");


    CHECK_EQUAL(osgText::Text::RIGHT_TOP, text.mText->getText()->getAlignment());
    CHECK(text.mFramedBackgroundEnabled == true);
    CHECK_EQUAL(srcdir + "hud/band_top_left_off.tga", text.mLeft->getCurrentFrameImage()->getFileName());
    CHECK_EQUAL(srcdir + "hud/band_top_right_off.tga", text.mRight->getCurrentFrameImage()->getFileName());
    CHECK_EQUAL(srcdir + "hud/band_top_middle_off.tga", text.mCenter->getCurrentFrameImage()->getFileName());
    CHECK_EQUAL(osg::Vec3(0.0, 3.0, 0.0), text.mTransform->getMatrix().getTrans());
    
    text.SetText("salut les aminches");
    osgText::Text* osgText = text.getText()->getText();
    CUSTOM_ASSERT(osgText);
    const osg::BoundingBox& bbox = osgText->getBound();
    int textWidth = (int)(bbox.xMax() - bbox.xMin());
    int textLeft = -textWidth-14;
    int textRight = 0;
    int textCenter = -textWidth;
    CHECK_EQUAL(textLeft,  text.mLeft->getMatrix().getTrans().x());
    CHECK_EQUAL(textRight, text.mRight->getMatrix().getTrans().x());
    CHECK_EQUAL(textCenter, text.mCenter->getMatrix().getTrans().x());
    CHECK_EQUAL((unsigned int)textWidth, text.mCenter->getCurrentFrame()->_w);
    CHECK_EQUAL("salut les aminches", text.getText()->getText()->getText().createUTF8EncodedString());
  }
  {
    PokerHUD::Panel::Text text;
    text.Load(hudxml, "/sequence/hud/textName");
    CHECK_EQUAL(osg::Vec3(0.0, 0.0, 0.0), text.mTransform->getMatrix().getTrans());    
  }
}

TEST(FormatChips)
{
  CHECK_EQUAL("1.01$", PokerHUD::Panel::FormatChipAmount(101));
  CHECK_EQUAL("1$", PokerHUD::Panel::FormatChipAmount(100));
  CHECK_EQUAL("12.50$", PokerHUD::Panel::FormatChipAmount(1250));
  CHECK_EQUAL("1000000$", PokerHUD::Panel::FormatChipAmount(100000000));
}

TEST(PokerHUDWidthHeight)
{
  {
    PokerHUD hud;
    hud.Load(hudxml, "/sequence/hud");  
    for (unsigned int i = 0; i < hud.mPanels.size(); ++i)
      {
	CHECK_EQUAL(PokerHUD::DEFAULT_WIDTH, hud.mPanels[i]->mWidth);
	CHECK_EQUAL(PokerHUD::DEFAULT_HEIGHT, hud.mPanels[i]->mHeight);
      }
  }
  {
    PokerHUD hud;
    hud.Load(hudxml, "/sequence/hud", 1280, 1024);
    for (unsigned int i = 0; i < hud.mPanels.size(); ++i)
      {
	CHECK_EQUAL(1280u, hud.mPanels[i]->mWidth);
	CHECK_EQUAL(1024u, hud.mPanels[i]->mHeight);
      }
  }
}

struct PokerHUDFixture
{
  std::map<int, unsigned int> _serial2seat;
  osg::ref_ptr<PokerHUDController> _controller;
  bool _g_criticalIsCalled;
  PokerHUDFixture() : _controller(NULL), _g_criticalIsCalled(false)
  {
    CustomAssert::Instance().SetHandler(CustomAssert::DefaultHandler);  
    PokerHUD* hud = new PokerHUD();
    hud->Load(hudxml, "/sequence/hud");
    _controller = new PokerHUDController(hud);
    MAFPacket playerArrive;
    playerArrive.SetType("POKER_PLAYER_ARRIVE");
    unsigned int me = 42;
    for (unsigned int seat = 0; seat < 4; ++seat)
      {
	int serial = me + seat;
	_serial2seat[serial] = seat;
	playerArrive.SetMember("serial", me + seat);
	std::ostringstream oss;
	oss << "player" << seat;
	std::string name(oss.str());
	playerArrive.SetMember("name", name);
	playerArrive.SetMember("seat", seat);
	_controller->PythonAccept(playerArrive, _serial2seat);
      }
    g_log_set_handler(NULL, (GLogLevelFlags)(G_LOG_LEVEL_CRITICAL), g_criticalHandler, this);
  }
  static void g_criticalHandler(const gchar *log_domain,
				GLogLevelFlags log_level,
				const gchar *message,
				gpointer user_data)
  {
    CUSTOM_ASSERT(user_data);
    PokerHUDFixture* fixture = (PokerHUDFixture*)user_data;
    fixture->_g_criticalIsCalled = true;
  }
};

TEST_FIXTURE(PokerHUDFixture, BugPokerHUDPanelSetCardsRT1123GNA7095)
{
  MAFPacket packet;
  packet.SetType("POKER_PLAYER_CARDS");
  std::vector<int> cards;
  int serial = (*_serial2seat.begin()).first;
  cards.push_back(255);
  cards.push_back(13);
  packet.SetMember("cards", cards);
  packet.SetMember("serial", serial);
  _controller->PythonAccept(packet, _serial2seat);
  CHECK(_g_criticalIsCalled);
}


void testPokerHUDPanelTextWithBackground()
{
   osgViewer viewer;
   viewer.Create();  
   PokerHUD::Panel::Text* text = new PokerHUD::Panel::Text();
   text->Load(hudxml, "/sequence/hud/textChips");
   text->setMatrix(osg::Matrix::translate(500, 100, 0));
   viewer.GetRoot()->addChild(text);
   std::string textStr = "salut les aminches";
   text->mCenter->setCurrentFrame("InPosition");
   text->SetText(textStr);
   //text->SetText(textStr);
   while(viewer.GetRunning())
    {      
      viewer.Update();

      const SDL_Event* event = viewer.GetLastEvent();
      if (event)
	{
	  if (event->type == SDL_KEYDOWN)
	    {
	      static bool inPosition = false;
	      if (inPosition)
		text->mCenter->setCurrentFrame("OutPosition");
	      else
		text->mCenter->setCurrentFrame("InPosition");
	      inPosition = !inPosition;
	      //textStr += "a";
	      //text->SetText(textStr);
	    }
	}
      
      viewer.Render();
    }
   viewer.Destroy();
}

void testPokerHUD()
{
  unsigned int width = 1650;
  unsigned int height = 1024;
  osgViewer viewer;
  viewer.Create(width, height);

  PokerHUD* hud = new PokerHUD();
  hud->Load("/home/proppy/underware/examples/poker/conf/client.xml", "/sequence/hud", width, height, "/home/proppy/data.proprio/");
  //hud->Load(hudxml, "/sequence/hud");  
  unsigned int me = 42;
  PokerHUDController controller(hud);
  viewer.GetRoot()->addChild(hud);

  std::map<int, unsigned int> serial2seat;
  MAFPacket playerArrive;
  playerArrive.SetType("POKER_PLAYER_ARRIVE");
  for (unsigned int seat = 0; seat < 10; ++seat)
  {
    int serial = me + seat;
    serial2seat[serial] = seat;
    playerArrive.SetMember("serial", serial);
    std::ostringstream oss;
    oss << "player" << seat;
    std::string name(oss.str());
    playerArrive.SetMember("name", name);
    playerArrive.SetMember("seat", seat);
    controller.PythonAccept(playerArrive, serial2seat);
    //hud->EnablePanel(seat);
  }

  for (unsigned int seat = 0; seat < 5; ++seat)
  {  
    MAFPacket packet;
    int serial = me + seat;
    packet.SetMember("serial", serial);
    unsigned int money = seat * 100;
    packet.SetMember("money", money);
    packet.SetMember("bet", std::vector<int>(0));
    packet.SetType("POKER_PLAYER_CHIPS");
    controller.PythonAccept(packet, serial2seat);
  }
  for (unsigned int seat = 5; seat < 10; ++seat)
  {  
    MAFPacket packet;
    int serial = me + seat;
    packet.SetMember("serial", serial);
    unsigned int money = seat * 100000000;
    packet.SetMember("money", money);
    packet.SetMember("bet", std::vector<int>(0));
    packet.SetType("POKER_PLAYER_CHIPS");
    controller.PythonAccept(packet, serial2seat);
  }

  unsigned int seatInPosition = 5;
    {
      MAFPacket packet;  
      packet.SetType("POKER_POSITION");
      int serial = me + seatInPosition;
      packet.SetMember("serial", serial);
      controller.PythonAccept(packet, serial2seat);
    }
    {
      MAFPacket packetDealer;
      unsigned int dealerSeat = 1;
      packetDealer.SetType("POKER_DEALER");
      packetDealer.SetMember("dealer", dealerSeat);
      controller.PythonAccept(packetDealer, serial2seat);
    }
    
    {
      MAFPacket packet;
      packet.SetType("POKER_PLAYER_CARDS");
      std::vector<int> cards;
      cards.push_back(0);
      cards.push_back(13);
      packet.SetMember("cards", cards);
      int serial = me + seatInPosition;
      packet.SetMember("serial", serial);
      controller.PythonAccept(packet, serial2seat);
    }

    {
      MAFPacket packet;
      packet.SetType("POKER_PLAYER_CARDS");
      std::vector<int> cards;
      cards.push_back(0);
      cards.push_back(13);
      packet.SetMember("cards", cards);
      int serial = me + 2;
      packet.SetMember("serial", serial);
      controller.PythonAccept(packet, serial2seat);
    }

  while(viewer.GetRunning())
    {      
      viewer.Update();

      const SDL_Event* event = viewer.GetLastEvent();
      if (event)
	{
	  if (event->type == SDL_KEYDOWN)
	    {
	      if (event->key.keysym.sym == SDLK_w)
		{
		  static bool dowin = true;
		  if (dowin)
		    {
		      MAFPacket packet;
		      std::vector<int> serials;
		      int serial = me + seatInPosition;
		      serials.push_back(serial);
		      
		      packet.SetMember("serials", serials);
		      packet.SetType("POKER_WIN");
		      controller.PythonAccept(packet, serial2seat);        
		    }
		  else
		    {
		      MAFPacket packet;
		      
		      packet.SetType("POKER_POSITION");
		      int serial = me + seatInPosition;
		      packet.SetMember("serial", serial);
		      controller.PythonAccept(packet, serial2seat);

		      
		      packet.SetType("POKER_CALL");
		      controller.PythonAccept(packet, serial2seat);

		      packet.SetMember("message", "salut les aminches\nsalut les aminches\n");
		      packet.SetType("POKER_CHAT");
		      controller.PythonAccept(packet, serial2seat);
		    }
		  dowin = !dowin;
		}
	      else if (event->key.keysym.sym == SDLK_s)
		{
		  static bool show = false;
		  if (show == false)
		    hud->Show(0);
		  else
		    hud->Hide(0);
		  show = !show;
		}
	      else if (event->key.keysym.sym == SDLK_c)
		{
		  MAFPacket action;
		  int serial = me + seatInPosition;
		  action.SetMember("serial", serial);
		  action.SetType("POKER_CALL");
		  controller.PythonAccept(action, serial2seat);
		  {
		    ++seatInPosition;
		    if (seatInPosition == 10)
		      seatInPosition = 0;
		    MAFPacket packet;  
		    packet.SetType("POKER_POSITION");
		    int serial = me + seatInPosition;
		    packet.SetMember("serial", serial);
		    controller.PythonAccept(packet, serial2seat);
		  }
		}
	      else if (event->key.keysym.sym == SDLK_b)
		{
		  MAFPacket action;
		  int serial = me + seatInPosition;
		  action.SetMember("serial", serial);
		  action.SetMember("amount", 100);
		  action.SetType("POKER_BLIND");
		  controller.PythonAccept(action, serial2seat);
		  {
		    ++seatInPosition;
		    if (seatInPosition == 10)
		      seatInPosition = 0;
		    MAFPacket packet;  
		    packet.SetType("POKER_POSITION");
		    int serial = me + seatInPosition;
		    packet.SetMember("serial", serial);
		    controller.PythonAccept(packet, serial2seat);
		  }
		}
	      else if (event->key.keysym.sym == SDLK_h)
		{
		  MAFPacket action;
		  int serial = me + seatInPosition;
		  action.SetMember("serial", serial);
		  action.SetType("POKER_CHECK");
		  controller.PythonAccept(action, serial2seat);
		  {
		    ++seatInPosition;
		    if (seatInPosition == 10)
		      seatInPosition = 0;
		    MAFPacket packet;  
		    packet.SetType("POKER_POSITION");
		    int serial = me + seatInPosition;
		    packet.SetMember("serial", serial);
		    controller.PythonAccept(packet, serial2seat);
		  }
		}
	      else if (event->key.keysym.sym == SDLK_r)
		{
		  MAFPacket action;
		  int serial = me + seatInPosition;
		  action.SetMember("serial", serial);
		  {
		    action.SetMember("amount", 100);
		  }

		  action.SetType("POKER_RAISE");
		  controller.PythonAccept(action, serial2seat);
		  {
		    ++seatInPosition;
		    if (seatInPosition == 10)
		      seatInPosition = 0;
		    MAFPacket packet;  
		    packet.SetType("POKER_POSITION");
		    int serial = me + seatInPosition;
		    packet.SetMember("serial", serial);
		    controller.PythonAccept(packet, serial2seat);
		  }
		}
	      else if (event->key.keysym.sym == SDLK_t)
		{
		  MAFPacket action;
		  int serial = me + seatInPosition;
		  action.SetMember("serial", serial);
		  action.SetMember("message", "salut les aminches\nsalut les aminches\n");
		  action.SetType("POKER_CHAT");
		  controller.PythonAccept(action, serial2seat);
		  {
		    ++seatInPosition;
		    if (seatInPosition == 10)
		      seatInPosition = 0;
		    MAFPacket packet;  
		    packet.SetType("POKER_POSITION");
		    int serial = me + seatInPosition;
		    packet.SetMember("serial", serial);
		    controller.PythonAccept(packet, serial2seat);
		  }
		}
	    }
	}
      hud->UpdatePosition(viewer.GetDeltaTime(), 0);
      viewer.Render();
    }
  viewer.Destroy();
}


#ifdef WIN32
#undef main
#include <windows.h>
#include <mmsystem.h>
#include <conio.h>
#endif

int main(int argc, char **argv)
{
  fetchsrcdir();
  //testPokerHUD();  
  CustomAssert::Instance().SetHandler(reportCustomAssert);  
  return UnitTest::RunAllTests();
}
