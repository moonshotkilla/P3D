/*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Johan Euphrosine <johan@mekensleep.com>
 *
 */

#include <UnitTest++.h>
#include <ReportAssert.h>
#include <ugame/Bubble>
#include <CustomAssert/CustomAssert.h>

TEST(osgbubblePatchBaseSetTexture)
{
  osgbubble::PatchBase pb;
  CHECK_ASSERT(pb.setTexture("not-existing-file.tga"));
}

TEST(osgbubbleTailInit)
{
	osgbubble::Tail tail;
	tail.init();
	CHECK( tail.getStateSet() );
}

TEST(osgbubbleTailInitGiveNoTexture)
{
	osgbubble::Tail tail;
	tail.init();
	CHECK_EQUAL((const osg::StateAttribute*)NULL, tail.getStateSet()->getTextureAttribute(0, osg::StateAttribute::TEXTURE));
}

TEST(osgbubblePatchBase16bitsIndices)
{
	osgbubble::PatchBase pbase;
	unsigned short tristrip[] = { 0, 1, 2, 3 };
	pbase.addTriStrip(tristrip, 4);

	osg::DrawElementsUShort *pset = dynamic_cast<osg::DrawElementsUShort*>(pbase.getPrimitiveSet(0));
	CHECK(pset);
	CHECK_EQUAL(pset->size(), 4u);
	CHECK_EQUAL((*pset)[0], 0);
	CHECK_EQUAL((*pset)[1], 1);
	CHECK_EQUAL((*pset)[2], 2);
	CHECK_EQUAL((*pset)[3], 3);
}

void reportCustomAssert()
{
  const char* description = CustomAssert::Instance().GetDescription();
  const char* file = CustomAssert::Instance().GetFile();
  int line = CustomAssert::Instance().GetLine();
  UnitTest::ReportAssert(description, file, line);
}

int main()
{
  CustomAssert::Instance().SetHandler(reportCustomAssert);
  return UnitTest::RunAllTests();
}

