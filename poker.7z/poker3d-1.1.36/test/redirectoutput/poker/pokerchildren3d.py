class PokerChildXwnc:
    pass
class PokerChildInterface:
    pass
CHILD_INTERFACE_READY = 0
CHILD_INTERFACE_GONE = 1
