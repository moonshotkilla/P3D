class PokerSkin3D:
    pass
