 /*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include "CustomAssert/CustomAssert.h"
#include <UnitTest++.h>
#include <ReportAssert.h>
#include <iostream>
#include <maf/audio.h>
#include <maf/data.h>
#include <osg/Group>
#include <osgAL/SoundRoot>
#include <osgViewer.h>
#include <osg/MatrixTransform>
#include <osg/Projection>

#include "osgAL/SoundNode"
#include "osgAL/SoundRoot"
#include "osgAL/SoundManager"
#include "osgAL/SoundState"

std::string srcdir;
void fetchsrcdir()
{
  char* srcdirPtr = getenv("srcdir");
  if (srcdirPtr)
  {
    srcdir = std::string(srcdirPtr) + "/";
    if (srcdir == "./")
      srcdir = "";
  }
}

TEST(audioInitialized)
{
  CHECK_EQUAL(MAFAudioDevice::GetInstance()->SetSoundEnabled(true), true);
  CHECK_EQUAL(MAFAudioDevice::GetInstance()->IsSoundDeviceValid(), true);

  osgViewer viewer;
  viewer.Create();

	osg::Group* root = viewer.GetRoot();
	osgAL::SoundRoot* sound_root = new osgAL::SoundRoot;
	root->addChild(sound_root);

	MAFAudioDataWAV* md = new MAFAudioDataWAV;
	CUSTOM_ASSERT(md->LoadAudio(srcdir + "test.wav"));

	MAFAudioModel* audio_model = new MAFAudioModel;
	audio_model->SetName("test");

	audio_model->SetData(md);
	audio_model->SetGain(0.9);
	audio_model->SetAmbient(true);
	audio_model->SetSoundEvent(false);
	osg::ref_ptr<MAFAudioController> audio_controller = new MAFAudioController;
	audio_controller->SetModel(audio_model);
	audio_controller->Init();
	audio_controller->AttachTo(root);
	audio_controller->Play();

	for (int i = 0 ; i < 1000; i++) {
		viewer.Update();
		viewer.Render();
	}
  viewer.Destroy();
	MAFAudioDevice::GetInstance()->DeInitializeDevice();
	std::cout << "Played a sound with audio sound on\n";
}

TEST(audioInitializedEvent)
{
  CHECK_EQUAL(MAFAudioDevice::GetInstance()->SetSoundEnabled(true), true);
  CHECK_EQUAL(MAFAudioDevice::GetInstance()->IsSoundDeviceValid(), true);

  osgViewer viewer;
  viewer.Create();

	osg::Group* root = viewer.GetRoot();
	osgAL::SoundRoot* sound_root = new osgAL::SoundRoot;
	root->addChild(sound_root);

	MAFAudioDataWAV* md = new MAFAudioDataWAV;
	CUSTOM_ASSERT(md->LoadAudio(srcdir + "test.wav"));

	MAFAudioModel* audio_model = new MAFAudioModel;
	audio_model->SetName("test");

	audio_model->SetData(md);
	audio_model->SetGain(0.9);
	audio_model->SetAmbient(true);
	audio_model->SetSoundEvent(true);
	osg::ref_ptr<MAFAudioController> audio_controller = new MAFAudioController;
	audio_controller->SetModel(audio_model);
	audio_controller->Init();
	audio_controller->AttachTo(root);
	audio_controller->Play();

	for (int i = 0 ; i < 1000; i++) {
		viewer.Update();
		viewer.Render();
	}
  viewer.Destroy();
	MAFAudioDevice::GetInstance()->DeInitializeDevice();
	std::cout << "Played event sound with audio sound on\n";
}

TEST(audioUnInitialized)
{
  CHECK_EQUAL(MAFAudioDevice::GetInstance()->SetSoundEnabled(false), false);
	MAFAudioDevice::GetInstance()->DeInitializeDevice();

  osgViewer viewer;
  viewer.Create();

	osg::Group* root = viewer.GetRoot();
	osgAL::SoundRoot* sound_root = new osgAL::SoundRoot;
	root->addChild(sound_root);

	MAFAudioDataWAV* md = new MAFAudioDataWAV;
	CUSTOM_ASSERT(md->LoadAudio(srcdir + "test.wav"));

	MAFAudioModel* audio_model = new MAFAudioModel;
	audio_model->SetName("test");

	audio_model->SetData(md);
	audio_model->SetGain(0.9);
	audio_model->SetAmbient(true);
	audio_model->SetSoundEvent(false);
	osg::ref_ptr<MAFAudioController> audio_controller = new MAFAudioController;
	audio_controller->SetModel(audio_model);
	audio_controller->Init();
	audio_controller->AttachTo(root);
	audio_controller->Play();

	for (int i = 0 ; i < 1000; i++) {
		viewer.Update();
		viewer.Render();
	}
  viewer.Destroy();
	MAFAudioDevice::GetInstance()->DeInitializeDevice();
	std::cout << "Played a sound with audio sound off\n";
}

void reportCustomAssert()
{
  std::string description = CustomAssert::Instance().GetDescription();
  std::string function = CustomAssert::Instance().GetFunction();
  std::string file = CustomAssert::Instance().GetFile();
  int line  = CustomAssert::Instance().GetLine();
  UnitTest::ReportAssert(description.c_str(), (function+" "+file).c_str(), line);
}

#undef main

int main()
{
  fetchsrcdir();
  CustomAssert::Instance().SetHandler(reportCustomAssert);
  return UnitTest::RunAllTests();
}
