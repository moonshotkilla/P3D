 /*
 *
 * Copyright (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Cedric Pinson <cpinson@freesheep.org>
 *
 */

#include <UnitTest++.h>
#include <ReportAssert.h>
#include <math.h>
#include <iostream>
#include <openalpp/audioenvironment.h>
#include <openalpp/listener.h>
#include <openalpp/source.h>

extern std::string srcdir;

TEST(DivisionByZero)
{
  float nan = acos(2.0f);

  openalpp::Listener* listener = new openalpp::Listener();
  listener->setPosition(nan, nan, nan);
  listener->setVelocity(nan, nan, nan);
  listener->select();

  openalpp::Source* source = new openalpp::Source(srcdir + "test.wav");
  source->setPosition(nan, nan, nan);
  source->setVelocity(nan, nan, nan);
  source->play();

  sleep(1);
}

#if 0
static std::string srcdir;
void fetchsrcdir()
{
  char* srcdirPtr = getenv("srcdir");
  if (srcdirPtr)
  {
    srcdir = std::string(srcdirPtr) + "/";
    if (srcdir == "./")
      srcdir = "";
  }
}

int main()
{
  fetchsrcdir();
  return UnitTest::RunAllTests();
}
#endif
