/* (C) 2004-2006 Mekensleep
 *
 *	Mekensleep
 *	24 rue vieille du temple
 *	75004 Paris
 *       licensing@mekensleep.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * Authors:
 *  Igor Kravtchenko <igor@tsarevitch.org>
 *
 */

#include <UnitTest++.h>

#include <osg/Geometry>
#include <osg/MatrixTransform>
#include <osgDB/Registry>
#include <ugame/text.h>

static std::string g_srcDir = "./";

TEST(TestFramedTextPrimitiveSets)
{
	osg::ref_ptr<osg::Image> img =  new osg::Image();
	osg::ref_ptr<UGAMEFramedText> text = new UGAMEFramedText("", img.get(), NULL);

	osg::Geometry *geom = text->getGeometry();
	CHECK(geom);

	int nb_pset = geom->getNumPrimitiveSets();
	CHECK_EQUAL(3, nb_pset);

	osg::DrawElementsUShort *pset0 = dynamic_cast<osg::DrawElementsUShort*>(geom->getPrimitiveSet(0));
	CHECK(pset0);
	osg::DrawElementsUShort *pset1 = dynamic_cast<osg::DrawElementsUShort*>(geom->getPrimitiveSet(1));
	CHECK(pset1);
	osg::DrawElementsUShort *pset2 = dynamic_cast<osg::DrawElementsUShort*>(geom->getPrimitiveSet(2));
	CHECK(pset2);
}

#ifdef WIN32
#undef main
#endif

#ifndef WIN32
void fetchsrcdir()
{
	char* srcdirPtr = getenv("srcdir");
	if (srcdirPtr)
	{
		//beware "." is always first in PathList
		osgDB::Registry::instance()->getDataFilePathList().push_front(srcdirPtr);
		g_srcDir = std::string(srcdirPtr) + "/";
		if (g_srcDir == "./")
			g_srcDir = "";
	}
};
#endif

int	main()
{
#ifndef WIN32
  fetchsrcdir();
#endif
  return UnitTest::RunAllTests();
}
