/*
*
* Copyright (C) 2004-2006 Mekensleep
*
*	Mekensleep
*	24 rue vieille du temple
*	75004 Paris
*       licensing@mekensleep.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*
* Authors:
*  Igor Kravtchenko <igor@ozos.net>
*
*/

#define _USE_MATH_DEFINES

#include "undercal3dStdAfx.h"

#include "cal3d/corekeyframe.h"

static void quat2euler(const CalQuaternion &_src, float *_hpb)
{
	float test = _src.x*_src.y + _src.z*_src.w;
	if (test > 0.499f) { // singularity at north pole
		_hpb[0] = 2 * atan2(_src.x, _src.w);
		//_hpb[1] = M_PI_2;
		_hpb[2] = 0;
		return;
	}
	if (test < -0.499f) { // singularity at south pole
		_hpb[0] = -2 * atan2(_src.x, _src.w);
		//_hpb[1] = -M_PI_2;
		_hpb[2] = 0;
		return;
	}
	float sqx = _src.x*_src.x;
	float sqy = _src.y*_src.y;
	float sqz = _src.z*_src.z;

	_hpb[0] = atan2(2*_src.y*_src.w-2*_src.x*_src.z , 1 - 2*sqy - 2*sqz);
	_hpb[1] = asin(2*test);
	_hpb[2] = atan2(2*_src.x*_src.w-2*_src.y*_src.z , 1 - 2*sqx - 2*sqz)	;
}

static bool match(const CalVector &_vec1, const CalQuaternion &_quat1,
									const CalVector &_vec2, const CalQuaternion &_quat2,
									float _thresholdPos = 0.01f,
									float _thresholdRot = 0.0005f)
{
	if ( fabs(_vec1.x - _vec2.x) > _thresholdPos)
		return false;
	if ( fabs(_vec1.y - _vec2.y) > _thresholdPos)
		return false;
	if ( fabs(_vec1.z - _vec2.z) > _thresholdPos)
		return false;

	float hpb1[3];
	float hpb2[3];
	quat2euler(_quat1, hpb1);
	quat2euler(_quat2, hpb2);

	if ( fabs(hpb1[0] - hpb2[0]) > _thresholdRot)
		return false;
	if ( fabs(hpb1[1] - hpb2[1]) > _thresholdRot)
		return false;
	if ( fabs(hpb1[2] - hpb2[2]) > _thresholdRot)
		return false;

	return true;
}

static bool canOptimizeBetween(CalCoreTrack *_track, int _iLeftKey, int _iRightKey, float _posThreshold, float _angleThreshold)
{
	if (_iRightKey >= _track->getCoreKeyframeCount())
		return false;

	CalCoreKeyframe *leftKey = _track->getCoreKeyframe(_iLeftKey);
	CalCoreKeyframe *rightKey = _track->getCoreKeyframe(_iRightKey);

	float leftTime = leftKey->getTime();
	float rightTime = rightKey->getTime();

	const CalVector &leftPos = leftKey->getTranslation();
	const CalQuaternion &leftRot = leftKey->getRotation();

	const CalVector &rightPos = rightKey->getTranslation();
	const CalQuaternion &rightRot = rightKey->getRotation();

	if (_iRightKey == _iLeftKey)
		return false;

	if (_iRightKey == _iLeftKey+1) {
		if (!match(leftPos, leftRot, rightPos, rightRot, _posThreshold, _angleThreshold))
			return false;
		return true;
	}

	for (int i = _iLeftKey+1; i < _iRightKey; i++) {
		CalCoreKeyframe *key = _track->getCoreKeyframe(i);
		float time = key->getTime();

		const CalVector &idealPos = key->getTranslation();
		const CalQuaternion &idealRot = key->getRotation();

		float blend = (time - leftTime) / (rightTime - leftTime);

		CalVector blendedPos = leftPos;
		blendedPos.blend(blend, rightPos);

		CalQuaternion blendedRot = leftRot;
		blendedRot.blend(blend, rightRot);

		if (!match(idealPos, idealRot, blendedPos, blendedRot, _posThreshold, _angleThreshold))
			return false;
	}
	return true;
}

CalCoreAnimation* CalReduceKeys(CalCoreAnimation *_anim, float _posThreshold, float _angleThreshold, CalReduceKeysReport *_report)
{
	CalCoreAnimation *optimizedAnim = new CalCoreAnimation();

	optimizedAnim->setFilename( _anim->getFilename());
	optimizedAnim->setName( _anim->getName());
	optimizedAnim->setDuration( _anim->getDuration());

	if (_report) {
		_report->nbKeysBefore = 0;
		_report->nbKeysAfter = 0;
	}

	std::list<CalCoreTrack *> &listTracks = _anim->getListCoreTrack();
	for (std::list<CalCoreTrack *>::iterator it = listTracks.begin(); it != listTracks.end(); ++it) {
		CalCoreTrack *coreTrack = (*it);

		int nbKeysFrame = coreTrack->getCoreKeyframeCount();

		if (nbKeysFrame < 3)
			continue;

		bool ikf[20000];
		memset(ikf, 0, sizeof ikf);

		int iLeft = 0;
		int iRight = 2;

		while(1) {

			if (iRight >= nbKeysFrame)
				break;

			int iLastOK = -1;
			while(1) {
				bool res = canOptimizeBetween(coreTrack, iLeft, iRight, _posThreshold, _angleThreshold);
				if (res) {
					iLastOK = iRight;
					iRight++;
				}
				else
					break;
			}

			ikf[iLeft] = true;
			if (iLastOK != -1)
				ikf[iLastOK] = true;

			iLeft = iRight-1;
			iRight++;
		}

		CalCoreTrack *optimizedTrack = new CalCoreTrack();
		optimizedTrack->setCoreBoneId( coreTrack->getCoreBoneId() );

		optimizedAnim->addCoreTrack(optimizedTrack);

		for (int i = 0; i < nbKeysFrame; i++) {
			if (ikf[i] == true) {
				CalCoreKeyframe *kf = coreTrack->getCoreKeyframe(i);
				optimizedTrack->addCoreKeyframe(kf);
			}
		}

		int nbAfter = optimizedTrack->getCoreKeyframeCount();
		nbAfter = nbAfter;
		if (_report) {
			_report->nbKeysBefore += nbKeysFrame;
			_report->nbKeysAfter += nbAfter;
		}
	}

	return optimizedAnim;
}
